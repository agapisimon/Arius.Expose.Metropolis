#ifndef MATERIALS_HPP
#define MATERIALS_HPP

#include <QtWidgets>
#include <QtSvg>
#include <QtOpenGL>
#include <QGLWidget>
#include <vector>
#include <GL/glu.h>
#include <GL/gl.h>
#include <time.h>
//#include <omp.h>
#include <widgets.hpp>
#include <geometry.hpp>
#include <globals.hpp>
#include <settings.hpp>

#include <fstream>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <stdio.h>
#include <QXmlSimpleReader>
#include <QDomDocument>

#include<qmath.hpp>



enum MATERIAL_TYPES
{
    MATERIAL_BASE,
    MATERIAL_PHONG,
    MATERIAL_COOK_TORRANCE,
    MATERIAL_LAMBERT,
    MATERIAL_BLINN,
    MATERIAL_COLOR,
    MATERIAL_MATCAP,
    MATERIAL_WIREFRAME,
    MATERIAL_XRAY,
};

enum MATERIAL_LAYER
{
    LAYER_AMBIENT,
    LAYER_DIFFUSE,
    LAYER_AO,
    LAYER_REFLECTION,
    LAYER_SPECULAR,
    LAYER_REFRACTION,
    LAYER_TRANSPARENCY,
    LAYER_BUMP,
    LAYER_DISPLACEMENT,
    LAYER_EMISSION,
    LAYER_WIREFRAME,
    LAYER_NORMAL,
    LAYER_COLOR,
    LAYER_FRESNEL,
};

class QBaseMaterial : public QObject
{
    Q_OBJECT

public:

    QString name;

    enum { Type = MATERIAL_BASE};

    virtual int type() const  { return Type; }

    QGLShaderProgram shaderProgram;

    QBaseMaterial(QObject * parent =0):QObject(parent)
    {

    }   
};

class QPhongMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;


    QColor color;

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    enum { Type = MATERIAL_PHONG};

    virtual int type() const  { return Type; }


    QPropertiesTreeWidget *properties;

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));

        properties->addPropertyPanel(parameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    QPhongMaterialParameters * parameters;


    QPhongMaterial(QObject * parent =0):QBaseMaterial(parent)
    {
        name = QString("Phone Material");

        parameters = new QPhongMaterialParameters;


        updateMaterial();

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateMaterial()));

        addWidgets();


        createPhongMaterial();
    }

    ~QPhongMaterial()
    {
        delete properties;
        delete parameters;
    }

    virtual void setTheme(QWidget * widget)
    {
        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st =file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

        qDebug()<<"Styles Loaded";
    }


    virtual void createPhongMaterial()
    {
        shaderProgram.removeAllShaders();

        shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/phongVertex.glsl"));

        shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/phongFragment.glsl"));


        shaderProgram.link();

    }





    virtual void bind(const QMatrix4x4 & modelViewMatrix,
                               const QMatrix4x4 & modelViewProjectionMatrix,
                               const QVector3D & centerPicking,
                               float radiusSquared)
    {
        shaderProgram.bind();
        shaderProgram.setUniformValue("modelViewMatrix", modelViewMatrix);
        shaderProgram.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
        shaderProgram.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
        shaderProgram.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
        shaderProgram.setUniformValue("radiusSquared", radiusSquared);
        shaderProgram.setUniformValue("color", color);

    }


    virtual void release()
    {
        shaderProgram.release();
    }


signals:

     void valueChanged();

private slots:


     void updateMaterial()
     {
         alpha        = parameters->alpha;
         ambient      = parameters->ambient;
         diffuse      = parameters->diffuse;
         specular     = parameters->specular;
         reflection   = parameters->reflection;
         bump         = parameters->bump;
         refraction   = parameters->refraction;
         transparency = parameters->transparency;
         emission     = parameters->emission;
     }

};

class QWireFrameMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_WIREFRAME};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QWireFrameMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
        //indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
        //edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QWireFrameMaterial()
    {

    }


    virtual void createMaterial()
    {

    }



    virtual void createWireFrameMaterial()
    {
        shaderProgram.removeAllShaders();

        shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/wireframeVertex.glsl"));
        shaderProgram.addShaderFromSourceFile(QGLShader::Geometry,QString(":/Shaders/wireframeGeometry.glsl"));
        shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/wireframeFragment.glsl"));

        shaderProgram.setGeometryInputType(GL_TRIANGLES);
        shaderProgram.setGeometryOutputType(GL_TRIANGLE_STRIP);
        shaderProgram.setGeometryOutputVertexCount(3);

        shaderProgram.link();
    }





     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }




signals:

     void valueChanged();

private slots:

};

class QXrayMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_XRAY};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QXrayMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
        //indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
        //edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QXrayMaterial()
    {

    }

    virtual void createMaterial()
    {

    }






    virtual void createXrayMaterial()
    {
        shaderProgram.removeAllShaders();

        shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/transparencyVertex.glsl"));
        shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/transparencyFragment.glsl"));

        shaderProgram.link();
    }





     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }







signals:

     void valueChanged();

private slots:

};

class QMatCapMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_MATCAP};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint matCapTexturePointer; //texture reflection

    QList<GLuint> textures;

    QMatCapMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
        //indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
        //edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QMatCapMaterial()
    {

    }


    virtual void createMaterial()
    {

    }

    virtual void createMatCapMaterial()
    {
        shaderProgram.removeAllShaders();

        QImage matCapTextClay;

        bool loaded = false;

        loaded = matCapTextClay.load(QString(":/Shaders/reflection2.png"));

        if(loaded)
        {
            matCapTextClay = QGLWidget::convertToGLFormat(matCapTextClay);

            glGenTextures( 1, &matCapTexturePointer );
            glBindTexture( GL_TEXTURE_2D, matCapTexturePointer );
            glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,matCapTextClay.width(),matCapTextClay.height(),0,GL_RGBA,GL_UNSIGNED_BYTE,matCapTextClay.bits());
            glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
            glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
        }

        shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/reflectionVertex.glsl"));
        shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/reflectionFragment.glsl"));

        shaderProgram.link();
    }


     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }







signals:

     void valueChanged();

private slots:

};

class QBlinnMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_BLINN};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QBlinnMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
        //indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
        //edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QBlinnMaterial()
    {

    }


    virtual void createMaterial()
    {

    }

    virtual void createBlinnMaterial()
    {
        shaderProgram.removeAllShaders();

        shaderProgram.link();

    }





     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }





     virtual void createXrayMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/transparencyVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/transparencyFragment.glsl"));

         shaderProgram.link();
     }

     virtual void createWireFrameMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/wireframeVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Geometry,QString(":/Shaders/wireframeGeometry.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/wireframeFragment.glsl"));

         shaderProgram.setGeometryInputType(GL_TRIANGLES);
         shaderProgram.setGeometryOutputType(GL_TRIANGLE_STRIP);
         shaderProgram.setGeometryOutputVertexCount(3);

         shaderProgram.link();
     }




signals:

     void valueChanged();

private slots:

};

class QLambertMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;


    QColor color;

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    enum { Type = MATERIAL_LAMBERT};

    virtual int type() const  { return Type; }


    QPropertiesTreeWidget *properties;

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));

        properties->addPropertyPanel(parameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    QPhongMaterialParameters * parameters;


    QLambertMaterial(QObject * parent =0):QBaseMaterial(parent)
    {
        name = QString("Phone Material");

        parameters = new QPhongMaterialParameters;


        updateMaterial();

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateMaterial()));

        addWidgets();


        createLambertMaterial();
    }

    ~QLambertMaterial()
    {
        delete properties;
        delete parameters;
    }

    virtual void setTheme(QWidget * widget)
    {
        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st =file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

        qDebug()<<"Styles Loaded";
    }


    virtual void createLambertMaterial()
    {
        shaderProgram.removeAllShaders();

        shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/lambertVertex.glsl"));

        shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/lambertFragment.glsl"));
    }





    virtual void bind()
    {
        shaderProgram.bind();

        shaderProgram.link();

    }

    virtual void setShaderParamters(QMatrix4x4 projection,
                                    QMatrix4x4 viewmatrix,
                                    QMatrix4x4 normalMatrix,
                                    QVector3D lightPos,
                                    //QVector3D lightVec,
                                    float attenuationVal,int mode = 3)
    {
        //projection, modelview, normalMat;
        shaderProgram.setUniformValue("projection", projection);
        shaderProgram.setUniformValue("modelview", viewmatrix);
        shaderProgram.setUniformValue("normalMat", normalMatrix);


        shaderProgram.setUniformValue("mode", mode);
        shaderProgram.setUniformValue("lightPos", lightPos);
        //shaderProgram.setUniformValue("lightVec", lightVec);

        shaderProgram.setUniformValue("attenuationVal", attenuationVal);
    }


    virtual void release()
    {
        shaderProgram.release();
    }


signals:

     void valueChanged();

private slots:


     void updateMaterial()
     {
         alpha        = parameters->alpha;
         ambient      = parameters->ambient;
         diffuse      = parameters->diffuse;
         specular     = parameters->specular;
         reflection   = parameters->reflection;
         bump         = parameters->bump;
         refraction   = parameters->refraction;
         transparency = parameters->transparency;
         emission     = parameters->emission;
     }

};



class QCookTorranceMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_COOK_TORRANCE};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QCookTorranceMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
        //indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
        //edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QCookTorranceMaterial()
    {

    }

    virtual void createMaterial()
    {

    }

    virtual void createCookTorranceMaterial()
    {
        shaderProgram.removeAllShaders();


        shaderProgram.link();
    }







     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }





     virtual void createXrayMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/transparencyVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/transparencyFragment.glsl"));

         shaderProgram.link();
     }

     virtual void createWireFrameMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/wireframeVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Geometry,QString(":/Shaders/wireframeGeometry.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/wireframeFragment.glsl"));

         shaderProgram.setGeometryInputType(GL_TRIANGLES);
         shaderProgram.setGeometryOutputType(GL_TRIANGLE_STRIP);
         shaderProgram.setGeometryOutputVertexCount(3);

         shaderProgram.link();
     }




signals:

     void valueChanged();

private slots:

};

class QColorMaterial : public QBaseMaterial
{
    Q_OBJECT

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;

    enum { Type = MATERIAL_COOK_TORRANCE};

    virtual int type() const  { return Type; }



     ///---------glsl acceleration-----------

    QColor color;




   // ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QColorMaterial()
    {
        //verticesBuffer  = QGLBuffer(QGLBuffer::VertexBuffer);
        //normalsBuffer   = QGLBuffer(QGLBuffer::VertexBuffer);
       // indicesBuffer   = QGLBuffer(QGLBuffer::IndexBuffer);
        //texCoordsBuffer = QGLBuffer(QGLBuffer::VertexBuffer);
       // edgesBuffer     = QGLBuffer(QGLBuffer::IndexBuffer);


    }

    ~QColorMaterial()
    {

    }

    virtual void createMaterial()
    {

    }

    virtual void createColorMaterial()
    {
        shaderProgram.removeAllShaders();


        shaderProgram.link();
    }







     //Initialize Vertex Buffer Object (VBO)
     void initVertexBufferObject()
     {
          /*
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);



         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }



         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();


         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();


         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);

         */
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         /*
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);

         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);


         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);




         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         indicesBuffer_.release();
         normalsBuffer_.release();
         verticesBuffer_.release();

         */
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {

         /*




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;


         }

          */
     }





     virtual void createXrayMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/transparencyVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/transparencyFragment.glsl"));

         shaderProgram.link();
     }

     virtual void createWireFrameMaterial()
     {
         shaderProgram.removeAllShaders();

         shaderProgram.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/wireframeVertex.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Geometry,QString(":/Shaders/wireframeGeometry.glsl"));
         shaderProgram.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/wireframeFragment.glsl"));

         shaderProgram.setGeometryInputType(GL_TRIANGLES);
         shaderProgram.setGeometryOutputType(GL_TRIANGLE_STRIP);
         shaderProgram.setGeometryOutputVertexCount(3);

         shaderProgram.link();
     }




signals:

     void valueChanged();

private slots:

};




#endif // MATERIALS_HPP
