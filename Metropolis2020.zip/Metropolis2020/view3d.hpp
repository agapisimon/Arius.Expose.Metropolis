#ifndef VIEW3D_H
#define VIEW3D_H

#include<QtWidgets>
#include<QtOpenGL>
#include<QGLWidget>
#include<GL/gl.h>
#include<GL/glu.h>
#include<scene.hpp>





class QView3D :  public QGLWidget
{
    Q_OBJECT

public:

    QSceneGraph *scenegraph;


    QSize minimumSizeHint() const
    {
        return QSize(250, 100);
    }

    QSize sizeHint() const
    {
        return QSize(width(), height());
         //return QSize(QApplication::desktop()->width(), QApplication::desktop()->height());
    }

    QView3D( QWidget * parent=0) : QGLWidget(parent)
    {
        setAcceptDrops(true);

        setWindowTitle(QString("Metroplis:"));

        //setFormat(QGLFormat(QGL::SampleBuffers));

        QGLFormat format;
        format.setVersion(4, 5);
        format.setOption(QGL::SampleBuffers);
        format.setProfile(QGLFormat::CompatibilityProfile);
        format.setSwapInterval(0);
        setFormat(format);



        scenegraph = new QSceneGraph(this,0);

        setFocusPolicy(Qt::ClickFocus);
    }

    ~QView3D()
    {
        delete scenegraph;
    }


    void initializeGL()
    {
        scenegraph->resizeViewPort();
    }

    void resizeGL(int width, int height)
    {
        scenegraph->resizeViewPort();
    }

    void paintGL()
    {
        scenegraph->drawScene();

        update();
    }



    void wheelEvent(QWheelEvent *event)
    {
        scenegraph->zoomViewPort(event);
    }

    void keyPressEvent(QKeyEvent * event)
    {
        scenegraph->keyPressEvents(event);        
    }

    void mouseDoubleClickEvent(QMouseEvent *event)
    {
        scenegraph->mouseDoubleClickEvent(event);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        scenegraph->mousePressEvents(event);
    }

    void mouseMoveEvent(QMouseEvent * event)
    {
        scenegraph->mouseMoveEvents(event);
    }

    void mouseReleaseEvent(QMouseEvent * event)
    {
        scenegraph->mouseReleaseEvents(event);        
    }

    void dragEnterEvent(QDragEnterEvent * event)
    {
        event->acceptProposedAction();

        QGLWidget::dragEnterEvent(event);
    }

    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important

        QGLWidget::dragMoveEvent(event);
    }

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if(event->mimeData()->hasText())
        {
            //addNode(event->mimeData()->text(),QCursor::pos());

            //scene()->update();

            qDebug()<<"Objects"<<event->mimeData()->text();
        }

        QGLWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {

        //scenegraph->showContextMenue();
    }

signals:

public slots:

};



#endif // VIEW3D_H
