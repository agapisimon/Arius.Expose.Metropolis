#ifndef SVGPARSER_HPP
#define SVGPARSER_HPP


/*
svg-path:
wsp* moveto-drawto-command-groups? wsp*
moveto-drawto-command-groups:
moveto-drawto-command-group
| moveto-drawto-command-group wsp* moveto-drawto-command-groups
moveto-drawto-command-group:
moveto wsp* drawto-commands?
drawto-commands:
drawto-command
| drawto-command wsp* drawto-commands
drawto-command:
closepath
| lineto
| horizontal-lineto
| vertical-lineto
| curveto
| smooth-curveto
| quadratic-bezier-curveto
| smooth-quadratic-bezier-curveto
| elliptical-arc
moveto:
( "M" | "m" ) wsp* moveto-argument-sequence
moveto-argument-sequence:
coordinate-pair
| coordinate-pair comma-wsp? lineto-argument-sequence
closepath:
("Z" | "z")
lineto:
( "L" | "l" ) wsp* lineto-argument-sequence
lineto-argument-sequence:
coordinate-pair
| coordinate-pair comma-wsp? lineto-argument-sequence
horizontal-lineto:
( "H" | "h" ) wsp* horizontal-lineto-argument-sequence
horizontal-lineto-argument-sequence:
coordinate
| coordinate comma-wsp? horizontal-lineto-argument-sequence
vertical-lineto:
( "V" | "v" ) wsp* vertical-lineto-argument-sequence
vertical-lineto-argument-sequence:
coordinate
| coordinate comma-wsp? vertical-lineto-argument-sequence
curveto:
( "C" | "c" ) wsp* curveto-argument-sequence
curveto-argument-sequence:
curveto-argument
| curveto-argument comma-wsp? curveto-argument-sequence
curveto-argument:
coordinate-pair comma-wsp? coordinate-pair comma-wsp? coordinate-pair
smooth-curveto:
( "S" | "s" ) wsp* smooth-curveto-argument-sequence
smooth-curveto-argument-sequence:
smooth-curveto-argument
| smooth-curveto-argument comma-wsp? smooth-curveto-argument-sequence
smooth-curveto-argument:
coordinate-pair comma-wsp? coordinate-pair
quadratic-bezier-curveto:
( "Q" | "q" ) wsp* quadratic-bezier-curveto-argument-sequence
quadratic-bezier-curveto-argument-sequence:
quadratic-bezier-curveto-argument
| quadratic-bezier-curveto-argument comma-wsp?
    quadratic-bezier-curveto-argument-sequence
quadratic-bezier-curveto-argument:
coordinate-pair comma-wsp? coordinate-pair
smooth-quadratic-bezier-curveto:
( "T" | "t" ) wsp* smooth-quadratic-bezier-curveto-argument-sequence
smooth-quadratic-bezier-curveto-argument-sequence:
coordinate-pair
| coordinate-pair comma-wsp? smooth-quadratic-bezier-curveto-argument-sequence
elliptical-arc:
( "A" | "a" ) wsp* elliptical-arc-argument-sequence
elliptical-arc-argument-sequence:
elliptical-arc-argument
| elliptical-arc-argument comma-wsp? elliptical-arc-argument-sequence
elliptical-arc-argument:
nonnegative-number comma-wsp? nonnegative-number comma-wsp?
    number comma-wsp flag comma-wsp? flag comma-wsp? coordinate-pair
coordinate-pair:
coordinate comma-wsp? coordinate
coordinate:
number
nonnegative-number:
integer-constant
| floating-point-constant
number:
sign? integer-constant
| sign? floating-point-constant
flag:
"0" | "1"
comma-wsp:
(wsp+ comma? wsp*) | (comma wsp*)
comma:
","
integer-constant:
digit-sequence
floating-point-constant:
fractional-constant exponent?
| digit-sequence exponent
fractional-constant:
digit-sequence? "." digit-sequence
| digit-sequence "."
exponent:
( "e" | "E" ) sign? digit-sequence
sign:
"+" | "-"
digit-sequence:
digit
| digit digit-sequence
digit:
"0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9"
wsp:
(#x20 | #x9 | #xD | #xA)
*/

#include<QtGui>
#include<QtXml>
#include<QtOpenGL>


class SVGStyle
{
public:
   float opacity;
   QString fill;//#008080;
   float fill_opacity;
   QString stroke;//#000000;
   float stroke_width;//:0.5;
   QString stroke_linecap;//:round;
   float stroke_miterlimit;//:4;
   QString stroke_dasharray;//:none;
   float stroke_dashoffset;//:0;
   float stroke_opacity;//:1"

};

class SVGPoint
{
public:
    enum Type
    {
        MOVE_POINT,
        CURVE_POINT,
        LINE_POINT,
    };

    QVector3D point;

    Type type;

    SVGPoint()
    {}

    SVGPoint(QVector3D point,Type type)
    {
        this->point = point;

        this->type =  type;

        qDebug()<<"QVector3D:"<<this->point;
    }
};

class SVGshape
{
    // d stands for path data
    // m to z stands for subshape , m stands for moveto and z is the end of shape;
    // between m and z, c stands for curve, and l stands for Line
    // e.g d = "m  c  l c l   z"

public:

    QList<QVector3D> vertices;

    QList<SVGPoint> points;

    int ID;

    SVGshape(QString m,QVector3D translate =QVector3D(0,0,0),QVector3D scale =QVector3D(0,0,0),QVector3D rotation = QVector3D(0,0,0))
    {



        QString str;

        if(m.startsWith("m")==false)
        {
            str  = QString("m")+m;
        }

        if(m.endsWith("z")==false)
        {
            str = str+QString("z");
        }

        str = str.trimmed();

        if(str.startsWith("m") ==true && str.endsWith("z") ==true)
        {
            QStringList pointsList = str.split(" ");

            int pointCount = 0;

            QString starts;

            foreach(QString p,pointsList)
            {
                //qDebug()<<"Shape Point Data:"<<p<<"\n\n";

                if(p.startsWith("m"))
                {
                    starts = QString("m");
                }
                if(p.startsWith(" "))
                {

                }
                if(p.startsWith("z"))
                {
                    starts = QString("z");
                }


                if(p.startsWith("c"))
                {
                    starts = QString("c");
                }

                if(p.startsWith("l"))
                {
                    starts = QString("l");
                }

                if(p.contains(","))
                {
                    float x = p.split(",")[0].toFloat();
                    float y = p.split(",")[1].toFloat();

                    QVector3D v(x,0,y);

                    //v += translate;

                    SVGPoint point;

                    if(starts.startsWith("m"))
                    {
                        point = SVGPoint(v,SVGPoint::MOVE_POINT );

                        points.append(point);

                        pointCount++;

                         //qDebug()<<"Point==>"<<v;

                    }

                    if(starts.startsWith("c"))
                    {
                        point = SVGPoint(v,SVGPoint::CURVE_POINT );

                        points.append(point);
                    }

                    if(starts.startsWith("l"))
                    {
                        point = SVGPoint(v,SVGPoint::LINE_POINT );

                        points.append(point);
                    }

                    pointCount++;

                    //qDebug()<<"Vector3D"<<"X"<<x<<"Y"<<y;
                }


                pointCount++;
            }
        }
    }
};

class SVGGroup
{
    // d stands for path data
    // m to z stands for subshape , m stands for moveto and z is the end of shape;
    // between m and z, c stands for curve, and l stands for Line
    // e.g d = "m  c  l c l   z"

public:

    QString pathID;

    SVGStyle style;

    QVector3D translate;
    QVector3D rotation;
    QVector3D scale;

    QList<SVGshape> shapes;

    void addshapes(QString strshapes)
    {
        QStringList list = strshapes.split("z m");

        //qDebug()<<"Shape Count:"<<list.count()<<"\n\n";

        int shapeCount = 0;

        foreach(QString m,list)
        {
            SVGshape shape(m,translate);

            shape.ID = shapeCount;

            shapes.append(shape);

            shapeCount++;
        }
    }
};

class SVGParser
{
public:

    SVGGroup svgshape;

    QVector2D polarToCartesian(float centerX,float centerY, float radius,float angleInDegrees)
    {
      float angleInRadians = (angleInDegrees-90) * PI / 180.0;

      float x =  centerX + (radius * cos(angleInRadians));
      float y =  centerY + (radius * sin(angleInRadians));

      return QVector2D(x,y);

    }

    void describeArc(float x, float y, float radius, float startAngle, float endAngle)
    {

        QVector2D start = polarToCartesian(x, y, radius, endAngle);
        QVector2D end = polarToCartesian(x, y, radius, startAngle);

        QString arcSweep = endAngle - startAngle <= 180 ? "0" : "1";

        /*
        var d = [
            "M", start.x, start.y,
            "A", radius, radius, 0, arcSweep, 0, end.x, end.y,
            "L", x,y,
            "L", start.x, start.y
        ].join(" ");

        return d;

        */
    }

    QColor hexToRGB(QString color)
    {
        color.remove("#");

        float R = ((color.toInt()>>16)&0xFF)/255.0;
        float G = ((color.toInt()>>8)&0xFF)/255.0;
        float B = ((color.toInt())&0xFF)/255.0;

        return QColor(R,G,B);
    }


    virtual void parseSVG()
    {
        QString campassFile = QString(":/Tools Icons/compass_shape1.svg");

        //QString campassFile = QString(":/Tools Icons/compass_shape.svg");

        QDomDocument doc("shapeDocument");

        QFile  file(campassFile);

        if (!file.open(QIODevice::ReadOnly))
        {
            qDebug()<<"File not loaded";

            return;
        }

        if (!doc.setContent(&file))
        {
            qDebug()<<"Contents not loaded";

            file.close();

            return;
        }

        file.close();

        QDomElement element = doc.documentElement();

        if(element.nodeName().startsWith("svg"))
        {
            QDomElement  groupElement = element.firstChildElement("g");

            QString text = groupElement.attribute("transform");

            //transform="translate(-119.50002,-274.71935)"
            //transform="translate(-10,-20) scale(2) rotate(45) translate(5,10)"
            //qDebug()<<text;

            if(text.length()>0)
            {
                text.remove("translate(");

                text.remove(")");

                svgshape.translate = QVector3D(text.split(",")[0].toFloat(),text.split(",")[1].toFloat(),0);

                qDebug()<<text<<svgshape.translate;
            }

            QDomElement n = groupElement.firstChildElement();


            while(!n.isNull())
            {
                QDomElement e = n;

                if(!e.isNull())
                {

                    if(e.tagName().startsWith("path"))
                    {
                        if(e.attribute("style").length()>0)
                        {
                            //sample style="opacity:1;fill:#008080;fill-opacity:1;stroke:#000000;stroke-width:0.5;stroke-linecap:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
                            QString text = e.attribute("style");

                            QStringList strs = text.split(";");

                            foreach(QString st,strs)
                            {
                                if(st.startsWith("opacity:"))
                                {
                                    svgshape.style.opacity = st.split(":")[1].toFloat();
                                }

                                if(st.startsWith("fill:"))
                                {
                                    svgshape.style.fill =st.split(":")[1];
                                }

                                if(st.startsWith("fill-opacity:"))
                                {
                                    svgshape.style.opacity =st.split(":")[1].toFloat();
                                }
                                if(st.startsWith("stroke:"))
                                {
                                    svgshape.style.stroke =st.split(":")[1].toFloat();
                                }

                                if(st.startsWith("stroke-width:"))
                                {
                                    svgshape.style.stroke_width =st.split(":")[1].toFloat();
                                }

                                if(st.startsWith("stroke-linecap:"))
                                {
                                    svgshape.style.stroke_linecap = st.split(":")[1];
                                }

                                if(st.startsWith("stroke-miterlimit:"))
                                {
                                    svgshape.style.stroke_miterlimit = st.split(":")[1].toFloat();
                                }

                                if(st.startsWith("stroke-dasharray:"))
                                {
                                    svgshape.style.stroke_dasharray = st.split(":")[1];
                                }

                                if(st.startsWith("stroke-dashoffset:"))
                                {
                                    svgshape.style.stroke_dashoffset = st.split(":")[1].toFloat();
                                }

                                if(st.startsWith("stroke-opacity:"))
                                {
                                    svgshape.style.stroke_opacity = st.split(":")[1].toFloat();
                                }
                            }
                        }

                        if(e.attribute("d").length()>0)
                        {
                            QString strShapes =  e.attribute("d");

                            svgshape.addshapes(strShapes);
                        }

                        if(e.attribute("id").length()>0)
                        {
                            //qDebug()<<"===>"<<e.attribute("id");

                            QString ids = e.attribute("id");

                            svgshape.pathID = ids;
                        }

                        //qDebug()<<"===>"<<e.tagName();
                    }
                }

                n = n.nextSiblingElement();
            }
        }
    }



    void drawCenter()
    {
        glDisable(GL_LIGHTING);

        glEnable(GL_DEPTH_TEST);

        if(svgshape.shapes.size()>0)
        {
            for(int i=0;i<svgshape.shapes.size();i++)
            {
                SVGshape shape=  svgshape.shapes[i];
                //SVGshape shape=  svgshape.shapes[5];

                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

                glBegin(GL_POLYGON);

                QColor color = hexToRGB(svgshape.style.fill);
                //QColor color = QColor(Qt::green);
                //qDebug()<<"Color:"<<color;

                glColor4f( color.redF(), color.greenF(), color.blueF(),svgshape.style.fill_opacity);

                for(int j=0;j<shape.points.size();j++)
                {
                    QVector3D c = shape.points[j].point;

                    glVertex3f(c.x(),c.y(),c.z());

                }

                glEnd();

                glDisable(GL_BLEND);
            }

            for(int i=0;i<svgshape.shapes.size();i++)
            {
                SVGshape shape=  svgshape.shapes[i];
                //SVGshape shape =  svgshape.shapes[5];

                //glLineWidth(svgshape.style.stroke_width);
                glLineWidth(2.0f);

                glBegin(GL_LINE_LOOP);

                QColor color = hexToRGB(svgshape.style.stroke);
                //QColor color = QColor(Qt::green);
                //qDebug()<<"Color:"<<color;


                glColor3f( color.redF(), color.greenF(), color.blueF());

                for(int j=0;j<shape.points.size();j++)
                {
                    QVector3D c = shape.points[j].point;

                    glVertex3f(c.x(),c.y(),c.z());
                }

                glEnd();

            }
        }

        //glDisable(GL_POINT_SMOOTH);
        //glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }
};


#endif // SVGPARSER_HPP
