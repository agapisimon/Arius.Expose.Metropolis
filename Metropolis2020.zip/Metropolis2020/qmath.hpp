#ifndef QMATH_HPP
#define QMATH_HPP

#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>



# define Epsilon 1.0e-5

class QRay3D
{
    QVector3D m_origin;
    QVector3D m_direction;

    QVector3D p0 ;
    QVector3D p1;

public:

    QRay3D()
    {
        m_direction = QVector3D(1.0f, 0.0f, 0.0f) ;
    }

    QRay3D( QVector3D origin_,  QVector3D direction_)

    {
         m_origin= QVector3D(origin_);
        m_direction= QVector3D(direction_);
    }




    QVector3D origin() const
    {
        return m_origin;
    }

    void setOrigin(const QVector3D &value)
    {
        m_origin = value;
    }

    QVector3D direction() const
    {
        return m_direction;
    }

    void setDirection(const QVector3D & value)
    {
        m_direction = value;
    }

    QVector3D getPointAt(float t) const
    {
        return m_origin + t * m_direction;
    }

    void transform( QMatrix4x4 &matrix)
    {
        m_origin = matrix * m_origin;
        m_direction = matrix.mapVector(m_direction);
    }

    QRay3D transformed( QMatrix4x4 & matrix)
    {
        return QRay3D(matrix * m_origin, matrix.mapVector(m_direction));
    }

    bool operator==( QRay3D other)
    {
        return m_origin == other.origin() && m_direction == other.direction();
    }

    bool operator!=( QRay3D other)
    {
        return m_origin != other.origin() || m_direction != other.direction();
    }




    /*!
        \class QRay3D
        \brief The QRay3D class defines a directional line in 3D space extending through an origin point.
        \since 4.8
        \ingroup qt3d
        \ingroup qt3d::math

        A ray is defined by the origin() point and the direction() vector.
        Rays are infinite in length, extending out from origin() in
        both directions.  If the direction() is zero length, then the
        behavior of the class is undefined.

        A ray can be thought of as a one-dimensional co-ordinate system.
        If the co-ordinate is \b t then the origin() point is at
        \b t = 0, the point origin() + direction() is at \b t = 1,
        and the point origin() - direction() is at \b t = -1.
        The point() method can be used to obtain the position of a point
        within this one-dimensional co-ordinate system. The projectedDistance()
        method can be used to convert a point into a value in this
        one-dimensional co-ordinate system.
    */

    /*!
        \fn QRay3D::QRay3D()

        Construct a default ray with an origin() of (0, 0, 0) and a
        direction() of (1, 0, 0).
    */

    /*!
        \fn QRay3D::QRay3D(const QVector3D &origin, const QVector3D &direction)

        Construct a ray given its defining \a origin and \a direction.  The
        \a direction does not need to be normalized.

        To construct a ray that passes through two points, use the following:

        \code
        QRay3D thruAB(pointA, pointB - pointA);
        \endcode
    */

    /*!
        \fn QVector3D QRay3D::origin() const

        Returns the origin of this ray.  The default value is (0, 0, 0).

        \sa setOrigin(), direction()
    */

    /*!
        \fn void QRay3D::setOrigin(const QVector3D &value)

        Sets the origin point of this ray to \a value.

        \sa origin(), setDirection()
     */

    /*!
        \fn QVector3D QRay3D::direction() const

        Returns the direction vector of this ray.  The default value is (1, 0, 0).

        \sa setDirection(), origin()
    */

    /*!
        \fn void QRay3D::setDirection(const QVector3D &direction)

        Sets the direction vector of this ray to \a direction.

        \sa direction(), setOrigin()
    */

    /*!
        Returns true if \a point lies on this ray; false otherwise.
    */
    bool contains( QVector3D point)
    {
        QVector3D ppVec(point - m_origin);
        if (ppVec.isNull()) // point coincides with origin
            return true;
        float dot = QVector3D::dotProduct(ppVec, m_direction);
        if (qFuzzyIsNull(dot))
            return false;
        //return qFuzzyCompare(dot*dot, ppVec.lengthSquared() * m_direction.lengthSquared());

        return equals(dot*dot, ppVec.lengthSquared() * m_direction.lengthSquared());
    }

    bool equals(float x, float y)
    {
        if(x==y)
            return true;


        return false;

    }

    /*!
        Returns true if \a ray lies on this ray; false otherwise.  If true,
        this implies that the two rays are actually the same, but with
        different origin() points or an inverted direction().
    */
    bool contains( QRay3D ray)
    {
         float dot = QVector3D::dotProduct(m_direction, ray.direction());
        //if (!qFuzzyCompare(dot*dot, m_direction.lengthSquared() * ray.direction().lengthSquared()))

        if(!equals(dot*dot, m_direction.lengthSquared() * ray.direction().lengthSquared()))
            return false;
        return contains(ray.origin());
    }

    /*!
        \fn QVector3D QRay3D::point(float t) const

        Returns the point on the ray defined by moving \a t units
        along the ray in the direction of the direction() vector.
        Note that \a t may be negative in which case the point returned
        will lie behind the origin() point with respect to the
        direction() vector.

        The units for \a t are defined by direction().  The return value
        is precisely origin() + t * direction().

        \sa projectedDistance(), distance()
    */

    /*!
        Returns the number of direction() units along the ray from origin()
        to \a point.  Essentially, this function computes the value t, where
        \a point = origin() + t * direction().  If \a point is not on the ray,
        then the closest point that is on the ray will be used instead.

        If the return value is positive, then \a point lies in front of
        the origin() with respect to the direction() vector.  If the return
        value is negative, then \a point lies behind the origin() with
        respect to the direction() vector.

        \sa point(), project()
    */
    float projectedDistance(const QVector3D &point)
    {
        return QVector3D::dotProduct(point - m_origin, m_direction) /
                    m_direction.lengthSquared();
    }

    /*!
        Returns the projection of \a vector onto this ray.  In the
        following diagram, the dotted line is the ray, and V is the
        \a vector.  The return value will be the vector V':

        \image qray3d-project.png

        \sa projectedDistance()
    */
    QVector3D project( QVector3D vector)
    {
        QVector3D norm = m_direction.normalized();
        return QVector3D::dotProduct(vector, norm) * norm;
    }

    /*!
        Returns the minimum distance from this ray to \a point, or equivalently
        the length of a line perpendicular to this ray which passes through
        \a point.  If \a point is on the ray, then this function will return zero.

        \sa point()
    */
    float distance( QVector3D &point)
    {
        float t = projectedDistance(point);
        return (point - (m_origin + t * m_direction)).length();
    }

    /*!
        \fn void QRay3D::transform(const QMatrix4x4 &matrix)

        Transforms this ray using \a matrix, replacing origin() and
        direction() with the transformed versions.

        \sa transformed()
    */

    /*!
        \fn QRay3D QRay3D::transformed(const QMatrix4x4 &matrix) const

        Returns a new ray that is formed by transforming origin()
        and direction() using \a matrix.

        \sa transform()
    */

    /*!
        \fn bool QRay3D::operator==(const QRay3D &other)

        Returns true if this ray is the same as \a other; false otherwise.

        \sa operator!=()
    */

    /*!
        \fn bool QRay3D::operator!=(const QRay3D &other)

        Returns true if this ray is not the same as \a other; false otherwise.

        \sa operator==()
    */

    /*!
        \fn bool qFuzzyCompare(const QRay3D &ray1, const QRay3D &ray2)
        \relates QRay3D

        Returns true if \a ray1 and \a ray2 are almost equal; false otherwise.
    */


    /*
    bool qFuzzyCompare( QRay3D ray1,  QRay3D ray2)
    {
        return qFuzzyCompare(ray1.origin(), ray2.origin()) &&
               qFuzzyCompare(ray1.direction(), ray2.direction());
    }

    */

    void rayCastScene( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 1;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );


        double x_start= 0, y_start=0, z_start=0;
        gluUnProject( x, viewport[3]-y, 0, modelview, projection, viewport, &x_start, &y_start, &z_start );
        QVector3D start(x_start,y_start,z_start);
       // printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);


        double x_end= 0, y_end=0, z_end=0;
        gluUnProject( x, viewport[3]-y, 1, modelview, projection, viewport, &x_end, &y_end, &z_end );
        QVector3D end(x_end,y_end,z_end);
        //printf("end x:%f,y:%f,z:%f\n\n",end.x,end.y,end.z);


        p0 = start;
        p1 = end;

        QVector3D direction = p1 - p0;
        direction = direction.normalized();

        m_direction =  direction;

        //printf("Ray x:%f,y:%f,z:%f\n\n",ray.x,ray.y,ray.z);
    }

    QVector3D getRayCastSceneDirection( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 1;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );


        double x_start= 0, y_start=0, z_start=0;
        gluUnProject( x, viewport[3]-y, 0, modelview, projection, viewport, &x_start, &y_start, &z_start );
        QVector3D start(x_start,y_start,z_start);
       // printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);


        double x_end= 0, y_end=0, z_end=0;
        gluUnProject( x, viewport[3]-y, 1, modelview, projection, viewport, &x_end, &y_end, &z_end );
        QVector3D end(x_end,y_end,z_end);
        //printf("end x:%f,y:%f,z:%f\n\n",end.x,end.y,end.z);


        p0 = start;
        p1 = end;

        QVector3D direction = p1 - p0;
        direction = direction.normalized();

        m_direction =  direction;

        //printf("Ray x:%f,y:%f,z:%f\n\n",ray.x,ray.y,ray.z);

        return direction;
    }

    // using the current viewport, projection and modelview data that defines our (camera's)
    // view into the 3D world. It is only used to pick objects in 3D space.

    static QColor  getColorAtPixel(int x, int y)
    {
        static GLint    viewport[4];

        GLfloat winX, winY;

        glGetIntegerv(GL_VIEWPORT, viewport);

        GLubyte pixel[3];

        winX = (float)x;
        winY = (float)viewport[3] - (float)y;

        glReadBuffer( GL_BACK );

        //read color and depth
        glReadPixels(x, int(winY),1,1,GL_RGB,GL_UNSIGNED_BYTE,(void *)pixel);

        QColor color(pixel[0],pixel[1],pixel[2]);

        return color;
    }

    static QVector3D  get3DPositionAtPixel(int x, int y)
    {
        static GLint    viewport[4];
        static GLdouble modelview[16];
        static GLdouble projection[16];

        GLfloat winX, winY, winZ;
        GLdouble posX, posY, posZ;

        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
        glGetDoublev(GL_PROJECTION_MATRIX, projection);
        glGetIntegerv(GL_VIEWPORT, viewport);


        winX = (float)x;
        winY = (float)viewport[3] - (float)y;

        //glReadBuffer( GL_BACK );

        //read color and depth

        glReadPixels( x, int(winY), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ );

        gluUnProject( winX, winY, winZ, modelview, projection,viewport, &posX, &posY, &posZ);

        QVector3D point  = QVector3D((float)posX,(float)posY,(float)posZ);

        return point;
    }


    virtual void drawRay()
    {
        glDisable(GL_LIGHTING);

        glLineWidth(1.0);

        float size = 1.0f;
        // xy plane default
        float x = m_origin.x();
        float y = m_origin.z();
        float z = m_origin.y();

        glPushMatrix();

        glLineWidth(2.0);
        glBegin(GL_LINES);
        glColor3f(1.0f,1.0f,0.0f);
        glVertex3f(m_origin.x(),m_origin.z(),m_origin.y());
        glVertex3f(m_direction.x()*4+m_origin.x(),m_direction.z()*4+m_origin.z(),m_direction.y()*5+m_origin.y());
        glEnd();


        glPopMatrix();

        glEnable(GL_LIGHTING);
    }







};

class QPlane3D
{

    QVector3D m_origin;

    QVector3D m_normal;

public:

    QPlane3D()
    {
        m_normal = QVector3D(1.0f, 0.0f, 0.0f);
    }

    QPlane3D( QVector3D point,  QVector3D normal_)
    {
         m_origin = QVector3D(point);
         m_normal = QVector3D(normal_);
    }

    QPlane3D( QVector3D p,  QVector3D q,  QVector3D r)
    {
         m_origin=QVector3D(p);
         m_normal=QVector3D(QVector3D::crossProduct(q - p, r - q));
    }

    QVector3D origin()
    {
        return m_origin;
    }

    QVector3D normal()
    {
        return m_normal;
    }


    /*!
        Returns true if an intersection of \a ray with this plane exists;
        false otherwise.

        \sa intersection()
    */
    bool intersects(const QRay3D &ray)
    {
        return !qFuzzyIsNull((float)QVector3D::dotProduct(m_normal, ray.direction()));
    }

    /*!
        Returns the t value at which \a ray intersects this plane, or
        not-a-number if there is no intersection.

        When the \a ray intersects this plane, the return value is a
        parametric value that can be passed to QRay3D::point() to determine
        the actual intersection point, as shown in the following example:

        \code
        float t = plane.intersection(ray);
        QVector3D pt;
        if (qIsNaN(t)) {
            qWarning("no intersection occurred");
        else
            pt = ray.point(t);
        \endcode

        If the return value is positive, then the QRay3D::origin() of
        \a ray begins below the plane and then extends through it.
        If the return value is negative, then the origin begins
        above the plane.

        There are two failure cases where no single intersection point exists:

        \list
        \li when the ray is parallel to the plane (but does not lie on it)
        \li the ray lies entirely in the plane (thus every point "intersects")
        \endlist

        This method does not distinguish between these two failure cases and
        simply returns not-a-number for both.

        \sa intersects()
    */
    float intersection(const QRay3D& ray)
    {
        float dotLineAndPlane = QVector3D::dotProduct(m_normal, ray.direction());

        if (qFuzzyIsNull(float(dotLineAndPlane)))
        {
            // degenerate case - ray & plane-normal vectors are at
            // 90 degrees to each other, so either plane and ray never meet
            // or the ray lies in the plane - return failure case.
            return qSNaN();
        }

        return QVector3D::dotProduct(m_origin - ray.origin(), m_normal) / dotLineAndPlane;
    }


    //float distance(const QVector3D &point) const;

    /*!
        Returns the distance from this plane to \a point.  The value will
        be positive if \a point is above the plane in the direction
        of normal(), and negative if \a point is below the plane.
    */
    float distance(const QVector3D &point)
    {
        return QVector3D::dotProduct(point - m_origin, m_normal) / m_normal.length();
    }





    void setOrigin( QVector3D value)
    {
        m_origin = value;
    }



    void setNormal( QVector3D value)
    {
        m_normal = value;
    }

    void transform(const QMatrix4x4 &matrix)
    {
        m_origin   = matrix  *  m_origin;
        m_normal = matrix.mapVector(m_normal);
    }

    QPlane3D transformed(const QMatrix4x4 &matrix)
    {
        return QPlane3D(matrix * m_origin, matrix.mapVector(m_normal));
    }

    bool operator==( QPlane3D other)
    {
        bool val =  false;

        if(m_origin==other.origin() && m_normal == other.normal()  )
        {
            val = true;
        }

        return val;
    }

    bool operator!=( QPlane3D other)
    {
        return m_origin != other.origin() || m_normal != other.normal();
    }




    /*!
        \class QPlane3D
        \brief The QPlane3D class models the mathematics of planes in 3D space.
        \since 4.8
        \ingroup qt3d
        \ingroup qt3d::math

        A plane is defined by an origin() point lying on the plane, and a
        normal() vector, which is perpendicular to the surface of the plane.
        The normal() vector does not need to be normalized.  QPlane3D is an
        infinite surface, from which the normal() vector points out perpendicular
        from the origin() point.

        \sa QRay3D
    */

    /*!
        \fn QPlane3D::QPlane3D()

        Constructs a default plane object.  The defining origin() of the plane
        is set to (0, 0, 0) and the normal() vector is to (1, 0, 0).
    */

    /*!
        \fn QPlane3D::QPlane3D(const QVector3D &point, const QVector3D &normal)

        Constructs a new plane, where \a point lies on the plane, and \a normal
        is perpendicular to it.  The \a normal does not have to be normalized.
        If \a normal is zero, the behavior of the plane is undefined.
    */

    /*!
        \fn QPlane3D::QPlane3D(const QVector3D &p, const QVector3D &q, const QVector3D &r)

        Constructs a new plane defined by the three points \a p, \a q, and \a r.
        The point \a p is used as the plane's origin() point, and a normal()
        is constructed from the cross-product of \a q - \a p and \a r - \a q.
    */

    /*!
        \fn QVector3D QPlane3D::origin() const

        Returns this plane's defining origin point.  The default value is (0, 0, 0).

        \sa setOrigin(), normal()
    */

    /*!
        \fn void QPlane3D::setOrigin(const QVector3D& value)

        Set this plane's defining origin point to \a value.

        \sa origin(), setNormal()
    */

    /*!
        \fn QVector3D QPlane3D::normal() const

        Returns this plane's normal vector.  The default value is (1, 0, 0).

        \sa setNormal(), origin()
    */

    /*!
        \fn void QPlane3D::setNormal(const QVector3D& value)

        Set this plane's normal vector to \a value.  The \a value does
        not have to be normalized.  If \a value is zero, the behavior
        of the plane is undefined.

        \sa normal(), setOrigin()
    */

    /*!
        Returns true if \a point lies in this plane; false otherwise.
    */
    bool contains(const QVector3D &point)
    {
        return qFuzzyIsNull(float(QVector3D::dotProduct(m_normal, m_origin - point)));
    }

    /*!
        Returns true if all of the points on \a ray lie in this plane;
        false otherwise.
    */
    bool contains(const QRay3D &ray)
    {
        return qFuzzyIsNull (float(QVector3D::dotProduct(m_normal, ray.direction()))) && contains(ray.origin());
    }




    /*!
        \fn void QPlane3D::transform(const QMatrix4x4 &matrix)

        Transforms this plane using \a matrix, replacing origin() and
        normal() with the transformed versions.

        \sa transformed()
    */

    /*!
        \fn QPlane3D QPlane3D::transformed(const QMatrix4x4 &matrix) const

        Returns a new plane that is formed by transforming origin()
        and normal() using \a matrix.

        \sa transform()
    */

    /*!
        \fn bool QPlane3D::operator==(const QPlane3D &other)

        Returns true if this plane is the same as \a other; false otherwise.

        \sa operator!=()
    */

    /*!
        \fn bool QPlane3D::operator!=(const QPlane3D &other)

        Returns true if this plane is not the same as \a other; false otherwise.

        \sa operator==()
    */

    /*!
        \fn bool qFuzzyCompare(const QPlane3D &plane1, const QPlane3D &plane2)
        \relates QPlane3D

        Returns true if \a plane1 and \a plane2 are almost equal; false otherwise.
    */

    /*
    bool qFuzzyCompare(QPlane3D plane1, QPlane3D plane2)
    {
        return qFuzzyCompare(plane1.origin(), plane2.origin()) &&
               qFuzzyCompare(plane1.normal(), plane2.normal());
    }

    */

    virtual void drawPlane(float scale = 1.0f)
    {

        glDisable(GL_LIGHTING);

        glLineWidth(1.0);

        float size = 1.0f;
        // xy plane default
        float x = m_origin.x();
        float y = m_origin.z();
        float z = m_origin.y();

        glPushMatrix();

        glScalef(scale,scale,scale);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(1.0f,0.0f,1.0f,0.2f);
        glBegin(GL_QUADS);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z+size);
            glVertex3f(x+size,y,z-size);
        glEnd();
        glDisable(GL_BLEND);

        glColor3f(1.0f,0.0f,0.0f);
        glBegin(GL_LINES);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z-size);
            glVertex3f(x+size,y,z+size);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x+size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z+size);
        glEnd();

        glLineWidth(2.0);
        glBegin(GL_LINES);
        glColor3f(1.0f,1.0f,0.0f);
        glVertex3f(m_origin.x(),m_origin.z(),m_origin.y());
        glVertex3f(m_normal.x()*4+m_origin.x(),m_normal.z()*4+m_origin.z(),m_normal.y()*5+m_origin.y());
        glEnd();


        glPopMatrix();

        glEnable(GL_LIGHTING);
    }




};

class QBox3D
{

    enum Type
    {
        Null,
        Finite,
        Infinite
    };

    QBox3D::Type boxtype;
    QVector3D mincorner, maxcorner;

public:

    QBox3D()
    {
        boxtype=(Null);

        mincorner = QVector3D(0, 0, 0);
        maxcorner = QVector3D(0, 0, 0);
    }

    QBox3D(const QVector3D& corner1, const QVector3D& corner2)
    {
        boxtype =(Finite);

        mincorner= QVector3D(qMin(corner1.x(), corner2.x()),
                    qMin(corner1.y(), corner2.y()),
                    qMin(corner1.z(), corner2.z()));


        maxcorner=QVector3D(qMax(corner1.x(), corner2.x()),
                    qMax(corner1.y(), corner2.y()),
                    qMax(corner1.z(), corner2.z())) ;
    }

    QVector< QVector3D >  getAllCorners()
    {

        QVector< QVector3D > corners;

        QVector3D min =  minimum();
        QVector3D max =  maximum();


        corners[0] = min;

        corners[1] = QVector3D(min.x(),min.y(),max.z());

        corners[2] = QVector3D(min.x(),max.y(),min.z());

        corners[3] = QVector3D(max.x(),min.y(),min.z());

        corners[4] = QVector3D(max.x(),min.y(),max.z());

        corners[5] = QVector3D(max.x(),max.y(),min.z());

        corners[6] = QVector3D(min.x(),max.y(),max.z());

        corners[7] = max;

        return corners;
    }

    bool isNull()
    {
        return (boxtype == Null);
    }

    bool isFinite() const { return (boxtype == Finite); }
    bool isInfinite() const { return (boxtype == Infinite); }

    QVector3D minimum() const { return mincorner; }
    QVector3D maximum() const { return maxcorner; }

    void setExtents(const QVector3D& corner1, const QVector3D& corner2)
    {
        boxtype = Finite;
        mincorner = QVector3D(qMin(corner1.x(), corner2.x()),
                              qMin(corner1.y(), corner2.y()),
                              qMin(corner1.z(), corner2.z()));
        maxcorner = QVector3D(qMax(corner1.x(), corner2.x()),
                              qMax(corner1.y(), corner2.y()),
                              qMax(corner1.z(), corner2.z()));
    }

    void setToNull()
    {
        boxtype = Null;
        mincorner = QVector3D(0, 0, 0);
        maxcorner = QVector3D(0, 0, 0);
    }

    void setToInfinite()
    {
        boxtype = Infinite;
        mincorner = QVector3D(0, 0, 0);
        maxcorner = QVector3D(0, 0, 0);
    }

    QVector3D size()
    {

        return maxcorner - mincorner;
    }
    QVector3D center()
    {
        return (mincorner + maxcorner) * 0.5f;
    }

    bool contains(const QVector3D& point)
    {
        if (boxtype == Finite)
        {
            return (point.x() >= mincorner.x() && point.x() <= maxcorner.x() &&
                    point.y() >= mincorner.y() && point.y() <= maxcorner.y() &&
                    point.z() >= mincorner.z() && point.z() <= maxcorner.z());
        }
        else if (boxtype == Infinite)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    bool contains(const QBox3D& box)
    {
        if (box.boxtype == Finite)
            return contains(box.mincorner) && contains(box.maxcorner);
        else if (box.boxtype == Infinite)
            return (boxtype == Infinite);
        else
            return false;
    }

    bool operator ==(const QBox3D& box)
    {
        return (boxtype == box.boxtype &&
                mincorner == box.mincorner &&
                maxcorner == box.maxcorner);
    }

    bool operator!=(const QBox3D& box)
    {
        return (boxtype != box.boxtype ||
                mincorner != box.mincorner ||
                maxcorner != box.maxcorner);
    }




    /*!
        \class QBox3D
        \brief The QBox3D class represents an axis-aligned box in 3D space.
        \since 4.8
        \ingroup qt3d
        \ingroup qt3d::math

        QBox3D can be used to represent the bounding box of objects in a 3D
        scene so that they can be easily culled if they are out of view.

        The sides of the box are always aligned with the x, y, and z axes of
        the world co-ordinate system.  Transforming a box with transformed()
        will result in the smallest axis-aligned bounding box that contains
        the transformed box.

        Boxes may be null, finite, or infinite.  A null box does not occupy
        any space and does not intersect with any other box.  A finite
        box consists of a minimum() and maximum() extent in 3D space.
        An infinite box encompasses all points in 3D space.

        The extents of a finite box are also included within the box.
        A box with minimum() and maximum() set to the same value
        contains a single point.
    */

    /*!
        \fn QBox3D::QBox3D()

        Constructs a null box in 3D space.

        \sa isNull()
    */

    /*!
        \fn QBox3D::QBox3D(const QVector3D& corner1, const QVector3D& corner2)

        Constructs a finite box in 3D space from \a corner1 to \a corner2.
        The minimum() and maximum() co-ordinates of the new box are set
        to the minimum and maximum x, y, and z values from \a corner1 and
        \a corner2.  The \a corner1 and \a corner2 values can be any two
        opposite corners that define the box.

        \sa isFinite(), minimum(), maximum()
    */

    /*!
        \fn bool QBox3D::isNull() const

        Returns true if this box is null; false otherwise.

        \sa isFinite(), isInfinite(), setToNull()
    */

    /*!
        \fn bool QBox3D::isFinite() const

        Returns true if this box is finite in size; false otherwise.

        \sa isNull(), isInfinite(), setExtents()
    */

    /*!
        \fn bool QBox3D::isInfinite() const

        Returns true if this box is infinite in size; false otherwise.

        \sa isNull(), isFinite(), setToInfinite()
    */

    /*!
        \fn QVector3D QBox3D::minimum() const

        Returns the minimum corner of this box.

        \sa maximum(), setExtents()
    */

    /*!
        \fn QVector3D QBox3D::maximum() const

        Returns the maximum corner of this box.

        \sa minimum(), setExtents()
    */

    /*!
        \fn void QBox3D::setExtents(const QVector3D& corner1, const QVector3D& corner2)

        Sets the extents of this box to a finite region from \a corner1 to
        \a corner2.  The minimum() and maximum() co-ordinates of the box are
        set to the minimum and maximum x, y, and z values from \a corner1 and
        \a corner2.  The \a corner1 and \a corner2 values can be any two
        opposite corners that define the box.

        \sa minimum(), maximum()
    */

    /*!
        \fn void QBox3D::setToNull()

        Sets this box to null.

        \sa isNull()
    */

    /*!
        \fn void QBox3D::setToInfinite()

        Sets this box to be infinite in size.

        \sa isInfinite()
    */

    /*!
        \fn QVector3D QBox3D::size() const

        Returns the finite size of this box.  If this box is null or
        infinite, the returned value will be zero.

        \sa center(), isNull(), isInfinite()
    */

    /*!
        \fn QVector3D QBox3D::center() const

        Returns the finite center of this box.  If this box is null
        or infinite, the returned value will be zero.

        \sa size(), isNull(), isInfinite()
    */

    /*!
        \fn bool QBox3D::contains(const QVector3D& point) const

        Returns true if this box contains \a point; false otherwise.
        Null boxes do not contain any points and infinite boxes contain
        all points.

        Containment is not a strict test: the point is contained if it
        lies on one of the faces of the box.

        \sa intersects()
    */

    /*!
        \fn bool QBox3D::contains(const QBox3D& box) const

        Returns true if this box completely contains \a box.  If this box
        is null, then it will not contain \a box.  If this box is infinite,
        and \a box is not null, then \a box will be contained within this box.
        If \a box is infinite, then this box must also be infinite to contain it.

        \sa intersects()
    */

    /*!
        Returns true if \a box intersects this box; false otherwise.

        \sa intersect(), intersected(), contains()
    */
    bool intersects(const QBox3D& box) const
    {
        if (boxtype == Null)
            return false;
        else if (boxtype == Infinite)
            return box.boxtype != Null;
        else if (box.boxtype == Null)
            return false;
        else if (box.boxtype == Infinite)
            return true;

        if (maxcorner.x() < box.mincorner.x())
            return false;
        if (mincorner.x() > box.maxcorner.x())
            return false;

        if (maxcorner.y() < box.mincorner.y())
            return false;
        if (mincorner.y() > box.maxcorner.y())
            return false;

        if (maxcorner.z() < box.mincorner.z())
            return false;
        if (mincorner.z() > box.maxcorner.z())
            return false;

        return true;
    }

    /*!
        Returns true if \a ray intersects this box; false otherwise.

        \sa intersection()
    */
    bool intersects(const QRay3D &ray)
    {
        float minimum_t, maximum_t;
        return intersection(ray, &minimum_t, &maximum_t);
    }

    void trackIntersectionX(const QBox3D &box, const QRay3D &ray, float t, float *minimum_t, float *maximum_t, bool *found)
    {
        QVector3D point = ray.getPointAt(t);
        if (point.y() < box.minimum().y() || point.y() > box.maximum().y())
            return;
        if (point.z() < box.minimum().z() || point.z() > box.maximum().z())
            return;
        if (!(*found)) {
            *minimum_t = *maximum_t = t;
            *found = true;
        } else {
            if (t < *minimum_t)
                *minimum_t = t;
            if (t > *maximum_t)
                *maximum_t = t;
        }
    }

    void trackIntersectionY(const QBox3D &box, const QRay3D &ray, float t,float *minimum_t, float *maximum_t, bool *found)
    {
        QVector3D point = ray.getPointAt(t);
        if (point.x() < box.minimum().x() || point.x() > box.maximum().x())
            return;
        if (point.z() < box.minimum().z() || point.z() > box.maximum().z())
            return;
        if (!(*found)) {
            *minimum_t = *maximum_t = t;
            *found = true;
        } else {
            if (t < *minimum_t)
                *minimum_t = t;
            if (t > *maximum_t)
                *maximum_t = t;
        }
    }

    void trackIntersectionZ(const QBox3D &box, const QRay3D &ray, float t, float *minimum_t, float *maximum_t, bool *found)
    {
        QVector3D point = ray.getPointAt(t);
        if (point.x() < box.minimum().x() || point.x() > box.maximum().x())
            return;
        if (point.y() < box.minimum().y() || point.y() > box.maximum().y())
            return;
        if (!(*found)) {
            *minimum_t = *maximum_t = t;
            *found = true;
        } else {
            if (t < *minimum_t)
                *minimum_t = t;
            if (t > *maximum_t)
                *maximum_t = t;
        }
    }

    /*!
        Finds the \a minimum_t and \a maximum_t values where \a ray intersects
        this box.  Returns true if intersections were found; or false if there
        is no intersection.

        If \a minimum_t and \a maximum_t are set to the same value, then the
        intersection is at a corner or the volume of the box is zero.
        If the t values are negative, then the intersection occurs before the
        ray's origin point in the reverse direction of the ray.

        The \a minimum_t and \a maximum_t values can be passed to QRay3D::point()
        to determine the actual intersection points, as shown in the following
        example:

        \code
        float minimum_t, maximum_t;
        if (box.intersection(ray, &minimum_t, &maximum_t)) {
            qDebug() << "intersections at"
                     << ray.point(minimum_t) << "and"
                     << ray.point(maximum_t);
        }
        \endcode

        \sa intersects(), QRay3D::point()
    */
    bool intersection(const QRay3D &ray, float *minimum_t, float *maximum_t)
    {
        bool found = false;
        QVector3D origin = ray.origin();
        QVector3D direction = ray.direction();

        *minimum_t = *maximum_t = qSNaN();

        if (boxtype == Finite)
        {
            if (direction.x() != 0.0f)
            {
                trackIntersectionX
                    (*this, ray, (mincorner.x() - origin.x()) / direction.x(),
                     minimum_t, maximum_t, &found);
                trackIntersectionX
                    (*this, ray, (maxcorner.x() - origin.x()) / direction.x(),
                     minimum_t, maximum_t, &found);
            }
            if (direction.y() != 0.0f) {
                trackIntersectionY
                    (*this, ray, (mincorner.y() - origin.y()) / direction.y(),
                     minimum_t, maximum_t, &found);
                trackIntersectionY
                    (*this, ray, (maxcorner.y() - origin.y()) / direction.y(),
                     minimum_t, maximum_t, &found);
            }
            if (direction.z() != 0.0f) {
                trackIntersectionZ
                    (*this, ray, (mincorner.z() - origin.z()) / direction.z(),
                     minimum_t, maximum_t, &found);
                trackIntersectionZ
                    (*this, ray, (maxcorner.z() - origin.z()) / direction.z(),
                     minimum_t, maximum_t, &found);
            }
        }
        return found;
    }

    /*!
        Returns the t value at which \a ray first intersects the sides of
        this box, or not-a-number if there is no intersection.

        When the \a ray intersects this box, the return value is a
        parametric value that can be passed to QRay3D::point() to determine
        the actual intersection point, as shown in the following example:

        \code
        float t = box.intersection(ray);
        QVector3D pt;
        if (qIsNaN(t)) {
            qWarning("no intersection occurred");
        else
            pt = ray.point(t);
        \endcode

        The \a ray might intersect at two points - as the ray passes through
        the box - one on the near side, one on the far side; where near and far
        are relative to the origin point of the ray.  This function only
        returns the near intersection point.

        Only positive values on the ray are considered.  This means that if
        the origin point of the ray is inside the box, there is only one
        solution, not two.  To get the other solution, simply change
        the sign of the ray's direction vector.  If the origin point of
        the ray is outside the box, and the direction points away from
        the box, then there will be no intersection.

        When the ray does not intersect the box in the positive direction,
        or the box is not finite, then the return value is not-a-number.

        \sa intersects(), QRay3D::point()
    */
    float intersection(const QRay3D &ray)
    {
        float minimum_t, maximum_t;

        if (intersection(ray, &minimum_t, &maximum_t))
        {
            if (minimum_t >= 0.0f)
                return minimum_t;
            else if (maximum_t >= 0.0f)
                return maximum_t;
            else
                return qSNaN();
        }
        else
        {
            return qSNaN();
        }
    }

    /*!
        Intersects this box with \a box.

        \sa intersected(), intersects(), unite()
    */
    void intersect(const QBox3D& box)
    {
        // Handle the simple cases first.
        if (boxtype == Null)
        {
            // Null intersected with anything is null.
            return;
        }
        else if (boxtype == Infinite)
        {
            // Infinity intersected with a box is that box.
            *this = box;
            return;
        }
        else if (box.boxtype == Null)
        {
            // Anything intersected with null is null.
            setToNull();
            return;
        }
        else if (box.boxtype == Infinite)
        {
            // Box intersected with infinity is the box.
            return;
        }

        // Intersect two finite boxes.
        QVector3D min1 = mincorner;
        QVector3D max1 = maxcorner;
        QVector3D min2 = box.mincorner;
        QVector3D max2 = box.maxcorner;

        if (min2.x() > min1.x())
            min1.setX(min2.x());
        if (min2.y() > min1.y())
            min1.setY(min2.y());
        if (min2.z() > min1.z())
            min1.setZ(min2.z());
        if (max2.x() < max1.x())
            max1.setX(max2.x());
        if (max2.y() < max1.y())
            max1.setY(max2.y());
        if (max2.z() < max1.z())
            max1.setZ(max2.z());
        if (min1.x() > max1.x() || min1.y() > max1.y() || min1.z() > max1.z()) {
            setToNull();
        } else {
            mincorner = min1;
            maxcorner = max1;
        }
    }

    /*!
        Returns a new box which is the intersection of this box with \a box.

        \sa intersect(), intersects(), united()
    */
    QBox3D intersected(const QBox3D& box) const
    {
        QBox3D result(*this);
        result.intersect(box);
        return result;
    }

    /*!
        Unites this box with \a point by expanding it to encompass \a point.
        If \a point is already contained within this box, then this box
        will be unchanged.

        \sa united(), intersect()
    */
    void unite(const QVector3D& point)
    {
        if (boxtype == Finite)
        {
            if (point.x() < mincorner.x())
                mincorner.setX(point.x());
            else if (point.x() > maxcorner.x())
                maxcorner.setX(point.x());
            if (point.y() < mincorner.y())
                mincorner.setY(point.y());
            else if (point.y() > maxcorner.y())
                maxcorner.setY(point.y());
            if (point.z() < mincorner.z())
                mincorner.setZ(point.z());
            else if (point.z() > maxcorner.z())
                maxcorner.setZ(point.z());
        }
        else if (boxtype == Null)
        {
            boxtype = Finite;
            mincorner = point;
            maxcorner = point;
        }
    }

    /*!
        Unites this box with \a box by expanding this box to encompass the
        region defined by \a box.  If \a box is already contained within
        this box, then this box will be unchanged.

        \sa united(), intersect()
    */
    void unite(const QBox3D& box)
    {
        if (box.boxtype == Finite)
        {
            unite(box.minimum());
            unite(box.maximum());
        }
        else if (box.boxtype == Infinite)
        {
            setToInfinite();
        }
    }

    /*!
        Returns a new box which unites this box with \a point.  The returned
        value will be the smallest box that contains both this box and \a point.

        \sa unite(), intersected()
    */
    QBox3D united(const QVector3D& point)
    {
        if (boxtype == Finite)
        {
            QBox3D result(*this);
            result.unite(point);
            return result;
        }
        else if (boxtype == Null)
        {

            return QBox3D(point, point);
        }
        else
        {
            return *this;
        }
    }

    /*!
        Returns a new box which unites this box with \a box.  The returned value
        will be the smallest box that contains both this box and \a box.

        \sa unite(), intersected()
    */
    QBox3D united(const QBox3D& box)
    {
        if (boxtype == Finite)
        {
            QBox3D result(*this);
            result.unite(box);
            return result;
        }
        else if (boxtype == Null)
        {
            return box;
        }
        else
        {
            return *this;
        }
    }

    /*!
        Transforms this box according to \a matrix.  Each of the 8 box
        corners are transformed and then a new box that encompasses all
        of the transformed corner values is created.

        \sa transformed()
    */
    void transform(const QMatrix4x4& matrix)
    {
        *this = transformed(matrix);
    }

    /*!
        Returns this box transformed by \a matrix.  Each of the 8 box
        corners are transformed and then a new box that encompasses all
        of the transformed corner values is returned.

        \sa transform()
    */
    QBox3D transformed(const QMatrix4x4& matrix)
    {
        if (boxtype != Finite)
            return *this;
        QBox3D result;
        result.unite(matrix * mincorner);
        result.unite(matrix * QVector3D(mincorner.x(), mincorner.y(), maxcorner.z()));
        result.unite(matrix * QVector3D(mincorner.x(), maxcorner.y(), maxcorner.z()));
        result.unite(matrix * QVector3D(mincorner.x(), maxcorner.y(), mincorner.z()));
        result.unite(matrix * QVector3D(maxcorner.x(), mincorner.y(), mincorner.z()));
        result.unite(matrix * QVector3D(maxcorner.x(), maxcorner.y(), mincorner.z()));
        result.unite(matrix * QVector3D(maxcorner.x(), mincorner.y(), maxcorner.z()));
        result.unite(matrix * maxcorner);
        return result;
    }

    /*!
        \fn bool QBox3D::operator==(const QBox3D& box) const

        Returns true if this box is identical to \a box.
    */

    /*!
        \fn bool QBox3D::operator!=(const QBox3D& box) const

        Returns true if this box is not identical to \a box.
    */

    /*!
        \fn bool qFuzzyCompare(const QBox3D& box1, const QBox3D& box2)
        \relates QBox3D

        Returns true if \a box1 and \a box2 are almost equal; false otherwise.
    */

    /*

    bool qFuzzyCompare(const QBox3D& box1, const QBox3D& box2)
    {
        return box1.boxtype == box2.boxtype &&
               qFuzzyCompare(box1.mincorner, box2.mincorner) &&
               qFuzzyCompare(box1.maxcorner, box2.maxcorner);
    }

    */

    // Draw the aabb
    void draw( QColor color= QColor(Qt::cyan))
    {
        glLineWidth(1);
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glBegin(GL_LINES);

        QVector3D  min = this->minimum();
        QVector3D  max = this->maximum();

        glColor3f(color.redF(), color.greenF(), color.blueF());
        glVertex3f(min.x(), min.y(), min.z());glVertex3f(max.x(), min.y(), min.z());
        glVertex3f(max.x(), min.y(), min.z());glVertex3f(max.x(), max.y(), min.z());
        glVertex3f(max.x(), max.y(), min.z());glVertex3f(min.x(), max.y(), min.z());
        glVertex3f(min.x(), max.y(), min.z());glVertex3f(min.x(), min.y(), min.z());
        glVertex3f(min.x(), min.y(), min.z());glVertex3f(min.x(), min.y(), max.z());
        glVertex3f(min.x(), min.y(), max.z());glVertex3f(max.x(), min.y(), max.z());
        glVertex3f(max.x(), min.y(), max.z());glVertex3f(max.x(), min.y(), min.z());
        glVertex3f(max.x(), min.y(), max.z());glVertex3f(max.x(), max.y(), max.z());
        glVertex3f(max.x(), max.y(), max.z());glVertex3f(max.x(), max.y(), min.z());
        glVertex3f(max.x(), max.y(), max.z());glVertex3f(min.x(), max.y(), max.z());
        glVertex3f(min.x(), max.y(), max.z());glVertex3f(min.x(), max.y(), min.z());
        glVertex3f(min.x(), max.y(), max.z());glVertex3f(min.x(), min.y(), max.z());
        glEnd();

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }


};

class QSphere3D
{
private:
    QVector3D m_center;
    float m_radius;
public:



     QSphere3D()
     {

         m_radius= (1.0f);
     }

     QSphere3D(const QVector3D &center_, float radius_)

     {
         m_center = QVector3D(center_);
         m_radius=(radius_) ;
     }

    QVector3D center()
    {
        return m_center;
    }

     void setCenter(const QVector3D &center_)
    {
        m_center = center_;
    }

     float radius()
    {
        return m_radius;
    }

     void setRadius(float radius_)
    {
        m_radius = radius_;
    }

    bool contains(const QVector3D &point)
    {
        return (point - m_center).lengthSquared() <= (m_radius * m_radius);
    }

    bool intersects(QSphere3D sphere)
    {
        float radsum = sphere.radius() + m_radius;

        if((sphere.center() - m_center).lengthSquared() <= (radsum * radsum))
            return true;

        return false;
    }

    void transform(const QMatrix4x4 &matrix)
    {
        *this = transformed(matrix);
    }

    bool operator==(const QSphere3D &sphere)
    {
        return m_center == sphere.m_center && m_radius == sphere.m_radius;
    }

    bool operator!=(const QSphere3D &sphere)
    {
        return m_center != sphere.m_center || m_radius != sphere.m_radius;
    }



    /*!
        \class QSphere3D
        \brief The QSphere3D class represents a mathematical sphere in 3D space.
        \since 4.8
        \ingroup qt3d
        \ingroup qt3d::math

        QSphere3D can be used to represent the bounding regions of objects
        in a 3D scene so that they can be easily culled if they are out of view.
        It can also be used to assist with collision testing.

        \sa QBox3D
    */

    /*!
        \fn QSphere3D::QSphere3D()

        Constructs a default sphere with a center() of (0, 0, 0)
        and radius() of 1.
    */

    /*!
        \fn QSphere3D::QSphere3D(const QVector3D &center, float radius)

        Constructs a sphere with the specified \a center and \a radius.
    */

    /*!
        \fn QVector3D QSphere3D::center() const

        Returns the center of this sphere.

        \sa setCenter(), radius()
    */

    /*!
        \fn void QSphere3D::setCenter(const QVector3D &center)

        Sets the \a center of this sphere.

        \sa center(), setRadius()
    */

    /*!
        \fn float QSphere3D::radius() const

        Returns the radius of this sphere.

        \sa setRadius(), center()
    */

    /*!
        \fn void QSphere3D::setRadius(float radius)

        Sets the \a radius of this sphere.

        \sa radius(), setCenter()
    */

    /*!
        \fn bool QSphere3D::contains(const QVector3D &point) const

        Returns true if \a point is contained within the bounds of
        this sphere; false otherwise.
    */

    /*!
        Returns true if this sphere intersects \a ray; false otherwise.

        \sa intersection()
    */
    bool intersects(const QRay3D &ray)
    {
        QVector3D centerToOrigin = ray.origin() - m_center;
        float term1 = ray.direction().lengthSquared();
        float term2 = 2.0f * QVector3D::dotProduct(centerToOrigin, ray.direction());
        float term3 = centerToOrigin.lengthSquared() - m_radius * m_radius;
        float det = term2 * term2 - (4.0f * term1 * term3);
        return term1 != 0.0f && det >= 0.0f;
    }

    /*!
        \fn bool QSphere3D::intersects(const QSphere3D &sphere) const

        Returns true if this sphere intersects \a sphere; false otherwise.

        \sa contains()
    */

    /*!
        Returns true if this sphere intersects \a box; false otherwise.
    */
    bool intersects(const QBox3D &box)
    {
        if (box.isFinite())
        {
            // Use Arvo's Algorithm to determine if we have an intersection.
            float dist = 0.0f;
            float center = m_center.x();
            float minval = box.minimum().x();
            float maxval = box.maximum().x();
            if (center < minval)
                dist += (center - minval) * (center - minval);
            else if (center > maxval)
                dist += (center - maxval) * (center - maxval);
            center = m_center.y();
            minval = box.minimum().y();
            maxval = box.maximum().y();
            if (center < minval)
                dist += (center - minval) * (center - minval);
            else if (center > maxval)
                dist += (center - maxval) * (center - maxval);
            center = m_center.z();
            minval = box.minimum().z();
            maxval = box.maximum().z();
            if (center < minval)
                dist += (center - minval) * (center - minval);
            else if (center > maxval)
                dist += (center - maxval) * (center - maxval);
            return dist <= (m_radius * m_radius);
        } else {
            return box.isInfinite();
        }
    }

    /*!
        Returns true if this sphere intersects \a plane; false otherwise.
    */
    bool intersects( QPlane3D plane)
    {
        double  dist =  plane.distance(m_center);

        bool result = false;

        if(qAbs(dist) <= m_radius)
        {
            result = true;
        }

        return result;
    }

    /*!
        Finds the \a minimum_t and \a maximum_t values where \a ray intersects
        this sphere.  Returns true if intersections were found; or false if there
        is no intersection.

        If \a minimum_t and \a maximum_t are set to the same value, then \a ray
        touches the surface of the sphere at a single point.  If the t values are
        negative, then the intersection occurs before the ray's origin point
        in the reverse direction of the ray.

        The \a minimum_t and \a maximum_t values can be passed to QRay3D::point()
        to determine the actual intersection points, as shown in the following
        example:

        \code
        float minimum_t, maximum_t;
        if (sphere.intersection(ray, &minimum_t, &maximum_t)) {
            qDebug() << "intersections at"
                     << ray.point(minimum_t) << "and"
                     << ray.point(maximum_t);
        }
        \endcode

        \sa intersects(), QRay3D::point()
    */
    bool intersection(const QRay3D &ray, float *minimum_t, float *maximum_t)
    {
        QVector3D centerToOrigin = ray.origin() - m_center;
        float term1 = ray.direction().lengthSquared();
        float term2 = 2.0f * QVector3D::dotProduct(centerToOrigin, ray.direction());
        float term3 = centerToOrigin.lengthSquared() - m_radius * m_radius;
        float det = term2 * term2 - (4.0f * term1 * term3);
        if (term1 == 0.0f || det < 0.0f) {
            *minimum_t = qSNaN();
            *maximum_t = qSNaN();
            return false;
        } else if (det == 0.0f) {
            *minimum_t = *maximum_t = -term2 / (2.0f * term1);
        } else {
            float sqrtDet = sqrtf(det);
            float t1 = (-term2 - sqrtDet) / (2.0f * term1);
            float t2 = (-term2 + sqrtDet) / (2.0f * term1);
            if (t1 < t2) {
                *minimum_t = t1;
                *maximum_t = t2;
            } else {
                *minimum_t = t2;
                *maximum_t = t1;
            }
        }
        return true;
    }

    /*!
        Returns the t value at which \a ray first intersects the surface of
        this sphere, or not-a-number if there is no intersection.

        When the \a ray intersects this sphere, the return value is a
        parametric value that can be passed to QRay3D::point() to determine
        the actual intersection point, as shown in the following example:

        \code
        float t = sphere.intersection(ray);
        QVector3D pt;
        if (qIsNaN(t)) {
            qWarning("no intersection occurred");
        else
            pt = ray.point(t);
        \endcode

        The \a ray might intersect at two points - as the ray passes through
        the sphere - one on the near side, one on the far side; where near and far
        are relative to the origin point of the ray.  This function only
        returns the near intersection point.

        Only positive values on the ray are considered.  This means that if
        the origin point of the ray is inside the sphere, there is only one
        solution, not two.  To get the other solution, simply change
        the sign of the ray's direction vector.  If the origin point of
        the ray is outside the sphere, and the direction points away from
        the sphere, then there will be no intersection.

        When the ray does not intersect the sphere in the positive direction,
        then the return value is not-a-number.

        \sa intersects(), QRay3D::point()
    */
    float intersection(const QRay3D &ray)
    {
        float minimum_t, maximum_t;
        if (intersection(ray, &minimum_t, &maximum_t)) {
            if (minimum_t >= 0.0f)
                return minimum_t;
            else if (maximum_t >= 0.0f)
                return maximum_t;
            else
                return qSNaN();
        } else {
            return qSNaN();
        }
    }

    /*!
        \fn void QSphere3D::transform(const QMatrix4x4 &matrix)

        Transforms this sphere's center() and radius() according to \a matrix.

        It is assumed that \a matrix contains a uniform scale factor in the
        x, y, and z directions.  Otherwise the radius() in the result is undefined.

        \sa transformed()
    */

    /*!
        Returns the result of transforming this sphere's center() and radius()
        according to \a matrix.

        It is assumed that \a matrix contains a uniform scale factor in the
        x, y, and z directions.  Otherwise the radius() in the result is undefined.

        \sa transform()
    */
    QSphere3D transformed(const QMatrix4x4 &matrix)
    {
        return QSphere3D(matrix * m_center,
                         matrix.mapVector(QVector3D(m_radius, 0, 0)).length());
    }

    /*!
        \fn bool QSphere3D::operator==(const QSphere3D &sphere) const

        Returns true if this sphere is the same as \a sphere; false otherwise.

        \sa operator!=()
    */

    /*!
        \fn bool QSphere3D::operator!=(const QSphere3D &sphere) const

        Returns true if this sphere is not the same as \a sphere; false otherwise.

        \sa operator==()
    */

    /*!
        \fn bool qFuzzyCompare(const QSphere3D &sphere1, const QSphere3D &sphere2)
        \relates QSphere3D

        Returns true if \a sphere1 and \a sphere2 are almost equal;
        false otherwise.
    */

    /*
    bool qFuzzyCompare(QSphere3D sphere1,  QSphere3D sphere2)
    {
        return qFuzzyCompare(sphere1.center(), sphere2.center()) &&
               qFuzzyCompare(sphere1.radius(), sphere2.radius());
    }

    */








};

class QTriangle3D
{
private:
    QVector3D a, b, c;
public:


    QTriangle3D()
    {
        a = QVector3D(0.0f, 0.0f, 0.0f);
        b = QVector3D(1.0f, 0.0f, 0.0f);
        c = QVector3D(0.0f, 1.0f, 0.0f);
    }

   QTriangle3D(const QVector3D &a_, const QVector3D &b_, const QVector3D &c_)
    {
        a=QVector3D(a_);
         b=QVector3D(b_);
         c=QVector3D(c_);
   }

    QVector3D A()
    {
        return a;
    }

    void setA(const QVector3D &point)
    {
        a = point;
    }

    QVector3D B()
    {
        return b;
    }

    void setB(const QVector3D &point)
    {
        b = point;
    }

    QVector3D C()
    {
        return c;
    }

    void setC(const QVector3D &point)
    {
        c = point;
    }

    QPlane3D plane()
    {
        return QPlane3D(a, b, c);
    }

    QVector3D center()
    {
        return (a + b + c) / 3.0f;
    }

    QVector3D faceNormal()
    {
        return QVector3D::crossProduct(b - a, c - b);
    }

    bool operator==(const QTriangle3D &other)
    {
        return a == other.a && b == other.b && c == other.c;
    }

    bool operator!=(const QTriangle3D &other)
    {
        return a != other.a || b != other.b || c != other.c;
    }




    /*!
        \class QTriangle3D
        \brief The QTriangle3D class represents a triangle as three points in 3D space.
        \since 4.8
        \ingroup qt3d
        \ingroup qt3d::math

        A triangle is defined by 3 points in 3D space.  Since any 3 points define
        a plane, the triangle can be thought of as defining a plane, and forming a
        geometric region in that plane.

        If you need a simple plane, with no particular geometry, then
        QPlane3D is a more compact and mathematically sufficient class.

        The three points are labelled p(), q() and r() for consistency with
        textbook treatments.  It is recommended that the points be supplied
        in counter-clockwise order for correct orientation of the
        triangle's plane().

        \sa QPlane3D
    */

    /*!
        \fn QTriangle3D::QTriangle3D()

        Constructs a default triangle which lies in the x-z plane,
        with the three vertices (0, 0, 0), (1, 0, 0), and (0, 1, 0).
    */

    /*!
        \fn QTriangle3D::QTriangle3D(const QVector3D &p, const QVector3D &q, const QVector3D &r)

        Constructs a triangle with the supplied \a p, \a q and \a r vertices.
    */

    /*!
        \fn QVector3D QTriangle3D::p() const

        Returns the value of the P vertex on the triangle.

        \sa q(), r(), setP()
    */

    /*!
        \fn void QTriangle3D::setP(const QVector3D &point)

        Sets the value of the P vertex on the triangle to \a point.

        \sa setQ(), setR(), p()
    */

    /*!
        \fn QVector3D QTriangle3D::q() const

        Returns the value of the Q vertex on the triangle.

        \sa p(), r(), setQ()
    */

    /*!
        \fn void QTriangle3D::setQ(const QVector3D &point)

        Sets the value of the Q vertex on the triangle \a point.

        \sa setP(), setR(), q()
    */


    /*!
        \fn QVector3D QTriangle3D::r() const

        Returns the value of the R vertex on the triangle.

        \sa p(), q(), setR()
    */

    /*!
        \fn void QTriangle3D::setR(const QVector3D &point)

        Sets the value of the R vertex on the triangle \a point.

        \sa setP(), setQ(), r()
    */

    /*!
        \fn QPlane3D QTriangle3D::plane() const

        Returns the plane in which the triangle lies.

        \sa QPlane3D
    */

    /*!
        \fn QVector3D QTriangle3D::center() const

        Returns the center of the triangle, which is the geometric average of the
        three vertices.
    */

    /*!
        \fn QVector3D QTriangle3D::faceNormal() const

        Returns the vector normal to this triangle, computed from the
        cross-product of P-Q and Q-R.  The result is not normalized.
    */

    bool uvInTriangle(const QVector2D &c)
    {
        if (c.x() < 0.0f || c.x() > 1.0f)
            return false;
        if (c.y() < 0.0f || c.y() > 1.0f)
            return false;
        if ((c.x() + c.y()) > 1.0f)
            return false;
        return true;
    }

    /*!
        Returns true if this triangle contains \a point; false otherwise.
        To contain the \a point means that:
        \list
        \li the point lies on the same plane as the triangle, and
        \li the point
            \list
            \li lies either wholly within the triangle, or
            \li lies on one of the sides, or
            \li coincides with one of the 3 vertices
            \endlist
        \endlist

        \sa intersects()
    */
    bool contains(const QVector3D &point)
    {
        // Check if the point is on the triangle's plane first.
        QVector3D normal = QVector3D::crossProduct(b - a, c - b);
        if (!qFuzzyIsNull(float(QVector3D::dotProduct(normal.normalized(), a - point))))
            return false;

        // Compute the barycentric co-ordinates and use them to determine
        // if the point is within the triangle.
        return uvInTriangle(uv(point));
    }

    /*!
        Returns true if the \a ray intersects this triangle; false otherwise.

        This function will return false if the triangle is degenerate.

        \sa contains(), intersection()
    */
    bool intersects(const QRay3D &ray)
    {

        QPlane3D plane =  QPlane3D(a, b, c);

        float t = plane.intersection(ray);

        if (qIsNaN(t))
            return false;
        return uvInTriangle(uv(ray.getPointAt(t)));
    }

    /*!
        Returns the t value at which \a ray intersects this triangle, or
        not-a-number if there is no intersection.

        When the \a ray intersects this triangle, the return value is a
        parametric value that can be passed to QRay3D::point() to determine
        the actual intersection point, as shown in the following example:

        \code
        float t = triangle.intersection(ray);
        QVector3D pt;
        if (qIsNaN(t)) {
            qWarning("no intersection occurred");
        else
            pt = ray.point(t);
        \endcode

        \sa intersects(), contains(), QRay3D::point()
     */
    float intersection(const QRay3D &ray)
    {
        float t = plane().intersection(ray);

        if (qIsNaN(t) || contains(ray.getPointAt(t)))
            return t;

        return qSNaN();
    }

    /*!
        Transforms the points of this triangle according to \a matrix.

        \sa transformed()
    */
    void transform(const QMatrix4x4 &matrix)
    {
        a = matrix * a;
        b = matrix * b;
        c = matrix * c;
    }

    /*!
        Returns a new triangle that results from transforming this
        one using \a matrix.

        \sa transform()
    */
    QTriangle3D transformed(const QMatrix4x4 &matrix)
    {
        return QTriangle3D(matrix * a, matrix * b, matrix * c);
    }

    /*!
        Returns the (u, v) barycentric co-ordinates of \a point within
        this triangle.

        The returned barycentric co-ordinates will be (1, 0) at p(),
        (0, 1) at q(), and (0, 0) at r().  Technically, barycentric
        co-ordinates have three components with the corners at
        (1, 0, 0), (0, 1, 0), and (0, 0, 1).  However, the third
        component is always equal to (1 - u - v) so we do not return it.

        The typical use case for this function is to convert an intersection
        point on a triangle into the texture co-ordinate corresponding to
        that point.  If \c p, \c q, and \c r are the points on the triangle,
        with corresponding texture co-ordinates \c tp, \c tq, and \c tr,
        then the texture co-ordinate \c tc of \a point can be determined
        by the following code:

        \code
        QTriangle3D triangle(p, q, r);
        QVector2D uv = triangle.uv(point);
        QVector2D tc = uv.x() * tp + uv.y() * tq + (1 - uv.x() - uv.y()) * tr;
        \endcode

        \sa contains(), intersection()
    */
    QVector2D uv(const QVector3D &point)
    {
        // Algorithm from: http://www.blackpawn.com/texts/pointinpoly/default.html
        // More: http://en.wikipedia.org/wiki/Barycentric_coordinates_(mathematics)
        QVector3D rq = b - c;
        QVector3D rp = a - c;
        QVector3D pp = point - c;

        float dot_rq_rq = QVector3D::dotProduct(rq, rq);
        float dot_rq_rp = QVector3D::dotProduct(rq, rp);
        float dot_rq_pp = QVector3D::dotProduct(rq, pp);
        float dot_rp_rp = QVector3D::dotProduct(rp, rp);
        float dot_rp_pp = QVector3D::dotProduct(rp, pp);

        float det = dot_rq_rq * dot_rp_rp - dot_rq_rp * dot_rq_rp;

        if (qFuzzyIsNull(float(det)))
        {
            // The point is probably not in the triangle, or the triangle
            // is degenerate.  Return an out of range value for (u, v) so
            // that contains() will fail when this case happens.
            return QVector2D(-1.0f, -1.0f);
        }
        return QVector2D((dot_rq_rq * dot_rp_pp - dot_rq_rp * dot_rq_pp) / det,
                         (dot_rp_rp * dot_rq_pp - dot_rq_rp * dot_rp_pp) / det);
    }

    /*!
        \fn bool QTriangle3D::operator==(const QTriangle3D &other)

        Returns true if this triangle is the same as \a other; false otherwise.

        \sa operator!=()
    */

    /*!
        \fn bool QTriangle3D::operator!=(const QTriangle3D &other)

        Returns true if this triangle is not the same as \a other; false otherwise.

        \sa operator==()
    */

    /*!
        \fn bool qFuzzyCompare(const QTriangle3D &triangle1, const QTriangle3D &triangle2)
        \relates QTriangle3D

        Returns true if \a triangle1 and \a triangle2 are almost equal;
        false otherwise.
    */

    /*

    inline bool qFuzzyCompare( QTriangle3D triangle1,  QTriangle3D triangle2)
    {
        return qFuzzyCompare(triangle1.A(), triangle2.A()) &&
               qFuzzyCompare(triangle1.B(), triangle2.B()) &&
               qFuzzyCompare(triangle1.C(), triangle2.C());
    }

    */




};

class QGeomath3D
{
public:
    //Compute intersection vertex between a ray and a triangle. Returne false if it doesn't intersect.
    bool intersectionRayTriangle(const QVector3D &s1, const QVector3D &s2, const QVector3D &v1, const QVector3D &v2, const QVector3D &v3, const QVector3D &normal, QVector3D &vertInter)
    {
        float dist1 = QVector3D::dotProduct(s1-v1, normal);
        float dist2 = QVector3D::dotProduct(s2-v1, normal);
        if ((dist1*dist2)>= 0.0f)
            return false;
        if (dist1==dist2)        //ray parallel to triangle plane
            return false;
        //intersection between ray and triangle
        vertInter = s1+(s2-s1)*(-dist1/(dist2-dist1));
        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v2-v1), vertInter-v1)<0.0f)
            return false;
        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v3-v2), vertInter-v2)<0.0f)
            return false;
        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v1-v3), vertInter-v1)<0.0f)
            return false;
        return true;
    }

    //Intersection point between a ray and a plane
    QVector3D intersectionRayPlane(const QVector3D &s1,const QVector3D &s2, const QVector3D &v1, const QVector3D &normal)
    {
        float dist1 = QVector3D::dotProduct(s1-v1, normal);
        float dist2 = QVector3D::dotProduct(s2-v1, normal);
        if ((dist1*dist2)>= 0.0f)
            return QVector3D();
        if (dist1==dist2)        //ray parallel to triangle plane
            return QVector3D();
        //intersection between ray and triangle
        return s1+(s2-s1)*(-dist1/(dist2-dist1));
    }

    //Projection of mouse coordinate on sphere unit
    QVector3D mouseOnUnitSphere(const QPointF &mouseXY)
    {
        float tempZ = 1-mouseXY.x()*mouseXY.x()-mouseXY.y()*mouseXY.y();

        float mouseZ= tempZ>0 ? sqrtf(tempZ) : 0;

        QVector3D sourisSphere(mouseXY.x(), mouseXY.y(), mouseZ);

        return sourisSphere.normalized();
    }

    // Normalize coordinate mouse between 0 and 1

    QPointF normalizedMouse(const QPointF &mouseXY, const QSizeF viewport)
    {
        return QPointF(2.0*mouseXY.x()/viewport.width()-1.0,1.0-(2.0*mouseXY.y()/viewport.height()));
    }

    // Compute the ray normal to screen (through mouse)
    void getRayNormalToScreen(const QPointF &mouseXY, const QSizeF &viewport, QVector3D &vertexNear, QVector3D &vertexFar)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY, dZ;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);
        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),0.0, model, projection, view, &dX, &dY, &dZ);
        vertexNear.setX((float)dX);
        vertexNear.setY((float)dY);
        vertexNear.setZ((float)dZ);
        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),1.0, model, projection, view, &dX, &dY, &dZ);
        vertexFar.setX((float)dX);
        vertexFar.setY((float)dY);
        vertexFar.setZ((float)dZ);
    }

    // Compute the unit vector coplanar to screen
    QVector3D getCoplanarVectorOnScreen(const QPointF &mouseXYOld, const QPointF &mouseXYNew, const QSizeF &viewport)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX1, dX2, dY1, dY2, dZ1, dZ2;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);
        gluUnProject (mouseXYOld.x(), viewport.height()-mouseXYOld.y(), 0.0, model, projection, view, &dX1, &dY1, &dZ1);
        gluUnProject (mouseXYNew.x(), viewport.height()-mouseXYNew.y(), 0.0, model, projection, view, &dX2, &dY2, &dZ2);
        return QVector3D(dX2 - dX1, dY2 - dY1, dZ2 -dZ1).normalized();
    }

    // Compute the projection of a vertex on a line
    QVector3D vertexOnLine(const QVector3D &vertex, const QVector3D &vertexNear, const QVector3D &vertexFar)
    {
        QVector3D ab = vertexFar - vertexNear;
        float abSquared = ab.lengthSquared();
        float dot = QVector3D::dotProduct(ab, (vertex - vertexNear));
        float t = dot / abSquared;
        return (vertexNear + ab*t);
    }

    // Project the mouse coordinate into the world coordinate at a given z
    QVector3D point2Dto3D(const QPointF &mouseXY, const QSizeF &viewport, float z)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY, dZ;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);
        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(), z, model, projection, view, &dX, &dY, &dZ);
        return QVector3D(dX, dY, dZ);
    }

    // Project a vertex onto the screen
    QPointF point3Dto2D(const QVector3D &vertex, const QSizeF &viewport, double &z)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);
        gluProject(vertex.x(), vertex.y(), vertex.z(), model, projection, view, &dX, &dY, &z);
        return QPointF(dX, viewport.height()-dY);
    }

    // Return any perpendicular vector to another vector
    QVector3D getPerpendicularVector(const QVector3D &vec)
    {
        QVector3D result;

        if (vec.x() == 0.0f || vec.y() == 0.0f || vec.z() == 0.0f)
        {
            if (vec.x() == 0.0f)
                result.setX(1.0f);
            else if (vec.y() == 0.0f)
                result.setY(1.0f);
            else
                result.setZ(1.0f);
        }
        else
        {
            result.setX(vec.z());
            result.setY(vec.z());
            result.setZ(-(vec.x()+vec.y()));
            result.normalize();
        }

        return result;
    }

    // Compute the bounding box of a triangle defined by three vertices
    QBox3D computeTriangleAabb(const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        float minX = std::min(std::min(v1.x(),v2.x()),v3.x());
        float minY = std::min(std::min(v1.y(),v2.y()),v3.y());
        float minZ = std::min(std::min(v1.z(),v2.z()),v3.z());

        float maxX = std::max(std::max(v1.x(),v2.x()),v3.x());
        float maxY = std::max(std::max(v1.y(),v2.y()),v3.y());
        float maxZ = std::max(std::max(v1.z(),v2.z()),v3.z());

        return QBox3D(QVector3D(minX, minY, minZ), QVector3D(maxX, maxY, maxZ));
    }

    // Compute the inradius (radius of incircle) of a triangle
    float computeInradiusSquared(const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        float a = (v1-v2).length();
        float b = (v1-v3).length();
        float c = (v2-v3).length();

        float halfPerimeter = (a+b+c)*0.5f;

        return (1/halfPerimeter)*(halfPerimeter-a)*(halfPerimeter-b)*(halfPerimeter-c);
    }

    // If point is inside the triangle, test the sum of the areas
    bool pointInsideTriangle(const QVector3D &point, const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        QVector3D vec1  = v1-v2;
        QVector3D vec2  = v1-v3;
        QVector3D vecP1 = point-v2;
        QVector3D vecP2 = point-v3;

        float total = QVector3D::crossProduct(vec1, vec2).length();
        float area1 = QVector3D::crossProduct(vec1, vecP1).length();
        float area2 = QVector3D::crossProduct(vec2, vecP2).length();
        float area3 = QVector3D::crossProduct(vecP1, vecP2).length();
        if(fabs(total-(area1+area2+area3))<0.0001f) //magic epsilon...
            return true;
        else
            return false;
    }

    // If a sphere intersect a triangle
    bool sphereIntersectTriangle(const QVector3D &point, float radiusSq, const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        if(distanceToSegment(point,v1,v2)<radiusSq) return true;
        if(distanceToSegment(point,v2,v3)<radiusSq) return true;
        if(distanceToSegment(point,v1,v3)<radiusSq) return true;
        return false;
    }

    // Minimum distance to a segment
    float distanceToSegment(const QVector3D &point, const QVector3D &v1, const QVector3D &v2)
    {
        float length = (v2-v1).lengthSquared();
        float t = QVector3D::dotProduct(point-v1,v2-v1)/length;
        if(t < 0.0) return (point-v1).lengthSquared();
        if(t> 1.0) return (point-v2).lengthSquared();
        QVector3D ptProj = v1 + t*(v2-v1);
        return (point-ptProj).lengthSquared();
    }

};

class QArchBall3D
{
public:

    QVector3D   startVector; //Saved click vector
    QVector3D   endVector;   //Saved drag vector

    GLfloat     AdjustWidth;    //Mouse bounds width
    GLfloat     AdjustHeight;   //Mouse bounds height


    //const float PI2 = 2.0*3.1415926535f;								// PI Squared

    QQuaternion quaternion;

    QMatrix4x4 lastRotationMatrix;
    QMatrix4x4 newRotationMatrix;


    //Create/Destroy
    QArchBall3D(GLfloat windowWidth, GLfloat windowHeight)
    {
        //Clear initial values
        startVector = QVector3D(0,0,0);
        endVector   = QVector3D(0,0,0);

        //Set initial bounds
        setBounds(windowWidth, windowHeight);

        lastRotationMatrix.setToIdentity();
        newRotationMatrix.setToIdentity();

    }

    ~QArchBall3D()
    {

    }

    //Set new bounds
    void setBounds(GLfloat windowWidth, GLfloat windowHeight)
    {
        Q_ASSERT((windowWidth > 1.0f) && (windowHeight > 1.0f));

        //Set adjustment factor for width/height
       AdjustWidth  = 1.0f / ((windowWidth  - 1.0f) * 0.5f);
       AdjustHeight = 1.0f / ((windowHeight - 1.0f) * 0.5f);
    }

    QVector3D mapToSphere(const QPointF NewPt) const
    {
        QPointF TempPt;
        GLfloat length;

        //Copy paramter into temp point
        TempPt = NewPt;

        //Adjust point coords and scale down to range of [-1 ... 1]
        TempPt.setX((TempPt.x() * AdjustWidth)  - 1.0f);
        TempPt.setY(1.0f - (TempPt.y() * AdjustHeight));

        //Compute the square of the length of the vector to the point from the center
        length      = (TempPt.x() * TempPt.x()) + (TempPt.y() * TempPt.y());

         QVector3D newVector;
        //If the point is mapped outside of the sphere... (length > radius squared)
        if (length > 1.0f)
        {
            GLfloat norm;

            //Compute a normalizing factor (radius / sqrt(length))
            norm    = 1.0f / sqrt(length);

            //Return the "normalized" vector, a point on the sphere
            newVector = QVector3D(TempPt.x() * norm,TempPt.y() * norm,0.0f);
        }
        else    //Else it's on the inside
        {
            //Return a vector to a point mapped inside the sphere sqrt(radius squared - length)
            newVector =  QVector3D( TempPt.x(),TempPt.y(),sqrt(1.0f - length));

        }

        return newVector;
    }


    //Mouse down
    virtual void mousePressEvent(QMouseEvent * event)
    {
        lastRotationMatrix = newRotationMatrix;

        QPointF NewPt =  QPointF(event->pos());

        //Map the point to the sphere
        startVector =  mapToSphere(NewPt);
    }

    //Mouse drag, calculate rotation
    virtual void mouseMoveEvent(QMouseEvent * event)
    {
        QPointF newPoint =  QPointF(event->pos());
        //Map the point to the sphere
        endVector = mapToSphere(newPoint);
        //Return the quaternion equivalent to the rotation
        //if (NewRot)
        {
            QVector3D  Perp;

            //Compute the vector perpendicular to the begin and end vectors
            Perp = QVector3D::crossProduct(startVector, endVector);

            //Compute the length of the perpendicular vector
            if (Perp.length() > Epsilon)    //if its non-zero
            {
                //so return the perpendicular vector as the transform after all

                //In the quaternion values, w is cosine (theta / 2), where theta is rotation angle
                float w = QVector3D::dotProduct(startVector, endVector);

                quaternion =  QQuaternion(w,Perp);
            }
            else    //if its zero
            {
                //The begin and end vectors coincide, so return an identity transform

                quaternion = QQuaternion(0,0,0,0);

            }
        }


    }

    virtual void computeRotationMatrix()
    {
        // Convert Quaternion Into Matrix3fT
        newRotationMatrix.rotate(quaternion);
        //Matrix3fSetRotationFromQuat4f(&ThisRot, &ThisQuat);

        //Matrix3fMulMatrix3f(&ThisRot, &LastRot);

        // Accumulate Last Rotation Into This One
        newRotationMatrix = newRotationMatrix * lastRotationMatrix;

        //Matrix4fSetRotationFromMatrix3f(&Transform, &ThisRot); // Set Our Final Transform's Rotation From This One

    }
};

class QTransform3D
{
    bool m_dirty;
    QVector3D m_translation;
    QVector3D m_scale;
    QQuaternion m_rotation;
    QMatrix4x4 m_world;

public:

   QTransform3D()
   {
        m_dirty  =  true;

        m_scale =  QVector3D(1.0f, 1.0f, 1.0f);
   }


   // Accessors
   const QVector3D& translation() const { return m_translation; }
   const QVector3D& scale() const { return m_scale; }
   const QQuaternion& rotation() const { return m_rotation; }
   const QMatrix4x4 &toMatrix()
   {
     if (m_dirty)
     {
       m_dirty = false;
       m_world.setToIdentity();
       m_world.translate(m_translation);
       m_world.rotate(m_rotation);
       m_world.scale(m_scale);
     }
     return m_world;
   }



    // Transform By (Add/Scale)
    void translate(float dx, float dy,float dz) { translate(QVector3D(dx, dy, dz)); }
    void scale(float dx, float dy,float dz) { scale(QVector3D(dx, dy, dz)); }
    void scale(float factor) { scale(QVector3D(factor, factor, factor)); }
    void rotate(float angle, const QVector3D &axis) { rotate(QQuaternion::fromAxisAndAngle(axis, angle)); }
    void rotate(float angle, float ax, float ay,float az) { rotate(QQuaternion::fromAxisAndAngle(ax, ay, az, angle)); }
    void grow(float dx, float dy, float dz) { grow(QVector3D(dx, dy, dz)); }
    void grow(float factor) { grow(QVector3D(factor, factor, factor)); }

    // Transform To (Setters)
    void setTranslation(float x, float y, float z) { setTranslation(QVector3D(x, y, z)); }
    void setScale(float x, float y, float z) { setScale(QVector3D(x, y, z)); }
    void setScale(float k) { setScale(QVector3D(k, k, k)); }
    void setRotation(float angle, const QVector3D &axis) { setRotation(QQuaternion::fromAxisAndAngle(axis, angle)); }
    void setRotation(float angle, float ax, float ay, float az) { setRotation(QQuaternion::fromAxisAndAngle(ax, ay, az, angle)); }


    // Transform By (Add/Scale)
    void translate(const QVector3D &dt)
    {
      m_dirty = true;
      m_translation += dt;
    }

    void scale(const QVector3D &ds)
    {
      m_dirty = true;
      m_scale *= ds;
    }

    void rotate(const QQuaternion &dr)
    {
      m_dirty = true;
      m_rotation = dr * m_rotation;
    }

    void grow(const QVector3D &ds)
    {
      m_dirty = true;
      m_scale += ds;
    }

    // Transform To (Setters)
    void setTranslation(const QVector3D &t)
    {
      m_dirty = true;
      m_translation = t;
    }

    void setScale(const QVector3D &s)
    {
      m_dirty = true;
      m_scale = s;
    }

    void setRotation(const QQuaternion &r)
    {
      m_dirty = true;
      m_rotation = r;
    }


};

class QTrackBall3D
{
public:
    enum TrackMode
    {
        Plane,
        Sphere,
    };

private:
    QQuaternion m_rotation;
    QVector3D m_axis;
    float m_angularVelocity;

    QPointF m_lastPos;
    QTime m_lastTime;
    bool m_paused;
    bool m_pressed;
    TrackMode m_mode;


public:

    QTrackBall3D(TrackMode mode)
    {
        m_angularVelocity=(0);
        m_paused=(false);
        m_pressed=(false);
        m_mode=(mode);
        m_axis = QVector3D(0, 1, 0);
        m_rotation = QQuaternion();
        m_lastTime = QTime::currentTime();
    }

    QTrackBall3D(float angularVelocity, const QVector3D& axis, TrackMode mode)
    {
        m_axis     =axis;
        m_angularVelocity=angularVelocity;
        m_paused  = false;
        m_pressed = false;
        m_mode    = mode ;
        m_rotation = QQuaternion();
        m_lastTime = QTime::currentTime();
    }


    QQuaternion rotation() const
    {
       if (m_paused || m_pressed)
           return m_rotation;

       QTime currentTime = QTime::currentTime();

       float angle = m_angularVelocity * m_lastTime.msecsTo(currentTime);

       return QQuaternion::fromAxisAndAngle(m_axis, angle) * m_rotation;

    }

   /*


    void push(const QPointF& p, const QQuaternion &)
    {
        m_rotation = rotation();
        m_pressed = true;
        m_lastTime = QTime::currentTime();
        m_lastPos = p;
        m_angularVelocity = 0.0f;
    }

    void move(const QPointF& p, const QQuaternion &transformation)
    {
        if (!m_pressed)
            return;

        QTime currentTime = QTime::currentTime();
        int msecs = m_lastTime.msecsTo(currentTime);
        if (msecs <= 20)
            return;

        switch (m_mode)
        {
        case Plane:
            {
                QLineF delta(m_lastPos, p);
                m_angularVelocity = 180*delta.length() / (M_PI*msecs);
                m_axis = QVector3D(-delta.dy(), delta.dx(), 0.0f).normalized();
                m_axis = transformation.rotatedVector(m_axis);
                m_rotation = QQuaternion::fromAxisAndAngle(m_axis, 180 / M_PI * delta.length()) * m_rotation;
            }
            break;


        case Sphere:
            {
                QVector3D lastPos3D = QVector3D(m_lastPos.x(), m_lastPos.y(), 0.0f);

                float sqrZ = 1 - QVector3D::dotProduct(lastPos3D, lastPos3D);

                if (sqrZ > 0)
                    lastPos3D.setZ(sqrt(sqrZ));
                else
                    lastPos3D.normalize();

                QVector3D currentPos3D = QVector3D(p.x(), p.y(), 0.0f);

                sqrZ = 1 - QVector3D::dotProduct(currentPos3D, currentPos3D);
                if (sqrZ > 0)
                    currentPos3D.setZ(sqrt(sqrZ));
                else
                    currentPos3D.normalize();

                m_axis = QVector3D::crossProduct(lastPos3D, currentPos3D);

                float angle = 180 / M_PI * asin(sqrt(QVector3D::dotProduct(m_axis, m_axis)));

                m_angularVelocity = angle / msecs;

                m_axis.normalize();

                m_axis = transformation.rotatedVector(m_axis);

                m_rotation = QQuaternion::fromAxisAndAngle(m_axis, angle) * m_rotation;
            }
            break;
        }


        m_lastPos = p;
        m_lastTime = currentTime;
    }

    void release(const QPointF& p, const QQuaternion &transformation)
    {
        // Calling move() caused the rotation to stop if the framerate was too low.
        move(p, transformation);
        m_pressed = false;
    }

    */

    virtual void mousePressEvent(QMouseEvent * event)
    {
        m_rotation = rotation();
        m_pressed = true;
        m_lastTime = QTime::currentTime();
        m_lastPos = QPointF(event->pos());
        m_angularVelocity = 0.0f;
    }

    virtual void mouseMoveEvent(QMouseEvent * event, const QQuaternion &transformation)
    {
        if (!m_pressed)
            return;

        QPointF p = QPointF(event->pos());

        QTime currentTime = QTime::currentTime();

        int msecs = m_lastTime.msecsTo(currentTime);

        if (msecs <= 20)
            return;

        switch (m_mode)
        {

        case Plane:
        {
            QLineF delta(m_lastPos, p);

            m_angularVelocity = 180*delta.length() / (M_PI*msecs);

            m_axis = QVector3D(-delta.dy(), delta.dx(), 0.0f).normalized();

            m_axis = transformation.rotatedVector(m_axis);

            m_rotation = QQuaternion::fromAxisAndAngle(m_axis, 180 / M_PI * delta.length()) * m_rotation;
         }

            break;


        case Sphere:
        {
            QVector3D lastPos3D = QVector3D(m_lastPos.x(), m_lastPos.y(), 0.0f);


            float sqrZ = 1 - QVector3D::dotProduct(lastPos3D, lastPos3D);


            if (sqrZ > 0)
                lastPos3D.setZ(sqrt(sqrZ));
            else
                lastPos3D.normalize();


            QVector3D currentPos3D = QVector3D(p.x(), p.y(), 0.0f);


            sqrZ = 1 - QVector3D::dotProduct(currentPos3D, currentPos3D);

            if (sqrZ > 0)
                currentPos3D.setZ(sqrt(sqrZ));
            else
                currentPos3D.normalize();


            m_axis = QVector3D::crossProduct(lastPos3D, currentPos3D);


            float angle = 180 / M_PI * asin(sqrt(QVector3D::dotProduct(m_axis, m_axis)));


            m_angularVelocity = angle / msecs;

            m_axis.normalize();

            m_axis = transformation.rotatedVector(m_axis);

            m_rotation = QQuaternion::fromAxisAndAngle(m_axis, angle) * m_rotation;

        }

            break;


        }


        m_lastPos = p;
        m_lastTime = currentTime;
    }

    virtual void mouseReleaseEvent(QMouseEvent * event, const QQuaternion &transformation)
    {
        // Calling move() caused the rotation to stop if the framerate was too low.
        m_rotation = rotation();
        m_pressed = true;
        m_lastTime = QTime::currentTime();
        m_lastPos = QPointF(event->pos());
        m_angularVelocity = 0.0f;
        m_pressed = false;
    }




    void start()
    {
        m_lastTime = QTime::currentTime();
        m_paused = false;
    }

    void stop()
    {
        m_rotation = rotation();
        m_paused = true;
    }
};

class QCamera3D
{
    int width;
    int height;

    // pixel coordinates (centre-based) of the viewport's corners
    int _viewport_x1;
    int _viewport_y1;
    int _viewport_x2;
    int _viewport_y2;

    // pixel coordinates (centre-based) of the viewport's centre.
    // These will be half-integers if the viewport's dimensions are even.

    float _viewport_cx;
    float _viewport_cy;

    // the radius of the viewport, in pixels
    float viewportRadiusInPixels;
    float viewportRadius;

    // dimensions of the viewport, in world space, measured on the near plane

    float viewportWidth;
    float viewportHeight;

    QVector3D sceneCentre;
    float sceneRadius;

    float minimumFeatureSize;
    float zNear;
    float zFar; // clipping planes

    QVector3D position; // point of view
    QVector3D target;   // point of interest

    QVector3D up;      // a unit vector, perpendicular to the line-of-sight
    QVector3D _ground;  // a unit vector perpendicular to the ground plane
    QVector3D _initialGround;

    // constants that can be tuned
    float zNearPlaneFactor;
    float zFarPlaneFactor;

    float Fov_SemiAngle;
    float fudgeFactor;

    float rotationSpeedInDegreesPerRadius; // for yaw, pitch, roll
    float orbitingSpeedInDegreesPerRadius; // for orbit
    float pushThreshold;

public:


    QCamera3D( int width,int height,float scene_radius, const QVector3D& scene_centre = QVector3D(0,0,0) )
    {
      initialize( scene_centre,
                  scene_radius,
                  width,
                  height,
                  0, 0,
                  width - 1,
                  height - 1 );
    }

    QCamera3D( int width,int height,
           int viewport_x1, int viewport_y1, // centre-based coordinates
           int viewport_x2, int viewport_y2, // centre-based coordinates
           float scene_radius, const QVector3D& scene_centre = QVector3D(0,0,0)
    )
    {
      initialize(
         scene_centre,
         scene_radius,
         width, height,
         viewport_x1, viewport_y1, viewport_x2, viewport_y2
      );
    }

    QVector3D getPerpendicularVector(QVector3D p)
    {
       // Pick the two largest components,
       // permute them and negate one of them, and
       // replace the other (i.e. smallest) component with zero.

       float X = fabs(p.x());
       float Y = fabs(p.y());
       float Z = fabs(p.z());

       QVector3D v;

       if ( X < Y )
       {
          if ( Y < Z )
          {
             // X < Y < Z
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else if ( X < Z )
          {
             // X < Z <= Y
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else
          {
             // Z <= X < Y
             v = QVector3D( p.y(), -p.x(), 0 );
          }
       }
       else
       {
          if ( Z < Y )
          {
             // Z < Y <= X
             v = QVector3D( p.y(), -p.x(), 0 );
          }
          else if ( Z < X )
          {
             // Y <= Z < X
             v = QVector3D( p.z(), 0, -p.x() );
          }
          else
          {
             // Y <= X <= Z
             v = QVector3D( p.z(), 0, -p.x() );
          }
       }

       //#ifdef DEBUG
       //float dotProduct =QVector3D::dotProduct(v , p);
       //ASSERT_IS_EQUAL( dotProduct, 0 );
       //#endif

       return v;
    }



    void initialize(
      const QVector3D& scene_centre,

           float scene_radius,

           int width,
           int height,

           int viewport_x1,
           int viewport_y1,

           int viewport_x2,
           int viewport_y2
    )

    {

       // A good angle for the field-of-view is 30 degrees.
       // Setting this very small will give the user the impression
       // of looking through a telescope.
       // Setting it very big will give the impression of a wide-angle
       // lens, with strong foreshortening effects that are especially
       // noticeable near the edges of the viewport.
       Fov_SemiAngle   = M_PI * 15 / 180.0;

       // This should be a little greater than 1.0.
       // If it's set to one, the user will initially
       // just *barely* see all of the scene in the window
       // (assuming the scene is a sphere of radius scene_radius).
       fudgeFactor     = 1.1f;

       // This should be a little greater than 0.0.
       // If no minimum feature size is given by the user,
       //    minimum_feature_size = _nearPlaneFactor * scene_radius
      zNearPlaneFactor = 0.1f;

       // far_plane = _farPlaneFactor * scene_radius

      zFarPlaneFactor  = 15;

       // Used for yaw, pitch, roll.
       rotationSpeedInDegreesPerRadius = 150;

       // Used for orbit.
       orbitingSpeedInDegreesPerRadius = 300;

       // The target (or point-of-interest) of the camera is kept
       // at a minimal distance of
       //   _pushThreshold * near_plane
       // from the camera position.
       // This number should be greater than 1.0, to ensure
       // that the target is never clipped.
       pushThreshold = 1.3f;

      _initialGround = QVector3D( 0, 1, 0 );

      _initialGround.normalize();

      setSceneCentre( scene_centre );
      setSceneRadius( scene_radius );

      minimumFeatureSize = zNearPlaneFactor * sceneRadius;

      zNear = minimumFeatureSize;

      width  = width;
      height = height;

      _viewport_x1 = viewport_x1;
      _viewport_y1 = viewport_y1;
      _viewport_x2 = viewport_x2;
      _viewport_y2 = viewport_y2;

      resetCamera();

      resizeViewport( width, height,viewport_x1, viewport_y1, viewport_x2, viewport_y2 );
    }


    const QVector3D  & getPosition() const { return position; }
    const QVector3D  & getTarget() const { return target; }
    const QVector3D  & getUp() const { return up; }
    const QVector3D    getRight() const { QVector3D direction = ( target - position ).normalized(); return QVector3D::crossProduct(direction , up); }

    //int getViewportWidthInPixels() const { return width; }
    //int getViewportHeightInPixels() const { return height; }

    void setPositionAndOrientation( const QVector3D & pos, const QVector3D & direction, const QVector3D & _up )
    {
       position = pos;
       target   = pos + direction;
       up       = _up;
    }

    void setSceneCentre( const QVector3D& p )
    {
       sceneCentre = p;
    }

    // This causes the far plane to be recomputed.
    void setSceneRadius( float r )
    {
       if ( r <= 0 )
           return;

       if( r > 0 )
       {
           sceneRadius = r;

           zFar = zFarPlaneFactor * sceneRadius;
       }
    }

    // This causes the near plane to be recomputed.
    // Note that the argument passed in must be positive.
    // Also note that smaller arguments will pull the
    // near plane closer, but will also reduce the
    // z-buffer's precision.
    void setMinimumFeatureSize( float s )
    {
       if ( s <= 0 )
           return;

       if( s > 0 )
       {
           minimumFeatureSize = s;

           if( zNear > 0 )
           {
               float k = minimumFeatureSize / zNear;

               zNear   = minimumFeatureSize;

               viewportRadius *= k;

               computeViewportWidthAndHeight();
           }
       }
    }




   void resizeViewport(int width,int height )
   {
      resizeViewport( width, height,0, 0, width - 1, height - 1 );
   }

   void resizeViewport(int width,int height,

                       int viewport_x1,
                       int viewport_y1,

                       int viewport_x2,
                       int viewport_y2 )

   {
      if(( viewport_x1 < viewport_x2 )&& ( viewport_y1 < viewport_y2 ))
      {
          width  = width;
          height = height;

          _viewport_x1 = viewport_x1;
          _viewport_y1 = viewport_y1;

          _viewport_x2 = viewport_x2;
          _viewport_y2 = viewport_y2;


          _viewport_cx = ( _viewport_x1 + _viewport_x2 ) * 0.5;
          _viewport_cy = ( _viewport_y1 + _viewport_y2 ) * 0.5;

       #ifdef OPENGL_IS_CENTRE_BASED
          float viewport_radius_x = _viewport_cx - _viewport_x1;
          float viewport_radius_y = _viewport_cy - _viewport_y1;
       #else
          float viewport_radius_x = _viewport_cx - _viewport_x1 + 0.5f;
          float viewport_radius_y = _viewport_cy - _viewport_y1 + 0.5f;
       #endif
          viewportRadiusInPixels = ( viewport_radius_x < viewport_radius_y )
             ? viewport_radius_x
             : viewport_radius_y;

          computeViewportWidthAndHeight();

          // This function expects coordinates relative to an origin
          // in the lower left corner of the window (i.e. y+ is up).
       #ifdef OPENGL_IS_CENTRE_BASED
          // Also, the dimensions passed in should be between pixel centres.
       #else
          // The coordinates are edge-based.
          // Also, the dimensions passed in should be between pixel edges.
       #endif
          //
          // Say you have a window composed of the pixels marked with '.',
          // and want a viewport over the pixels marked with 'x':
          //
          //    ............
          //    ............
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    ............
          //    ............
          //    ............
          //
       #ifdef OPENGL_IS_CENTRE_BASED
          // You would have to call glViewport( 1, 3, 6, 4 );
       #else
          // You would have to call glViewport( 1, 3, 7, 5 );
       #endif
          //
          glViewport(
             _viewport_x1,
             height - 1 - _viewport_y2,
       #ifdef OPENGL_IS_CENTRE_BASED
             _viewport_x2 - _viewport_x1,
             _viewport_y2 - _viewport_y1
       #else
             _viewport_x2 - _viewport_x1 + 1,
             _viewport_y2 - _viewport_y1 + 1
       #endif
          );

      }
   }






   void computeViewportWidthAndHeight()
   {

     // recompute _viewport_width, _viewport_height
     //
     int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

     int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

     if ( viewport_width_in_pixels < viewport_height_in_pixels )
     {
        viewportWidth = 2.0 * viewportRadius;
        viewportHeight = viewportWidth
  #ifdef OPENGL_IS_CENTRE_BASED
           * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
  #else
           * viewport_height_in_pixels / (float)viewport_width_in_pixels;
  #endif
     }
     else
     {
        viewportHeight = 2.0 * viewportRadius;
        viewportWidth = viewportHeight
  #ifdef OPENGL_IS_CENTRE_BASED
           * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
  #else
           * viewport_width_in_pixels / (float)viewport_height_in_pixels;
  #endif
     }
  }





   // Clients that want to, for example, use this class to draw
   // 3D graphics within a smaller viewport on top of a larger
   // 2D graphical scene (such as surrounding widgets),
   // can use these methods to prepare for and clean up after,
   // respectively, drawing 3D stuff.
   void pushViewportAndTransform(
      int width, int height,
      int viewport_x1, int viewport_y1,
      int viewport_x2, int viewport_y2,
      int originalViewport[4]
   ) {
      glGetIntegerv( GL_VIEWPORT, originalViewport );
      resizeViewport(
         width, height,
         viewport_x1, viewport_y1,
         viewport_x2, viewport_y2
      );
      glMatrixMode( GL_PROJECTION );
      glPushMatrix();
      transform();
   }

   void popViewportAndTransform( int originalViewport[4] )
   {
      glMatrixMode( GL_PROJECTION );
      glPopMatrix();
      glMatrixMode( GL_MODELVIEW );
      glViewport( originalViewport[0], originalViewport[1],originalViewport[2],originalViewport[3]);
   }



   // Moves the camera forward or backward.  Some refer to
   // this as "tracking" the camera.
   // If the boolean flag is true, the target (or point of interest)
   // is moved with the camera, keeping the distance between the two
   // constant.


   void dollyCameraForward( float delta_pixels, bool pushTarget )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit = viewportRadiusInPixels / translationSpeedInUnitsPerRadius;

      float dollyDistance = delta_pixels / pixelsPerUnit;

      if ( ! pushTarget )
      {
         distance_from_target -= dollyDistance;

         if ( distance_from_target < pushThreshold*zNear )
         {
            distance_from_target = pushThreshold*zNear;
         }
      }

      position += direction * dollyDistance;


      target    = position + direction * distance_from_target;
   }

   // Changes the elevation angle of the camera.
   // Some refer to this as "tilting" the camera.

   void pitchCameraUp( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle   = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t   = target - position;

      QVector3D right = QVector3D::crossProduct((p2t.normalized()) , up);

      QMatrix4x4 m;

      m.rotate( angle, right );

      p2t    = m * p2t;

      up     = m * up;

      target = position + p2t;
   }




   // Changes the azimuth angle of the camera.
   // Some refer to this as "panning" the camera.

   void yawCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels  / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t = target - position;

      QMatrix4x4 m;
      m.rotate( -angle, _ground );

      p2t    = m*p2t;

      up     = m*up;

      target = position + p2t;
   }




   // Rolls the camera.

   void rollCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D direction = (target - position).normalized();

      QMatrix4x4 m;
      m.rotate( angle, direction );

      _ground = m * _ground;

      up = m * up;
   }




   // Rotates the camera toward the given point.

   void lookAt( const QVector3D& p )
   {
      // FIXME: we do not check if the target point is too close
      // to the camera (i.e. less than _pushThreshold * near_plane ).
      // If it is, perhaps we should dolly the camera away from the
      // target to maintain the minimal distance.

      target            = p;

      QVector3D direction = (target - position).normalized();

      QVector3D right     = ( QVector3D::crossProduct(direction , _ground) ).normalized();

      up                  = QVector3D::crossProduct(right , direction);

      up.normalize();
      //ASSERT_IS_NORMALIZED( up );
   }


   // Uses the z-buffer to find the nearest rendered pixel,
   // and makes the camera look at it.

   void zBufferLookAt( int pixel_x, int pixel_y )
   {

      int W = _viewport_x2 - _viewport_x1 + 1;
      int H = _viewport_y2 - _viewport_y1 + 1;

      GLfloat * zbuffer = new GLfloat[ W * H ];

      // FIXME: we want to fetch the z-buffer of the most
      // recently rendered image.  Unfortunately, this code
      // probably grabs the back z-buffer, rather than the
      // front z-buffer, which (if I'm not mistaken) is what we want.
      // FIXME: instead of grabbing the whole buffer, we should just
      // grab a small region around the pixel of interest.
      // Grabbing the whole buffer is very slow on
      // some Iris machines (e.g. Indigo2).
      glReadPixels(
         _viewport_x1,
         height - 1 - _viewport_y2,
         W, H,
         GL_DEPTH_COMPONENT, GL_FLOAT, zbuffer
      );

      // // Print contents of z-buffer (for debugging only).
      // for ( int b = H-1; b >= 0; --b ) {
      //    for ( int a = 0; a < W; ++a ) {
      //       printf("%c",zbuffer[ b*W + a ]==1?'.':'X');
      //    }
      //    puts("");
      // }

      // Keep in mind that zbuffer[0] corresponds to the lower-left
      // pixel of the viewport, *not* the upper-left pixel.

      // Transform the pixel passed in so that it is
      // in the z-buffer's coordinate system.
      pixel_x -= _viewport_x1;
      pixel_y  = H - 1 - (pixel_y - _viewport_y1);

      // Assume, as is typically the case, that the z-buffer was
      // cleared with a value of 1.0f (the maximum z value).
      // Also assume that any pixels containing a value of 1.0f
      // have this value because no rendered geometry covered them.
      // Now, search outward from the pixel passed in, in larger
      // and larger rectangles, for a pixel with a z value
      // less than 1.0f.

      if( 0 <= pixel_x && pixel_x < W && 0 <= pixel_y && pixel_y < H )
      {
          // the search rectangle
          int x1 = pixel_x, y1 = pixel_y;
          int x2 = x1, y2 = y1;

          int x,y,x0=W/2,y0=H/2;
          int min, max;
          float z = 1;
          while ( z == 1 )
          {
             // top edge of rectangle
             if ( y1 >= 0 )
             {
                y = y1;

                min = x1 < 0 ? 0 : x1;

                max = x2 >= W ? W-1 : x2;

                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // bottom edge of rectangle
             if ( y2 < H )
             {
                y = y2;
                min = x1 < 0 ? 0 : x1;
                max = x2 >= W ? W-1 : x2;
                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // left edge of rectangle
             if ( x1 >= 0 )
             {
                x = x1;
                min = y1 < 0 ? 0 : y1;
                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // right edge of rectangle
             if ( x2 < W )
             {
                x = x2;

                min = y1 < 0 ? 0 : y1;

                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }

             // grow the rectangle
             --x1;  --y1;
             ++x2;  ++y2;

             // is there nothing left to search ?
             if ( y1 < 0 && y2 >= H && x1 < 0 && x2 >= W )
                break;
          }

          if ( z < 1 )
          {
             // compute point in clipping space
       #ifdef OPENGL_IS_CENTRE_BASED
             QVector4D pc( 2*x0/(float)(W-1)-1, 2*y0/(float)(H-1)-1, 2*z-1 ,1);
       #else
             // The +0.5f here is to convert from centre-based coordinates
             // to edge-based coordinates.
             QVector4D pc( 2*(x0+0.5f)/(float)W-1, 2*(y0+0.5f)/(float)H-1, 2*z-1,1 );
       #endif



             // compute inverse view transform
             QMatrix4x4 M;
             //M.setToLookAt( position, target, up, true );
             M.lookAt( position, target, up );

             // compute inverse perspective transform
             QMatrix4x4 M2;
             /*
             M2.setToFrustum(
                - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                zNear, zFar,
                true
             );
             */

             M2.frustum(- 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                        - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                        zNear, zFar   );

             // compute inverse of light transform
             M = M * M2;

             // compute point in world space
             QVector4D t0 = M * pc;

             QVector3D t( t0.x()/t0.w(), t0.y()/t0.w(), t0.z()/t0.w() );

             lookAt( t );
          }

      }

      delete [] zbuffer;
      zbuffer = 0;
   }


   // Returns the ray through the centre of the given pixel.
   //Ray computeRay( int pixel_x, int pixel_y ) const;  // centre-based coordinates

   QRay3D computeRay( int pixel_x, int pixel_y ) const
   {
      // this is a point on the near plane, in camera space
      QVector3D p( (pixel_x-_viewport_cx)*viewportRadius/viewportRadiusInPixels,
                (_viewport_cy-pixel_y)*viewportRadius/viewportRadiusInPixels,
                 zNear
              );

      // transform p to world space
      QVector3D direction = (target - position).normalized();

      QVector3D right = QVector3D::crossProduct( direction , up);

      QVector3D v = right*p.x() + up*p.y() + direction*p.z();

      p = position + v;

      return QRay3D( p, v.normalized() );
   }

   /*


   // Computes the pixel covering the given point.
   // Also returns the z-distance (in camera space) to the point.
   //float computePixel(const Point3&,int& pixel_x, int& pixel_y )const;  // centre-based coordinates

   float computePixel( const QVector3D & p, int& pixel_x, int& pixel_y) const
   {
      // Transform the point from world space to camera space.

      QVector3D direction = (target - position).normalized();
      QVector3D right = QVector3D::crossProduct(direction , up);

      // Note that (right, _up, direction) form an orthonormal basis.
      // To transform a point from camera space to world space,
      // we can use the 3x3 matrix formed by concatenating the
      // 3 vectors written as column vectors.  The inverse of such
      // a matrix is simply its transpose.  So here, to convert from
      // world space to camera space, we do

      QVector3D v = p-position;
      float x = QVector3D::dotProduct(v,right);
      float y = QVector3D::dotProduct(v,up);
      float z = QVector3D::dotProduct(v,direction);

      // (or, more simply, the projection of a vector onto a unit vector
      // is their dot product)

      float k = zNear / z;

      // The +0.5f here is for rounding.
      pixel_x = (int)(
         k*viewportRadiusInPixels*x/viewportRadius + _viewport_cx + 0.5f
      );
      pixel_y = (int)(
         _viewport_cy - k*viewportRadiusInPixels*y/viewportRadius + 0.5f
      );
      return z;
   }



   // Compute the necessary size, in world space, of an object
   // (at the given distance from the camera,
   // or centred at the given point, respectively)
   // for it to cover the given fraction of the viewport.
   // These methods are useful for determining the necessary size of widgets
   // placed in 3D space for them to have a constant size in screen space.
   //float convertLength( float z_distance, float fractionOfViewportSize ) const;

   float convertLength(float z_distance, float fractionOfViewportSize) const
   {
      return z_distance * fractionOfViewportSize * 2 * viewportRadius / zNear; //tangent of field-of-view's semi-angle
   }

   float convertLength( const QVector3D& p, float fractionOfViewportSize ) const
   {
      int x, y;
      return convertLength( computePixel( p, x, y ), fractionOfViewportSize );
   }


   // Compute the necessary size, in world space, of an object
   // centred at the given point
   // for it to cover the given length of pixels.
   float convertPixelLength( const QVector3D& p, int pixelLength ) const
   {
      int x, y;
      return convertLength(  computePixel( p, x, y ),
         0.5 * pixelLength / (float)viewportRadiusInPixels
      );
   }




   // Unlinke lookAt(), these methods do NOT change the camera's orientation.
   // Instead, they translate the camera
   // such that the given points (or corners of the given box)
   // are just visible within the viewport.



   void framePoints( const vector< QVector3D >& l, bool frameExactly )
   {
      if ( l.empty() )
         return;
      QVector3D direction = (target - position).normalized();
      QVector3D right = QVector3D::crossProduct(direction , up);

      // Transform each of the points to camera space,
      // and find the minimal bounding box containing them
      // that is aligned with camera space.
      // FIXME the projection we do here is orthogonal;
      // it ignores the perspective projection of the camera
      // that will make distant points appear closer to the line of sight.
      // Thus, the camera will not frame points as tightly as it could.
      AlignedBox3D box;

      vector< QVector3D >::const_iterator it = l.begin();

      for ( ; it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;
         box.bound( QVector3D( QVector3D::dotProduct(v , right), QVector3D::dotProduct(v , up), QVector3D::dotProduct(v ,direction) ) );
      }

      // Translate the camera such
      // that the line of sight passes through the centre of the bounding box,
      // and the target point is at the centre of the bounding box.
      QVector3D boxCentre = box.getCentre();
      QVector3D newTarget = position  + right * boxCentre.x() + up * boxCentre.y() + direction * boxCentre.z();
      QVector3D translation = newTarget - target;

      position += translation;
      target = newTarget;

      // Next, dolly the camera forward (or backward)
      // such that all points are visible.
      // For each given point,
      // we compute the amount by which to dolly forward for that point,
      // and find the minimum of all such amounts
      // to use for the actual dolly.
//
//         In the below diagram,
//            "1" is the current position of the camera, which is pointing down
//            "a" is the distance to the near plane
//            "b" is half the width/height of the viewport
//            "3" is a point we want to frame by dollying the camera forward
//            "2" is the new location to place the camera to just frame "3"
//            "?" is the distance to dolly forward, which we want to compute
//
//                      |-b-|
//
//                         1  -  -  -
//                         /|  |  |  |
//                        / |  a  |  |
//                       /  |  |  |  |
//                      /---|  -  ?  |
//                     /    |     |  |
//                    /     |     |  |
//                   /      |     |  c
//                  /       2     -  |
//                 /       /|     |  |
//                /       / |     |  |
//               /       /  |     e  |
//             /       /   |     |  |
//            /       /    |     |  |
//           .-------3-----.     -  -
//
//                    |--f--|
//
       //     |------d------|
      //     The two hypotenuses are parallel because we don't want to change
      //    the camera's field of view.
      //   We have
      //       a/b = c/d = e/f   (where a,b,c,f are known)
      //    and
      //       ? = c - e
      //         = c - f*a/b

      bool minDollyDeltaInitialized = false;


      float minDollyDelta = 0;

      float min_c = 0;

      for ( it = l.begin(); it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;

         float c = QVector3D::dotProduct(v , direction);

         if ( it == l.begin() )
             min_c = c;
         else if ( c < min_c )
             min_c = c;

         float f, dollyDelta;

         if ( viewportWidth > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , right) );

            dollyDelta = c - f * zNear * 2 / viewportWidth;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
         if ( viewportHeight > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , up ));

            dollyDelta = c - f * zNear * 2 / viewportHeight;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
      }

      if ( ! frameExactly ) {
         // check that the dolly won't put some points
         // in front of the near plane
         if ( min_c - minDollyDelta < zNear )
            minDollyDelta = min_c - zNear;

         // fudge factor, to add a tiny margin around the points
         minDollyDelta -= 0.05f * zNear;
      }

      // perform the dolly
      position += direction * minDollyDelta;

      if ( ( target - position ).length() <= pushThreshold*zNear ) {
         // The target point is too close.
         target = position + direction * ( pushThreshold*zNear );
      }

      // FIXME: should we check if some points are beyond the
      // far plane, and if so move the far plane further back ?
   }


   virtual void frameBox( const AlignedBox3D& box )
   {
      vector< QVector3D > corners;

      for ( int i = 0; i < 8; ++i )
         corners.push_back( box.getCorner( i ) );

      framePoints( corners,true );
   }

   */

   virtual void transform()
   {
      glMatrixMode( GL_PROJECTION );
      glLoadIdentity();  // clear matrix

      if( zNear < zFar )
      {
          /*
          glFrustum(
             - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
             - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
             zNear, zFar
          );

          */

          glFrustum(
             - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
             - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
             zNear, 1000.0f
          );

          QMatrix4x4 m;

          m.setToIdentity();

          m.lookAt( position, target, up );

          qMultMatrix(m );
      }
   }

   void qMultMatrix(const QMatrix4x4 &mat)
   {
       if (sizeof(qreal) == sizeof(GLfloat))
           glMultMatrixf((GLfloat*)mat.constData());

   #ifndef QT_OPENGL_ES
       else if (sizeof(qreal) == sizeof(GLdouble))
           glMultMatrixd((GLdouble*)mat.constData());
   #endif
       else
       {
           GLfloat fmat[16];

           qreal const *r =(qreal*) mat.constData();

           for (int i = 0; i < 16; ++i)
           {
               fmat[i] = r[i];
           }

           glMultMatrixf(fmat);
       }
   }


   // Changes the field-of-view.

   virtual void changeFOV( float delta_pixels )
   {
      // this should be a little greater than 1.0
      float magnificationFactorPerPixel = 1.005;

      viewportRadius *= pow( magnificationFactorPerPixel, - delta_pixels );


      // recompute _viewport_width, _viewport_height
      //computeViewportWidthAndHeight()

      int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

      int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

      if ( viewport_width_in_pixels < viewport_height_in_pixels )
      {
         viewportWidth  = 2.0 * viewportRadius;

         viewportHeight = viewportWidth

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
   #else
            * viewport_height_in_pixels / (float)viewport_width_in_pixels;
   #endif
      }
      else
      {
         viewportHeight = 2.0 * viewportRadius;

         viewportWidth  = viewportHeight

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
   #else
            * viewport_width_in_pixels / (float)viewport_height_in_pixels;
   #endif
      }

   }

   virtual void zoom( float delta )
   {
       QVector3D dir =  target - position;

       dir = dir.normalized();

       target   += dir * delta;

       position += dir * delta;
   }

   virtual void pan( QPointF delta )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit  = viewportRadiusInPixels  / translationSpeedInUnitsPerRadius;

      QVector3D right        = QVector3D::crossProduct(direction , up);

      QVector3D translation  = right * ( - delta.x() / pixelsPerUnit )  + up * (  delta.y() / pixelsPerUnit );

      position += translation;

      target   += translation;

   }

   virtual void orbit(QPointF delta)
   {
       /*
      float pixelsPerDegree = viewportRadiusInPixels / orbitingSpeedInDegreesPerRadius;
      float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

      QVector3D t2p = position - target;

      QMatrix4x4 m;
      m.setToIdentity();
      m.rotate((delta.x()*-1) * radiansPerPixel,_ground);

      t2p = m*t2p;
      up = m*up;

      QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
      m.rotate( (delta.y() *-1) * radiansPerPixel,right);

      t2p = m*t2p;
      up = m*up;
      position = target + t2p;

      */





       QVector3D t2p = position - target;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate((delta.x()*-1),_ground);

       t2p = m*t2p;
       up = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
       m.rotate( (delta.y() *-1),right);

      t2p = m*t2p;
      up = m*up;
      position = target + t2p;
   }

   virtual void orbit(QPointF delta,const QVector3D& centre )
   {
       /*
      float pixelsPerDegree = viewportRadiusInPixels
         / orbitingSpeedInDegreesPerRadius;
      float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

      QVector3D t2p = position - target;
      QVector3D c2p = position - centre;

      QMatrix4x4 m;
      m.setToIdentity();
      m.rotate(  (delta.x() *-1) * radiansPerPixel,   _ground  );

      c2p = m*c2p;
      t2p = m*t2p;
      up  = m*up;

      QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

      m.rotate( (delta.y()*-1) * radiansPerPixel,   right  );

      c2p = m*c2p;

      t2p = m*t2p;

      up = m*up;

      position = centre + c2p;

      target   = position - t2p;

      */

       QVector3D t2p = position - target;
       QVector3D c2p = position - centre;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate(  (delta.x() *-1) ,   _ground  );

       c2p = m*c2p;
       t2p = m*t2p;
       up  = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

       m.rotate( (delta.y()*-1),   right  );

       c2p = m*c2p;

       t2p = m*t2p;

       up = m*up;

       position = centre + c2p;

       target   = position - t2p;
   }

   //void reset();
   virtual void resetCamera()
   {

      double tangent = tan( Fov_SemiAngle );

      viewportRadius = zNear * tangent;

      float distance_from_target = fudgeFactor * sceneRadius / tangent;

      computeViewportWidthAndHeight();

      // The ground vector can change if the user rolls the camera,
      // hence we reset it here.
      _ground = _initialGround;

      up = _ground;

      QVector3D v;

      if ( up.x()==0 && up.y()==1 && up.z()==0 )
          v = QVector3D( 0, 0, 1 );
      else
          v = getPerpendicularVector(up).normalized();//.choosePerpendicular().normalized();

      target   = sceneCentre;

      position = target + v * distance_from_target;
   }



   // Sets the state of the camera to be an
   // interpolation of the states of the given cameras.
   // The interpolation parameter should be in the interval [0,1]
   // This method can be used for animating camera motions.

   virtual void interpolate( const QCamera3D& c1, const QCamera3D& c2, float u )
   {
      // FIXME I only bother to interpolate a few data members.
      // You may need to add more data members here eventually.

       position  = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(c2.position)*u );

       target    = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(c2.target)*u );

       up        = c1.up*(1-u) + c2.up*u;
   }

   /*
   // Similar to interpolate(),
   // but rather than performing a linear interpolation,
   // this routine interpolates through an
   // "overview" of what both c1 and c2 see.
   // Thus, when this routine is used for animating camera transitions
   // from one place to another (possibly distant) place,
   // at some point during the transition
   // the user can see both places simultaneously,
   // and thus gain a better idea of how they are related spatially.
   // As currently implemented, this routine assumes that
   // c1 and c2 have the same orientation and the same field-of-view.
   virtual void interpolateThroughOverview( const QCamera3D& c1, const QCamera3D& c2, float u )
   {
      // initialize our state with the proper orientation, field of view, etc.
      *this = c1;

      // set our state equal to the intermediate, "overview" state
      vector< QVector3D > l;
      l.push_back( c1.getPosition() );
      l.push_back( c2.getPosition() );
      framePoints( l, true );

      // compute the value of u corresponding to the "overview" state
      float length1 = ( position - c1.position ).length();
      float length2 = ( position - c2.position ).length();

      if ( length1 + length2 == 0 )
      {
         // For definiteness (e.g. to ensure our state has
         // the correct target point and other parameters)
         // set our state equal to one of the given states.
         *this = u < 0.5f ? c1 : c2;
         return;
      }

      float u_overview = length1 / ( length1 + length2 );

      // now interpolate linearly between our state and one of the end states
      if ( u < 0 )
          u = 0;
      else if ( u > 1 )
          u = 1;

      if ( u < u_overview )
      {
         if ( u_overview > 0 )
            u /= u_overview; // normalize u

         position = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(position)*u );
         target = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(target)*u );
         up = c1.up*(1-u) + up*u;
      }
      else
      {
         if ( u_overview < 1 )
            u      = (u-u_overview)/(1-u_overview); // normalize u

         position = QVector3D( QVector3D(position)*(1-u) + QVector3D(c2.position)*u );
         target   = QVector3D( QVector3D(target)*(1-u)   + QVector3D(c2.target)*u );
         up       = up*(1-u) + c2.up*u;
      }
   }

   */




};

#endif // QMATH_HPP
