#ifndef METROPOLIS_HPP
#define METROPOLIS_HPP

#include<QtWidgets>



class MetropoleObject  : public QObject
{
    Q_OBJECT

public:

    MetropoleObject()
    {

    }
};


class CameraObject     : public MetropoleObject
{
    Q_OBJECT

public:

    CameraObject()
    {

    }
};



class RoadObject     : public MetropoleObject
{
    Q_OBJECT

public:

    RoadObject()
    {
        //signages,zebra,Rails,Traffics,laneTypes 2,3,4,5,6,7,8,bus stops

    }
};

class BridgeObject   : public MetropoleObject
{
    Q_OBJECT

public:

    BridgeObject()
    {

    }
};

class TerrainObject  : public MetropoleObject
{
    Q_OBJECT

public:

    TerrainObject()
    {

    }
};

class ForestObject   : public MetropoleObject
{
    Q_OBJECT

public:

    ForestObject()
    {

    }
};

class LightsObject         : public MetropoleObject
{
    Q_OBJECT

public:

    LightsObject()
    {

    }
};

class ResidencesObject     : public MetropoleObject
{
    Q_OBJECT

public:

    ResidencesObject()
    {

    }
};

class EstatesObject        : public MetropoleObject
{
    Q_OBJECT

public:

    EstatesObject()
    {

    }
};

class UniversecitiesObject : public MetropoleObject
{
    Q_OBJECT

public:

    UniversecitiesObject()
    {

    }
};

class HighSchoolsObject    : public MetropoleObject
{
    Q_OBJECT

public:

    HighSchoolsObject()
    {

    }
};

class PrimarySchoolsObject : public MetropoleObject
{
    Q_OBJECT

public:

    PrimarySchoolsObject()
    {

    }
};

class NurserySchoolsObject : public MetropoleObject
{
    Q_OBJECT

public:

    NurserySchoolsObject()
    {

    }
};

class PublicLibraryObject  : public MetropoleObject
{
    Q_OBJECT

public:

    PublicLibraryObject()
    {

    }
};

class SupermarketsObject   : public MetropoleObject
{
    Q_OBJECT

public:

    SupermarketsObject()
    {

    }
};

class PoliceStationsObject : public MetropoleObject
{
    Q_OBJECT

public:

    PoliceStationsObject()
    {

    }
};

class FireStationsObject   : public MetropoleObject
{
    Q_OBJECT

public:

    FireStationsObject()
    {

    }
};

class LakesObject       : public MetropoleObject
{
    Q_OBJECT

public:

    LakesObject()
    {

    }
};

class ParksObject       : public MetropoleObject
{
    Q_OBJECT

public:

    ParksObject()
    {

    }
};

class AirportsObject    : public MetropoleObject
{
    Q_OBJECT

public:

    AirportsObject()
    {

    }
};

class BusStationsObject : public MetropoleObject
{
    Q_OBJECT

public:

    BusStationsObject()
    {

    }
};

class RiverObject       : public MetropoleObject
{
    Q_OBJECT

public:

    RiverObject()
    {

    }
};

class MonumentsObject   : public MetropoleObject
{
    Q_OBJECT

public:

    MonumentsObject()
    {

    }
};

class FarmObject        : public MetropoleObject
{
    Q_OBJECT

public:

    FarmObject()
    {

    }
};

class WaterPipesObject        : public MetropoleObject
{
    Q_OBJECT

public:

    WaterPipesObject()
    {

    }
};

class SeweragePipesObject     : public MetropoleObject
{
    Q_OBJECT

public:

    SeweragePipesObject()
    {

    }
};

class ElectricityLinesObject  : public MetropoleObject
{
    Q_OBJECT

public:

    ElectricityLinesObject()
    {

    }
};

class FibreOpticsLinesObject  : public MetropoleObject
{
    Q_OBJECT

public:

    FibreOpticsLinesObject()
    {

    }
};

class StadiumsObject          : public MetropoleObject
{
    Q_OBJECT

public:

    StadiumsObject()
    {

    }
};

class MallsObject             : public MetropoleObject
{
    Q_OBJECT

public:

    MallsObject()
    {

    }
};

class HopitalsObject          : public MetropoleObject
{
    Q_OBJECT

public:

    HopitalsObject()
    {

    }
};

class SkyRisesObject          : public MetropoleObject
{
    Q_OBJECT

public:

    SkyRisesObject()
    {

    }
};

class TrainObject             : public MetropoleObject
{
    Q_OBJECT

public:

    TrainObject()
    {

    }
};

class TrashInseneratorsObject          : public MetropoleObject
{
    Q_OBJECT

public:

    TrashInseneratorsObject()
    {

    }
};

class GabageManagementStationsObject   : public MetropoleObject
{
    Q_OBJECT

public:

    GabageManagementStationsObject()
    {

    }
};

class RocksObject   : public MetropoleObject
{
    Q_OBJECT

public:

    RocksObject()
    {

    }
};




class Grid   : public MetropoleObject
{
    Q_OBJECT

public:

    Grid()
    {

    }
};

class Floor   : public MetropoleObject
{
    Q_OBJECT

public:

    Floor()
    {

    }
};







class Metropolis : public QObject
{
    Q_OBJECT

public:

    Metropolis()
    {
        printf("Metropolis Loaded.\n");
    }
};






#endif // METROPOLIS_HPP
