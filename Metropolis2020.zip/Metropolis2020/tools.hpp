#ifndef TOOLS_HPP
#define TOOLS_HPP

#include<QtWidgets>

class penTools : QObject
{
    Q_OBJECT
public:

    QActionGroup *toolsActiongroups;

    QCursor cursor;


    penTools(QObject * parent = 0):QObject(parent)
    {
        toolsActiongroups =  new QActionGroup(this);

        QAction * c0 = new QAction(QIcon(":/Tools Icons/Text.svg"),QString("Text: SHIFT + 1"),this);
        QAction * c1 = new QAction(QIcon(":/Tools Icons/Brush.svg"),QString("Brush: SHIFT + 2"),this);
        QAction * c2 = new QAction(QIcon(":/Tools Icons/Pen.svg"),QString("Pen: SHIFT + 3"),this);
        QAction * c3 = new QAction(QIcon(":/Tools Icons/Line.svg"),QString("Line: SHIFT + 4"),this);
        QAction * c4 = new QAction(QIcon(":/Tools Icons/Polygon.svg"),QString("Polygon: SHIFT + 5"),this);
        QAction * c5 = new QAction(QIcon(":/Tools Icons/Spline.svg"),QString("Spline: SHIFT + 6"),this);
        QAction * c6 = new QAction(QIcon(":/Tools Icons/Curves.svg"),QString("Curves: SHIFT + 7"),this);

        c0->setCheckable(true);c0->setShortcut(Qt::SHIFT|Qt::Key_1);
        c1->setCheckable(true);c1->setShortcut(Qt::SHIFT|Qt::Key_2);
        c2->setCheckable(true);c2->setShortcut(Qt::SHIFT|Qt::Key_3);
        c3->setCheckable(true);c3->setShortcut(Qt::SHIFT|Qt::Key_4);
        c4->setCheckable(true);c4->setShortcut(Qt::SHIFT|Qt::Key_5);
        c5->setCheckable(true);c5->setShortcut(Qt::SHIFT|Qt::Key_6);
        c6->setCheckable(true);c6->setShortcut(Qt::SHIFT|Qt::Key_7);


        connect(c0, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c1, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c2, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c3, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c4, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c5, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c6, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));


        toolsActiongroups->addAction(c0);
        toolsActiongroups->addAction(c1);
        toolsActiongroups->addAction(c2);
        toolsActiongroups->addAction(c3);
        toolsActiongroups->addAction(c4);
        toolsActiongroups->addAction(c5);
        toolsActiongroups->addAction(c6);

    }
    ~penTools()
    {
        delete toolsActiongroups;

    }

signals:

    void toolChanged();
    void textActionLoaded();
    void brushActionLoaded();
    void penActionLoaded();
    void lineActionLoaded();
    void polygonActionLoaded();
    void splineActionLoaded();
    void curveActionLoaded();

public slots:

    void setToolsActions()
    {
        if(toolsActiongroups->actions()[0]->isChecked())
        {
            qDebug()<<"Text Action active";
            //this->setCursor(QCursor(QPixmap(":/Tools Icons/Text.svg")));

            cursor = QCursor(QPixmap(":/Tools Icons/Text.svg"));

            emit textActionLoaded();
        }
        else
        {
            qDebug()<<"Text Action inactive";
        }

        if(toolsActiongroups->actions()[1]->isChecked())
        {
           qDebug()<<"Brush Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Brush.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Brush.svg"));

           emit brushActionLoaded();

        }
        else
        {
            qDebug()<<"Brush Action inactive";
        }

        if(toolsActiongroups->actions()[2]->isChecked())
        {
           qDebug()<<"Pen Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Pen.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Pen.svg"));

           emit penActionLoaded();
        }
        else
        {
            qDebug()<<"Pen Action inactive";
        }

        if(toolsActiongroups->actions()[3]->isChecked())
        {
           qDebug()<<"Line Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Line.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Line.svg"));

           emit lineActionLoaded();

        }
        else
        {
            qDebug()<<"Line Action inactive";
        }

        if(toolsActiongroups->actions()[4]->isChecked())
        {
           qDebug()<<"Polygon Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Polygon.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Polygon.svg"));

           emit polygonActionLoaded();


        }
        else
        {
            qDebug()<<"Polygon Action inactive";
        }

        if(toolsActiongroups->actions()[5]->isChecked())
        {
           qDebug()<<"Spline Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Spline.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Spline.svg"));

           emit splineActionLoaded();


        }
        else
        {
            qDebug()<<"Spline Action inactive";
        }

        if(toolsActiongroups->actions()[6]->isChecked())
        {
           qDebug()<<"Curves Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Curves.svg")));

           cursor = QCursor(QPixmap(":/Tools Icons/Curves.svg"));

           emit curveActionLoaded();

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }


        qDebug()<<"/n";

        emit toolChanged();
    }


};

class selectionTools : QObject
{
    Q_OBJECT
public:

    QActionGroup *toolsActiongroups;

    QCursor cursor;

    selectionTools(QObject * parent = 0):QObject(parent)
    {
        toolsActiongroups =  new QActionGroup(this);

        QAction * a1 = new QAction(QIcon(":/Tools Icons/Select Circle.svg"),QString("Circle Select: CTRL + 1"),this);
        QAction * a2 = new QAction(QIcon(":/Tools Icons/Select Curve.svg"),QString("Curve Select: CTRL + 2"),this);
        QAction * a3 = new QAction(QIcon(":/Tools Icons/Select Polygon.svg"),QString("Polygon Select: CTRL + 3"),this);
        QAction * a4 = new QAction(QIcon(":/Tools Icons/Select Rect.svg"),QString("Rect Select: CTRL + 4"),this);
        QAction * a5 = new QAction(QIcon(":/Tools Icons/Select Wand.svg"),QString("Wand Select: CTRL + 5"),this);

        a1->setCheckable(true);a1->setShortcut(Qt::CTRL|Qt::Key_1);
        a2->setCheckable(true);a2->setShortcut(Qt::CTRL|Qt::Key_2);
        a3->setCheckable(true);a3->setShortcut(Qt::CTRL|Qt::Key_3);
        a4->setCheckable(true);a4->setShortcut(Qt::CTRL|Qt::Key_4);
        a5->setCheckable(true);a5->setShortcut(Qt::CTRL|Qt::Key_5);

        connect(a1, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a2, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a3, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a4, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a5, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));


        toolsActiongroups->addAction(a1);
        toolsActiongroups->addAction(a2);
        toolsActiongroups->addAction(a3);
        toolsActiongroups->addAction(a4);
        toolsActiongroups->addAction(a5);
    }

    ~selectionTools()
    {
        delete toolsActiongroups;

    }

signals:

    void selectionChanged();

    void selectCircleActionChanged();
    void selectCurveActionChanged();
    void selectPolygonActionChanged();
    void selectRectActionChanged();
    void selectWandActionChanged();


public slots:

    void setSelectionToolsAction()
    {
        if(toolsActiongroups->actions()[0]->isChecked())
        {
            qDebug()<<"Select Circle Action active";

            //this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Circle.svg")));
            cursor = QCursor(QPixmap(":/Tools Icons/Select Circle.svg"));
            emit selectCircleActionChanged();

        }
        else
        {
            qDebug()<<"Select Circle Action inactive";
        }

        if(toolsActiongroups->actions()[1]->isChecked())
        {
           qDebug()<<"Select Curve Action active";
           cursor = QCursor(QPixmap(":/Tools Icons/Select Curve.svg"));

           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Curve.svg")));
           emit selectCurveActionChanged();

        }
        else
        {
            qDebug()<<"Select Curve Action inactive";
        }

        if(toolsActiongroups->actions()[2]->isChecked())
        {
           qDebug()<<"Select Polygon Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Polygon.svg")));
           cursor = QCursor(QPixmap(":/Tools Icons/Select Polygon.svg"));
           emit selectPolygonActionChanged();

        }
        else
        {
            qDebug()<<"Select Polygon Action inactive";
        }

        if(toolsActiongroups->actions()[3]->isChecked())
        {
           qDebug()<<"Select Rect Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Rect.svg")));
           cursor = QCursor(QPixmap(":/Tools Icons/Select Rect.svg"));

           emit selectRectActionChanged();

        }
        else
        {
            qDebug()<<"Select Rect Action inactive";
        }

        if(toolsActiongroups->actions()[4]->isChecked())
        {
           qDebug()<<"Select Wand Action active";
           //this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Wand.svg")));
           cursor  = QCursor(QPixmap(":/Tools Icons/Select Wand.svg"));
           emit selectWandActionChanged();

        }
        else
        {
            qDebug()<<"Select Wand Action inactive";
        }


        qDebug()<<"/n";

        emit selectionChanged();
    }



};

#endif // TOOLS_HPP

