#ifndef MODIFIERS_HPP
#define MODIFIERS_HPP

#include<QtWidgets>

enum QModifierTypes
{
    MODIFIER_BASE,
    MODIFIER_SUBDIVISION,
    MODIFIER_EXPLODE,
    MODIFIER_BOOLEAN,
    MODIFIER_SHELL,
};

class QBaseModifier: public QObject
{
    Q_OBJECT

public:

    enum { Type = MODIFIER_BASE};

    virtual int type() const  { return Type; }

    QBaseModifier(QObject * parent =0): QObject(parent)
    {

    }

    virtual void computeDeformer()
    {

    }
};

class QSubdivisionModifier: public QBaseModifier
{
    Q_OBJECT

public:

    enum { Type = MODIFIER_SUBDIVISION};

    virtual int type() const  { return Type; }

    QSubdivisionModifier(QObject * parent =0): QBaseModifier(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QExplodeModifier: public QBaseModifier
{
    Q_OBJECT

public:

    enum { Type = MODIFIER_EXPLODE};

    virtual int type() const  { return Type; }

    QExplodeModifier(QObject * parent =0): QBaseModifier(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QBooleanModifier: public QBaseModifier
{
    Q_OBJECT

public:

    enum { Type = MODIFIER_BOOLEAN};

    virtual int type() const  { return Type; }

    QBooleanModifier(QObject * parent =0): QBaseModifier(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QShellModifier: public QBaseModifier
{
    Q_OBJECT

public:

    enum { Type = MODIFIER_SHELL};

    virtual int type() const  { return Type; }

    QShellModifier(QObject * parent =0): QBaseModifier(parent)
    {

    }

    void computeDeformer()
    {

    }
};





#endif // MODIFIERS_HPP
