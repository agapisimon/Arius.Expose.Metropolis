#ifndef SOUND_HPP
#define SOUND_HPP

#include <QtWidgets>
#include <stdlib.h>
#include <iostream>


#include <fmod.hpp>
#include <fmod_errors.h>
//#include <windows.h>

inline void printResult(FMOD_RESULT result)
{
    if (result != FMOD_OK)
    {
        char    errstring[1024];

        sprintf(errstring, "FMOD error! (%d) %s \n", result, FMOD_ErrorString(result));

        printf("FMOD error %s \n",errstring);
    }
}

class SoundSource : public QGraphicsEllipseItem
{
    QBrush mBrushBlue;
    QBrush mBrushRed;

    FMOD::System  * gSystem = 0;
    FMOD::Sound   * gSound  = 0;
    FMOD::Channel * mChannel;

    FMOD_VECTOR mPos, mVel;

public:

    enum { Type = UserType + 1 };

    int type() const
    {
        // Enable the use of qgraphicsitem_cast with this item.
        return Type;
    }

    QRectF boundingRect() const
    {
        return QRectF(-5,-5,10,10);
    }

    QPainterPath shape() const
    {
        QPainterPath path;

        path.addEllipse(boundingRect());

        return path;
    }

    SoundSource(FMOD::Sound *sound  = 0,FMOD::System    *system=0,QGraphicsItem * parent = 0): QGraphicsEllipseItem(parent)
    {
        setFlags(ItemIsFocusable|ItemIsMovable|ItemIsSelectable);

        gSystem =  system;
        gSound  =  sound;

        mBrushRed  = QBrush(Qt::red);
        mBrushBlue = QBrush(Qt::blue);


        FMOD_RESULT result;

        result = gSystem->playSound(FMOD_CHANNEL_FREE, gSound, true, &mChannel);
        printResult(result);

        result = mChannel->setFrequency(22050.0f + (float)(qrand() % 88200));
        printResult(result);

        mPos.x = 0.0f;
        mPos.y = 0.0f;
        mPos.z = 0.0f;

        mVel.x = 0.0f;
        mVel.y = 0.0f;
        mVel.z = 0.0f;

        result = mChannel->set3DAttributes(&mPos, &mVel);
        printResult(result);

        result = mChannel->setPaused(false);
        printResult(result);

    }



    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        painter->setRenderHint(QPainter::Antialiasing);

        FMOD_RESULT result;

        bool isvirtual;

        result = mChannel->isVirtual(&isvirtual);

        printResult(result);

        if (this->isSelected())
        {
            painter->setBrush( mBrushBlue);
        }
        else
        {
            painter->setBrush( mBrushRed);
        }

        QRectF rect =  QRectF(-5,-5,10,10);

        painter->drawEllipse(rect);

        setSoundSourcePosition(QVector3D(pos().x(),pos().y(),0));

        update();

    }

    void setSoundSourcePosition(QVector3D position,QVector3D velocity = QVector3D(0,0,0))
    {
        FMOD_RESULT result;

        mPos.x = position.x();
        mPos.y = position.y();
        mPos.z = position.z();

        mVel.x = velocity.x();
        mVel.y = velocity.y();
        mVel.z = velocity.z();

        result = mChannel->set3DAttributes(&mPos, &mVel);

        printResult(result);
    }

};

class Listener : public QGraphicsEllipseItem
{

    FMOD_VECTOR mListenerPos;
    FMOD_VECTOR mUp, mVel, mForward;

    QBrush mBrushBlue;
    QBrush mBrushRed;

    FMOD::System *gSystem = 0;

    // consider drawing the listeners radius

public:

    QRectF selectionRadius;
    QRectF hotspot;



    enum { Type = UserType + 1 };

    int type() const
    {
        // Enable the use of qgraphicsitem_cast with this item.
        return Type;
    }

    QRectF boundingRect() const
    {
        return selectionRadius;//QRectF(0,0,20,20);
    }

    QPainterPath shape() const
    {
        QPainterPath path;

        path.addEllipse(boundingRect());

        return path;
    }

    Listener(FMOD::System *system = 0,QGraphicsItem * parent =0):QGraphicsEllipseItem(parent)
    {
        setFlags(ItemIsFocusable|ItemIsMovable|ItemIsSelectable);

        mBrushRed  = QBrush(Qt::red);
        mBrushBlue = QBrush(Qt::blue);

        selectionRadius = QRectF(-50,-50,100,100);
        hotspot  = QRectF(-10,-10,20,20);

        mListenerPos.x = 0;
        mListenerPos.y = 0;
        mListenerPos.z = 0;

        gSystem = system;

        mUp.x = 0;
        mUp.y = 0;
        mUp.z = 1;

        mForward.x =  0;
        mForward.y = -1;
        mForward.z =  0;

        mVel.x = 0;
        mVel.y = 0;
        mVel.z = 0;

        FMOD_RESULT result;

        result = gSystem->set3DListenerAttributes(0, &mListenerPos, &mVel, &mForward, &mUp);

        printResult(result);
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        painter->setRenderHint(QPainter::Antialiasing);

        if (this->isSelected())
        {
            painter->setBrush( mBrushBlue);
        }
        else
        {
            painter->setBrush( mBrushRed);
        }

        QRectF rect =  hotspot;

        painter->drawEllipse(hotspot);

        painter->save();

        painter->setBrush(Qt::NoBrush);
        painter->setPen(QPen(QBrush(Qt::black),1.5f,Qt::DotLine));
        painter->drawEllipse(selectionRadius);
        painter->restore();

        setSoundSourcePosition(QVector3D(pos().x(),pos().y(),0));

        update();
    }

    void setSoundSourcePosition(QVector3D position,QVector3D velocity = QVector3D(0,0,0))
    {
        FMOD_RESULT result;

        mListenerPos.x = position.x();
        mListenerPos.y = position.y();
        mListenerPos.z = position.z();

        mVel.x = velocity.x();
        mVel.y = velocity.y();
        mVel.z = velocity.z();

        //qDebug()<<"Position:"<<position;

        result = gSystem->set3DListenerAttributes(0, &mListenerPos, &mVel, &mForward, &mUp);

        printResult(result);
    }
};





class SoundWidget : public QWidget
{
    FMOD::System    *gSystem = 0;
    FMOD::Sound     *gSound = 0;

    QBasicTimer timer;


public:

     void timerEvent(QTimerEvent *event)
     {
         if (event->timerId() == timer.timerId())
         {
             qDebug()<<"Updated:";

             gSystem->update();

             int   channels;

             FMOD_RESULT result;

             result = gSystem->getChannelsPlaying(&channels);
             printResult(result);

             printf("Channels Playing: %d \n", channels);
             printf("Real Channels:    %d (RED)\n", NUMREALCHANNELS);
             printf("Virtual Channels: %d (BLUE)\n", NUMCHANNELS - NUMREALCHANNELS);

             update();
         }
         else
         {
             QWidget::timerEvent(event);
         }
     }




    int  NUMCHANNELS     = 50;
    int  NUMREALCHANNELS = 10;
    int  WIDTH           = 640;
    int  HEIGHT          = 480;

    int   INTERFACE_UPDATETIME = 50;      // 50ms update for interface
    float DISTANCEFACTOR = 1.0f;          // Units per meter.  I.e feet would = 3.28.  centimeters would = 100.



    SoundSource *gSelectedSource = 0;
    Listener    *gListener;



    QList<SoundSource *> sources;
    QList<Listener*> listeners;



    QGraphicsScene *scene;
    QGraphicsView *view;

    SoundWidget(QWidget * parent =0):QWidget(parent)
    {
        sources.reserve(NUMCHANNELS);

        view  = new QGraphicsView;
        scene = new QGraphicsScene;

        view->setScene(scene);

        QVBoxLayout  * layout =  new QVBoxLayout;

        layout->addWidget(view);


        setLayout(layout);

        initSound();

        timer.start(10,this);
    }



    void initSound()
    {
        FMOD_RESULT  result;

        int          count;
        unsigned int version;

        //Create a System object and initialize.

         result = FMOD::System_Create(&gSystem);
         printResult(result);

         //Initialise

         result = gSystem->getVersion(&version);
         printResult(result);

         if (version < FMOD_VERSION)
         {
             printf("INCORRECT DLL VERSION!!,FMOD ERROR");
         }
         else
         {
            qDebug()<<"DLL VERSION,FMOD VERSION"<<version;

         }

         result = gSystem->setSoftwareChannels(NUMREALCHANNELS);
         printResult(result);

         result = gSystem->init(NUMCHANNELS, FMOD_INIT_NORMAL, 0);
         printResult(result);

         QFile file(":/media/drumloop.wav");

         result = gSystem->createSound( "D:/PROJECT QT5.5/View Agapi Fmod 3d sound/envirnoment/media/drumloop.wav", FMOD_SOFTWARE | FMOD_3D | FMOD_LOOP_NORMAL, 0, &gSound);
         printResult(result);

         result = gSound->set3DMinMaxDistance(4.0f, 10000.0f);
         printResult(result);

         qDebug()<<"SOunds Loaded";

         //srand(timeGetTime());

         //Create a listener in the middle of the window

         gListener = new Listener(gSystem);

         gListener->setPos(QPointF(WIDTH/2, HEIGHT/2));


         if(scene)
         {
             scene->addItem(gListener);
         }

         //Initialise all of the sound sources

         for (count = 0; count < NUMCHANNELS; count++)
         {
             int x = qrand() % WIDTH;
             int y = qrand() % HEIGHT;

             qDebug()<<"Point"<<QPoint(x,y);

             SoundSource * source  =  new SoundSource(gSound,gSystem,0);

             source->setPos(x,y);

             sources.append(source);

             if(scene)
             {
                 scene->addItem(source);
             }
        }
    }

    ~SoundWidget()
    {
        CloseDown();
    }

    void CloseDown()
    {
        FMOD_RESULT result;

        int         count;

        // Release listener
        delete gListener;

        scene->items().clear();

        //Release sound sources

        for (count = 0; count < NUMCHANNELS; count++)
        {
            delete sources[count];
        }

        //Shutdown FMOD

        if (gSound)
        {
            result = gSound->release();
            printResult(result);
        }
        if (gSystem)
        {
            result = gSystem->close();
            printResult(result);

            result = gSystem->release();
            printResult(result);
        }
    }
};


/*
int main(int argc, char *argv[])
{
    //QCoreApplication a(argc, argv);
    qsrand(QDateTime().currentDateTime().time().msec());

    QApplication a(argc, argv);

    SoundWidget w;
    w.showMaximized();

    return a.exec();;
}
*/

class SoundTools :  QObject
{
    Q_OBJECT

public:

    QActionGroup *audioActiongroups;

    SoundTools(QObject * parent =0):QObject(parent)
    {
        audioActiongroups =  new QActionGroup(this);

        QAction * audio0 = new QAction(QIcon(":/Tools Icons/audio listener.svg"),QString("Add Listener: SHIFT + 0"),this);
        QAction * audio1 = new QAction(QIcon(":/Tools Icons/audio speaker.svg"),QString("Add Speaker: SHIFT + 1"),this);

        QAction * audio2 = new QAction(QIcon(":/Tools Icons/audio play.svg"),QString("Play Sound: SHIFT + 1"),this);
        QAction * audio3 = new QAction(QIcon(":/Tools Icons/audio pause.svg"),QString("Pause Sound: SHIFT + 1"),this);
        QAction * audio4 = new QAction(QIcon(":/Tools Icons/audio stop.svg"),QString("Stop Sound: SHIFT + 1"),this);

        QAction * audio5 = new QAction(QIcon(":/Tools Icons/audio mute.svg"),QString("Mute Sound: SHIFT + 2"),this);
        QAction * audio6 = new QAction(QIcon(":/Tools Icons/audio manager.svg"),QString("Add Sound Manager: SHIFT + 2"),this);


        audio0->setCheckable(true);audio0->setShortcut(Qt::SHIFT|Qt::Key_1);
        audio1->setCheckable(true);audio1->setShortcut(Qt::SHIFT|Qt::Key_1);

        audio2->setCheckable(true);audio2->setShortcut(Qt::SHIFT|Qt::Key_1);
        audio3->setCheckable(true);audio3->setShortcut(Qt::SHIFT|Qt::Key_1);
        audio4->setCheckable(true);audio4->setShortcut(Qt::SHIFT|Qt::Key_1);

        audio5->setCheckable(true);audio5->setShortcut(Qt::SHIFT|Qt::Key_2);
        audio6->setCheckable(true);audio6->setShortcut(Qt::SHIFT|Qt::Key_2);

        connect(audio0, SIGNAL(triggered(bool)), this, SLOT(addListenerModel()));
        connect(audio1, SIGNAL(triggered(bool)), this, SLOT(addSpeakerModel()));

        connect(audio2, SIGNAL(triggered(bool)), this, SLOT(playSound));
        connect(audio3, SIGNAL(triggered(bool)), this, SLOT(pauseSound()));
        connect(audio4, SIGNAL(triggered(bool)), this, SLOT(stopSound()));

        connect(audio5, SIGNAL(triggered(bool)), this, SLOT(muteSound()));
        connect(audio6, SIGNAL(triggered(bool)), this, SLOT(loadSoundManager()));

        audioActiongroups->addAction(audio0);
        audioActiongroups->addAction(audio1);
        audioActiongroups->addAction(audio5);
        audioActiongroups->addAction(audio2);
        audioActiongroups->addAction(audio3);
        audioActiongroups->addAction(audio4);
        audioActiongroups->addAction(audio6);


        //SoundWidget w;
        //w.showMaximized();
    }
    ~SoundTools()
    {
        delete audioActiongroups;
    }

signals:

    void valueChanged();
    void addedListener();
    void addedSpeaker();
    void pausedSound();
    void stoppedSound();
    void mutedSound();
    void playingSound();


public slots:


    void addListenerModel()
    {

        emit addedListener();
    }

    void addSpeakerModel()
    {

        emit addedSpeaker();
    }

    void playSound()
    {

        emit playingSound();
    }

    void pauseSound()
    {

        emit pausedSound();
    }

    void stopSound()
    {

        emit stoppedSound();
    }

    void muteSound()
    {
        emit mutedSound();
    }

    void loadSoundManager()
    {

    }
};







#endif // SOUND_HPP
