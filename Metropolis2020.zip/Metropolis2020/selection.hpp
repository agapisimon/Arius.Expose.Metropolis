#ifndef SELECTION_HPP
#define SELECTION_HPP
#include<QtGui>




#endif // SELECTION_HPP
