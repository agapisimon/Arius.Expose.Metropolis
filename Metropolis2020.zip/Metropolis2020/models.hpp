#ifndef MODELS
#define MODELS


//Copyright © 2015  AGAPI SIMON
//Email: mittisimone@gmail.com


#include <QtWidgets>
#include <QtSvg>
#include <QtOpenGL>



#include <QGLWidget>
#include <vector>
#include <GL/glu.h>
#include <GL/gl.h>
#include <time.h>
//#include <omp.h>
#include <widgets.hpp>
#include <geometry.hpp>
#include <globals.hpp>
#include <settings.hpp>

#include <fstream>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <stdio.h>
#include <QXmlSimpleReader>
#include <QDomDocument>

#include<qmath.hpp>

//#define LINELEN 100

//#include<particles.hpp>

#define GL_MULTISAMPLE  0x809D

//#include<materials.hpp>

enum QPerspectiveMode
{
    FRUSTRUM,
    ORTHO,
    PERSPECTIVE,
    ORTHO2D,
};

enum QSpaceTransform
{
    GLOBAL_SPACE,
    LOCAL_SPACE,
    SCREEN_SPACE,
};

enum QOutlineMode
{
    OUTLINE,
    OUTLINE_ONLY,
    SILHOUETTE,
    SILHOUETTE_ONLY,
    NO_OUTLINE,
    DEFAULT_OUTLINE,
    STENCIL
};

enum QModelTypes
{
    MODEL_BASE,
    MODEL_ROOTMODEL,
    MODEL_LOCATION,
    MODEL_CUBE,
    MODEL_ROUNDED_CUBE,
    MODEL_CYLINDER,
    MODEL_PIPE,
    MODEL_TUBE,
    MODEL_SPHERE,
    MODEL_QUAD,
    MODEL_GRID,
    MODEL_PLANE,
    MODEL_TRIANGLES,
    MODEL_DONUT,
    MODEL_CONE,
    MODEL_DISK,
    MODEL_LINE,
    MODEL_CIRCLE,
    MODEL_PIE,
    MODEL_TEXT,
    MODEL_SPLINE,
    MODEL_CABEL,
    MODEL_ICOSPHERE,
    MODEL_PYRAMID,
    MODEL_MESH,
    MODEL_LIGHT,
    MODEL_CAMERA_FREE,
    MODEL_CAMERA_TARGET,
    MODEL_SPIRAL,
    MODEL_IVY,
    MODEL_GROUP,
    MODEL_PARTICLES,
    MODEL_TERRAIN,
    MODEL_SVG,
};




class QGroupModel;

class QBaseModel: public QObject
{
    Q_OBJECT

public:

    QString name;

    QMutex mutex;

    TransformParameters  * transformParameters;
    VisibilityParameters * visibilityParameters;

    QVector<QVector3D> vertices;
    QVector<QVector3D> normals; 
    QVector<QVector2D> texcoords;

    QVector<int> indices;
    QVector<int> edges;

    //QVector< QVector4D > quads;
    //QVector< QVector3D > triangles;

    enum { Type = MODEL_BASE};

    virtual int type() const  { return Type; }


    //QBoundSphere  boundingSphere;
    //QAabb  boundingAabbox;
    QSphere3D boundingSphere;

    QBox3D boundingAabbox;

    float scalevalue;

    int ID;


    QColor colorId;
    QColor selectedColor;

    QMatrix4x4 localMatrix;
    QMatrix4x4 worldMatrix;

    QVector3D position;
    QVector3D scale;
    QVector3D rotation;
    QVector3D pivotPoint;

    QQuaternion orientation;
    QVector3D axis;
    qreal angle;


    QString getName()
    {
        return name;
    }

    void setName(QString name)
    {
        this->name  =  name;
    }

    QColor getColorModelID()
    {
        QColor c;

        int r = Globals::frandom(1000)*255;
        int g = Globals::frandom(1000)*255;
        int b = Globals::frandom(1000)*255;

        c = QColor(r,g,b);

        //c.setRedF(0.0392157);
        //c.setGreenF(0.466667);
        //c.setBlueF(0.333333);
        //c.setAlphaF(1.0);

        //qDebug()<<"First Color:"<<c;

        return c;
    }

    virtual void SaveModel()
    {

    }

    virtual void ReadModel()
    {

    }

    QBaseModel(QObject * parent =0) : QObject(parent)
    {
        //phongMaterial        =  new QPhongMaterial;
        transformParameters  =  new TransformParameters(this);
        visibilityParameters =  new VisibilityParameters(this);

        connect(transformParameters,SIGNAL(valueChanged(QVector3D)),this,SLOT(setTransforms()));
        connect(visibilityParameters,SIGNAL(valueChanged(bool)),this,SLOT(setShowParameters()));


        Globals::ModelID++;

        ID =  Globals::ModelID;

        vertices.append(position);

        colorId  = getColorModelID();

        selectedColor  = QColor(222,97,123);


        position = QVector3D(0,0,0);
        rotation = QVector3D(0,0,0);
        scale    = QVector3D(1,1,1);

        //boundingSphere.radius = 0.4;

        name =  QString("Base Object");

        hasParent =  false;
    }

    ~QBaseModel()
    {
        delete transformParameters;

        delete visibilityParameters;

        delete parent;
    }


   // QPhongMaterial * phongMaterial;

    virtual void drawToolTip(QWidget * parent)
    {

        QString tipstr("<b>QToolTip Example:</b>\n"
                       "Create N points on a sphere\n "
                       "aproximately equi-distant from each other\n"
                       "Basically, N points are randomly\n "
                       "placed on the sphere and then moved\n"
                       "around until then moved around \n"
                       "until the minimal distance between the\n"
                       "closed two points is minimaised.\n");

         QPoint p = QCursor::pos();

         QToolTip::showText(p,tipstr,parent,QRect(p,QSize(100,120)));

    }

    virtual void setTheme(QWidget * widget)
    {
        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st =file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

        qDebug()<<"Styles Loaded";
    }


    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

            const float*r = mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }


    virtual void simpleDraw()
    {
        //--Draw the surface---------------------------


        if(indices.size()%4==0 && indices.size()>0)
        {
            glEnableClientState(GL_VERTEX_ARRAY);

            glVertexPointer(3, GL_FLOAT, 0, (float*)vertices.constData());

            glDrawElements(GL_QUADS, indices.size(), GL_UNSIGNED_INT, indices.constData());

            glDisableClientState(GL_VERTEX_ARRAY);

        }


        if(indices.size()%3==0 && indices.size()>0)
        {
            glEnableClientState(GL_VERTEX_ARRAY);

            glVertexPointer(3, GL_FLOAT, 0, (float*)vertices.constData());

            glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, indices.constData());

            glDisableClientState(GL_VERTEX_ARRAY);
        }



        //----------------
    }
    virtual void drawOutline()
    {
        /*
        glDisable( GL_LIGHTING );
        // Push the GL attribute bits so that we don't wreck any settings
        glPushAttrib( GL_ALL_ATTRIB_BITS );
        // Enable polygon offsets, and offset filled polygons forward by 2.5
        glEnable( GL_POLYGON_OFFSET_FILL );
        glPolygonOffset( -2.5f, -2.5f );
        // Set the render mode to be line rendering with a thick line width
        glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
        //glPolygonMode( GL_FRONT_AND_BACK, GL_POLYGON );
        //glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

        glLineWidth( 5.0f );
        // Set the colour to be white
        glColor3f( 1.0f, 0.0f, 0.0f );
        // Render the object
        simpleDraw();

        // Set the polygon mode to be filled triangles
        glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

        // Set the colour to the background
        //Draw solid object
        glColor3f (colorId.redF(), colorId.greenF(), colorId.blueF());

        // Render the object
        simpleDraw();
        // Pop the state changes off the attribute stack
        // to set things back how they were
        glPopAttrib();

        glEnable( GL_LIGHTING );
        */

        glPushAttrib (GL_POLYGON_BIT);
        glEnable (GL_CULL_FACE);

            /*
             * Draw front-facing polygons as filled
             */

            glPolygonMode (GL_FRONT, GL_FILL);
            glCullFace (GL_BACK);

            /* Draw solid object */
            //glColor3f (1.0f, 1.0f, 1.0f);
            glColor3f (colorId.redF(), colorId.greenF(), colorId.blueF());

            simpleDraw();

            /*
             * Draw back-facing polygons as red lines
             */

            /* Disable lighting for outlining */
            glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
            glDisable (GL_LIGHTING);

            glPolygonMode (GL_BACK, GL_LINE);
            glCullFace (GL_FRONT);

            glDepthFunc (GL_LEQUAL);
            glLineWidth (5.0f);

            /* Draw wire object */
            glColor3f (1.0f, 0.0f, 0.0f);
            simpleDraw();

            /* GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT */
            glPopAttrib ();

            /* GL_POLYGON_BIT */
            glPopAttrib ();

    }
    virtual void drawOutlineOnly()
    {
        glPushAttrib (GL_POLYGON_BIT);
        glEnable (GL_CULL_FACE);

            /*
             * Draw front-facing polygons as filled
             */

            /* Disable color buffer */
            glColorMask (GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

            glPolygonMode (GL_FRONT, GL_FILL);
            glCullFace (GL_BACK);

            /* Draw solid object */
            glColor3f (1.0f, 1.0f, 1.0f);
            simpleDraw();

            /*
             * Draw back-facing polygons as red lines
             */

            /* Enable color buffer */
            glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

            /* Disable lighting for outlining */
            glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
            glDisable (GL_LIGHTING);

            glPolygonMode (GL_BACK, GL_LINE);
            glCullFace (GL_FRONT);

            glDepthFunc (GL_LEQUAL);
            glLineWidth (5.0f);

            /* Draw wire object */
            glColor3f (1.0f, 0.0f, 0.0f);
            simpleDraw();

            /* GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT */
            glPopAttrib ();

            /* GL_POLYGON_BIT */
            glPopAttrib ();

    }
    virtual void drawSilhouette()
    {
        glDisable (GL_LIGHTING);

        //SILHOUETTE
        glPushAttrib (GL_POLYGON_BIT);
        glEnable (GL_CULL_FACE);

        //Draw back-facing polygons as red lines
        //Disable lighting for outlining
        glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);

        glPolygonMode (GL_BACK, GL_LINE);
        glCullFace (GL_FRONT);

        glDisable (GL_DEPTH_TEST);
        glLineWidth (5.0f);

        // Draw wire object
        glColor3f (1.0f, 0.0f, 0.0f);

        simpleDraw();

        // GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT
        glPopAttrib ();

        // Draw front-facing polygons as filled

        glPolygonMode (GL_FRONT, GL_FILL);
        glCullFace (GL_BACK);

        //Draw solid object
        glColor3f (colorId.redF(), colorId.greenF(), colorId.blueF());

        simpleDraw();

        //GL_POLYGON_BIT
        glPopAttrib ();

        glEnable (GL_LIGHTING);
    }
    virtual void drawSilhouetteOnly()
    {
        glDisable (GL_LIGHTING);
        glPushAttrib (GL_POLYGON_BIT);
        glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
        // Draw front-facing polygons as filled
        glPolygonMode (GL_FRONT, GL_FILL);
        //glCullFace (GL_BACK);
        //Draw solid object
        glColor3f (colorId.redF(), colorId.greenF(), colorId.blueF());

        simpleDraw();
        glPopAttrib ();

        glEnable (GL_LIGHTING);
    }
    virtual void drawStencilOutline()
    {
        /* Clear stencil buffer */
            glClearStencil (0);
            glClear (GL_STENCIL_BUFFER_BIT);

            /*
             * Draw front-facing polygons as filled
             */

            /* Disable color and depth buffers */
            glColorMask (GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
            glDepthMask (GL_FALSE);

            /* Setup stencil buffer. Draw always in it */
            glEnable (GL_STENCIL_TEST);
            glStencilFunc (GL_ALWAYS, 1, 0xFFFFFFFF);
            glStencilOp (GL_REPLACE, GL_REPLACE, GL_REPLACE);

            /* Draw solid object to create a mask */
            glColor3f (1.0f, 1.0f, 1.0f);
            simpleDraw();

            /*
             * Draw back-facing polygons as red lines
             */

            /* Enable color and depth buffers */
            glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
            glDepthMask (GL_TRUE);

            /* Setup stencil buffer. We don't draw inside the mask */
            glStencilFunc (GL_NOTEQUAL, 1, 0xFFFFFFFF);

            /* Disable lighting for outlining */
            glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_POLYGON_BIT);
            glDisable (GL_LIGHTING);

            glEnable (GL_CULL_FACE);

            glPolygonMode (GL_BACK, GL_LINE);
            glCullFace (GL_FRONT);

            glLineWidth (5.0f);

            /* Draw wire object */
            //c.setRedF(0.0392157);
            //c.setGreenF(0.466667);
            //c.setBlueF(0.333333);
            //c.setAlphaF(1.0);
            glColor3f (1.0f, 0.0f, 0.0f);
            //glColor3f (0.0392157f, 0.466667f, 0.333333f);

            simpleDraw();

            /* GL_LIGHTING_BIT | GL_LINE_BIT | GL_POLYGON_BIT */
            glPopAttrib ();

            glDisable (GL_STENCIL_TEST);

    }



    virtual void drawSurface()
    {
        glEnable(GL_DEPTH_TEST);

        if(vertices.size()>0)
            glEnableClientState(GL_VERTEX_ARRAY);

        if(normals.size()>0)
            glEnableClientState(GL_NORMAL_ARRAY);

        if(texcoords.size()>0)
           glEnableClientState(GL_TEXTURE_COORD_ARRAY);

        if(vertices.size()>0)
            glVertexPointer(3, GL_FLOAT, 0, (float*)vertices.constData());

        if(normals.size()>0)
            glNormalPointer(GL_FLOAT, 0, (float *)normals.constData());

        if(texcoords.size()>0)
           glTexCoordPointer(2, GL_FLOAT, 0, (float*)texcoords.constData() );



        if(type()==MODEL_MESH)
        {
            if(indices.size()>0)
               glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, indices.constData());
        }
        else
        {
            //draw quads
            if(indices.size()%4==0 && indices.size()>0)
                glDrawElements(GL_QUADS, indices.size(), GL_UNSIGNED_INT, indices.constData());


            //draw triangles
            if(indices.size()%3==0 && indices.size()>0)
               glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, indices.constData());

        }

        if(normals.size()>0)
            glDisableClientState(GL_NORMAL_ARRAY);

        if(vertices.size()>0)
            glDisableClientState(GL_VERTEX_ARRAY);

        if(texcoords.size()>0)
            glDisableClientState(GL_TEXTURE_COORD_ARRAY);


        glDisable(GL_DEPTH_TEST);


    }
    virtual void drawEdges()
    {
        if(edges.size()>0)
        {
            glDisable(GL_LIGHTING);
            glEnable(GL_DEPTH_TEST);

            glEnableClientState(GL_VERTEX_ARRAY);
            glEnable(GL_COLOR_MATERIAL);

            QColor Ccyan(71,206,218);

            //QColor edgeColor(Qt::cyan);
            //QColor edgeColor(Qt::magenta);
            //QColor edgeColor(Qt::green);
            //QColor edgeColor(Qt::darkGreen);

            //QColor edgeColor(Qt::gray);
            //QColor edgeColor(Qt::black);
            //QColor edgeColor(Qt::white);

            //QColor edgeColor(Qt::darkBlue);
            //QColor edgeColor(Qt::yellow);

            QColor edgeColor(Ccyan);

            glColor3f(edgeColor.redF(),edgeColor.greenF(),edgeColor.blueF());
            glLineWidth(2);

            glVertexPointer(3, GL_FLOAT, 0, (float*)vertices.constData());
            glDrawElements(GL_LINES, edges.size(), GL_UNSIGNED_INT, edges.constData());

            glDisable(GL_COLOR_MATERIAL);
            glDisableClientState(GL_VERTEX_ARRAY);
            glDisable(GL_DEPTH_TEST);

            glEnable(GL_LIGHTING);

        }
    }
    virtual void drawPoints()
    {
        if(vertices.size()>0)
        {
            glPointSize(5.0);
            glEnable(GL_POINT_SMOOTH);

            glDisable(GL_LIGHTING);
            glEnable(GL_DEPTH_TEST);
            glEnable(GL_COLOR_MATERIAL);
            glEnableClientState(GL_VERTEX_ARRAY);

            glVertexPointer(3, GL_FLOAT, 0, (float *)vertices.constData());
            glDrawElements(GL_POINTS, indices.size(), GL_UNSIGNED_INT, indices.constData());

            glDisableClientState(GL_VERTEX_ARRAY);
            glDisable(GL_COLOR_MATERIAL);
            glDisable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);

            glDisable(GL_POINT_SMOOTH);

        }

    }
    virtual void drawPointsNormals()
    {
        if(normals.size()>0)
        {
            // This function needs to be sped up
            glEnable(GL_DEPTH_TEST);

            glEnableClientState(GL_VERTEX_ARRAY);

            // Consider caching this normals

            QVector<QVector3D> normals;

            for (int i = 0; i < normals.size(); ++i)
            {
                // N = point + normal * scalar

                // Draw line from point to N

                normals << vertices.at(i) << (vertices.at(i) + normals.at(i) * 0.2f);
            }

            glVertexPointer(3, GL_FLOAT, 0, (float *)normals.constData());

            glDrawArrays(GL_LINES, 0, normals.size());

            glDisableClientState(GL_VERTEX_ARRAY);

            glDisable(GL_DEPTH_TEST);
        }
    }

    virtual void drawFacesNormals()
    {

    }
    virtual void drawCenter()
    {

        glDisable(GL_LIGHTING);        
        glEnable(GL_DEPTH_TEST);
        //glEnable(GL_COLOR_MATERIAL);

        glPointSize(5.0);
        //glTexEnvi(GL_POINT_SPRITE, GL_COORD_REPLACE, GL_TRUE);
        //glPointParameteri(GL_POINT_SPRITE_COORD_ORIGIN, GL_LOWER_LEFT);
        //glEnable(GL_POINT_SPRITE);
        //glEnable(GL_BLEND);
        //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


        //glPointSize(50);

        glBegin(GL_POINTS);
        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());
        glVertex3f(position.x(),position.y(),position.z());
        glEnd();

        /*

        glBegin(GL_QUADS);
        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());

        glNormal3d(0, 0, 1);
        //first vertex
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(-1.0f, 1.0f, 0);
        //second vertex
        glTexCoord2f(1.0f, 0.0f);
        glVertex3f(1.0, 1.0, 0);
        //third vertex
        glTexCoord2f(1.0f, 1.0f);
        glVertex3f(1.0, -1.0, 0);
        //fourth vertex
        glTexCoord2f(0.0f, 1.0f);
        glVertex3f(-1.0, -1.0, 0);
        glEnd();

        */

        /*
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, (float *)m_points.constData());
        glDrawElements(GL_POINTS, m_pointIndices.size(), GL_UNSIGNED_INT, m_pointIndices.constData());
        glDisableClientState(GL_VERTEX_ARRAY);
        */

        //glDisable(GL_POINT_SMOOTH);
        //glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    virtual void drawPivot()
    {
        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);

        glPointSize(50.0);

        glBegin(GL_POINTS);
        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());
        glVertex3f(pivotPoint.x(),pivotPoint.y(),pivotPoint.z());
        glEnd();


        glDisable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

    virtual void drawBoundingBox()
    {
        /*
        if(boundingAabbox.min.y() == boundingAabbox.max.y())
        {
            boundingAabbox.min -= QVector3D(0,0.05,0);
            boundingAabbox.max += QVector3D(0,0.05,0);
        }

        QAabb b;

        b = boundingAabbox;

        //b.translate(position);

        b.draw(colorId);

        */
    }

    virtual void drawModel(bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */

            if(!hasParent)
            {
                qComputeLocalMatrix();
                qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                qMultMatrix(worldMatrix);
            }

            if(SilhouetteOnly)
            {
                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }
            }
            else
            {

                if(visibilityParameters->showStencil)
                {
                    drawStencilOutline();
                }

                if(visibilityParameters->showOutline)
                {
                    drawOutline();
                }

                if(visibilityParameters->showSilhuoette)
                {
                    drawSilhouette();
                }

                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }

                if(visibilityParameters->showSurface)
                {
                    drawSurface();
                }

                if(visibilityParameters->showWireframe)
                {
                    drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                    drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    drawPoints();
                }

            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }
    virtual void drawModel(QMatrix4x4 PV,bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */

            if(!hasParent)
            {
                qComputeLocalMatrix();

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  localMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
                //qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                //qMultMatrix(worldMatrix);

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  worldMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
            }

            if(SilhouetteOnly)
            {
                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }
            }
            else
            {

                if(visibilityParameters->showStencil)
                {
                    drawStencilOutline();
                }

                if(visibilityParameters->showOutline)
                {
                    drawOutline();
                }

                if(visibilityParameters->showSilhuoette)
                {
                    drawSilhouette();
                }

                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }

                if(visibilityParameters->showSurface)
                {
                    drawSurface();                    
                }

                if(visibilityParameters->showWireframe)
                {
                    drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                    drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    drawPoints();
                }
            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }

    virtual void computeFaceNormals()
    {
        /*
        facesNormals.clear();
        normals.clear();

        for(int i=0;i<faces.size();i++)
        {
            QVector4D face  =  faces[i];

            QVector3D v1 =  vertices[(int)face.x()];
            QVector3D v2 =  vertices[(int)face.y()];
            QVector3D v3 =  vertices[(int)face.z()];
            QVector3D v4 =  vertices[(int)face.w()];

            QVector3D vec1 = v2 - v1;
            QVector3D vec2 = v3 - v1;

            vec1.normalize();
            vec2.normalize();

            QVector3D normal =  QVector3D::crossProduct(vec1,vec2);

            normal.normalize();

            facesNormals.append(normal);
        }

        QList<QVector3D> neighborFaceNormals;

        for(int i=0;i<vertices.size();i++)
        {
            for( int j =0;j<faces.size();j++)
            {
                QVector4D face = faces[j];

                if((int)face.x() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }

                if((int)face.y() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
                if((int)face.z() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
                if((int)face.w() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
           }

            QVector3D ve;

            if(neighborFaceNormals.size()==4)
            {
                ve += neighborFaceNormals[0];
                ve += neighborFaceNormals[1];
                ve += neighborFaceNormals[2];
                ve += neighborFaceNormals[3];

                ve/= 4;
            }

            if(neighborFaceNormals.size()==3)
            {
                ve += neighborFaceNormals[0];
                ve += neighborFaceNormals[1];
                ve += neighborFaceNormals[2];
                //ve += neighborFaceNormals[3];

                ve/= 3;
            }

            ve.normalize();

            normals.append(ve);
        }

        */
    }
    virtual void computeNormals()
    {
        normals.clear();
        normals.resize(vertices.size());

        //Quads
        if(indices.size()%4==0)
        {

            for (int i = 0; i < indices.size(); i += 4)
            {
                const QVector3D a = vertices.at(indices.at(i));
                const QVector3D b = vertices.at(indices.at(i+1));
                const QVector3D c = vertices.at(indices.at(i+2));

                const QVector3D normal = QVector3D::crossProduct(b - a, c - a).normalized();

                for (int j = 0; j < 4; ++j)
                {
                    normals[indices.at(i + j)] += normal;
                }
            }
        }

        //Triangles
        if(indices.size()%3==0)
        {

            for (int i = 0; i < indices.size(); i += 3)
            {
                const QVector3D a = vertices.at(indices.at(i));
                const QVector3D b = vertices.at(indices.at(i+1));
                const QVector3D c = vertices.at(indices.at(i+2));

                const QVector3D normal = QVector3D::crossProduct(b - a, c - a).normalized();

                for (int j = 0; j < 4; ++j)
                {
                    normals[indices.at(i + j)] += normal;
                }
            }
        }

        for (int i = 0; i < normals.size(); ++i)
        {
            normals[i] = normals[i].normalized()*-1;
        }


    }
    virtual void flipNormals()
    {
        for (int i = 0; i < normals.size(); ++i)
        {
            normals[i] *= -1.0;
        }
    }
    virtual void computeUvCoordinates(){}
    virtual void computeBounds()
    {
        boundingSphere = QSphere3D(QVector3D(0,0,0),0);

        boundingAabbox = QBox3D(QVector3D(0,0,0),QVector3D(0,0,0));


        if(vertices.size()>0)
        {
            for(int i=0;i<vertices.size();i++)
            {
                boundingAabbox.unite(vertices[i]);
            }

            if(boundingAabbox.maximum().y() == boundingAabbox.minimum().y())
            {
                boundingAabbox.unite(QVector3D(0,0.1,0));
                boundingAabbox.unite(QVector3D(0,-0.1,0));
            }


            QVector3D center = boundingAabbox.maximum() + boundingAabbox.minimum();


            center/=2;

            float radius = (boundingAabbox.maximum() -boundingAabbox.minimum()).length();

            boundingSphere =  QSphere3D(center,radius);
        }
    }


    //-----------relationships-----------------

    virtual void setModelPivot(QVector3D pivot = QVector3D(5,0,0))
    {
        pivotPoint =  pivot;
    }

    virtual QVector3D getModelPivot()
    {
        return pivotPoint;
    }

    virtual int getChildCount()
    {
        return children.size();
    }

    bool getHasParent()
    {
        return hasParent;
    }

    void setHasParent(bool hasAparent = false)
    {
        hasParent = hasAparent;
    }

    QBaseModel * parent;

    bool hasParent;

    QList<QBaseModel*> children;

    virtual QBaseModel * getParentModel(){return parent;}

    virtual const QList<QBaseModel*>  & getChildren(){return children;}

    virtual void setParentModel(QBaseModel* model)
    {
        parent = model;
    }
    virtual void addChildModel( QBaseModel* model)
    {
        children.append(model);
    }
    virtual void removeChildModel(QBaseModel* model)
    {
        if(model)
        {
            children.removeAt(children.indexOf(model));
        }
    }

    //-----------relationships-----------------

signals:

    void valueChanged();

public slots:

    virtual void centerMesh()
    {
        QVector3D center(0,0,0);

        QAabb box;

        for(int i=0;i<vertices.size();i++)
        {
            center += vertices[i];

            box.expand(vertices[i]);
        }

        center /= vertices.size();

        for(int i=0;i<vertices.size();i++)
        {
            vertices[i] -= center;
        }
    }

    void setShowParameters()
    {


    }

    void setTransforms()
    {
        position  =  transformParameters->position;
        rotation  =  transformParameters->rotation;
        scale     =  transformParameters->scale;

        emit valueChanged();
    }

    void qComputeLocalMatrix()
    {
        QMatrix4x4 TM,RM,SM;

        TM.translate( position );

        SM.scale( scale );

        RM.rotate(rotation.x(),1,0,0);
        RM.rotate(rotation.y(),0,1,0);
        RM.rotate(rotation.z(),0,0,1);

        localMatrix =  TM *SM* RM;


        /*
        setModelPivot( QVector3D(5,0,0) );

        QMatrix4x4 matrix;
        matrix.translate(pivotPoint * -1);

        matrix.scale(scale);
        matrix.rotate(rotation.x(),1,0,0);
        matrix.rotate(rotation.y(),0,1,0);
        matrix.rotate(rotation.z(),0,0,1);

        matrix.translate(pivotPoint);

        localMatrix =  matrix;
        */
    }

    void qComputeGLobalMatrix()
    {
        QMatrix4x4 TM,RM,SM;

        TM.translate(position);

        SM.scale(scale);

        RM.rotate(rotation.x(),1,0,0);
        RM.rotate(rotation.y(),0,1,0);
        RM.rotate(rotation.z(),0,0,1);

        localMatrix =  TM *SM* RM;

        if(hasParent)
        {
            worldMatrix = localMatrix * parent->localMatrix;
        }
    }

};

class QRootModel : public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    enum { Type = MODEL_ROOTMODEL};

    int type() const  { return Type; }




    QRootModel(QObject * parent =0) : QBaseModel(parent)
    {

        name = QString("Root Model");

        //QString campassFile = QString(":/Tools Icons/compass_shape1.svg");

        QString campassFile = QString(":/Tools Icons/compass_shape.svg");



        //error no direct acces to the the polygons

        //polygons = path.toSubpathPolygons();

        qDebug()<<"Polygons:"<<polygons;

        addWidgets();

        /*

        QPolygonF polyN;

        polyN.append(QPointF(37.316,95.768));
        polyN.append(QPointF(44.328,95.768));
        polyN.append(QPointF(53.182,84.501));
        polyN.append(QPointF(53.182,95.768));
        polyN.append(QPointF(59.134,95.768));
        polyN.append(QPointF(59.134,79.340));
        polyN.append(QPointF(52.122,79.340));
        polyN.append(QPointF(43.267,90.607));
        polyN.append(QPointF(43.267,79.340));
        polyN.append(QPointF(37.316,79.340));


        QPolygonF polyE;

        polyE.append(QPointF(85.912,49.958));
        polyE.append(QPointF(91.962,49.958));
        polyE.append(QPointF(91.962,48.268));
        polyE.append(QPointF(88.154,48.263));
        polyE.append(QPointF(88.154,46.645));
        polyE.append(QPointF(91.735,46.645));
        polyE.append(QPointF(91.735,44.950));
        polyE.append(QPointF(88.154,44.950));
        polyE.append(QPointF(88.154,42.958));
        polyE.append(QPointF(92.090,42.958));
        polyE.append(QPointF(92.090,41.264));
        polyE.append(QPointF(85.912,41.264));

        QPointF c(0,0);


        QPolygonF polyCompass;
        polyCompass.append(QPointF(13.399,46.855));
        polyCompass.append(QPointF(27.972,55.179));
        polyCompass.append(QPointF(27.947,49.847));
        polyCompass.append(QPointF(33.926,49.847));
        polyCompass.append(QPointF(44.890,60.739));
        polyCompass.append(QPointF(44.890,65.268));
        polyCompass.append(QPointF(39.978,65.268));
        polyCompass.append(QPointF(48.370,79.803));

        polyCompass.append(QPointF(56.761,65.267));
        polyCompass.append(QPointF(51.850,65.267));
        polyCompass.append(QPointF(51.850,60.837));
        polyCompass.append(QPointF(63.276,49.641));
        polyCompass.append(QPointF(68.749,49.641));
        polyCompass.append(QPointF(68.805,54.337));
        polyCompass.append(QPointF(83.238,45.772));
        polyCompass.append(QPointF(68.604,37.555));
        polyCompass.append(QPointF(68.670,43.091));
        polyCompass.append(QPointF(63.427,43.091));
        polyCompass.append(QPointF(52.157,31.357));
        polyCompass.append(QPointF(52.157,26.372));
        polyCompass.append(QPointF(57.274,26.371));
        polyCompass.append(QPointF(48.879,11.89));
        polyCompass.append(QPointF(40.491,26.376));
        polyCompass.append(QPointF(45.197,26.375));
        polyCompass.append(QPointF(45.197,31.307));
        polyCompass.append(QPointF(33.689,43.296));
        polyCompass.append(QPointF(27.917,43.296));
        polyCompass.append(QPointF(27.894,38.396));


        for(int i=0;i<polyN.size();i++)
        {
            c+=polyN[i];
        }

        for(int i=0;i<polyE.size();i++)
        {
            c+=polyE[i];
        }

        for(int i=0;i<polyCompass.size();i++)
        {
            c+=polyCompass[i];
        }

        c/=(polyN.size()+polyCompass.size()+polyE.size());

        for(int i=0;i<polyN.size();i++)
        {
            polyN[i] -= c;

            polyN[i] /=100;
        }

        for(int i=0;i<polyE.size();i++)
        {
            polyE[i] -= c;

            polyE[i] /=100;
        }

        for(int i=0;i<polyCompass.size();i++)
        {
            polyCompass[i] -= c;

            polyCompass[i] /=100;
        }

        polygons.clear();
        polygons.append(polyN);
        polygons.append(polyE);
        polygons.append(polyCompass);

        */



        qDebug()<<"Polygons:"<<polygons;
    }

    ~QRootModel()
    {
        delete properties;
    }


    QList<QPolygonF> polygons;

    void drawCenter()
    {
        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);

        /*

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        QColor color = QColor(Qt::black);

        glColor4f( color.redF(), color.greenF(), color.blueF(),0.5f);

        for(int j=0;j<polygons.size();j++)
        {
            QPolygonF polygon =  polygons[j];

            glBegin(GL_POLYGON);

            foreach(QPointF t,polygon.toList())
            {                
                QVector3D c = QVector3D(-t.x(),0,t.y());

                glVertex3f(c.x(),c.y(),c.z());
            }

            glEnd();
        }

        glDisable(GL_BLEND);
        */


        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(2.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( scolor.redF(), scolor.greenF(), scolor.blueF());

        /*
        for(int j=0;j<polygons.size();j++)
        {
            QPolygonF polygon =  polygons[j];

            glBegin(GL_LINE_LOOP);

            foreach(QPointF t,polygon.toList())
            {
                QVector3D c = QVector3D(-t.x(),0,t.y());

                glVertex3f(c.x(),c.y(),c.z());
            }

            glEnd();
        }
        */

        glBegin(GL_LINE_LOOP);



            glVertex3f(0,0,1);
            glVertex3f(0,0,-1);


        glEnd();

        glBegin(GL_LINE_LOOP);



            glVertex3f(1,0,0);
            glVertex3f(-1,0,0);


        glEnd();

        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);
    }


    void drawOutline()
    {


    }
    void drawOutlineOnly()
    {


    }

    void drawSilhouette()
    {

    }
    void drawSilhouetteOnly()
    {

    }
    void drawStencilOutline()
    {

    }

    void drawSurface()
    {

        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);

        /*

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        QColor color = QColor(Qt::black);

        glColor4f( color.redF(), color.greenF(), color.blueF(),0.5f);

        for(int j=0;j<polygons.size();j++)
        {
            QPolygonF polygon =  polygons[j];

            glBegin(GL_POLYGON);

            foreach(QPointF t,polygon.toList())
            {
                QVector3D c = QVector3D(-t.x(),0,t.y());

                glVertex3f(c.x(),c.y(),c.z());
            }

            glEnd();
        }

        glDisable(GL_BLEND);
        */


        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(2.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( scolor.redF(), scolor.greenF(), scolor.blueF());

        /*
        for(int j=0;j<polygons.size();j++)
        {
            QPolygonF polygon =  polygons[j];

            glBegin(GL_LINE_LOOP);

            foreach(QPointF t,polygon.toList())
            {
                QVector3D c = QVector3D(-t.x(),0,t.y());

                glVertex3f(c.x(),c.y(),c.z());
            }

            glEnd();
        }
        */

        glBegin(GL_LINE_LOOP);



            glVertex3f(0,0,1);
            glVertex3f(0,0,-1);


        glEnd();

        glBegin(GL_LINE_LOOP);



            glVertex3f(1,0,0);
            glVertex3f(-1,0,0);


        glEnd();









        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);

        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);
    }
    void drawEdges()
    {
        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);
        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(2.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( scolor.redF(), scolor.greenF(), scolor.blueF());

        /*
        for(int j=0;j<polygons.size();j++)
        {
            QPolygonF polygon =  polygons[j];

            glBegin(GL_LINE_LOOP);

            foreach(QPointF t,polygon.toList())
            {
                QVector3D c = QVector3D(-t.x(),0,t.y());

                glVertex3f(c.x(),c.y(),c.z());
            }

            glEnd();
        }
        */

        glBegin(GL_LINE_LOOP);



            glVertex3f(0,0,1);
            glVertex3f(0,0,-1);


        glEnd();

        glBegin(GL_LINE_LOOP);



            glVertex3f(1,0,0);
            glVertex3f(-1,0,0);


        glEnd();

        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);

        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);
    }

    void drawPoints()
    {



    }
    void drawPointsNormals()
    {


    }
    void drawFacesNormals()
    {

    }


    void drawPivot()
    {

    }


    void drawModel(bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */

            if(!hasParent)
            {
                qComputeLocalMatrix();
                qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                qMultMatrix(worldMatrix);
            }

            if(SilhouetteOnly)
            {
                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }
            }
            else
            {

                if(visibilityParameters->showStencil)
                {
                    drawStencilOutline();
                }

                if(visibilityParameters->showOutline)
                {
                    drawOutline();
                }

                if(visibilityParameters->showSilhuoette)
                {
                    drawSilhouette();
                }

                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }


                if(visibilityParameters->showSurface)
                {
                    drawSurface();
                }

                if(visibilityParameters->showWireframe)
                {
                    drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                    drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    drawPoints();
                }

            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }

    void drawModel(QMatrix4x4 PV,bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */



            if(!hasParent)
            {
                qComputeLocalMatrix();

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  localMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
                //qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                //qMultMatrix(worldMatrix);

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  worldMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
            }


            {
                if(visibilityParameters->showSurface)
                {
                    drawSurface();
                }

                if(visibilityParameters->showWireframe)
                {
                    //drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    //drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                   // drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    //drawPoints();
                }

            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }


    void computeFaceNormals()
    {

    }
    void computeNormals()
    {



    }
    void flipNormals()
    {

    }
    void computeUvCoordinates(){}

    /*
    void computeBounds()
    {
        boundingSphere = QBoundSphere(0,QVector3D(0,0,0));
        boundingAabbox =  QAabb(QVector3D(0,0,0),QVector3D(0,0,0));

        boundingSphere.radius =0;
        boundingAabbox.radius = 0;


        if(vertices.size()>0)
        {
            for(int i=0;i<vertices.size();i++)
            {
                boundingSphere.center += vertices[i];
                boundingAabbox.expand(vertices[i]);
            }

            boundingSphere.center /= vertices.size();
            boundingAabbox.center = boundingAabbox.getCenter();


            QList<float> distances;

            for(int i=0;i<vertices.size();i++)
            {
                QVector3D d  = boundingSphere.center - vertices[i];

                distances.append(fabs(d.length()));
            }

            qSort(distances);

            boundingSphere.radius = distances.last();

            if(boundingSphere.radius==0)
            {
                boundingSphere.radius = 1;
            }

            boundingAabbox.radius = boundingSphere.radius;

            if((boundingAabbox.max.y()-boundingAabbox.min.y())==0)
            {
                boundingAabbox.max += QVector3D(0,.1,0);
                boundingAabbox.min -= QVector3D(0,.1,0);

                boundingAabbox.radius = 0.5*(boundingAabbox.max-boundingAabbox.min).length();
           }
        }
    }

    */
};

class QLocationModel : public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    enum { Type = MODEL_LOCATION};

    int type() const  { return Type; }

    QLocationModel(QObject * parent =0) : QBaseModel(parent)
    {
        vertices.clear();

        name = QString("Location Model");

        //QString campassFile = QString(":/Tools Icons/compass_shape1.svg");

        QString campassFile = QString(":/Tools Icons/compass_shape.svg");

        vertices.clear();
        vertices.append(QVector3D(-0.5,0,0));
        vertices.append(QVector3D(0.5,0,0));

        vertices.append(QVector3D(0,-0.5,0));
        vertices.append(QVector3D(0,0.5,0));

        vertices.append(QVector3D(0,0,-0.5));
        vertices.append(QVector3D(0,0,0.5));

        vertices.append(QVector3D(0,0,0));

        computeBounds();

        addWidgets();
    }

    ~QLocationModel()
    {
        delete properties;
    }

    void drawOutline()
    {


    }
    void drawOutlineOnly()
    {


    }

    void drawSilhouette()
    {

    }
    void drawSilhouetteOnly()
    {

    }
    void drawStencilOutline()
    {

    }

    void drawSurface()
    {

        //QColor colorId;
        //QColor selectedColor;

        glDisable(GL_LIGHTING);

        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(5.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());

        glBegin(GL_LINES);

        glVertex3f(-0.5,0,0);
        glVertex3f(0.5,0,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,-0.5,0);
        glVertex3f(0,0.5,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,0,-0.5);
        glVertex3f(0,0,0.5);

        glEnd();

        glEnable(GL_LIGHTING);
    }
    void drawEdges()
    {
        glDisable(GL_LIGHTING);

        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(5.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());

        glBegin(GL_LINES);

        glVertex3f(-0.5,0,0);
        glVertex3f(0.5,0,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,-0.5,0);
        glVertex3f(0,0.5,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,0,-0.5);
        glVertex3f(0,0,0.5);

        glEnd();

        glEnable(GL_LIGHTING);
    }

    void drawPoints()
    {



    }
    void drawPointsNormals()
    {


    }
    void drawFacesNormals()
    {

    }
    void drawCenter()
    {
        glDisable(GL_LIGHTING);

        //glLineWidth(svgshape.style.stroke_width);
        glLineWidth(5.0f);

        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( colorId.redF(), colorId.greenF(), colorId.blueF());

        glBegin(GL_LINES);

        glVertex3f(-0.5,0,0);
        glVertex3f(0.5,0,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,-0.5,0);
        glVertex3f(0,0.5,0);

        glEnd();

        glBegin(GL_LINES);

        glVertex3f(0,0,-0.5);
        glVertex3f(0,0,0.5);

        glEnd();

        glEnable(GL_LIGHTING);
    }


    void drawPivot()
    {

    }


    void drawModel(bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */

            if(!hasParent)
            {
                qComputeLocalMatrix();
                qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                qMultMatrix(worldMatrix);
            }

            if(SilhouetteOnly)
            {
                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }
            }
            else
            {

                if(visibilityParameters->showStencil)
                {
                    drawStencilOutline();
                }

                if(visibilityParameters->showOutline)
                {
                    drawOutline();
                }

                if(visibilityParameters->showSilhuoette)
                {
                    drawSilhouette();
                }

                if(visibilityParameters->showSilhuoetteOnly)
                {
                    drawSilhouetteOnly();
                }


                if(visibilityParameters->showSurface)
                {
                    drawSurface();
                }

                if(visibilityParameters->showWireframe)
                {
                    drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                    drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    drawPoints();
                }

            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }

    void drawModel(QMatrix4x4 PV,bool SilhouetteOnly = false)
    {
        if(visibilityParameters->showModel == true)
        {
            glPushMatrix();

            /*

            printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

            glTranslatef(position.x(),position.y(),position.z());

            glRotatef(rotation.x(),1,0,0);
            glRotatef(rotation.y(),0,1,0);
            glRotatef(rotation.z(),0,0,1);

            glScalef(scale.x(),scale.y(),scale.z());

            */



            if(!hasParent)
            {
                qComputeLocalMatrix();

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  localMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
                //qMultMatrix(localMatrix);
            }
            else
            {
                qComputeGLobalMatrix();
                //qMultMatrix(worldMatrix);

                QMatrix4x4 modelMatrix;

                modelMatrix.setToIdentity();

                modelMatrix =  worldMatrix;

                QMatrix4x4 PVM   = PV * modelMatrix;

                qMultMatrix(PVM);
            }


            {
                if(visibilityParameters->showSurface)
                {
                    drawSurface();
                }

                if(visibilityParameters->showWireframe)
                {
                    //drawEdges();
                }

                if(visibilityParameters->showCenter)
                {
                    //drawCenter();
                }

                if(visibilityParameters->showBoundingBox)
                {
                   // drawBoundingBox();
                }

                if(visibilityParameters->showPoints)
                {
                    //drawPoints();
                }

            }




            if(!SilhouetteOnly)
            {
                if(visibilityParameters->showPointsNormals)
                {
                    drawPointsNormals();
                }

                if(visibilityParameters->showFacesNormals)
                {
                    drawFacesNormals();
                }
            }


            glPopMatrix();
        }
    }


    void computeFaceNormals()
    {

    }
    void computeNormals()
    {



    }
    void flipNormals()
    {

    }
    void computeUvCoordinates(){}

    /*
    void computeBounds()
    {
        boundingSphere = QBoundSphere(0,QVector3D(0,0,0));
        boundingAabbox =  QAabb(QVector3D(0,0,0),QVector3D(0,0,0));

        boundingSphere.radius =0;
        boundingAabbox.radius = 0;


        if(vertices.size()>0)
        {
            for(int i=0;i<vertices.size();i++)
            {
                boundingSphere.center += vertices[i];
                boundingAabbox.expand(vertices[i]);
            }

            boundingSphere.center /= vertices.size();
            boundingAabbox.center = boundingAabbox.getCenter();


            QList<float> distances;

            for(int i=0;i<vertices.size();i++)
            {
                QVector3D d  = boundingSphere.center - vertices[i];

                distances.append(fabs(d.length()));
            }

            qSort(distances);

            boundingSphere.radius = distances.last();

            if(boundingSphere.radius==0)
            {
                boundingSphere.radius = 1;
            }

            boundingAabbox.radius = boundingSphere.radius;

            if((boundingAabbox.max.y()-boundingAabbox.min.y())==0)
            {
                boundingAabbox.max += QVector3D(0,.1,0);
                boundingAabbox.min -= QVector3D(0,.1,0);

                boundingAabbox.radius = 0.5*(boundingAabbox.max-boundingAabbox.min).length();
           }
        }
    }

    */

};

class QGroupModel: public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }
    QList<QBaseModel*> group;

    enum { Type = MODEL_GROUP};

    int type() const  { return Type; }   

    QGroupModel(QObject * parent =0) : QBaseModel(parent)
    {
        name = QString("Group Model");

        addWidgets();
    }

    ~QGroupModel()
    {

    }

    void addModel(QBaseModel * model)
    {
        group.append(model);
    }

    void removeModel(QBaseModel * model)
    {
        group.removeAt(group.indexOf(model));
    }

    int getModelCount()
    {
        return group.size();
    }

    void draw()
    {
        drawBoundingBox();
    }

    void drawBoundingBox()
    {

        QBox3D b = boundingAabbox;

        for(int i=0;i<group.size();i++)
        {
            QBaseModel * m =  group[i];

            b.unite(m->boundingAabbox);
        }

        QColor col =  QColor(Qt::cyan);



        /*
        b.draw(col);

        QAabb b = boundingAabbox;

        for(int i=0;i<group.size();i++)
        {
            QBaseModel * m =  group[i];

            b.merge(m->boundingAabbox);
        }

        QColor col =  QColor(Qt::cyan);

        b.draw(col);
        */
    }
};

class QQuadModel: public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }


    enum { Type = MODEL_QUAD};

    int type() const  { return Type; }


    QQuadModel(QObject * parent =0) : QBaseModel(parent)
    {
        vertices.clear();

        name = QString("Quad Polygon");

        generateQuad();

        addWidgets();
    }

    ~QQuadModel()
    {
        delete properties;

    }

    void generateQuad()
    {
        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();

        position = QVector3D(0,0,0);

        QVector3D normal(0,1,0);

        float n = 1;

        QVector3D v0(-n, 0,  n );
        QVector3D v1(-n, 0, -n );
        QVector3D v2( n, 0, -n );
        QVector3D v3( n, 0,  n );

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);

        normals.append(normal);
        normals.append(normal);
        normals.append(normal);
        normals.append(normal);

        int index_0 =0;
        int index_1 =1;
        int index_2 =2;
        int index_3 =3;


        indices.append(index_0);
        indices.append(index_1);
        indices.append(index_2);
        indices.append(index_3);


        edges.append(index_0);
        edges.append(index_1);

        edges.append(index_1);
        edges.append(index_2);

        edges.append(index_2);
        edges.append(index_3);

        edges.append(index_3);
        edges.append(index_0);

        computeBounds();

        //boundingAabbox.max += QVector3D(0,.5,0);
        //boundingAabbox.min -= QVector3D(0,.5,0);
    }
};

class QPlaneModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float width;
    float length;


    QPropertiesTreeWidget *properties;

public:



    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }




    PlaneParameters * parameters;


    QPlaneModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new PlaneParameters;

        //usteps = 4;
        //vsteps = 4;

        //width  = 1;
        //length = 1;

        usteps = parameters->usteps;
        vsteps = parameters->vsteps;
        width  = parameters->width;
        length = parameters->length;


        name = QString("Plane Model");

        n_grid(width,length,usteps,vsteps);

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));


        addWidgets();
    }

    ~QPlaneModel()
    {
        delete properties;
        delete parameters;
    }

    enum { Type = MODEL_PLANE};


    int type() const  { return Type; }



    void n_grid(int width,int length, int u_steps,int v_steps)
    {
        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();

        if(u_steps>0 && v_steps>0 && width>0&&length >0)
        {
            float c_x = width/2.0;
            float c_z = length/2.0;

            QList< QPair<int,int> > tuples;

            float step_u = (float)width / u_steps;

            float step_v = (float)length / v_steps;


            float s_u   = 1 / u_steps;
            float s_v   = 1 / v_steps;

            for( int i=0;i<=u_steps ;i++)
            {
                //#pragma omp parallel for
                for(int j=0; j<=v_steps;j++)
                {
                    float s = s_u  * i;
                    float t = s_v  * j;

                    texcoords.append(QVector2D(s,t));

                    float x = i * step_u;
                    float z = j * step_v;

                    float y = 0;

                    QVector3D p = QVector3D(x , y , z );

                    p -= QVector3D(c_x,0,c_z);

                    vertices.append(p);

                    QVector3D normal(0,1,0);

                    normals.append(normal);

                    tuples.append(QPair<int,int>(i, j));

                }
            }

            //#pragma omp parallel for
            for(int i=0;i<=u_steps-1;i++)
            {
                //#pragma omp parallel for
                for(int j =0;j<=v_steps-1;j++)
                {
                    int index0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    indices.append(index0);
                    indices.append(index1);
                    indices.append(index2);
                    indices.append(index3);

                    edges.append(index0);
                    edges.append(index1);

                    edges.append(index1);
                    edges.append(index2);

                    edges.append(index2);
                    edges.append(index3);

                    edges.append(index3);
                    edges.append(index0);
                }
            }

            //computeNormals();

            computeBounds();
        }
    }

signals:

    void valueChanged();


private slots:

    void updateGrid()
    {
        usteps = parameters->usteps;
        vsteps = parameters->vsteps;
        width  = parameters->width;
        length = parameters->length;

        n_grid(width,length,usteps,vsteps);

        qDebug()<<"Parameters Changed \n";

        emit valueChanged();
    }   
};

class QCubeModel: public QBaseModel
{
    Q_OBJECT


    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_CUBE};

    int type() const  { return Type; }


    QCubeModel(QObject * parent =0) : QBaseModel(parent)
    {
        vertices.clear();

        name = QString("Cube Model");

        n_cube();

        addWidgets();
    }

    ~QCubeModel()
    {
        delete properties;
        //delete parameters;

    }

    void n_cube(float pscale =0.5f)
    {
        //cube vertices
        //
        //       (-1,1,1)
        //      (4)-----------------(5)(1,1,1)
        //      /|                 /|
        //     / |                / |
        //    / (-1,1,-1)        /  |
        //  (7)-----------------(6) |
        //   |    |              |  |
        //   |    |              |  |
        //   |    |  (-1,-1,1)   |  |
        //   |    (3)--------------(2)(1,-1,1)
        //   |    /             |   /
        //   |   /              |  /
        //   |  /               | /
        //   | /                |/
        //   (0)----------------(1)(1,-1,-1)
        //   (-1,-1,-1)
        //
        //
        // faces:
        //
        // A = (1,2,5,6),B = (7,4,3,0)
        // C = (7,4,5,6),D = (0,3,2,1)
        // E = (0,7,6,1),F = (3,2,5,4)
        //
        // edges:
        //
        //(0,7),(3,4),(2,5),(1,6),
        //(7,4),(0,3),(6,5),(1,2),(3,2),
        //(4,5),(0,1),(7,6)

        /*
    glBegin(GL_QUADS);
            // ??
            glNormal3f( 0.0f, 0.0f, 1.0f);					// ???????
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// ?????????
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// ?????????
            // ??
            glNormal3f( 0.0f, 0.0f,-1.0f);					// ???????
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// ?????????
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// ?????????
            // ??
            glNormal3f( 0.0f, 1.0f, 0.0f);					// ????
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// ?????????
            // ??
            glNormal3f( 0.0f,-1.0f, 0.0f);					// ????
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// ?????????

            // ??
            glNormal3f( 1.0f, 0.0f, 0.0f);					// ????
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// ?????????
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// ?????????
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// ?????????
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// ?????????

            // ??
            glNormal3f(-1.0f, 0.0f, 0.0f);					// ????
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// ?????????
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// ?????????
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// ?????????
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// ?????????
    glEnd();


          */


        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();

        int index0 = 0; vertices.append(QVector3D(-1,-1,-1));
        int index1 = 1; vertices.append(QVector3D(1,-1,-1));
        int index2 = 2; vertices.append(QVector3D(1,-1,1));
        int index3 = 3; vertices.append(QVector3D(-1,-1,1));
        int index4 = 4; vertices.append(QVector3D(-1,1,1));
        int index5 = 5; vertices.append(QVector3D(1,1,1));
        int index6 = 6; vertices.append(QVector3D(1,1,-1));
        int index7 = 7; vertices.append(QVector3D(-1,1,-1));

        //faces

        //right face
        indices.append(index1);
        indices.append(index2);
        indices.append(index5);
        indices.append(index6);

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));

        //left face
        indices.append(index7);
        indices.append(index4);
        indices.append(index3);
        indices.append(index0);

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));


        //top face
        indices.append(index7);
        indices.append(index4);
        indices.append(index5);
        indices.append(index6);

        normals.append(QVector3D(0.0f, 0.0f, 1.0f));

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));

        //bottom face
        indices.append(index0);
        indices.append(index3);
        indices.append(index2);
        indices.append(index1);

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));


        //back face
        indices.append(index0);
        indices.append(index7);
        indices.append(index6);
        indices.append(index1);

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));


        //front face
        indices.append(index3);
        indices.append(index2);
        indices.append(index5);
        indices.append(index4);

        texcoords.append(QVector2D(0,0));
        texcoords.append(QVector2D(1,0));
        texcoords.append(QVector2D(1,1));
        texcoords.append(QVector2D(0,1));

        //edge pairs

        edges.append(indices[0]);
        edges.append(indices[7]);

        edges.append(indices[3]);
        edges.append(indices[4]);

        edges.append(indices[2]);
        edges.append(indices[5]);

        edges.append(indices[1]);
        edges.append(indices[6]);

        edges.append(indices[7]);
        edges.append(indices[4]);

        edges.append(indices[0]);
        edges.append(indices[3]);

        edges.append(indices[6]);
        edges.append(indices[5]);

         edges.append(indices[1]);
         edges.append(indices[2]);

         edges.append(indices[3]);
         edges.append(indices[2]);

         edges.append(indices[4]);
         edges.append(indices[5]);

         edges.append(indices[0]);
         edges.append(indices[1]);

         edges.append(indices[7]);
         edges.append(indices[6]);

         for(int i=0;i<vertices.size();i++)
         {
             vertices[i] *= pscale;
         }

        //computeNormals();

        flipNormals();

        computeBounds();
    }
};

class QRoundedCubeModel: public QBaseModel
{
    Q_OBJECT


    QPropertiesTreeWidget *properties;

    float size;

    float strength;

    int N;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_ROUNDED_CUBE};

    int type() const  { return Type; }

    RoundedCubeParameters * parameters;


    QRoundedCubeModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters =  new RoundedCubeParameters;

        size= parameters->size;

        strength = parameters->strength;

        N = parameters->N;

        vertices.clear();

        name = QString("Rounded Cube Model");

        n_roundedcube(size,N,strength);

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateRoundedCube()));


        addWidgets();
    }

    ~QRoundedCubeModel()
    {
        delete properties;
        //delete parameters;

    }

    void n_roundedcube(float size, int N, float strength)
    {
        //cube vertices
        //
        //       (-1,1,1)
        //      (4)-----------------(5)(1,1,1)
        //      /|                 /|
        //     / |                / |
        //    / (-1,1,-1)        /  |
        //  (7)-----------------(6) |
        //   |    |              |  |
        //   |    |              |  |
        //   |    |  (-1,-1,1)   |  |
        //   |    (3)--------------(2)(1,-1,1)
        //   |    /             |   /
        //   |   /              |  /
        //   |  /               | /
        //   | /                |/
        //   (0)----------------(1)(1,-1,-1)
        //   (-1,-1,-1)
        //
        //
        // faces:
        //
        // A = (1,2,5,6),B = (7,4,3,0)
        // C = (7,4,5,6),D = (0,3,2,1)
        // E = (0,7,6,1),F = (3,2,5,4)
        //
        // edges:
        //
        //(0,7),(3,4),(2,5),(1,6),
        //(7,4),(0,3),(6,5),(1,2),(3,2),
        //(4,5),(0,1),(7,6)


        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();

        if(N>0)
        {
            int i,j,index;
            //int i1,i2,i3,i4;
            double theta,phi;


            //MESHVERTEX *p = NULL,n;
            //double len;
            //FILE *fptr;

            //if (argc < 3)
            //{
            //    fprintf(stderr,"Usage: %s nres strength\n",argv[0]);

            //    exit(-1);
            //}

            //N = atoi(argv[1]);

            //strength = atof(argv[2]);

            // Create vertices
            //if ((p = malloc((N+1)*(N/2+1)*sizeof(MESHVERTEX))) == NULL)
            //{
            //    fprintf(stderr,"malloc failed\n");
            //    exit(-1);
            //}

            vertices.resize((N+1)*(N/2+1));
            texcoords.resize((N+1)*(N/2+1));
            normals.resize((N+1)*(N/2+1));

            strength /= 100;

            // Pole is along the z axis
            for (j=0;j<=N/2;j++)
            {
                for (i=0;i<=N;i++)
                {
                    index = j * (N+1) + i;

                    theta = i * 2 * M_PI / N;

                    phi   = -0.5 * M_PI + M_PI * j / (N/2.0);

                    float x = cpower( cos(phi),strength ) * cpower( cos(theta),strength );
                    float y = cpower( cos(phi),strength ) * cpower( sin(theta),strength );
                    float z = cpower( sin(phi),strength );

                    // Unit sphere, power determines roundness
                   // p[index].x =
                    //p[index].y =
                    //p[index].z =

                    vertices[index] =  QVector3D(x,y,z);

                     // Texture coordinates
                     // Project texture coordinates from a surrounding sphere

                    //p[index].u = atan2(p[index].y,p[index].x) / (2*M_PI);
                    //if (p[index].u < 0)
                    //   p[index].u = 1 + p[index].u;
                    //p[index].v = 0.5 + atan2(p[index].z,sqrt(p[index].x*p[index].x+p[index].y*p[index].y)) / M_PI;


                    float u = atan2( vertices[index].y() , vertices[index].x() ) / (2*M_PI);


                    if (u < 0)
                        u = 1 + u;

                    float length = sqrt(vertices[index].x()*vertices[index].x()+vertices[index].y()*vertices[index].y());

                    float v = 0.5 + atan2( vertices[index].z(),length) / M_PI;


                    texcoords[index] = QVector2D(u,v);


                    // Seams


                    if (j == 0)
                    {
                         vertices[index] = QVector3D(0,0,-1);

                         //p[index].x = 0;
                         //p[index].y = 0;
                         //p[index].z = -1;
                    }


                    if (j == N/2)
                    {
                        //p[index].x = 0;
                        //p[index].y = 0;
                        //p[index].z = 1;

                         vertices[index] = QVector3D(0,0,1);
                    }


                    if (i == N)
                    {
                        //p[index].x = p[j*(N+1)+i-N].x;
                        //p[index].y = p[j*(N+1)+i-N].y;
                        // z isnt handled

                         float x = vertices[j*(N+1)+i-N].x();
                         float y = vertices[j*(N+1)+i-N].y();
                         float z = vertices[index].z();

                         vertices[index] = QVector3D(x,y,z);
                    }
                }
            }

            // Save as textured obj file
            //fptr = fopen("roundcube.obj","w");

            //fprintf(fptr,"mtllib roundcube.mtl\n");
            // Vertices

            //for (j=0;j<=N/2;j++)
           // {
            //    for (i=0;i<=N;i++)
            //    {
            //        index = j * (N+1) + i;

             //       fprintf(fptr,"v %lf %lf %lf\n",p[index].x,p[index].y,p[index].z);
            //    }
            //}


            // Normals (same as vertices in this case but normalised)

            for (j=0;j<=N/2;j++)
            {
                for (i=0;i<=N;i++)
                {
                    index = j * (N+1) + i;

                    QVector3D normal = vertices[index];

                    normal.normalize();

                    normals[index] = normal;

                    //n = p[index];

                    //len = sqrt(n.x*n.x + n.y*n.y + n.z*n.z);

                    //fprintf(fptr,"vn %lf %lf %lf\n",n.x/len,n.y/len,n.z/len);

                }

            }
            // Texture coordinates

            //for (j=0;j<=N/2;j++)
           // {
            //    for (i=0;i<=N;i++)
            //    {
            //        index = j * (N+1) + i;
            //        fprintf(fptr,"vt %lf %lf\n",p[index].u,p[index].v);
             //   }
            //}
            // Faces, each a triangle
            // Vertex count starts at 1 not 0
            //fprintf(fptr,"usemtl material0\n");

            for (j=0;j<N/2;j++)
            {
                for (i=0;i<N;i++)
                {
                    int index0 =  j    * (N+1) + i       + 1;
                    int index1 =  j    * (N+1) + (i + 1) + 1;
                    int index2 = (j+1) * (N+1) + (i + 1) + 1;
                    int index3 = (j+1) * (N+1) + i       + 1;


                    indices.append(index0);
                    indices.append(index1);
                    indices.append(index2);
                    indices.append(index3);

                    edges.append(index0);
                    edges.append(index1);

                    edges.append(index1);
                    edges.append(index2);

                    edges.append(index2);
                    edges.append(index3);

                    edges.append(index3);
                    edges.append(index0);

                    //fprintf(fptr,"f %d/%d/%d %d/%d/%d %d/%d/%d\n",i1,i1,i1,i2,i2,i2,i3,i3,i3);
                    //fprintf(fptr,"f %d/%d/%d %d/%d/%d %d/%d/%d\n",i1,i1,i1,i3,i3,i3,i4,i4,i4);
                }
            }
        }

        //computeNormals();

        flipNormals();

        computeBounds();
    }

    double cpower(double v,double n)
    {
        if (v >= 0)
            return(pow(v,n));
        else
            return(-pow(-v,n));
    }

    /*
double mypower(double,double);

int N = 64; // Mesh resolution
double rpower = 1; // Power that controls corner strength

typedef struct {
    double x,y,z;
    double u,v;
} MESHVERTEX;

int main(int argc,char **argv)
{
    int i,j,index;
    int i1,i2,i3,i4;
    double theta,phi;
    MESHVERTEX *p = NULL,n;
    double len;
    FILE *fptr;

    if (argc < 3) {
        fprintf(stderr,"Usage: %s nres rpower\n",argv[0]);
        exit(-1);
    }
    N = atoi(argv[1]);
    rpower = atof(argv[2]);

    // Create vertices
    if ((p = malloc((N+1)*(N/2+1)*sizeof(MESHVERTEX))) == NULL) {
        fprintf(stderr,"malloc failed\n");
        exit(-1);
    }

    // Pole is along the z axis
    for (j=0;j<=N/2;j++) {
        for (i=0;i<=N;i++) {
            index = j * (N+1) + i;
            theta = i * 2 * M_PI / N;
            phi = -0.5*M_PI + M_PI * j / (N/2.0);

            // Unit sphere, power determines roundness
            p[index].x = mypower(cos(phi),rpower) * mypower(cos(theta),rpower);
            p[index].y = mypower(cos(phi),rpower) * mypower(sin(theta),rpower);
            p[index].z = mypower(sin(phi),rpower);

         // Texture coordinates
         // Project texture coordinates from a surrounding sphere
         p[index].u = atan2(p[index].y,p[index].x) / (2*M_PI);
         if (p[index].u < 0)
            p[index].u = 1 + p[index].u;
         p[index].v = 0.5 + atan2(p[index].z,sqrt(p[index].x*p[index].x+p[index].y*p[index].y)) / M_PI;

            // Seams
            if (j == 0) {
                p[index].x = 0;
                p[index].y = 0;
                p[index].z = -1;
            }
         if (j == N/2) {
            p[index].x = 0;
            p[index].y = 0;
            p[index].z = 1;
         }
            if (i == N) {
                p[index].x = p[j*(N+1)+i-N].x;
            p[index].y = p[j*(N+1)+i-N].y;
            }

        }
    }

    // Save as textured obj file
    fptr = fopen("roundcube.obj","w");
    fprintf(fptr,"mtllib roundcube.mtl\n");
    // Vertices
   for (j=0;j<=N/2;j++) {
      for (i=0;i<=N;i++) {
         index = j * (N+1) + i;
            fprintf(fptr,"v %lf %lf %lf\n",p[index].x,p[index].y,p[index].z);
      }
   }
    // Normals (same as vertices in this case but normalised)
   for (j=0;j<=N/2;j++) {
      for (i=0;i<=N;i++) {
         index = j * (N+1) + i;
         n = p[index];
         len = sqrt(n.x*n.x + n.y*n.y + n.z*n.z);
         fprintf(fptr,"vn %lf %lf %lf\n",n.x/len,n.y/len,n.z/len);
      }
   }
    // Texture coordinates
   for (j=0;j<=N/2;j++) {
        for (i=0;i<=N;i++) {
            index = j * (N+1) + i;
            fprintf(fptr,"vt %lf %lf\n",p[index].u,p[index].v);
        }
    }
    // Faces, each a triangle
    // Vertex count starts at 1 not 0
    fprintf(fptr,"usemtl material0\n");
    for (j=0;j<N/2;j++) {
        for (i=0;i<N;i++) {
            i1 =  j    * (N+1) + i       + 1;
            i2 =  j    * (N+1) + (i + 1) + 1;
            i3 = (j+1) * (N+1) + (i + 1) + 1;
            i4 = (j+1) * (N+1) + i       + 1;
            fprintf(fptr,"f %d/%d/%d %d/%d/%d %d/%d/%d\n",i1,i1,i1,i2,i2,i2,i3,i3,i3);
            fprintf(fptr,"f %d/%d/%d %d/%d/%d %d/%d/%d\n",i1,i1,i1,i3,i3,i3,i4,i4,i4);
        }
    }
    fclose(fptr);

    // Create placeholder material file
    fptr = fopen("roundcube.mtl","w");
    fprintf(fptr,"# Create as many materials as desired\n");
    fprintf(fptr,"# Each is referenced by name before the faces it applies to in the obj file\n");
    fprintf(fptr,"\n");
    for (i=0;i<2;i++) {
        fprintf(fptr,"newmtl material%d\n",i);
        fprintf(fptr,"Ka 1.000000 1.000000 1.000000\n");
        fprintf(fptr,"Kd 1.000000 1.000000 1.000000\n");
        fprintf(fptr,"Ks 0.000000 0.000000 0.000000\n");
        fprintf(fptr,"Tr 1.000000\n");
        fprintf(fptr,"illum 1\n");
        fprintf(fptr,"Ns 0.000000\n");
        fprintf(fptr,"map_Kd roundcube%d.jpg\n",i);
        fprintf(fptr,"\n");
    }
    fclose(fptr);

    exit(0);
}

double mypower(double v,double n)
{
    if (v >= 0)
        return(pow(v,n));
    else
        return(-pow(-v,n));
}
*/


signals:
    void valueChanged();

public slots:

    void updateRoundedCube()
    {
        N    = parameters->N;
        size = parameters->size;
        strength = parameters->strength;

        n_roundedcube(size,N,strength);

        qDebug()<<"Parameters Changed \n";

        emit valueChanged();
    }
};

class QCylinderModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float cylinderRadius;
    float cylinderHeight;


    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCylinder()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }
    CylinderParameters * parameters;



    enum { Type = MODEL_CYLINDER};

    int type() const  { return Type; }


    QCylinderModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new CylinderParameters;

        usteps = 10;
        vsteps = 10;
        //boundingSphereRadius =  1;
        cylinderRadius = 0.2f;
        cylinderHeight = 1;

        parameters->usteps =  usteps;
        parameters->vsteps =  vsteps;
        parameters->cylinderRadius = cylinderRadius;
        parameters->cylinderHeight = cylinderHeight;

        vertices.clear();

        name = QString("Cylinder Model");

        uv_cylinder(cylinderHeight,cylinderRadius,usteps,vsteps);


        addWidgets();


    }

    ~QCylinderModel()
    {
        delete properties;
        delete parameters;
    }

    void uv_cylinder(float height,float radius, int u_seg=10, int v_seg=10)
    {

        if (u_seg > 0 && v_seg > 0)
        {
            QList< QPair<int,int> > tuples;

            vertices.clear();
            indices.clear();
            normals.clear();
            edges.clear();

            float step_theta = (float)2*M_PI / u_seg;

            float step_height = (float)height / v_seg;

            float step_u   = 1 / u_seg;
            float step_v   = 1 / v_seg;




            //printf("steps Rings %f,steps Height %f",step_theta,step_height);

            //#pragma omp parallel for
            for(int i =0; i <=v_seg; i++)
            {
                float deltah = i * step_height;

                //#pragma omp parallel for
                for(int j =0; j<=u_seg;j++)
                {
                    float s = step_u  * i;
                    float t = step_v  * j;

                    texcoords.append(QVector2D(s,t));

                    float theta = j * step_theta;

                    tuples.append(QPair<int,int>(i, j));

                    float x = radius * sin(theta);
                    float y = deltah;
                    float z = radius * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    vertices.append(p);

                    QVector3D n=  p - QVector3D(0,deltah,0);
                    n.normalize();

                    normals.append(n);
                }
            }

            //printf("PointS %i",vertices.size());

            //#pragma omp parallel for
            for( int i=0;i<=v_seg-1;i++)
            {
                //#pragma omp parallel for
                for(int j=0;j<=u_seg-1;j++)
                {
                    int index0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    indices.append(index0);
                    indices.append(index1);
                    indices.append(index2);
                    indices.append(index3);

                    edges.append(index0);
                    edges.append(index1);

                    edges.append(index1);
                    edges.append(index2);

                    edges.append(index2);
                    edges.append(index3);

                    edges.append(index3);
                    edges.append(index0);
                }
            }
        }

        //printf("Indices computed %i",indices.size());

        //computeNormals();

        flipNormals();

        computeBounds();
    }


signals:

    void valueChanged();

private slots:

    void updateCylinder()
    {
        usteps = parameters->usteps;
        vsteps = parameters->vsteps;
        cylinderRadius = parameters->cylinderRadius;
        cylinderHeight = parameters->cylinderHeight;

        uv_cylinder(cylinderHeight,cylinderRadius,usteps,vsteps);

        emit valueChanged();

    }

};

class QPieModel: public QBaseModel
{
    Q_OBJECT

    float radius;
    float radius2;

    float startangle;
    float endangle;

    int sides;
    int rings;


    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;


        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        connect(parameters,SIGNAL(valueChanged()),this,SLOT(updatePie()));

        setTheme(properties);

        properties->hide();
    }


    PieParameters * parameters;

    enum { Type = MODEL_PIE};

    int type() const  { return Type; }


    QPieModel(QObject * parent =0) : QBaseModel(parent)
    {
        name = QString("Pie Model");

        parameters = new PieParameters;

        radius     = parameters->radius;
        radius2    = parameters->radius2;;
        startangle = parameters->startangle;
        endangle   = parameters->endangle;
        sides      = parameters->sides;
        rings      = parameters->rings;

        pie(radius,radius2,startangle,endangle,sides,rings);


        addWidgets();
    }

    ~QPieModel()
    {
        delete properties;
        delete parameters;
    }

    void pie( float radius,float radius2,float startangle,float endangle,int sides,int rings)
    {
        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();

        if (radius >= 0 && radius2 >= 0  && sides > 0&& rings > 0 && endangle>=0 &&startangle>=0)
        {
            qDebug()<<"Pie model started \n";

            if (endangle < startangle)
                endangle = startangle;

            if (radius2 < radius)
                radius2 = radius;

            QList< QPair<int,int> > tuples;


            float step_angle = (endangle - startangle) / sides;

            float step_ring = (radius2 - radius) / rings;


            float s_u   = 1 / sides;
            float s_v   = 1 / rings;

            for( int i = 0;i<=sides;i++)
            {
                float angle = i * step_angle + startangle;

                for(int j=0;j<=rings;j++)
                {
                    float s = s_u  * i;
                    float t = s_v  * j;

                    texcoords.append(QVector2D(s,t));

                    float sectorRadius = step_ring * j + radius;

                    float x = sectorRadius * sin(angle * PI/180);
                    float y = 0;
                    float z = sectorRadius * cos(angle* PI/180);

                    QVector3D p = QVector3D(x , y , z );

                    vertices.append(p);


                    QVector3D n=  p - QVector3D(0,0,0);
                    n.normalize();

                    normals.append(n);

                    tuples.append(QPair<int,int>(i, j));
                }
            }

            for( int i = 0;i<=sides-1;i++)
            {
                for(int j = 0;j<=rings-1;j++)
                {
                    int index0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    indices.append(index0);
                    indices.append(index1);
                    indices.append(index2);
                    indices.append(index3);

                    edges.append(index0);
                    edges.append(index1);

                    edges.append(index1);
                    edges.append(index2);

                    edges.append(index2);
                    edges.append(index3);

                    edges.append(index3);
                    edges.append(index0);

                }
            }

            //computeNormals();

            qDebug()<<"Pie model completed \n";

            flipNormals();

            computeBounds();
        }
    }

signals:

    void valueChanged();

private slots:

    void updatePie()
    {
        radius     = parameters->radius;
        radius2    = parameters->radius2;

        sides      = parameters->sides;
        rings      = parameters->rings;

        startangle = parameters->startangle;
        endangle   = parameters->endangle;

        pie(radius,radius2,startangle,endangle,sides,rings);

        emit valueChanged();
    }
};

class QSphereModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;
    float radius;

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        //properties->hide();

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateShere()));

    }

    SphereParameters * parameters;


    enum { Type = MODEL_SPHERE};

    int type() const  { return Type; }


    QSphereModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new SphereParameters;

        usteps = 15;
        vsteps = 15;
        radius =  1;

        parameters->usteps = usteps;
        parameters->vsteps = vsteps;
        parameters->radius = radius;

        //vertices.clear();

        name = QString("Sphere Model");

        //name = QString("Sphere Model");
        uv_sphere(radius,usteps,vsteps);

        //computeBounds();

        addWidgets();
    }

    ~QSphereModel()
    {
        delete properties;
        delete parameters;
    }


    void uv_sphere(float radius, unsigned int rings, unsigned int sectors)
    {
        float const R = 1./(float)(rings-1);
        float const S = 1./(float)(sectors-1);
        int r, s;

        vertices.clear();
        normals.clear();
        texcoords.clear();
        edges.clear();
        indices.clear();

        for(r = 0; r < rings; r++)
        {
            for(s = 0; s < sectors; s++)
            {
                float const y = sin( -M_PI_2 + M_PI * r * R );
                float const x = cos(2*M_PI * s * S) * sin( M_PI * r * R );
                float const z = sin(2*M_PI * s * S) * sin( M_PI * r * R );


                float s = s*S;
                float t = r*R;

                float _X = x * radius;
                float _Y = y * radius;
                float _Z = z * radius;

                float nx = x;
                float ny = y;
                float nz = z;

                vertices.append(QVector3D(_X,_Y,_Z));
                texcoords.append(QVector2D(s,t));
                normals.append(QVector3D(nx,ny,nz));            }
        }

        //indices.resize(rings * sectors * 4);

        for(r = 0; r < rings-1; r++)
        {
            for(s = 0; s < sectors-1; s++)
            {
                int index0,index1,index2,index3;

                index0 = r * sectors + s;
                index1 = r * sectors + (s+1);

                index2 = (r+1) * sectors + (s+1);
                index3 = (r+1) * sectors + s;

                indices.append(index0);
                indices.append(index1);
                indices.append(index2);
                indices.append(index3);

                edges.append(index0);
                edges.append(index1);

                edges.append(index1);
                edges.append(index2);

                edges.append(index2);
                edges.append(index3);

                edges.append(index3);
                edges.append(index0);
            }
        }

        computeBounds();
    }


    void uv_sphere_backup(float radius, int u_seg =10, int v_seg=10)
    {
        QVector<QVector3D> points;
        QVector<QVector3D> normals;

        QVector<int> pindices;
        QVector<int> indices;
        QVector<int> edges;

        QList< QPair<int,int> > tuples;

        int  count =0;

        if (u_seg > 0 && v_seg > 0)
        {
            float step_theta = M_PI / u_seg;
            float step_phie  = 2* M_PI / v_seg;

            for(int i =0; i < u_seg; i++)
            {
                float theta = i * step_theta;

                for(int j =0; j<v_seg;j++)
                {
                    tuples.append(QPair<int,int>(i, j));

                    float phie = j * step_phie;

                    float x = radius * sin(theta) * cos(phie);
                    float y = radius * sin(theta) * sin(phie);
                    float z = radius * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    points.append(p);

                    pindices.append(count);

                    count++;

                }
            }

            /*

            int stride  =  u_seg + 1;

            int loops = (int)pindices.size() / stride;

            for( int i=0;i<pindices.size();i++)
            {
                int index_0 = pindices[i];

                int index_1 = pindices[i+1];

                int index_2 = pindices[(i+1)* stride ];
                int index_3 = pindices[i* stride];

                indices.append(index_0);
                indices.append(index_1);
                indices.append(index_2);
                indices.append(index_3);

                edges.append(index_0);
                edges.append(index_1);

                edges.append(index_1);
                edges.append(index_2);

                edges.append(index_2);
                edges.append(index_3);

                edges.append(index_3);
                edges.append(index_0);
            }

            */

            //tuples.clear();




            for( int i=0;i<u_seg;i++)
            {
                for(int j=0;j<v_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    indices.append(index_0);
                    indices.append(index_1);
                    indices.append(index_2);
                    indices.append(index_3);

                    //---latitude--rings----
                    edges.append(index_0);
                    edges.append(index_1);

                    //---longitude--rings-------
                    edges.append(index_1);
                    edges.append(index_2);

                    //edges.append(index_2);
                    //edges.append(index_3);

                   // edges.append(index_3);
                    //edges.append(index_0);
                }
            }

            tuples.clear();



            mutex.lock();

            vertices       = points;
            indices = indices;
            normals      = normals;
            edges  = edges;


            computeNormals();

            computeBounds();

            mutex.unlock();
        }
    }


signals:

    void valueChanged();

private slots:

    void updateShere()
    {
        mutex.lock();

        usteps = parameters->usteps;
        vsteps = parameters->vsteps;
        radius = parameters->radius;

        uv_sphere(radius,usteps,vsteps);

        mutex.unlock();

        emit valueChanged();
    }
};

class QConeModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;

    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_CONE};

    int type() const  { return Type; }

    ConeParameters * parameters;


    QConeModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new ConeParameters;

        //usteps = 10;
        //hsteps = 10;
        //boundingSphereRadius =  1;

        //r1 = 1.0f;
        //r2 = 0.01f;
        //height  = 1.0f;

        usteps = parameters->usteps;
        hsteps = parameters->hsteps;
        r1 = parameters->r1;
        r2 = parameters->r2;
        height = parameters->height;


        name = QString("Cone Model");

        uv_cone(r1,r2,height,usteps,hsteps);

        addWidgets();

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));
    }

    ~QConeModel()
    {
        delete properties;
        delete parameters;
    }


    void uv_cone(float r1, float r2 ,float height,int u_seg , int h_seg)
    {

        QList< QPair<int,int> > tuples;


        if(u_seg>0 &&h_seg>0)
        {

            vertices.clear();
            indices.clear();
            normals.clear();
            edges.clear();



            float step_theta =  2 * M_PI / u_seg;


            float step_height  = height  / h_seg;

            float step_radius = (r1 -r2) / h_seg;


            float step_u   = 1 / u_seg;

            float step_v   = 1 / h_seg;



            for(int i =0;i<=(h_seg);i++)
            {
                float y = i  * step_height;

                float r = i  * step_radius + r1;


                for(int j =0; j<=(u_seg);j++)
                {

                    float s = step_u  * i;

                    float t = step_v  * j;


                    texcoords.append(QVector2D(s,t));


                    float theta = j * step_theta;


                    float x = r * sin(theta);

                    float z = r * cos(theta);


                    QVector3D p = QVector3D(x , y , z);


                    vertices.append(p);

                    tuples.append(QPair<int,int>(i, j));




                    QVector3D n=  p - QVector3D(0,y,0);

                    n.normalize();


                    normals.append(n);

                }

            }



            for( int i=0;i<=h_seg-1;i++)
            {

                for(int j=0;j<=u_seg-1;j++)
                {

                    int index0 = tuples.indexOf(QPair<int,int>(i, j));

                    int index1 = tuples.indexOf(QPair<int,int>(i, j + 1));

                    int index2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));

                    int index3 = tuples.indexOf(QPair<int,int>(i + 1, j));



                    indices.append(index0);

                    indices.append(index1);

                    indices.append(index2);

                    indices.append(index3);


                    edges.append(index0);

                    edges.append(index1);


                    edges.append(index1);

                    edges.append(index2);


                    edges.append(index2);

                    edges.append(index3);


                    edges.append(index3);

                    edges.append(index0);
                }

            }

        }


        //computeNormals();


        flipNormals();


        computeBounds();

    }


signals:
    void valueChanged();

private slots:

    void updateCone()
    {
        usteps = parameters->usteps;
        hsteps = parameters->hsteps;
        r1 = parameters->r1;
        r2 = parameters->r2;
        height = parameters->height;


        uv_cone(r1,r2,height,usteps,hsteps);

        emit valueChanged();
    }



};

class QTorusModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float r1;
    float r2;

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateTorus()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    enum { Type = MODEL_DONUT};

    int type() const  { return Type; }


    TorusParameters * parameters;

    QTorusModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new TorusParameters;

        usteps = 15;
        vsteps = 10;

        //boundingSphereRadius = 1;

        r1 = 2;
        r2 = 1;


        parameters->usteps = usteps;
        parameters->vsteps = vsteps;

        parameters->r1 = r1;
        parameters->r2 = r2;

        name = QString("Torus Model");

        n_torus(r1,r2,usteps,vsteps);
        //add_torus(usteps,vsteps,r1,r2);

        addWidgets();
    }

    ~QTorusModel()
    {
        delete properties;

        delete parameters;
    }


    void n_torus(float sectorRadius,float ringRadius, unsigned int rings, unsigned int sectors)
    {
        vertices.clear();
        normals.clear();
        texcoords.clear();
        edges.clear();
        indices.clear();

        if (sectors> 0 && rings > 0)
        {
            QList< QPair<int,int> > tuples;

            float step_sector = 2*M_PI / sectors;
            float step_ring   = 2*M_PI / rings;

            float step_u   = 1 / sectors;
            float step_v   = 1 / rings;

            QList<QVector3D> sectorVerts;

            for(int i=0;i<=sectors;i++)
            {
                for(int j=0;j<=rings;j++)
                {
                    float s = step_u  * i;
                    float t = step_v  * j;

                    texcoords.append(QVector2D(s,t));

                    float angle_ring   = j * step_ring ;
                    float angle_sector = i * step_sector;

                    float x = ( sectorRadius + ringRadius * cos(angle_sector)) * cos( angle_ring);
                    float z = ( sectorRadius + ringRadius * cos(angle_sector)) * sin( angle_ring);
                    float y = ringRadius * sin(angle_sector);


                    QVector3D p = QVector3D(x , y , z );

                    vertices.append(p);

                    tuples.append( QPair<int,int>(i, j) );

                }
            }


            for( int i=0;i<=sectors-1;i++)
            {
                for(int j=0;j<=rings-1;j++)
                {
                    //int index0 = i * sectors + j;
                    //int index1 = i * sectors + (j+1);

                    //int index2 = (i+1) * sectors + (j+1);
                    //int index3 = (i+1) * sectors + j;

                    int index0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    indices.append(index0);
                    indices.append(index1);
                    indices.append(index2);
                    indices.append(index3);

                    edges.append(index0);
                    edges.append(index1);

                    edges.append(index1);
                    edges.append(index2);

                    edges.append(index2);
                    edges.append(index3);

                    edges.append(index3);
                    edges.append(index0);
                }
            }
        }

        computeBounds();
    }

signals:

    void valueChanged();

private slots:

    void updateTorus()
    {
        mutex.lock();

        usteps = parameters->usteps;
        vsteps = parameters->vsteps;

        r1 = parameters->r1;
        r2 = parameters->r2;

        n_torus(r1,r2,usteps,vsteps);
        //add_torus(usteps,vsteps,r1,r2);

        //qDebug()<<"Parameters:"<<usteps<<";"<<vsteps;

        mutex.unlock();

        emit valueChanged();
    }

};

class QTubeModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;


    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateTube()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_TUBE};

    int type() const  { return Type; }


    TubeParameters * parameters;



    QTubeModel(QObject * parent =0) : QBaseModel(parent)
    {

        parameters = new TubeParameters;

        usteps = 10;
        hsteps = 10;
        //boundingSphereRadius =  1;

        r1 = 2.0f;
        r2 = 0.01f;
        height  = 2.0f;

        parameters->usteps =  usteps;
        parameters->hsteps = hsteps;
        parameters->r1 = r1;
        parameters->r2 = r2;
        parameters->height = height;

        vertices.clear();

        name = QString("Tube Model");

        uv_tube(r1,r2,height,usteps,hsteps);

        computeBounds();

        addWidgets();


    }

    ~QTubeModel()
    {
        delete properties;
        delete parameters;
    }


    void interpolate(float r1,float r2,int divisions)
    {
        float r = r2-r1;

        float step_r =  r/divisions;

    }

    void uv_tube(float r1 = 10.0f, float r2 = 10.0f,float height=2.0f,int u_seg = 10, int h_seg = 10)
    {
        QList< QPair<int,int> > tuples;


        if(u_seg<3) { u_seg = 3; }
        if(h_seg<1) { h_seg = 1; }
        {
            vertices.clear();
            indices.clear();
            normals.clear();
            edges.clear();


            float step_theta =  2 * M_PI / u_seg;

            float step_height  = height  / h_seg;
            float step_radius = (r1 -r2) / h_seg;



            for(int i =0;i<(h_seg+1);i++)
            {
                float theta = i * step_theta;

                float y = i  * step_height;

                float r = i  * step_radius + r1;


                for(int j =0; j<(u_seg+1);j++)
                {
                    float x = r * sin(theta);
                    float z = r * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    vertices.append(p);
                    tuples.append(QPair<int,int>(i, j));

                }
            }


            for( int i=0;i<h_seg;i++)
            {
                for(int j=0;j<u_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    indices.append(index_0);
                    indices.append(index_1);
                    indices.append(index_2);
                    indices.append(index_3);

                    //---latitude--rings----
                    edges.append(index_0);
                    edges.append(index_1);

                    //---longitude--rings-------
                    edges.append(index_1);
                    edges.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);

                }
            }
        }


        computeNormals();

        computeBounds();

    }

signals:

    void valueChanged();

private slots:

    void updateTube()
    {
        usteps = parameters->usteps;
        hsteps = parameters->hsteps;

        r1 = parameters->r1;
        r2 = parameters->r2;

        height = parameters->height;

        uv_tube(r1,r2,height,usteps,hsteps);

        emit valueChanged();

    }


};

class QLightModel: public QBaseModel
{
    Q_OBJECT

    bool enable;

    QColor diffuseColor ;
    QColor ambientColor ;
    QColor specularColor ;
    QColor emissionColor ;

    float shininess;

    void uv_sphere(float radius, int u_seg =10, int v_seg=10)
    {
        QList< QPair<int,int> > tuples;

        if (u_seg > 0 && v_seg > 0)
        {
            vertices.clear();
            indices.clear();
            normals.clear();
            edges.clear();

            float step_theta = M_PI / u_seg;
            float step_phie  = 2* M_PI / v_seg;

            for(int i =0; i < u_seg+1; i++)
            {
                float theta = i * step_theta;

                for(int j =0; j<v_seg+1;j++)
                {
                    tuples.append(QPair<int,int>(i, j));

                    float phie = j * step_phie;

                    float x = radius * sin(theta) * cos(phie);
                    float y = radius * sin(theta) * sin(phie);
                    float z = radius * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    vertices.append(p);

                }
            }

            for( int i=0;i<u_seg;i++)
            {

                for(int j=0;j<v_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    indices.append(index_0);
                    indices.append(index_1);
                    indices.append(index_2);
                    indices.append(index_3);

                    //---latitude--rings----
                    edges.append(index_0);
                    edges.append(index_1);

                    //---longitude--rings-------
                    edges.append(index_1);
                    edges.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);
                }
            }
        }

        tuples.clear();

        computeNormals();

        computeBounds();
    }

    QPropertiesTreeWidget *properties;

public:

    struct m_dirLightLocation
    {
        GLuint Color;
        GLuint AmbientIntensity;
        GLuint DiffuseIntensity;
        GLuint Direction;

    } ;


    struct m_pointLightsLocation
    {
        GLuint Color;

        GLuint AmbientIntensity;

        GLuint DiffuseIntensity;

        GLuint Position;

        struct Atten
        {
            GLuint Constant;
            GLuint Linear;
            GLuint Exp;

        };
    };

    struct m_spotLightsLocation
    {

        GLuint Color;

        GLuint AmbientIntensity;

        GLuint DiffuseIntensity;

        GLuint Position;

        GLuint Direction;

        GLuint Cutoff;

        struct Atten
        {
            GLuint Constant;
            GLuint Linear;
            GLuint Exp;

        };

    };


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateLight()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
       properties->hide();
    }

    enum { Type = MODEL_LIGHT};

    int type() const  { return Type; }

    LightParameters * parameters;


    QLightModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new LightParameters;

        diffuseColor   = QColor(0.8f, 0.8f, 0.8f ,1);
        ambientColor   = QColor(0.2f, 0.2f, 0.2f,1 );
        specularColor  = QColor(0.4f, 0.4f, 0.4f,1);
        emissionColor  = QColor(0.1f, 0.1f, 0.1f,1);

        shininess = 50.0;

        enable    = true;

        parameters->diffuseColor   = diffuseColor ;
        parameters->ambientColor   = ambientColor ;
        parameters->specularColor  = specularColor ;
        parameters->emissionColor  = emissionColor ;
        parameters->shininess = shininess;

        vertices.clear();
        //indices.clear();

        name = QString("Light Omni");

        position = QVector3D(0,0,0);


        vertices.append(position);
        //boundingSphereRadius = 5;

        uv_sphere(.5,10,10);

        addWidgets();



    }


    ~QLightModel()
    {
        delete properties;
        delete parameters;
    }


    void drawLight()
    {
        float pos[] = {position.x(),position.y(),position.z(),0};

        float spec[4]  = { 0.4f, 0.4f, 0.4f,1 };
        float diffuse[4]  = { .8f, 0.8f, 0.8f ,1};
        float ambient[4]  = { 0.2f, 0.2f, 0.2f,1 };

        GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
        GLfloat mat_shininess[] = { 50.0 };
        GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };



        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, spec);
        glLightfv(GL_LIGHT0, GL_POSITION, pos);

        //glEnable(GL_DEPTH_TEST);
        //glShadeModel(GL_SMOOTH);




        //glClearColor (0.0, 0.0, 0.0, 0.0);
        glShadeModel (GL_SMOOTH);

        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
        //glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        //glColorMaterial ( GL_FRONT_AND_BACK, GL_EMISSION ) ;
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        glEnable ( GL_COLOR_MATERIAL ) ;

        //glLightModeliv(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);

        GLfloat lmodel_ambient[] = { 0.2, 0.2, 0.2, 1.0 };

        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);


        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
    }

    void drawCenter()
    {
        glEnable(GL_POINT_SMOOTH);

        glPointSize(10);

        glBegin(GL_POINTS);

        glVertex3f(position.x(),position.y(),position.z());

        glEnd();
    }


    void drawModel()
    {
        glPushMatrix();

        //QMatrix4x4 mat;
        //mat.translate(position);
        //QQuaternion orientation;
        //orientation.fromAxisAndAngle()
        //mat.rotate(rotation);
        //mat.scale(scale);
        //qMultMatrix(mat);


        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
        glTranslatef(position.x(),position.y(),position.z());

        //glRotatef(rotation.x(),1,0,0);
        //glRotatef(rotation.y(),0,1,0);
        //glRotatef(rotation.z(),0,0,1);

        //glScalef(scale.x(),scale.y(),scale.z());

        visibilityParameters->showWireframe = true;

        if(visibilityParameters->showWireframe)
        {
            drawEdges();
        }

        visibilityParameters->showCenter = true;


        if(visibilityParameters->showCenter)
        {
            drawCenter();
        }

        glPopMatrix();
    }

signals:

    void valueChanged();

private slots:

    void updateLight()
    {
        diffuseColor = parameters->diffuseColor;
        ambientColor = parameters->ambientColor;
        specularColor = parameters->specularColor;
        emissionColor = parameters->emissionColor ;
        shininess = parameters->shininess ;

        emit valueChanged();
    }

};

class SynageTexture : public QObject
{
    Q_OBJECT

public:

    QImage  image;

    QSize imageSize;

    SynageTexture(QObject * parent =0):QObject(parent)
    {
        image = QImage(imageSize, QImage::Format_ARGB32_Premultiplied);

        QPainter imagePainter(&image);

        QGraphicsView * view = new QGraphicsView;

        view->render(&imagePainter);

        imagePainter.end();
    }

    void drawImage()
    {
        //QPainter p(imageSize);

        //p.drawImage(0, 0, image);
    }

};




class QCameraFreeModel: public QBaseModel
{
    Q_OBJECT

    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

            const float*r= mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }

    void updateMatrix()
    {
        float m_yaw   = rotation.y();
        float m_pitch = rotation.x();

        QMatrix4x4 m;

        m *= fromRotation(m_yaw - 180, Qt::YAxis);
        m.translate(-position.x(), -position.y(), -position.z());

        m = fromRotation(m_pitch, Qt::XAxis) * m;

        //view Matrix
        viewMatrix = m;

        float fovAngle = fov * 2 * 3.14159 / 360.0;

        float angle = qCos(fovAngle / 2) / qSin(fovAngle / 2);
        float _fov = viewport.width() / (float(viewport.height()) * angle);

        float zn = zNear;
        float zf = zFar;

        float m33 = -(zn + zf) / (zf - zn);
        float m34 = -(2 * zn * zf) / (zf - zn);

        //projection Matrix
        projectionMatrix = QMatrix4x4(
            1.0, 0.0, 0, 0,
            0, _fov, 0, 0,
            0, 0, m33, m34,
            0, 0, -1, 0);

        // Technique from "Oblique View Frustum Depth Projection and Clipping" by Eric Lengyel

        QVector4D viewClipPlane = nearClipPlane;

        QVector4D q((sign(viewClipPlane.x())),
                    (sign(viewClipPlane.y())) / _fov,
                    -1.0,
                    (1.0 + m33) / m34);

        QVector4D c = viewClipPlane * (2.0 / QVector4D::dotProduct(viewClipPlane, q)) + QVector4D(0, 0, 1, 0);

        projectionMatrix.setRow(2, c);


        //viewProjectionMatrix
        viewProjectionMatrix = projectionMatrix * viewMatrix;

        QPointF p = QLineF::fromPolar(1, m_yaw - 90).p2();

        direction = QVector3D(p.x(), 0, p.y());
    }

    inline float sign(float x) const
    {
        return x >= 0 ? 1 : -1;
    }

    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCamera()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }


    enum { Type = MODEL_CAMERA_FREE};

    int type() const  { return Type; }


    CameraParameters * parameters;

    QCameraFreeModel(QObject * parent = 0) : QBaseModel(parent)
    {

        initVertices();

        PerspectiveMode = PERSPECTIVE;

        aspectRatio = 1.0f;

        zNear  = 0.01f;
        zFar   = 1500.0f;
        fov    = 45.0f;

        parameters = new CameraParameters;
        parameters->zNear = zNear;
        parameters->zFar = zFar;
        parameters->fov = fov;

        nearClipPlane = QVector4D(0, 0, -1, -zNear);


        rotationSensitivity = 0.05f;
        panSensitivity = 0.05f;
        zoomSensitivity = 1.0f;


        boundingSphereRadius = 1;

        up       = QVector3D(0,1,0);
        target   = QVector3D(0.0f, 0.0f, 0.0f);


        position = QVector3D(0.0, 0, -15.0);
        rotation = QVector3D(32,-37,0);
        //rotation = QVector3D(-30,143,0);
        //scale    = QVector3D(1,1,-1);

        addWidgets();
    }

    ~QCameraFreeModel()
    {
        delete properties;
    }



    enum QCameraView
    {
        TOP = 0,
        BOTTOM,
        FRONT,
        BACK,
        LEFT,
        RIGHT,
        PERSPECTIVE,
        ORTHO,
        FRUSTRUM,

    };

    enum QCameraOrbitMode
    {
        WORLDCENTER,
        SELECTED,
        VIEWCNTER,

    };


    QCameraView PerspectiveMode;

    QCameraOrbitMode OrbitMode;

    QCameraView getCameraView()
    {
        return PerspectiveMode;
    }

    QCameraOrbitMode getCameraOrbitMode()
    {
        return OrbitMode;
    }

    void setCameraOrbitMode(QCameraOrbitMode mode = WORLDCENTER)
    {
        OrbitMode = mode;
    }


    //transforms
    QVector3D target;
    QVector3D up;
    QVector3D direction;

    //clipping
    QVector4D nearClipPlane;
    QSizeF viewport;
    QRectF viewRect;

    float zFar;
    float zNear;
    float fov;
    float aspectRatio;   
    float boundingSphereRadius;

    //mouse controls

    QVector2D delta2D;


    qreal rotationSensitivity;
    qreal panSensitivity;
    qreal zoomSensitivity;



    QMatrix4x4 projectionMatrix;
    QMatrix4x4 viewMatrix;
    QMatrix4x4 viewProjectionMatrix;

    QRay viewRay;

    const QMatrix4x4 fromRotation(float angle, Qt::Axis axis) const
    {
        QMatrix4x4 m;

        if (axis == Qt::XAxis)
            m.rotate(angle, QVector3D(1, 0, 0));
        else if (axis == Qt::YAxis)
            m.rotate(-angle, QVector3D(0, 1, 0));
        else if (axis == Qt::ZAxis)
            m.rotate(angle, QVector3D(0, 0, 1));
        return m;
    }

    QVector2D toScreen(const QVector3D &coordinate) const
    {
        QVector3D projected = viewProjectionMatrix.map(coordinate);

        QVector2D c(viewport.width() * 0.5, viewport.height() * 0.5);

        return c + c * projected.toVector2D() * QVector2D(1, -1);
    }

    QRectF toScreenRect(const QVector<QVector3D> &coordinates) const
    {
        QVector<QVector3D> mapped;

        for (int i = 0; i < coordinates.size(); ++i)
            mapped << viewMatrix.map(coordinates.at(i));

        qreal zClip = -zNear;

        QVector<QVector3D> clipped;

        for (int i = 0; i < mapped.size(); ++i)
        {
            const QVector3D &a = mapped.at(i);
            const QVector3D &b = mapped.at((i + 1) % mapped.size());

            bool aOut = a.z() > zClip;
            bool bOut = b.z() > zClip;

            if (aOut && bOut)
                continue;

            if (!aOut && !bOut) {
                clipped << b;
                continue;
            }

            qreal t = (zClip - a.z()) / (b.z() - a.z());
            QVector3D intersection = a + t * (b - a);

            clipped << intersection;

            if (!bOut)
                clipped << b;
        }

        QRectF bounds;

        QVector2D c(viewport.width() * 0.5, viewport.height() * 0.5);

        for (int i = 0; i < clipped.size(); ++i)
        {
            QVector2D projected = c + c * projectionMatrix.map(clipped.at(i)).toVector2D() * QVector2D(1, -1);
            bounds = bounds.united(QRectF(projected.toPointF(), QSizeF(0.01, 0.01)));
        }

        bounds = bounds.intersected(QRectF(0, 0, viewport.width(), viewport.height()));

        return bounds;
    }


    QVector3D getWorldCoordinateFromScreen( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 0.9;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );

        GLdouble hx = 0, hy = 0, hz = 0;

        gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &hx, &hy, &hz );

        QVector3D worldPos(hx,hy,hz);

        return worldPos;
    }

    QVector3D getScreenCoordinateFromWorld(QVector3D worldPos)
    {
        double modelview[16], projection[16];

        int viewports[4];

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewports );

        GLdouble x,y,z;

        gluProject( worldPos.x(), worldPos.y(), worldPos.z(), modelview, projection, viewports, &x, &y, &z );

        QVector3D hitpoint(x,y,z);

        return hitpoint;

    }


    void reset()
    {
        up       = QVector3D(0,1,0);



        target   = QVector3D(0.0f, 0.0f, 0.0f);

        position = QVector3D(0.0, 0, 15.0);

        rotation = QVector3D(32,-37,0);
    }

    /*
    void translate(QVector3D deltaPos)
    {
        position += deltaPos;
    }


    void setCameraView(QCameraView view = PERSPECTIVE)
    {
        cameraView =  view;

        switch(cameraView)
        {
        case FRONT://0
            position  = QVector3D(0,0,1);
            target    = QVector3D(0,0,0);
            up        = QVector3D(0,1,0);
            break;

        case BACK://1
            position  = QVector3D(0,0,-1);
            target    = QVector3D(0,0,0);
            up        = QVector3D(0,1,0);
            break;

        case TOP://2
            position = QVector3D(0,1,0);
            target   = QVector3D(0,0,0);
            up       = QVector3D(0,0,-1);
            break;

        case BOTTOM://3
            position    = QVector3D(0,-1,0);
            target = QVector3D(0,0,0);
            up     = QVector3D(0,0,1);
            break;

        case LEFT://4
            position      = QVector3D(-1,0,0);
            target   = QVector3D(0,0,0);
            up       = QVector3D(0,1,0);
            break;

        case RIGHT://5
            position    = QVector3D(1,0,0);
            target = QVector3D(0,0,0);
            up     = QVector3D(0,1,0);
            break;

        case PERSPECTIVE://6
            reset();
            break;
        case ORTHO:
            reset();
            break;

       default:

            break;
        }
    }

    */



    void setViewPort(QRectF _viewRect)
    {
        viewRect =  _viewRect;

        viewport = _viewRect.size();

        aspectRatio = (GLfloat) viewport.width() /(GLfloat) viewport.height() ;

    }

    /*

    void loadProjectionMatrix(QMatrix4x4  & projectionMatrix_)
    {
        glMatrixMode(GL_PROJECTION);

        glLoadIdentity();

        //qreal *dataMat = projectionMatrix_.transposed().data();

        qreal *dataMat = projectionMatrix_.data();

        GLfloat matriceArray[16];

        for (int i= 0; i < 16; ++i)
        {
            matriceArray[i] = dataMat[i];
        }

        glMultMatrixf(matriceArray);
    }

    void loadViewMatrix( QMatrix4x4 viewMatrix_)
    {
        glMatrixMode(GL_MODELVIEW);

        glLoadIdentity();

        //qreal *dataMat = viewMatrix_.transposed().data();

        qreal *dataMat = viewMatrix_.data();

        GLfloat matriceArray[16];

        for (int i= 0; i < 16; ++i)
        {
            matriceArray[i] = dataMat[i];
        }

        glMultMatrixf(matriceArray);
    }

    */

    void draw()
    {
        /*
        glPushMatrix();
        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
        //glTranslatef(position.x(),position.y(),position.z());

        //glRotatef(rotation.x(),1,0,0);
        //glRotatef(rotation.y(),0,1,0);
        //glRotatef(rotation.z(),0,0,1);

        //glScalef(scale.x(),scale.y(),scale.z());

        //printf("Polygons:%i \n",facesindices.length()/4);

        if(Selected)
        {
            //glColor3f( .5, .25, .79);
            glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            glColor3f( colorId.x(), colorId.y(), colorId.z());
        }
        drawCamera();

        glPopMatrix();

        drawBoundingBox();

        */
    }

    void initVertices()
    {
        int count = sizeof(Globals::cameraVertices)/sizeof(float);

        count/= 3;

        for(int i=0;i<count;i+=3)
        {
            QVector3D v(Globals::cameraVertices[i],Globals::cameraVertices[i+1],Globals::cameraVertices[i+2]);

            vertices.append(v);
        }

        computeBounds();

    }

    void drawCamera()
    {
        float shininess = 32.0f;
        float diffuseColor[3] = {1.0f, 1.0f, 1.0f};
        float specularColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};

        // set specular and shiniess using glMaterial
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess); // range 0 ~ 128
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specularColor);

        // set ambient and diffuse color using glColorMaterial (gold-yellow)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
        glColor3fv(diffuseColor);

        // start to render polygons
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_VERTEX_ARRAY);

        glNormalPointer(GL_FLOAT, 0, Globals::cameraNormals);
        glVertexPointer(3, GL_FLOAT, 0, Globals::cameraVertices);

        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[0]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[5]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[10]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[15]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[20]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[25]);
        glDrawElements(GL_TRIANGLE_STRIP, 39, GL_UNSIGNED_INT, &Globals::cameraIndices[30]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[69]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[113]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[157]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[201]);

        glDisableClientState(GL_VERTEX_ARRAY);	// disable vertex arrays
        glDisableClientState(GL_NORMAL_ARRAY);	// disable normal arrays
    }


    virtual void switchCameraView(QKeyEvent * event)
    {
        /*
        switch(event->key())
        {
        case Qt::Key_1:
            setCameraView(FRONT);
            break;

        case Qt::Key_2:
            setCameraView(BOTTOM);
            break;

        case Qt::Key_3:
            setCameraView(FRONT);

            break;

        case Qt::Key_4:
           setCameraView(BACK);
            break;

        case Qt::Key_5:
           setCameraView(LEFT);
            break;

        case Qt::Key_6:
            setCameraView(RIGHT);
            break;

        case Qt::Key_7:
            setCameraView(ORTHO);

            break;

        case Qt::Key_8:
            setCameraView(PERSPECTIVE);
            break;

        }

        */

    }

    virtual void cameraNavigation(QMouseEvent *event,QPoint delta)
    {
        viewRay.rayCastScene(event->pos().x(),event->pos().y());

        if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::MiddleButton)
        {
            pan(delta);
        }
        else if (event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::LeftButton)
        {
            rotate(delta);
        }
        else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::RightButton)
        {

            QVector3D dir1 = prev - target;

            dir1.normalize();

            float sc = sqrt(delta.x() * delta.x() + delta.y()* delta.y());

            position  += dir1 * -delta.x();
            target    += dir1 * -delta.x();

            prev = position;

            lastPos =  event->pos();

        }
        else if(event->buttons() & Qt::MiddleButton)
        {
            rotate(delta);
        }
    }

    QVector3D prev;
    QPoint lastPos;

signals:

    void valueChanged();

public slots:

    void orbitView()
    {
        double w =  viewport.width();
        double h =  viewport.height();

        // const qreal zNear = 0.1, zFar = 1000.0,fov = 45.0;

        // Calculate aspect ratio
        aspectRatio = qreal(w) / qreal(h ? h : 1);

        // Reset projection
        projectionMatrix.setToIdentity();

        if(PerspectiveMode == PERSPECTIVE)
        {
            // Set near plane to 3.0, far plane to 7.0, field of view 45 degrees

            projectionMatrix.perspective(fov, aspectRatio, zNear, zFar);

        }
        else if(PerspectiveMode == ORTHO)
        {
            //ProjectionMatrix.perspective(fov, aspectRatio, zNear, zFar);
            projectionMatrix.ortho(-0.5f, +0.5f, +0.5f, -0.5f, zNear, zFar);

        }


        viewMatrix.setToIdentity();

        //viewMatrix.lookAt(position,target,up);
        viewMatrix.translate(position.x(),position.y(),position.z());

        viewMatrix.rotate(rotation.x(), 1, 0, 0);
        viewMatrix.rotate(rotation.y(), 0, 1, 0);
        viewMatrix.rotate(rotation.z(), 0, 0, 1);


        //viewProjectionMatrix
        //viewProjectionMatrix = projectionMatrix * viewMatrix;


        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        qMultMatrix(projectionMatrix);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        qMultMatrix(viewMatrix);
    }



    void rotate(QPoint delta)
    {
        QVector3D deltaVec = QVector3D((delta.y()*rotationSensitivity),(delta.x()*rotationSensitivity),0);

        rotation += deltaVec;

        qDebug()<<"Rotation:"<< rotation;

        emit valueChanged();
    }

    void zoom(qreal delta)
    {
        qreal factor = qPow(1.2, delta / 240.0);

        if(delta<0)
            factor *= -1;

        QVector3D dir = target - position;

        dir.normalize();

        dir *= (zoomSensitivity*  factor );

        target   += dir;

        position += dir;

        emit valueChanged();
    }

    void pan(QPoint delta)
    {
        //----------------------------------------------------
        //
        //           UP
        //           |
        //           |
        //           |   dir = (target - P0)
        //           P0 -------(C)---------------------->  target
        //          /
        //         /
        //        /
        //       Normal
        //
        //  C is the center point on the screen not the camera position P0
        //---------------------------------------------------------------


        /*

        QVector3D dir = target - position;
        dir.normalize();

        QVector3D normal = QVector3D::crossProduct(dir,up);
        normal.normalize();

        QVector3D updelta = up;

        updelta *= ( delta.y() * -1 * panSensitivity );
        normal  *= ( delta.x() * -1 * panSensitivity );

        QVector3D finalOffset = updelta + normal;

        target   += finalOffset;
        position += finalOffset;


        */

        panXY(delta.x(),delta.y());

        emit valueChanged();
    }

    void panXY(int DeltaX, int DeltaY)
    {
        float Scalar = position.z();

        if(Scalar > -1.0f && Scalar < 1.0f) Scalar = -1.0f;
        if(Scalar > -1.0f) Scalar = -Scalar;

        float MoveX = (float)(DeltaX) * panSensitivity * Scalar * 1/viewport.width();
        float MoveY = (float)(DeltaY) * panSensitivity * Scalar * 1/viewport.width();

        position += QVector3D(-MoveX,MoveY,0);
        target   += QVector3D(-MoveX,MoveY,0);
    }


    void updateCamera()
    {
        parameters = new CameraParameters;

        zNear = parameters->zNear;
        zFar  = parameters->zFar;
        fov   = parameters->fov ;

        emit valueChanged();
    }

};

class CameraFinal
{
    int width;
    int height;

    // pixel coordinates (centre-based) of the viewport's corners
    int _viewport_x1;
    int _viewport_y1;
    int _viewport_x2;
    int _viewport_y2;

    // pixel coordinates (centre-based) of the viewport's centre.
    // These will be half-integers if the viewport's dimensions are even.

    float _viewport_cx;
    float _viewport_cy;

    // the radius of the viewport, in pixels
    float viewportRadiusInPixels;
    float viewportRadius;

    // dimensions of the viewport, in world space, measured on the near plane

    float viewportWidth;
    float viewportHeight;

    QVector3D sceneCentre;
    float sceneRadius;

    float minimumFeatureSize;
    float zNear;
    float zFar; // clipping planes

    QVector3D position; // point of view
    QVector3D target;   // point of interest

    QVector3D up;      // a unit vector, perpendicular to the line-of-sight

    QVector3D _ground;  // a unit vector perpendicular to the ground plane
    QVector3D _initialGround;

    // constants that can be tuned
    float zNearPlaneFactor;
    float zFarPlaneFactor;

    float Fov_SemiAngle;
    float fudgeFactor;

    float rotationSpeedInDegreesPerRadius; // for yaw, pitch, roll
    float orbitingSpeedInDegreesPerRadius; // for orbit
    float pushThreshold;


public:


    CameraFinal( int width,int height,float scene_radius, const QVector3D& scene_centre = QVector3D(0,0,0) )
    {
      initialize( scene_centre,
                  scene_radius,
                  width,
                  height,
                  0, 0,
                  width - 1,
                  height - 1 );
    }

    CameraFinal( int width,int height,
           int viewport_x1, int viewport_y1, // centre-based coordinates
           int viewport_x2, int viewport_y2, // centre-based coordinates
           float scene_radius, const QVector3D& scene_centre = QVector3D(0,0,0)
    )
    {
      initialize(
         scene_centre,
         scene_radius,
         width, height,
         viewport_x1, viewport_y1, viewport_x2, viewport_y2
      );
    }

    QVector3D getPerpendicularVector(QVector3D p)
    {
       // Pick the two largest components,
       // permute them and negate one of them, and
       // replace the other (i.e. smallest) component with zero.

       float X = fabs(p.x());
       float Y = fabs(p.y());
       float Z = fabs(p.z());

       QVector3D v;

       if ( X < Y )
       {
          if ( Y < Z )
          {
             // X < Y < Z
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else if ( X < Z )
          {
             // X < Z <= Y
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else
          {
             // Z <= X < Y
             v = QVector3D( p.y(), -p.x(), 0 );
          }
       }
       else
       {
          if ( Z < Y )
          {
             // Z < Y <= X
             v = QVector3D( p.y(), -p.x(), 0 );
          }
          else if ( Z < X )
          {
             // Y <= Z < X
             v = QVector3D( p.z(), 0, -p.x() );
          }
          else
          {
             // Y <= X <= Z
             v = QVector3D( p.z(), 0, -p.x() );
          }
       }

       //#ifdef DEBUG
       //float dotProduct =QVector3D::dotProduct(v , p);
       //ASSERT_IS_EQUAL( dotProduct, 0 );
       //#endif

       return v;
    }



    void initialize(
      const QVector3D& scene_centre,

           float scene_radius,

           int width,
           int height,

           int viewport_x1,
           int viewport_y1,

           int viewport_x2,
           int viewport_y2
    )

    {

       // A good angle for the field-of-view is 30 degrees.
       // Setting this very small will give the user the impression
       // of looking through a telescope.
       // Setting it very big will give the impression of a wide-angle
       // lens, with strong foreshortening effects that are especially
       // noticeable near the edges of the viewport.
       Fov_SemiAngle   = M_PI * 15 / 180.0;

       // This should be a little greater than 1.0.
       // If it's set to one, the user will initially
       // just *barely* see all of the scene in the window
       // (assuming the scene is a sphere of radius scene_radius).
       fudgeFactor     = 1.1f;

       // This should be a little greater than 0.0.
       // If no minimum feature size is given by the user,
       //    minimum_feature_size = _nearPlaneFactor * scene_radius
      zNearPlaneFactor = 0.1f;

       // far_plane = _farPlaneFactor * scene_radius

      zFarPlaneFactor  = 15;

       // Used for yaw, pitch, roll.
       rotationSpeedInDegreesPerRadius = 150;

       // Used for orbit.
       orbitingSpeedInDegreesPerRadius = 300;

       // The target (or point-of-interest) of the camera is kept
       // at a minimal distance of
       //   _pushThreshold * near_plane
       // from the camera position.
       // This number should be greater than 1.0, to ensure
       // that the target is never clipped.
       pushThreshold = 1.3f;

      _initialGround = QVector3D( 0, 1, 0 );

      _initialGround.normalize();

      setSceneCentre( scene_centre );
      setSceneRadius( scene_radius );

      minimumFeatureSize = zNearPlaneFactor * sceneRadius;

      zNear = minimumFeatureSize;

      width  = width;
      height = height;

      _viewport_x1 = viewport_x1;
      _viewport_y1 = viewport_y1;
      _viewport_x2 = viewport_x2;
      _viewport_y2 = viewport_y2;

      resetCamera();

      resizeViewport( width, height,viewport_x1, viewport_y1, viewport_x2, viewport_y2 );
    }


    const QVector3D  & getPosition() const { return position; }
    const QVector3D  & getTarget() const { return target; }
    const QVector3D  & getUp() const { return up; }
    const QVector3D    getRight() const { QVector3D direction = ( target - position ).normalized(); return QVector3D::crossProduct(direction , up); }

    //int getViewportWidthInPixels() const { return width; }
    //int getViewportHeightInPixels() const { return height; }

    void setPositionAndOrientation( const QVector3D & pos, const QVector3D & direction, const QVector3D & _up )
    {
       position = pos;
       target   = pos + direction;
       up       = _up;
    }

    void setSceneCentre( const QVector3D& p )
    {
       sceneCentre = p;
    }

    // This causes the far plane to be recomputed.
    void setSceneRadius( float r )
    {
       if ( r <= 0 )
           return;

       if( r > 0 )
       {
           sceneRadius = r;

           zFar = zFarPlaneFactor * sceneRadius;
       }
    }

    // This causes the near plane to be recomputed.
    // Note that the argument passed in must be positive.
    // Also note that smaller arguments will pull the
    // near plane closer, but will also reduce the
    // z-buffer's precision.
    void setMinimumFeatureSize( float s )
    {
       if ( s <= 0 )
           return;

       if( s > 0 )
       {
           minimumFeatureSize = s;

           if( zNear > 0 )
           {
               float k = minimumFeatureSize / zNear;

               zNear   = minimumFeatureSize;

               viewportRadius *= k;

               computeViewportWidthAndHeight();
           }
       }
    }




   void resizeViewport(int width,int height )
   {
      resizeViewport( width, height,0, 0, width - 1, height - 1 );
   }

   void resizeViewport(int width,int height,

                       int viewport_x1,
                       int viewport_y1,

                       int viewport_x2,
                       int viewport_y2 )

   {
      if(( viewport_x1 < viewport_x2 )&& ( viewport_y1 < viewport_y2 ))
      {
          width  = width;
          height = height;

          _viewport_x1 = viewport_x1;
          _viewport_y1 = viewport_y1;

          _viewport_x2 = viewport_x2;
          _viewport_y2 = viewport_y2;


          _viewport_cx = ( _viewport_x1 + _viewport_x2 ) * 0.5;
          _viewport_cy = ( _viewport_y1 + _viewport_y2 ) * 0.5;

       #ifdef OPENGL_IS_CENTRE_BASED
          float viewport_radius_x = _viewport_cx - _viewport_x1;
          float viewport_radius_y = _viewport_cy - _viewport_y1;
       #else
          float viewport_radius_x = _viewport_cx - _viewport_x1 + 0.5f;
          float viewport_radius_y = _viewport_cy - _viewport_y1 + 0.5f;
       #endif
          viewportRadiusInPixels = ( viewport_radius_x < viewport_radius_y )
             ? viewport_radius_x
             : viewport_radius_y;

          computeViewportWidthAndHeight();

          // This function expects coordinates relative to an origin
          // in the lower left corner of the window (i.e. y+ is up).
       #ifdef OPENGL_IS_CENTRE_BASED
          // Also, the dimensions passed in should be between pixel centres.
       #else
          // The coordinates are edge-based.
          // Also, the dimensions passed in should be between pixel edges.
       #endif
          //
          // Say you have a window composed of the pixels marked with '.',
          // and want a viewport over the pixels marked with 'x':
          //
          //    ............
          //    ............
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    ............
          //    ............
          //    ............
          //
       #ifdef OPENGL_IS_CENTRE_BASED
          // You would have to call glViewport( 1, 3, 6, 4 );
       #else
          // You would have to call glViewport( 1, 3, 7, 5 );
       #endif
          //
          glViewport(
             _viewport_x1,
             height - 1 - _viewport_y2,
       #ifdef OPENGL_IS_CENTRE_BASED
             _viewport_x2 - _viewport_x1,
             _viewport_y2 - _viewport_y1
       #else
             _viewport_x2 - _viewport_x1 + 1,
             _viewport_y2 - _viewport_y1 + 1
       #endif
          );

      }
   }






   void computeViewportWidthAndHeight()
   {

     // recompute _viewport_width, _viewport_height
     //
     int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

     int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

     if ( viewport_width_in_pixels < viewport_height_in_pixels )
     {
        viewportWidth = 2.0 * viewportRadius;
        viewportHeight = viewportWidth
  #ifdef OPENGL_IS_CENTRE_BASED
           * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
  #else
           * viewport_height_in_pixels / (float)viewport_width_in_pixels;
  #endif
     }
     else
     {
        viewportHeight = 2.0 * viewportRadius;
        viewportWidth = viewportHeight
  #ifdef OPENGL_IS_CENTRE_BASED
           * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
  #else
           * viewport_width_in_pixels / (float)viewport_height_in_pixels;
  #endif
     }
  }





   // Clients that want to, for example, use this class to draw
   // 3D graphics within a smaller viewport on top of a larger
   // 2D graphical scene (such as surrounding widgets),
   // can use these methods to prepare for and clean up after,
   // respectively, drawing 3D stuff.
   void pushViewportAndTransform(
      int width, int height,
      int viewport_x1, int viewport_y1,
      int viewport_x2, int viewport_y2,
      int originalViewport[4]
   ) {
      glGetIntegerv( GL_VIEWPORT, originalViewport );
      resizeViewport(
         width, height,
         viewport_x1, viewport_y1,
         viewport_x2, viewport_y2
      );
      glMatrixMode( GL_PROJECTION );
      glPushMatrix();
      transform();
   }

   void popViewportAndTransform( int originalViewport[4] )
   {
      glMatrixMode( GL_PROJECTION );
      glPopMatrix();
      glMatrixMode( GL_MODELVIEW );
      glViewport( originalViewport[0], originalViewport[1],originalViewport[2],originalViewport[3]);
   }



   // Moves the camera forward or backward.  Some refer to
   // this as "tracking" the camera.
   // If the boolean flag is true, the target (or point of interest)
   // is moved with the camera, keeping the distance between the two
   // constant.


   void dollyCameraForward( float delta_pixels, bool pushTarget )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit = viewportRadiusInPixels / translationSpeedInUnitsPerRadius;

      float dollyDistance = delta_pixels / pixelsPerUnit;

      if ( ! pushTarget )
      {
         distance_from_target -= dollyDistance;

         if ( distance_from_target < pushThreshold*zNear )
         {
            distance_from_target = pushThreshold*zNear;
         }
      }

      position += direction * dollyDistance;


      target    = position + direction * distance_from_target;
   }

   // Changes the elevation angle of the camera.
   // Some refer to this as "tilting" the camera.

   void pitchCameraUp( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle   = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t   = target - position;

      QVector3D right = QVector3D::crossProduct((p2t.normalized()) , up);

      QMatrix4x4 m;

      m.rotate( angle, right );

      p2t    = m * p2t;

      up     = m * up;

      target = position + p2t;
   }




   // Changes the azimuth angle of the camera.
   // Some refer to this as "panning" the camera.

   void yawCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels  / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t = target - position;

      QMatrix4x4 m;
      m.rotate( -angle, _ground );

      p2t    = m*p2t;

      up     = m*up;

      target = position + p2t;
   }




   // Rolls the camera.

   void rollCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D direction = (target - position).normalized();

      QMatrix4x4 m;
      m.rotate( angle, direction );

      _ground = m * _ground;

      up = m * up;
   }




   // Rotates the camera toward the given point.

   void lookAt( const QVector3D& p )
   {
      // FIXME: we do not check if the target point is too close
      // to the camera (i.e. less than _pushThreshold * near_plane ).
      // If it is, perhaps we should dolly the camera away from the
      // target to maintain the minimal distance.

      target            = p;

      QVector3D direction = (target - position).normalized();

      QVector3D right     = ( QVector3D::crossProduct(direction , _ground) ).normalized();

      up                  = QVector3D::crossProduct(right , direction);

      up.normalize();
   }


   // Uses the z-buffer to find the nearest rendered pixel,
   // and makes the camera look at it.

   void zBufferLookAt( int pixel_x, int pixel_y )
   {

      int W = _viewport_x2 - _viewport_x1 + 1;
      int H = _viewport_y2 - _viewport_y1 + 1;

      GLfloat * zbuffer = new GLfloat[ W * H ];

      // FIXME: we want to fetch the z-buffer of the most
      // recently rendered image.  Unfortunately, this code
      // probably grabs the back z-buffer, rather than the
      // front z-buffer, which (if I'm not mistaken) is what we want.
      // FIXME: instead of grabbing the whole buffer, we should just
      // grab a small region around the pixel of interest.
      // Grabbing the whole buffer is very slow on
      // some Iris machines (e.g. Indigo2).
      glReadPixels(
         _viewport_x1,
         height - 1 - _viewport_y2,
         W, H,
         GL_DEPTH_COMPONENT, GL_FLOAT, zbuffer
      );

      // // Print contents of z-buffer (for debugging only).
      // for ( int b = H-1; b >= 0; --b ) {
      //    for ( int a = 0; a < W; ++a ) {
      //       printf("%c",zbuffer[ b*W + a ]==1?'.':'X');
      //    }
      //    puts("");
      // }

      // Keep in mind that zbuffer[0] corresponds to the lower-left
      // pixel of the viewport, *not* the upper-left pixel.

      // Transform the pixel passed in so that it is
      // in the z-buffer's coordinate system.
      pixel_x -= _viewport_x1;
      pixel_y  = H - 1 - (pixel_y - _viewport_y1);

      // Assume, as is typically the case, that the z-buffer was
      // cleared with a value of 1.0f (the maximum z value).
      // Also assume that any pixels containing a value of 1.0f
      // have this value because no rendered geometry covered them.
      // Now, search outward from the pixel passed in, in larger
      // and larger rectangles, for a pixel with a z value
      // less than 1.0f.

      if( 0 <= pixel_x && pixel_x < W && 0 <= pixel_y && pixel_y < H )
      {

          // the search rectangle
          int x1 = pixel_x, y1 = pixel_y;
          int x2 = x1, y2 = y1;

          int x,y,x0=W/2,y0=H/2;
          int min, max;
          float z = 1;
          while ( z == 1 )
          {
             // top edge of rectangle
             if ( y1 >= 0 )
             {
                y = y1;

                min = x1 < 0 ? 0 : x1;

                max = x2 >= W ? W-1 : x2;

                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // bottom edge of rectangle
             if ( y2 < H )
             {
                y = y2;
                min = x1 < 0 ? 0 : x1;
                max = x2 >= W ? W-1 : x2;
                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // left edge of rectangle
             if ( x1 >= 0 )
             {
                x = x1;
                min = y1 < 0 ? 0 : y1;
                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // right edge of rectangle
             if ( x2 < W )
             {
                x = x2;

                min = y1 < 0 ? 0 : y1;

                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }

             // grow the rectangle
             --x1;  --y1;
             ++x2;  ++y2;

             // is there nothing left to search ?
             if ( y1 < 0 && y2 >= H && x1 < 0 && x2 >= W )
                break;
          }

          if ( z < 1 )
          {
             // compute point in clipping space
       #ifdef OPENGL_IS_CENTRE_BASED
             QVector4D pc( 2*x0/(float)(W-1)-1, 2*y0/(float)(H-1)-1, 2*z-1 ,1);
       #else
             // The +0.5f here is to convert from centre-based coordinates
             // to edge-based coordinates.
             QVector4D pc( 2*(x0+0.5f)/(float)W-1, 2*(y0+0.5f)/(float)H-1, 2*z-1,1 );
       #endif



             // compute inverse view transform
             QMatrix4x4 M;
             //M.setToLookAt( position, target, up, true );
             M.lookAt( position, target, up );

             // compute inverse perspective transform
             QMatrix4x4 M2;
             /*
             M2.setToFrustum(
                - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                zNear, zFar,
                true
             );
             */

             M2.frustum(- 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                        - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                        zNear, zFar   );

             // compute inverse of light transform
             M = M * M2;

             // compute point in world space
             QVector4D t0 = M * pc;

             QVector3D t( t0.x()/t0.w(), t0.y()/t0.w(), t0.z()/t0.w() );

             lookAt( t );
          }



      }
      delete [] zbuffer;
      zbuffer = 0;
   }


   // Returns the ray through the centre of the given pixel.
   //Ray computeRay( int pixel_x, int pixel_y ) const;  // centre-based coordinates

   QRay3D computeRay( int pixel_x, int pixel_y ) const
   {
      // this is a point on the near plane, in camera space
      QVector3D p( (pixel_x-_viewport_cx)*viewportRadius/viewportRadiusInPixels,
                (_viewport_cy-pixel_y)*viewportRadius/viewportRadiusInPixels,
                 zNear
              );

      // transform p to world space
      QVector3D direction = (target - position).normalized();

      QVector3D right = QVector3D::crossProduct( direction , up);

      QVector3D v = right*p.x() + up*p.y() + direction*p.z();

      p = position + v;

      return QRay3D( p, v.normalized() );
   }

   /*


   // Computes the pixel covering the given point.
   // Also returns the z-distance (in camera space) to the point.
   //float computePixel(const Point3&,int& pixel_x, int& pixel_y )const;  // centre-based coordinates

   float computePixel( const QVector3D & p, int& pixel_x, int& pixel_y) const
   {
      // Transform the point from world space to camera space.

      QVector3D direction = (target - position).normalized();
      QVector3D right = QVector3D::crossProduct(direction , up);

      // Note that (right, _up, direction) form an orthonormal basis.
      // To transform a point from camera space to world space,
      // we can use the 3x3 matrix formed by concatenating the
      // 3 vectors written as column vectors.  The inverse of such
      // a matrix is simply its transpose.  So here, to convert from
      // world space to camera space, we do

      QVector3D v = p-position;
      float x = QVector3D::dotProduct(v,right);
      float y = QVector3D::dotProduct(v,up);
      float z = QVector3D::dotProduct(v,direction);

      // (or, more simply, the projection of a vector onto a unit vector
      // is their dot product)

      float k = zNear / z;

      // The +0.5f here is for rounding.
      pixel_x = (int)(
         k*viewportRadiusInPixels*x/viewportRadius + _viewport_cx + 0.5f
      );
      pixel_y = (int)(
         _viewport_cy - k*viewportRadiusInPixels*y/viewportRadius + 0.5f
      );
      return z;
   }



   // Compute the necessary size, in world space, of an object
   // (at the given distance from the camera,
   // or centred at the given point, respectively)
   // for it to cover the given fraction of the viewport.
   // These methods are useful for determining the necessary size of widgets
   // placed in 3D space for them to have a constant size in screen space.
   //float convertLength( float z_distance, float fractionOfViewportSize ) const;

   float convertLength(float z_distance, float fractionOfViewportSize) const
   {
      return z_distance * fractionOfViewportSize * 2 * viewportRadius / zNear; //tangent of field-of-view's semi-angle
   }

   float convertLength( const QVector3D& p, float fractionOfViewportSize ) const
   {
      int x, y;
      return convertLength( computePixel( p, x, y ), fractionOfViewportSize );
   }


   // Compute the necessary size, in world space, of an object
   // centred at the given point
   // for it to cover the given length of pixels.
   float convertPixelLength( const QVector3D& p, int pixelLength ) const
   {
      int x, y;
      return convertLength(  computePixel( p, x, y ),
         0.5 * pixelLength / (float)viewportRadiusInPixels
      );
   }




   // Unlinke lookAt(), these methods do NOT change the camera's orientation.
   // Instead, they translate the camera
   // such that the given points (or corners of the given box)
   // are just visible within the viewport.



   void framePoints( const vector< QVector3D >& l, bool frameExactly )
   {
      if ( l.empty() )
         return;
      QVector3D direction = (target - position).normalized();
      QVector3D right = QVector3D::crossProduct(direction , up);

      // Transform each of the points to camera space,
      // and find the minimal bounding box containing them
      // that is aligned with camera space.
      // FIXME the projection we do here is orthogonal;
      // it ignores the perspective projection of the camera
      // that will make distant points appear closer to the line of sight.
      // Thus, the camera will not frame points as tightly as it could.
      AlignedBox3D box;

      vector< QVector3D >::const_iterator it = l.begin();

      for ( ; it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;
         box.bound( QVector3D( QVector3D::dotProduct(v , right), QVector3D::dotProduct(v , up), QVector3D::dotProduct(v ,direction) ) );
      }

      // Translate the camera such
      // that the line of sight passes through the centre of the bounding box,
      // and the target point is at the centre of the bounding box.
      QVector3D boxCentre = box.getCentre();
      QVector3D newTarget = position  + right * boxCentre.x() + up * boxCentre.y() + direction * boxCentre.z();
      QVector3D translation = newTarget - target;

      position += translation;
      target = newTarget;

      // Next, dolly the camera forward (or backward)
      // such that all points are visible.
      // For each given point,
      // we compute the amount by which to dolly forward for that point,
      // and find the minimum of all such amounts
      // to use for the actual dolly.
//
//         In the below diagram,
//            "1" is the current position of the camera, which is pointing down
//            "a" is the distance to the near plane
//            "b" is half the width/height of the viewport
//            "3" is a point we want to frame by dollying the camera forward
//            "2" is the new location to place the camera to just frame "3"
//            "?" is the distance to dolly forward, which we want to compute
//
//                      |-b-|
//
//                         1  -  -  -
//                         /|  |  |  |
//                        / |  a  |  |
//                       /  |  |  |  |
//                      /---|  -  ?  |
//                     /    |     |  |
//                    /     |     |  |
//                   /      |     |  c
//                  /       2     -  |
//                 /       /|     |  |
//                /       / |     |  |
//               /       /  |     e  |
//             /       /   |     |  |
//            /       /    |     |  |
//           .-------3-----.     -  -
//
//                    |--f--|
//
       //     |------d------|
      //     The two hypotenuses are parallel because we don't want to change
      //    the camera's field of view.
      //   We have
      //       a/b = c/d = e/f   (where a,b,c,f are known)
      //    and
      //       ? = c - e
      //         = c - f*a/b

      bool minDollyDeltaInitialized = false;


      float minDollyDelta = 0;

      float min_c = 0;

      for ( it = l.begin(); it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;

         float c = QVector3D::dotProduct(v , direction);

         if ( it == l.begin() )
             min_c = c;
         else if ( c < min_c )
             min_c = c;

         float f, dollyDelta;

         if ( viewportWidth > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , right) );

            dollyDelta = c - f * zNear * 2 / viewportWidth;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
         if ( viewportHeight > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , up ));

            dollyDelta = c - f * zNear * 2 / viewportHeight;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
      }

      if ( ! frameExactly ) {
         // check that the dolly won't put some points
         // in front of the near plane
         if ( min_c - minDollyDelta < zNear )
            minDollyDelta = min_c - zNear;

         // fudge factor, to add a tiny margin around the points
         minDollyDelta -= 0.05f * zNear;
      }

      // perform the dolly
      position += direction * minDollyDelta;

      if ( ( target - position ).length() <= pushThreshold*zNear ) {
         // The target point is too close.
         target = position + direction * ( pushThreshold*zNear );
      }

      // FIXME: should we check if some points are beyond the
      // far plane, and if so move the far plane further back ?
   }


   virtual void frameBox( const AlignedBox3D& box )
   {
      vector< QVector3D > corners;

      for ( int i = 0; i < 8; ++i )
         corners.push_back( box.getCorner( i ) );

      framePoints( corners,true );
   }

   */

   virtual void transform()
   {
      glMatrixMode( GL_PROJECTION );
      glLoadIdentity();  // clear matrix

      if( zNear < zFar )
      {

          /*
          glFrustum(
             - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
             - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
             zNear, zFar
          );

          */

          glFrustum(
             - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
             - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
             zNear, 1000.0f
          );

          QMatrix4x4 m;
          m.setToIdentity();
          m.lookAt( position, target, up );
          qMultMatrix(m );

      }
   }

   void qMultMatrix(const QMatrix4x4 &mat)
   {
       if (sizeof(qreal) == sizeof(GLfloat))
           glMultMatrixf((GLfloat*)mat.constData());

   #ifndef QT_OPENGL_ES
       else if (sizeof(qreal) == sizeof(GLdouble))
           glMultMatrixd((GLdouble*)mat.constData());
   #endif
       else
       {
           GLfloat fmat[16];

           qreal const *r =(qreal*) mat.constData();

           for (int i = 0; i < 16; ++i)
           {
               fmat[i] = r[i];
           }

           glMultMatrixf(fmat);
       }
   }


   // Changes the field-of-view.

   virtual void changeFOV( float delta_pixels )
   {
      // this should be a little greater than 1.0
      float magnificationFactorPerPixel = 1.005;

      viewportRadius *= pow( magnificationFactorPerPixel, - delta_pixels );


      // recompute _viewport_width, _viewport_height
      //computeViewportWidthAndHeight()

      int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

      int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

      if ( viewport_width_in_pixels < viewport_height_in_pixels )
      {
         viewportWidth  = 2.0 * viewportRadius;

         viewportHeight = viewportWidth

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
   #else
            * viewport_height_in_pixels / (float)viewport_width_in_pixels;
   #endif
      }
      else
      {
         viewportHeight = 2.0 * viewportRadius;

         viewportWidth  = viewportHeight

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
   #else
            * viewport_width_in_pixels / (float)viewport_height_in_pixels;
   #endif
      }

   }

   virtual void zoom( float delta )
   {
       QVector3D dir =  target - position;

       dir = dir.normalized();

       target   += dir * delta;

       position += dir * delta;
   }

   virtual void pan( QPointF delta )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit  = viewportRadiusInPixels  / translationSpeedInUnitsPerRadius;

      QVector3D right        = QVector3D::crossProduct(direction , up);

      QVector3D translation  = right * ( - delta.x() / pixelsPerUnit )  + up * (  delta.y() / pixelsPerUnit );

      position += translation;

      target   += translation;

   }

   virtual void orbit(QPointF delta)
   {
       /*
      float pixelsPerDegree = viewportRadiusInPixels / orbitingSpeedInDegreesPerRadius;
      float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

      QVector3D t2p = position - target;

      QMatrix4x4 m;
      m.setToIdentity();
      m.rotate((delta.x()*-1) * radiansPerPixel,_ground);

      t2p = m*t2p;
      up = m*up;

      QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
      m.rotate( (delta.y() *-1) * radiansPerPixel,right);

      t2p = m*t2p;
      up = m*up;
      position = target + t2p;

      */





       QVector3D t2p = position - target;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate((delta.x()*-1),_ground);

       t2p = m*t2p;
       up = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
       m.rotate( (delta.y() *-1),right);

      t2p = m*t2p;
      up = m*up;
      position = target + t2p;
   }

   virtual void orbit(QPointF delta,const QVector3D& centre )
   {
       /*
      float pixelsPerDegree = viewportRadiusInPixels
         / orbitingSpeedInDegreesPerRadius;
      float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

      QVector3D t2p = position - target;
      QVector3D c2p = position - centre;

      QMatrix4x4 m;
      m.setToIdentity();
      m.rotate(  (delta.x() *-1) * radiansPerPixel,   _ground  );

      c2p = m*c2p;
      t2p = m*t2p;
      up  = m*up;

      QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

      m.rotate( (delta.y()*-1) * radiansPerPixel,   right  );

      c2p = m*c2p;

      t2p = m*t2p;

      up = m*up;

      position = centre + c2p;

      target   = position - t2p;

      */

       QVector3D t2p = position - target;
       QVector3D c2p = position - centre;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate(  (delta.x() *-1) ,   _ground  );

       c2p = m*c2p;
       t2p = m*t2p;
       up  = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

       m.rotate( (delta.y()*-1),   right  );

       c2p = m*c2p;

       t2p = m*t2p;

       up = m*up;

       position = centre + c2p;

       target   = position - t2p;
   }

   //void reset();
   virtual void resetCamera()
   {

      double tangent = tan( Fov_SemiAngle );

      viewportRadius = zNear * tangent;

      float distance_from_target = fudgeFactor * sceneRadius / tangent;

      computeViewportWidthAndHeight();

      // The ground vector can change if the user rolls the camera,
      // hence we reset it here.
      _ground = _initialGround;

      up = _ground;

      QVector3D v;

      if ( up.x()==0 && up.y()==1 && up.z()==0 )
          v = QVector3D( 0, 0, 1 );
      else
          v = getPerpendicularVector(up).normalized();//.choosePerpendicular().normalized();

      target   = sceneCentre;

      position = target + v * distance_from_target;
   }



   // Sets the state of the camera to be an
   // interpolation of the states of the given cameras.
   // The interpolation parameter should be in the interval [0,1]
   // This method can be used for animating camera motions.

   virtual void interpolate( const CameraFinal& c1, const CameraFinal& c2, float u )
   {
      // FIXME I only bother to interpolate a few data members.
      // You may need to add more data members here eventually.

       position  = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(c2.position)*u );

       target    = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(c2.target)*u );

       up        = c1.up*(1-u) + c2.up*u;
   }

   /*
   // Similar to interpolate(),
   // but rather than performing a linear interpolation,
   // this routine interpolates through an
   // "overview" of what both c1 and c2 see.
   // Thus, when this routine is used for animating camera transitions
   // from one place to another (possibly distant) place,
   // at some point during the transition
   // the user can see both places simultaneously,
   // and thus gain a better idea of how they are related spatially.
   // As currently implemented, this routine assumes that
   // c1 and c2 have the same orientation and the same field-of-view.
   virtual void interpolateThroughOverview( const CameraFinal& c1, const CameraFinal& c2, float u )
   {
      // initialize our state with the proper orientation, field of view, etc.
      *this = c1;

      // set our state equal to the intermediate, "overview" state
      vector< QVector3D > l;
      l.push_back( c1.getPosition() );
      l.push_back( c2.getPosition() );
      framePoints( l, true );

      // compute the value of u corresponding to the "overview" state
      float length1 = ( position - c1.position ).length();
      float length2 = ( position - c2.position ).length();

      if ( length1 + length2 == 0 )
      {
         // For definiteness (e.g. to ensure our state has
         // the correct target point and other parameters)
         // set our state equal to one of the given states.
         *this = u < 0.5f ? c1 : c2;
         return;
      }

      float u_overview = length1 / ( length1 + length2 );

      // now interpolate linearly between our state and one of the end states
      if ( u < 0 )
          u = 0;
      else if ( u > 1 )
          u = 1;

      if ( u < u_overview )
      {
         if ( u_overview > 0 )
            u /= u_overview; // normalize u

         position = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(position)*u );
         target = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(target)*u );
         up = c1.up*(1-u) + up*u;
      }
      else
      {
         if ( u_overview < 1 )
            u      = (u-u_overview)/(1-u_overview); // normalize u

         position = QVector3D( QVector3D(position)*(1-u) + QVector3D(c2.position)*u );
         target   = QVector3D( QVector3D(target)*(1-u)   + QVector3D(c2.target)*u );
         up       = up*(1-u) + c2.up*u;
      }
   }

   */




};


class QCameraTargetModel: public QBaseModel
{
    Q_OBJECT


    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

           const float*r = mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }

    float safeTitleMargin;
    float safeActionMargin;

    QPointF lastPos;

    QString viewName;

    QMatrix4x4 projectionMatrix;
    QMatrix4x4 viewMatrix;
    QMatrix4x4 normalMatrix;


    QPropertiesTreeWidget *properties;

public:

    //----------------------------------------------------
    //
    //           UP
    //           |
    //           |
    //           |   dir = (target - P0)
    //           P0 -------(C)---------------------->  target
    //          /
    //         /
    //        /
    //       Normal
    //
    //  C is the center point on the screen not the camera position P0
    //---------------------------------------------------------------

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCameraParameters()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    enum { Type = MODEL_CAMERA_FREE};

    int type() const  { return Type; }

    CameraParameters * parameters;

    QCameraTargetModel(QObject * parent = 0) : QBaseModel(parent)
    {
        cameraViewMode     = VIEW;

        projectionMode = PERSPECTIVE;

        // A good angle for the field-of-view is 30 degrees.
        // Setting this very small will give the user the impression
        // of looking through a telescope.
        // Setting it very big will give the impression of a wide-angle
        // lens, with strong foreshortening effects that are especially
        // noticeable near the edges of the viewport.
        Fov_SemiAngle   = M_PI * 15 / 180.0;

        // This should be a little greater than 1.0.
        // If it's set to one, the user will initially
        // just *barely* see all of the scene in the window
        // (assuming the scene is a sphere of radius scene_radius).
        fudgeFactor     = 1.1f;

        // This should be a little greater than 0.0.
        // If no minimum feature size is given by the user,
        //    minimum_feature_size = _nearPlaneFactor * scene_radius

        zNearPlaneFactor = 0.1f;

        // far_plane = _farPlaneFactor * scene_radius


        zFarPlaneFactor  = 15;

        // Used for yaw, pitch, roll.
        rotationSpeedInDegreesPerRadius = 150;

        // Used for orbit.
        orbitingSpeedInDegreesPerRadius = 300;

        // The target (or point-of-interest) of the camera is kept
        // at a minimal distance of
        //   _pushThreshold * near_plane
        // from the camera position.
        // This number should be greater than 1.0, to ensure
        // that the target is never clipped.

        pushThreshold = 1.3f;


        initialGroundVector = QVector3D( 0, 1, 0 );


        setSceneRadius( 4 );


        setSceneCentre( QVector3D( 0, 0, 0) );


        minimumFeatureSize = zNearPlaneFactor * sceneRadius;


        safeTitleMargin   =  0.25f;


        safeActionMargin  =  0.15f;


        parameters  = new CameraParameters;


        zNear       = parameters->zNear;

        zFar        = parameters->zFar;

        fov         = parameters->fov;


        zNear       = minimumFeatureSize;

        aspectRatio =  1.0f;


        viewName    = QString("View");


        setViewAtOrigin();


        //setViewAtTarget();


        resetCamera();


        addWidgets();
    }

    ~QCameraTargetModel()
    {
        delete properties;
    }

    const QVector3D  & getPosition() const { return position; }
    const QVector3D  & getTarget() const { return target; }
    const QVector3D  & getUp() const { return up; }
    const QVector3D    getRight() const { QVector3D direction = ( target - position ).normalized(); return QVector3D::crossProduct(direction , up); }




    enum QCameraView
    {
        VIEW  = 0,
        FRONT,
        BACK,
        RIGHT,
        LEFT,
        TOP,
        BOTTOM,
    };


    QCameraView cameraViewMode;

    int currentView = 0;

    QString getViewName()
    {
        return viewName;
    }

    enum QProjection
    {
        PERSPECTIVE,
        ORTHO,
    };

    QProjection projectionMode;

    QRectF viewRect;

    // the radius of the viewport, in pixels
    float viewportRadiusInPixels;
    float viewportRadius;

    // dimensions of the viewport,
    // in world space, measured on the near plane

    float viewportWidth;
    float viewportHeight;

    //QVector3D position; // point of view
    QVector3D target;   // point of interest
    QVector3D up;      // a unit vector, perpendicular to the line-of-sight

    QVector3D groundVector;  // a unit vector perpendicular to the ground plane
    QVector3D initialGroundVector;

    QVector3D sceneCentre;

    // constants that can be tuned
    float zNearPlaneFactor;
    float zFarPlaneFactor;

    float Fov_SemiAngle;
    float fudgeFactor;

    float sceneRadius;

    float minimumFeatureSize;
    float zNear;
    float zFar;
    float fov;
    float aspectRatio;

    float rotationSpeedInDegreesPerRadius; // for yaw, pitch, roll
    float orbitingSpeedInDegreesPerRadius; // for orbit
    float pushThreshold;

    QCursor cursor;


    QMatrix4x4 getOrthoProjection()
    {
        float maxx = std::max(fabs(0), fabs(1));
        float maxy = std::max(fabs(0), fabs(1));
        float max  = std::max(maxx, maxy);

        float r = max * aspectRatio;
        float t = max;
        float l = -r;
        float b = -t;

        QMatrix4x4 orthoProjection;

        orthoProjection.setToIdentity();

        orthoProjection.ortho(l,r,b,t,zNear,zFar);
        //orthoProjection.ortho(-1.0f,1.0f,-1.0f,1.0f,_near,_far);

        return orthoProjection;
    }

    QMatrix4x4 getPerspectiveProjection()
    {
        QMatrix4x4 perspectiveProjection;

        perspectiveProjection.setToIdentity();

        perspectiveProjection.perspective(fov, aspectRatio, zNear, zFar);

        return perspectiveProjection;
    }

    QMatrix4x4 getProjectionMatrix()
    {
        if(projectionMode == ORTHO)
        {
            QMatrix4x4 orthoProjection       = getOrthoProjection();

            projectionMatrix = orthoProjection;


        }
        else if(projectionMode == PERSPECTIVE)
        {
            QMatrix4x4 perspectiveProjection = getPerspectiveProjection();

            projectionMatrix = perspectiveProjection;

        }
        return projectionMatrix;
    }

    QMatrix4x4 getViewMatrix()
    {
        QMatrix4x4 lookAtMatrix;

        lookAtMatrix.setToIdentity();

        lookAtMatrix.lookAt(position, target,up);

        viewMatrix = lookAtMatrix;

        return viewMatrix;
    }

    QMatrix4x4 getNormalMatrix()
    {
        QMatrix4x4 modelview = getViewMatrix();

        QMatrix4x4 modelviewInv;

        QMatrix4x4 normalmatrix;

        modelviewInv =  modelview.inverted();

        normalmatrix =  modelviewInv.transposed();

        normalMatrix = normalmatrix;

        return normalMatrix;
    }

    QMatrix4x4 getProjectionViewMatrix()
    {
        QMatrix4x4 lookAtMatrix;

        lookAtMatrix.setToIdentity();

        lookAtMatrix.lookAt(position, target,up);



        QMatrix4x4 PV;

        if(projectionMode == ORTHO)
        {
            QMatrix4x4 orthoProjection       = getOrthoProjection();


            PV = orthoProjection * lookAtMatrix;
        }
        else if(projectionMode == PERSPECTIVE)
        {
            QMatrix4x4 perspectiveProjection = getPerspectiveProjection();


            PV = perspectiveProjection * lookAtMatrix;
        }

        return PV;
    }

    /*

    QMatrix4x4 getProjectionViewMatrix()
    {

        QMatrix4x4 lookAtMatrix;

        lookAtMatrix.setToIdentity();

        float radiusDistance = (position - target).length();

        if(cameraViewMode == FRONT)
        {
            position  = QVector3D(0, 0, -1*radiusDistance);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);
        }
        else if(cameraViewMode == BACK)
        {
            position  = QVector3D(0, 0, radiusDistance);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(cameraViewMode == LEFT)
        {
            position = QVector3D(-1*radiusDistance, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);
        }
        else if(cameraViewMode == RIGHT)
        {
            position = QVector3D(radiusDistance, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(cameraViewMode == TOP)
        {
            position  = QVector3D(0, radiusDistance, 0);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 0, 1);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(cameraViewMode == BOTTOM)
        {
            position = QVector3D(0, -1*radiusDistance, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 0, 1);

            lookAtMatrix.lookAt(position, target,up);
        }
        else if(cameraViewMode == VIEW)
        {
            lookAtMatrix.lookAt(position, target,up);
        }

        QMatrix4x4 PV;

        if(projectionMode == ORTHO)
        {
            QMatrix4x4 orthoProjection       = getOrthoProjection();

            PV = orthoProjection * lookAtMatrix;
        }
        else if(projectionMode == PERSPECTIVE)
        {
            QMatrix4x4 perspectiveProjection = getPerspectiveProjection();

            PV = perspectiveProjection * lookAtMatrix;
        }

        return PV;
    }

    */

    void setViewAtOrigin()
    {
        float radiusDistance = (position - target).length();

        if(cameraViewMode == FRONT)
        {
            position  = QVector3D(0, 0, -1*radiusDistance);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == BACK)
        {
            position  = QVector3D(0, 0, radiusDistance);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == LEFT)
        {
            position = QVector3D(-1*radiusDistance, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == RIGHT)
        {
            position = QVector3D(radiusDistance, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == TOP)
        {
            position  = QVector3D(0, radiusDistance, 0);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 0, 1);
        }
        else if(cameraViewMode == BOTTOM)
        {
            position = QVector3D(0, -1*radiusDistance, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 0, 1);
        }
        else if(cameraViewMode == VIEW)
        {
            //lookAtMatrix.lookAt(position, target,up);
        }

        //if(cameraViewMode != VIEW)
        //{
        //    projectionMode=ORTHO;
       // }
    }

    void setViewAtTarget()
    {
        float radiusDistance = (position - target).length();

        //QVector3D dir = (position - target).normalize();

        //dir*=-1;

        if(cameraViewMode == FRONT)
        {
            position  = QVector3D(0, 0, -1*radiusDistance);
            //target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == BACK)
        {
            position  = QVector3D(0, 0, radiusDistance);
            //target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == LEFT)
        {
            position = QVector3D(-1*radiusDistance, 0, 0);
            //target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == RIGHT)
        {
            position = QVector3D(radiusDistance, 0, 0);
            //target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);
        }
        else if(cameraViewMode == TOP)
        {
            position  = QVector3D(0, radiusDistance, 0);
            //target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 0, 1);
        }
        else if(cameraViewMode == BOTTOM)
        {
            position = QVector3D(0, -1*radiusDistance, 0);
            //target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 0, 1);
        }
        else if(cameraViewMode == VIEW)
        {
            //lookAtMatrix.lookAt(position, target,up);
        }

        //if(cameraViewMode != VIEW)
        //{
        //    projectionMode=ORTHO;
       // }
    }



    QVector2D toScreen(QMatrix4x4 viewProjectionMatrix,const QVector3D &coordinate) const
    {
        QVector3D projected = viewProjectionMatrix.map(coordinate);

        QVector2D c(viewRect.width() * 0.5, viewRect.height() * 0.5);

        return c + c * projected.toVector2D() * QVector2D(1, -1);
    }
    QRectF toScreenRect(QMatrix4x4 projectionMatrix,QMatrix4x4 viewMatrix,const QVector<QVector3D> &coordinates) const
    {
        QVector<QVector3D> mapped;

        for (int i = 0; i < coordinates.size(); ++i)
            mapped << viewMatrix.map(coordinates.at(i));

        qreal zClip = -zNear;

        QVector<QVector3D> clipped;

        for (int i = 0; i < mapped.size(); ++i)
        {
            const QVector3D &a = mapped.at(i);
            const QVector3D &b = mapped.at((i + 1) % mapped.size());

            bool aOut = a.z() > zClip;
            bool bOut = b.z() > zClip;

            if (aOut && bOut)
                continue;

            if (!aOut && !bOut) {
                clipped << b;
                continue;
            }

            qreal t = (zClip - a.z()) / (b.z() - a.z());
            QVector3D intersection = a + t * (b - a);

            clipped << intersection;

            if (!bOut)
                clipped << b;
        }

        QRectF bounds;

        QVector2D c(viewRect.width() * 0.5, viewRect.height() * 0.5);

        for (int i = 0; i < clipped.size(); ++i)
        {
            QVector2D projected = c + c * projectionMatrix.map(clipped.at(i)).toVector2D() * QVector2D(1, -1);
            bounds = bounds.united(QRectF(projected.toPointF(), QSizeF(0.01, 0.01)));
        }

        bounds = bounds.intersected(QRectF(0, 0, viewRect.width(), viewRect.height()));

        return bounds;
    }

    QVector3D getWorldCoordinateFromScreen( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 0.9;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );

        GLdouble hx = 0, hy = 0, hz = 0;

        gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &hx, &hy, &hz );

        QVector3D worldPos(hx,hy,hz);

        return worldPos;
    }
    QVector3D getScreenCoordinateFromWorld(QVector3D worldPos)
    {
        double modelview[16], projection[16];

        int viewports[4];

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewports );

        GLdouble x,y,z;

        gluProject( worldPos.x(), worldPos.y(), worldPos.z(), modelview, projection, viewports, &x, &y, &z );

        QVector3D hitpoint(x,y,z);

        return hitpoint;

    }


    QPoint project(QVector3D position,QMatrix4x4 mainModelView)
    {
        position =  mainModelView * position;

        qreal winX = viewRect.width() * (position.x() + 1) / 2;

        qreal winY = viewRect.height() - viewRect.height() * (position.y() + 1) / 2;

        return QPoint((int)winX, (int)winY);
    }

    QVector3D unProject(int x, int y,QMatrix4x4 mainModelView)
    {

        // project click down to plane
        // about the mathematics: http://www.opengl.org/sdk/docs/man/xhtml/gluUnProject.xml
        // mainModelView should be our modelview projection matrix

        QMatrix4x4 inv = mainModelView.inverted();

        qreal coordx = 2 * (qreal) x / (qreal) viewRect.width() - 1;
        qreal coordy = 2 * (qreal) (viewRect.height() - y) / (qreal) viewRect.height() - 1;

        QVector4D nearPoint4 = inv * QVector4D(coordx, coordy, -1, 1); // winZ = 2 * 0 - 1 = -1
        QVector4D farPoint4  = inv * QVector4D(coordx, coordy, 1, 1); // win> = 2 * 1 - 1 = 1

        if(nearPoint4.w() == 0.0)
        {
            return QVector3D();
        }
        qreal w = 1.0/nearPoint4.w();

        QVector3D nearPoint = QVector3D(nearPoint4);

        nearPoint *= w;

        w = 1.0/farPoint4.w();

        QVector3D farPoint = QVector3D(farPoint4);

        farPoint *= w;

        QVector3D dir = farPoint - nearPoint;

        if (dir.z()==0.0) // if we are looking in a flat direction we won't hit the ground
            return QVector3D(0,0,0);

        qreal t = - nearPoint.z() / dir.z(); // how long it is to the ground

        QVector3D cursor = nearPoint + dir * t;

        return cursor;
    }


    virtual void drawSafeTitleRectangle(QGLWidget * widget)
    {

        float s = .75;


        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);

        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    virtual void drawSafeActionRectangle(QGLWidget * widget)
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        float s = .85f;

        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);


        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }


    virtual void resizeViewPort(QRectF rect)
    {
        viewRect    =  rect;

        aspectRatio = (GLfloat) viewRect.width() /(GLfloat) viewRect.height() ;

        //resetCamera();

        float width  = viewRect.width();
        float height = viewRect.height();

        float _viewport_x1 = viewRect.topLeft().x();
        float _viewport_y1 = viewRect.topLeft().y();
        float _viewport_x2 = viewRect.bottomRight().x() -1;
        float _viewport_y2 = viewRect.bottomRight().y() -1;


        if(( _viewport_x1 < _viewport_x2 )&& ( _viewport_y1 < _viewport_y2 ))
        {
            float _viewport_cx = ( _viewport_x1 + _viewport_x2 ) * 0.5;
            float _viewport_cy = ( _viewport_y1 + _viewport_y2 ) * 0.5;


         #ifdef OPENGL_IS_CENTRE_BASED
            float viewport_radius_x = _viewport_cx - _viewport_x1;
            float viewport_radius_y = _viewport_cy - _viewport_y1;
         #else
            float viewport_radius_x = _viewport_cx - _viewport_x1 + 0.5f;
            float viewport_radius_y = _viewport_cy - _viewport_y1 + 0.5f;
         #endif
            viewportRadiusInPixels = ( viewport_radius_x < viewport_radius_y )
               ? viewport_radius_x
               : viewport_radius_y;

            computeViewportWidthAndHeight();

            // This function expects coordinates relative to an origin
            // in the lower left corner of the window (i.e. y+ is up).
         #ifdef OPENGL_IS_CENTRE_BASED
            // Also, the dimensions passed in should be between pixel centres.
         #else
            // The coordinates are edge-based.
            // Also, the dimensions passed in should be between pixel edges.
         #endif
            //
            // Say you have a window composed of the pixels marked with '.',
            // and want a viewport over the pixels marked with 'x':
            //
            //    ............
            //    ............
            //    .xxxxxxx....
            //    .xxxxxxx....
            //    .xxxxxxx....
            //    .xxxxxxx....
            //    .xxxxxxx....
            //    ............
            //    ............
            //    ............
            //
         #ifdef OPENGL_IS_CENTRE_BASED
            // You would have to call glViewport( 1, 3, 6, 4 );
         #else
            // You would have to call glViewport( 1, 3, 7, 5 );
         #endif
            //
            glViewport(
               _viewport_x1,
               height - 1 - _viewport_y2,
         #ifdef OPENGL_IS_CENTRE_BASED
               _viewport_x2 - _viewport_x1,
               _viewport_y2 - _viewport_y1
         #else
               _viewport_x2 - _viewport_x1 + 1,
               _viewport_y2 - _viewport_y1 + 1
         #endif
            );

        }

        //resizeViewport( width, height,viewport_x1, viewport_y1, viewport_x2, viewport_y2 );



    }





    void setPositionAndOrientation( const QVector3D & pos, const QVector3D & direction, const QVector3D & _up )
    {
       position = pos;
       target   = pos + direction;
       up       = _up;
    }

    void setSceneCentre( const QVector3D& p )
    {
       sceneCentre = p;
    }

    // This causes the far plane to be recomputed.
    void setSceneRadius( float r )
    {
       if ( r <= 0 )
           return;

       if( r > 0 )
       {
           sceneRadius = r;

           zFar = zFarPlaneFactor * sceneRadius;
       }
    }

    // This causes the near plane to be recomputed.
    // Note that the argument passed in must be positive.
    // Also note that smaller arguments will pull the
    // near plane closer, but will also reduce the
    // z-buffer's precision.
    void setMinimumFeatureSize( float s )
    {
       if ( s <= 0 )
           return;

       if( s > 0 )
       {
           minimumFeatureSize = s;

           if( zNear > 0 )
           {
               float k = minimumFeatureSize / zNear;

               zNear   = minimumFeatureSize;

               viewportRadius *= k;

               computeViewportWidthAndHeight();
           }
       }
    }


    QVector3D getPerpendicularVector(QVector3D p)
    {
       // Pick the two largest components,
       // permute them and negate one of them, and
       // replace the other (i.e. smallest) component with zero.

       float X = fabs(p.x());
       float Y = fabs(p.y());
       float Z = fabs(p.z());

       QVector3D v;

       if ( X < Y )
       {
          if ( Y < Z )
          {
             // X < Y < Z
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else if ( X < Z )
          {
             // X < Z <= Y
             v = QVector3D( 0, p.z(), -p.y() );
          }
          else
          {
             // Z <= X < Y
             v = QVector3D( p.y(), -p.x(), 0 );
          }
       }
       else
       {
          if ( Z < Y )
          {
             // Z < Y <= X
             v = QVector3D( p.y(), -p.x(), 0 );
          }
          else if ( Z < X )
          {
             // Y <= Z < X
             v = QVector3D( p.z(), 0, -p.x() );
          }
          else
          {
             // Y <= X <= Z
             v = QVector3D( p.z(), 0, -p.x() );
          }
       }

       //#ifdef DEBUG
       //float dotProduct =QVector3D::dotProduct(v , p);
       //ASSERT_IS_EQUAL( dotProduct, 0 );
       //#endif

       return v;
    }



    void computeViewportWidthAndHeight()
    {
        float _viewport_x1 = viewRect.topLeft().x();
        float _viewport_y1 = viewRect.topLeft().y();
        float _viewport_x2 = viewRect.bottomRight().x() -1;
        float _viewport_y2 = viewRect.bottomRight().y() -1;


        // recompute _viewport_width, _viewport_height
        //
        int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

        int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

         if ( viewport_width_in_pixels < viewport_height_in_pixels )
         {
            viewportWidth = 2.0 * viewportRadius;
            viewportHeight = viewportWidth
      #ifdef OPENGL_IS_CENTRE_BASED
               * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
      #else
               * viewport_height_in_pixels / (float)viewport_width_in_pixels;
      #endif
         }
         else
         {
            viewportHeight = 2.0 * viewportRadius;
            viewportWidth = viewportHeight
      #ifdef OPENGL_IS_CENTRE_BASED
               * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
      #else
               * viewport_width_in_pixels / (float)viewport_height_in_pixels;
      #endif
         }

    }

   // Clients that want to, for example, use this class to draw
   // 3D graphics within a smaller viewport on top of a larger
   // 2D graphical scene (such as surrounding widgets),
   // can use these methods to prepare for and clean up after,
   // respectively, drawing 3D stuff.
   void pushViewportAndTransform(int originalViewport[4])
   {
       float width  = viewRect.width();
       float height = viewRect.height();

       float _viewport_x1 = viewRect.topLeft().x();
       float _viewport_y1 = viewRect.topLeft().y();
       float _viewport_x2 = viewRect.bottomRight().x() -1;
       float _viewport_y2 = viewRect.bottomRight().y() -1;

      glGetIntegerv( GL_VIEWPORT, originalViewport );

      /*

      resizeViewport(
         width, height,
         viewport_x1, viewport_y1,
         viewport_x2, viewport_y2
      );

      */

      if(( _viewport_x1 < _viewport_x2 )&& ( _viewport_y1 < _viewport_y2 ))
      {
          float _viewport_cx = ( _viewport_x1 + _viewport_x2 ) * 0.5;
          float _viewport_cy = ( _viewport_y1 + _viewport_y2 ) * 0.5;

       #ifdef OPENGL_IS_CENTRE_BASED
          float viewport_radius_x = _viewport_cx - _viewport_x1;
          float viewport_radius_y = _viewport_cy - _viewport_y1;
       #else
          float viewport_radius_x = _viewport_cx - _viewport_x1 + 0.5f;
          float viewport_radius_y = _viewport_cy - _viewport_y1 + 0.5f;
       #endif
          viewportRadiusInPixels = ( viewport_radius_x < viewport_radius_y )
             ? viewport_radius_x
             : viewport_radius_y;

          computeViewportWidthAndHeight();

          // This function expects coordinates relative to an origin
          // in the lower left corner of the window (i.e. y+ is up).
       #ifdef OPENGL_IS_CENTRE_BASED
          // Also, the dimensions passed in should be between pixel centres.
       #else
          // The coordinates are edge-based.
          // Also, the dimensions passed in should be between pixel edges.
       #endif
          //
          // Say you have a window composed of the pixels marked with '.',
          // and want a viewport over the pixels marked with 'x':
          //
          //    ............
          //    ............
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    .xxxxxxx....
          //    ............
          //    ............
          //    ............
          //
       #ifdef OPENGL_IS_CENTRE_BASED
          // You would have to call glViewport( 1, 3, 6, 4 );
       #else
          // You would have to call glViewport( 1, 3, 7, 5 );
       #endif
          //
          glViewport(
             _viewport_x1,
             height - 1 - _viewport_y2,
       #ifdef OPENGL_IS_CENTRE_BASED
             _viewport_x2 - _viewport_x1,
             _viewport_y2 - _viewport_y1
       #else
             _viewport_x2 - _viewport_x1 + 1,
             _viewport_y2 - _viewport_y1 + 1
       #endif
          );

      }



      glMatrixMode( GL_PROJECTION );
      glPushMatrix();
      transform();
   }

   void popViewportAndTransform( int originalViewport[4] )
   {
      glMatrixMode( GL_PROJECTION );
      glPopMatrix();
      glMatrixMode( GL_MODELVIEW );
      glViewport( originalViewport[0], originalViewport[1],originalViewport[2],originalViewport[3]);
   }



   // Moves the camera forward or backward.  Some refer to
   // this as "tracking" the camera.
   // If the boolean flag is true, the target (or point of interest)
   // is moved with the camera, keeping the distance between the two
   // constant.


   void dollyCameraForward( float delta_pixels, bool pushTarget )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit = viewportRadiusInPixels / translationSpeedInUnitsPerRadius;

      float dollyDistance = delta_pixels / pixelsPerUnit;

      if ( ! pushTarget )
      {
         distance_from_target -= dollyDistance;

         if ( distance_from_target < pushThreshold*zNear )
         {
            distance_from_target = pushThreshold*zNear;
         }
      }

      position += direction * dollyDistance;

      target    = position + direction * distance_from_target;
   }

   // Changes the elevation angle of the camera.
   // Some refer to this as "tilting" the camera.

   void pitchCameraUp( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle   = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t   = target - position;

      QVector3D right = QVector3D::crossProduct((p2t.normalized()) , up);

      QMatrix4x4 m;

      m.rotate( angle, right );

      p2t    = m * p2t;

      up     = m * up;

      target = position + p2t;
   }

   // Changes the azimuth angle of the camera.
   // Some refer to this as "panning" the camera.

   void yawCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels  / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D p2t = target - position;

      QMatrix4x4 m;

      m.rotate( -angle, groundVector );

      p2t    = m*p2t;

      up     = m*up;

      target = position + p2t;
   }

   // Rolls the camera.

   void rollCameraRight( float delta_pixels )
   {

      float pixelsPerDegree = viewportRadiusInPixels / rotationSpeedInDegreesPerRadius;

      float angle = delta_pixels / pixelsPerDegree * M_PI / 180;

      QVector3D direction = (target - position).normalized();

      QMatrix4x4 m;

      m.rotate( angle, direction );

      groundVector = m * groundVector;

      up = m * up;
   }


   void lookAt(const QVector3D& eye, const QVector3D& ptarget )
   {
       target              = ptarget;

       position            =  eye;

       QVector3D direction = (target - position).normalized();

       QVector3D right     = ( QVector3D::crossProduct(direction , groundVector) ).normalized();

       up                  = QVector3D::crossProduct(right , direction);

       up.normalize();
   }

   void lookAt(const QVector3D& eye, const QVector3D& ptarget, const QVector3D& _up  )
   {
       target   =  ptarget;

       position =  eye;

       up       =  _up;
   }

   void lookAt(QRay3D ray, float targetDistance )
   {
       //try this function for lights, top,bottom,left right etc
       position            = ray.origin();

       target              = ray.direction() * targetDistance;

       QVector3D direction = (target - position).normalized();

       QVector3D right     = ( QVector3D::crossProduct(direction , groundVector) ).normalized();

       up                  = QVector3D::crossProduct(right , direction);

       up.normalize();
   }

   // Rotates the camera toward the given point.

   void lookAt( const QVector3D& p )
   {
      // FIXME: we do not check if the target point is too close
      // to the camera (i.e. less than _pushThreshold * near_plane ).
      // If it is, perhaps we should dolly the camera away from the
      // target to maintain the minimal distance.

      target              = p;

      QVector3D direction = (target - position).normalized();

      QVector3D right     = ( QVector3D::crossProduct(direction , groundVector) ).normalized();

      up                  = QVector3D::crossProduct(right , direction);

      up.normalize();

   }


   // Uses the z-buffer to find the nearest rendered pixel,
   // and makes the camera look at it.

   void zBufferLookAt( int pixel_x, int pixel_y )
   {
       float width  = viewRect.width();
       float height = viewRect.height();

       float _viewport_x1 = viewRect.topLeft().x();
       float _viewport_y1 = viewRect.topLeft().y();
       float _viewport_x2 = viewRect.bottomRight().x() -1;
       float _viewport_y2 = viewRect.bottomRight().y() -1;


      int W = _viewport_x2 - _viewport_x1 + 1;
      int H = _viewport_y2 - _viewport_y1 + 1;

      GLfloat * zbuffer = new GLfloat[ W * H ];

      // FIXME: we want to fetch the z-buffer of the most
      // recently rendered image.  Unfortunately, this code
      // probably grabs the back z-buffer, rather than the
      // front z-buffer, which (if I'm not mistaken) is what we want.
      // FIXME: instead of grabbing the whole buffer, we should just
      // grab a small region around the pixel of interest.
      // Grabbing the whole buffer is very slow on
      // some Iris machines (e.g. Indigo2).
      glReadPixels(
         _viewport_x1,
         height - 1 - _viewport_y2,
         W, H,
         GL_DEPTH_COMPONENT, GL_FLOAT, zbuffer
      );

      // // Print contents of z-buffer (for debugging only).
      // for ( int b = H-1; b >= 0; --b ) {
      //    for ( int a = 0; a < W; ++a ) {
      //       printf("%c",zbuffer[ b*W + a ]==1?'.':'X');
      //    }
      //    puts("");
      // }

      // Keep in mind that zbuffer[0] corresponds to the lower-left
      // pixel of the viewport, *not* the upper-left pixel.

      // Transform the pixel passed in so that it is
      // in the z-buffer's coordinate system.
      pixel_x -= _viewport_x1;
      pixel_y  = H - 1 - (pixel_y - _viewport_y1);

      // Assume, as is typically the case, that the z-buffer was
      // cleared with a value of 1.0f (the maximum z value).
      // Also assume that any pixels containing a value of 1.0f
      // have this value because no rendered geometry covered them.
      // Now, search outward from the pixel passed in, in larger
      // and larger rectangles, for a pixel with a z value
      // less than 1.0f.

      if( 0 <= pixel_x && pixel_x < W && 0 <= pixel_y && pixel_y < H )
      {
          // the search rectangle
          int x1 = pixel_x, y1 = pixel_y;
          int x2 = x1, y2 = y1;

          int x,y,x0=W/2,y0=H/2;
          int min, max;
          float z = 1;
          while ( z == 1 )
          {
             // top edge of rectangle
             if ( y1 >= 0 )
             {
                y = y1;

                min = x1 < 0 ? 0 : x1;

                max = x2 >= W ? W-1 : x2;

                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // bottom edge of rectangle
             if ( y2 < H )
             {
                y = y2;
                min = x1 < 0 ? 0 : x1;
                max = x2 >= W ? W-1 : x2;
                for ( x = min; x <= max; ++x )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // left edge of rectangle
             if ( x1 >= 0 )
             {
                x = x1;
                min = y1 < 0 ? 0 : y1;
                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }
             // right edge of rectangle
             if ( x2 < W )
             {
                x = x2;

                min = y1 < 0 ? 0 : y1;

                max = y2 >= H ? H-1 : y2;

                for ( y = min; y <= max; ++y )
                   if ( zbuffer[ y*W + x ] < z )
                   {
                      z = zbuffer[ y*W + x ];
                      x0 = x;
                      y0 = y;
                   }
             }

             // grow the rectangle
             --x1;  --y1;
             ++x2;  ++y2;

             // is there nothing left to search ?
             if ( y1 < 0 && y2 >= H && x1 < 0 && x2 >= W )
                break;
          }

          if ( z < 1 )
          {
             // compute point in clipping space
       #ifdef OPENGL_IS_CENTRE_BASED
             QVector4D pc( 2*x0/(float)(W-1)-1, 2*y0/(float)(H-1)-1, 2*z-1 ,1);
       #else
             // The +0.5f here is to convert from centre-based coordinates
             // to edge-based coordinates.
             QVector4D pc( 2*(x0+0.5f)/(float)W-1, 2*(y0+0.5f)/(float)H-1, 2*z-1,1 );
       #endif



             // compute inverse view transform
             QMatrix4x4 M;
             //M.setToLookAt( position, target, up, true );
             M.lookAt( position, target, up );

             // compute inverse perspective transform
             QMatrix4x4 M2;
             /*
             M2.setToFrustum(
                - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                zNear, zFar,
                true
             );
             */

             M2.frustum(- 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
                        - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
                        zNear, zFar   );

             // compute inverse of light transform
             M = M * M2;

             // compute point in world space
             QVector4D t0 = M * pc;

             QVector3D t( t0.x()/t0.w(), t0.y()/t0.w(), t0.z()/t0.w() );

             lookAt( t );
          }

      }
      delete [] zbuffer;
      zbuffer = 0;
   }


   // Returns the ray through the centre of the given pixel.
   //Ray computeRay( int pixel_x, int pixel_y ) const;  // centre-based coordinates

   QRay3D computeRay( int x, int y ) const
   {
       float cx = viewRect.center().x();
       float cy = viewRect.center().y();

      // this is a point on the near plane, in camera space
      QVector3D p( (x-cx)*viewportRadius/viewportRadiusInPixels,
                   (cy-y)*viewportRadius/viewportRadiusInPixels,
                    zNear
                  );

      // transform p to world space
      QVector3D direction = (target - position).normalized();

      QVector3D right = QVector3D::crossProduct( direction , up);

      QVector3D v = right*p.x() + up*p.y() + direction*p.z();

      p = position + v;

      return QRay3D( p, v.normalized() );
   }




   // Computes the pixel covering the given point.
   // Also returns the z-distance (in camera space) to the point.
   //float computePixel(const Point3&,int& pixel_x, int& pixel_y )const;  // centre-based coordinates

   float computePixel( const QVector3D & p, int& pixel_x, int& pixel_y) const
   {
      // Transform the point from world space to camera space.

      QVector3D direction = (target - position).normalized();
      QVector3D right = QVector3D::crossProduct(direction , up);

      // Note that (right, _up, direction) form an orthonormal basis.
      // To transform a point from camera space to world space,
      // we can use the 3x3 matrix formed by concatenating the
      // 3 vectors written as column vectors.  The inverse of such
      // a matrix is simply its transpose.  So here, to convert from
      // world space to camera space, we do

      QVector3D v = p - position;

      float x = QVector3D::dotProduct(v,right);
      float y = QVector3D::dotProduct(v,up);
      float z = QVector3D::dotProduct(v,direction);

      // (or, more simply, the projection of a vector onto a unit vector
      // is their dot product)

      float k = zNear / z;

      // The +0.5f here is for rounding.
      pixel_x = (int)( k*viewportRadiusInPixels*x/viewportRadius + viewRect.center().x() + 0.5f  );
      pixel_y = (int)(viewRect.center().y() - k*viewportRadiusInPixels*y/viewportRadius + 0.5f );

      return z;
   }


   // Compute the necessary size, in world space, of an object
   // (at the given distance from the camera,
   // or centred at the given point, respectively)
   // for it to cover the given fraction of the viewport.
   // These methods are useful for determining the necessary size of widgets
   // placed in 3D space for them to have a constant size in screen space.
   //float convertLength( float z_distance, float fractionOfViewportSize ) const;

   float convertLength(float z_distance, float fractionOfViewportSize) const
   {
      return z_distance * fractionOfViewportSize * 2 * viewportRadius / zNear; //tangent of field-of-view's semi-angle
   }

   float convertLength( const QVector3D& p, float fractionOfViewportSize ) const
   {
      int x, y;
      return convertLength( computePixel( p, x, y ), fractionOfViewportSize );
   }


   // Compute the necessary size, in world space, of an object
   // centred at the given point
   // for it to cover the given length of pixels.
   float convertPixelLength( const QVector3D& p, int pixelLength ) const
   {
      int x, y;
      return convertLength(  computePixel( p, x, y ),
         0.5 * pixelLength / (float)viewportRadiusInPixels
      );
   }


   // Unlinke lookAt(), these methods do NOT change the camera's orientation.
   // Instead, they translate the camera
   // such that the given points (or corners of the given box)
   // are just visible within the viewport.



   void framePoints(  QVector< QVector3D > l, bool frameExactly )
   {
      if ( l.empty() )
         return;

      QVector3D direction = (target - position).normalized();

      QVector3D right     = QVector3D::crossProduct(direction , up);

      // Transform each of the points to camera space,
      // and find the minimal bounding box containing them
      // that is aligned with camera space.
      // FIXME the projection we do here is orthogonal;
      // it ignores the perspective projection of the camera
      // that will make distant points appear closer to the line of sight.
      // Thus, the camera will not frame points as tightly as it could.
      QBox3D box;

      QVector< QVector3D >::const_iterator it = l.begin();

      for ( ; it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;

         QVector3D p = QVector3D( QVector3D::dotProduct(v , right),
                                  QVector3D::dotProduct(v , up),
                                  QVector3D::dotProduct(v ,direction) ) ;

         box.unite(p);
      }

      // Translate the camera such
      // that the line of sight passes through the centre of the bounding box,
      // and the target point is at the centre of the bounding box.
      QVector3D boxCentre   = box.center();
      QVector3D newTarget   = position  + right * boxCentre.x() + up * boxCentre.y() + direction * boxCentre.z();
      QVector3D translation = newTarget - target;

      position += translation;
      target    = newTarget;

      // Next, dolly the camera forward (or backward)
      // such that all points are visible.
      // For each given point,
      // we compute the amount by which to dolly forward for that point,
      // and find the minimum of all such amounts
      // to use for the actual dolly.
        //
        //         In the below diagram,
        //            "1" is the current position of the camera, which is pointing down
        //            "a" is the distance to the near plane
        //            "b" is half the width/height of the viewport
        //            "3" is a point we want to frame by dollying the camera forward
        //            "2" is the new location to place the camera to just frame "3"
        //            "?" is the distance to dolly forward, which we want to compute
        //
        //                      |-b-|
        //
        //                         1  -  -  -
        //                         /|  |  |  |
        //                        / |  a  |  |
        //                       /  |  |  |  |
        //                      /---|  -  ?  |
        //                     /    |     |  |
        //                    /     |     |  |
        //                   /      |     |  c
        //                  /       2     -  |
        //                 /       /|     |  |
        //                /       / |     |  |
        //               /       /  |     e  |
        //             /       /   |     |  |
        //            /       /    |     |  |
        //           .-------3-----.     -  -
        //
        //                    |--f--|
        //
               //     |------d------|
      //     The two hypotenuses are parallel because we don't want to change
      //    the camera's field of view.
      //   We have
      //       a/b = c/d = e/f   (where a,b,c,f are known)
      //    and
      //       ? = c - e
      //         = c - f*a/b

      bool minDollyDeltaInitialized = false;

      float minDollyDelta = 0;

      float min_c = 0;

      for ( it = l.begin(); it != l.end(); ++it )
      {
         QVector3D v = (*it) - position;

         float c = QVector3D::dotProduct(v , direction);

         if ( it == l.begin() )
             min_c = c;
         else if ( c < min_c )
             min_c = c;

         float f, dollyDelta;

         if ( viewportWidth > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , right) );

            dollyDelta = c - f * zNear * 2 / viewportWidth;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
         if ( viewportHeight > 0 )
         {
            f = fabs( QVector3D::dotProduct(v , up ));

            dollyDelta = c - f * zNear * 2 / viewportHeight;

            if ( minDollyDeltaInitialized )
            {
               if ( dollyDelta < minDollyDelta )
                  minDollyDelta = dollyDelta;
            }
            else
            {
               minDollyDelta = dollyDelta;
               minDollyDeltaInitialized = true;
            }
         }
      }

      if ( ! frameExactly )
      {
         // check that the dolly won't put some points
         // in front of the near plane
         if ( min_c - minDollyDelta < zNear )
            minDollyDelta = min_c - zNear;

         // fudge factor, to add a tiny margin around the points
         minDollyDelta -= 0.05f * zNear;
      }

      // perform the dolly
      position += direction * minDollyDelta;

      if ( ( target - position ).length() <= pushThreshold*zNear )
      {
         // The target point is too close.
         target = position + direction * ( pushThreshold*zNear );
      }

      // FIXME: should we check if some points are beyond the
      // far plane, and if so move the far plane further back ?
   }


   virtual void frameBox(  QBox3D box )
   {
      QVector< QVector3D > corners ;

      for ( int i = 0; i < box.getAllCorners().size(); i++ )
      {
          corners.push_back( box.getAllCorners()[i] );
      }

      framePoints( box.getAllCorners() , true );
   }










   virtual void transform()
   {
      glMatrixMode( GL_PROJECTION );
      glLoadIdentity();  // clear matrix

      if( zNear < zFar )
      {
         //glFrustum(- 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
         //    - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
         //    zNear, zFar
         // );


          glFrustum(
             - 0.5 * viewportWidth,  0.5 * viewportWidth,    // left, right
             - 0.5 * viewportHeight, 0.5 * viewportHeight,   // bottom, top
             zNear, 1000.0f
          );

          QMatrix4x4 m;
          m.setToIdentity();
          m.lookAt( position, target, up );

          qMultMatrix(m );
      }
   }



   // Changes the field-of-view.

   virtual void changeFOV( float delta_pixels )
   {
       float width  = viewRect.width();
       float height = viewRect.height();

       float _viewport_x1 = viewRect.topLeft().x();
       float _viewport_y1 = viewRect.topLeft().y();

       float _viewport_x2 = viewRect.bottomRight().x() -1;
       float _viewport_y2 = viewRect.bottomRight().y() -1;


      // this should be a little greater than 1.0
      float magnificationFactorPerPixel = 1.005;

      viewportRadius *= pow( magnificationFactorPerPixel, - delta_pixels );


      // recompute _viewport_width, _viewport_height
      //computeViewportWidthAndHeight()

      int viewport_width_in_pixels  = _viewport_x2 - _viewport_x1 + 1;

      int viewport_height_in_pixels = _viewport_y2 - _viewport_y1 + 1;

      if ( viewport_width_in_pixels < viewport_height_in_pixels )
      {
         viewportWidth  = 2.0 * viewportRadius;

         viewportHeight = viewportWidth

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_height_in_pixels-1) / (float)(viewport_width_in_pixels-1);
   #else
            * viewport_height_in_pixels / (float)viewport_width_in_pixels;
   #endif
      }
      else
      {
         viewportHeight = 2.0 * viewportRadius;

         viewportWidth  = viewportHeight

   #ifdef OPENGL_IS_CENTRE_BASED
            * (viewport_width_in_pixels-1) / (float)(viewport_height_in_pixels-1);
   #else
            * viewport_width_in_pixels / (float)viewport_height_in_pixels;
   #endif
      }

   }


public:

   virtual void zoom( float delta )
   {
       QVector3D dir =  target - position;

       dir = dir.normalized();

       target   += dir * delta;

       position += dir * delta;
   }

   virtual void pan( QPointF delta )
   {
      QVector3D direction = target - position;

      float distance_from_target = direction.length();

      direction = direction.normalized();

      float translationSpeedInUnitsPerRadius = distance_from_target * viewportRadius / zNear;

      float pixelsPerUnit  = viewportRadiusInPixels  / translationSpeedInUnitsPerRadius;

      QVector3D right        = QVector3D::crossProduct(direction , up);

      QVector3D translation  = right * ( - delta.x() / pixelsPerUnit )  + up * (  delta.y() / pixelsPerUnit );

      position += translation;

      target   += translation;

   }

   virtual void orbit(QPointF delta)
   {

       /*
       float pixelsPerDegree = viewportRadiusInPixels / orbitingSpeedInDegreesPerRadius;
       float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

       QVector3D t2p = position - target;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate((delta.x()*-1) * radiansPerPixel,_ground);

       t2p = m*t2p;
       up = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
       m.rotate( (delta.y() *-1) * radiansPerPixel,right);

       t2p = m*t2p;
       up = m*up;
       position = target + t2p;

       */


       // QVector3D t2p should not be normalized
       QVector3D t2p = position - target;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate((delta.x()*-1),groundVector);

       t2p = m*t2p;
       up = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();
       m.rotate( (delta.y() *-1),right);

       t2p = m*t2p;
       up  = m*up;
       position = target + t2p;
   }

   virtual void orbit(QPointF delta,const QVector3D& centre )
   {
       /*
      float pixelsPerDegree = viewportRadiusInPixels
         / orbitingSpeedInDegreesPerRadius;
      float radiansPerPixel = 1.0 / pixelsPerDegree * M_PI / 180;

      QVector3D t2p = position - target;
      QVector3D c2p = position - centre;

      QMatrix4x4 m;
      m.setToIdentity();
      m.rotate(  (delta.x() *-1) * radiansPerPixel,   _ground  );

      c2p = m*c2p;
      t2p = m*t2p;
      up  = m*up;

      QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

      m.rotate( (delta.y()*-1) * radiansPerPixel,   right  );

      c2p = m*c2p;

      t2p = m*t2p;

      up = m*up;

      position = centre + c2p;

      target   = position - t2p;

      */

       QVector3D t2p = position - target;
       QVector3D c2p = position - centre;

       QMatrix4x4 m;
       m.setToIdentity();
       m.rotate(  (delta.x() *-1) ,   groundVector  );

       c2p = m*c2p;
       t2p = m*t2p;
       up  = m*up;

       QVector3D right = QVector3D::crossProduct(up , t2p).normalized();

       m.rotate( (delta.y()*-1),   right  );

       c2p = m*c2p;

       t2p = m*t2p;

       up = m*up;

       position = centre + c2p;

       target   = position - t2p;
   }

   virtual void pan(QMouseEvent *event)
   {
       QPointF p        =  QPointF(event->pos());
       QPointF delta    =  p - lastPos;


       pan(delta);

       lastPos   =  QPointF(event->pos());
   }

   virtual void zoom(QMouseEvent *event)
   {
       QPointF p      =  QPointF(event->pos());

       QPointF delta  =  p - lastPos;

       float factor   = (float) 0.05f * delta.x();

       zoom(factor);

       lastPos        =  QPointF(event->pos());
   }

   virtual void zoom(QWheelEvent *event)
   {
       qreal factor = qPow(1.2, event->delta() / 240.0);

       if(event->delta() <0)
            factor *= -1;

      zoom(factor);

   }

   virtual void rotate(QMouseEvent *event)
   {
       QPointF p = QPointF(event->pos());

       QPointF delta    =  p - lastPos;

       orbit(delta);

       lastPos          =  QPointF(event->pos());
   }

   virtual void wheelEvent(QWheelEvent *event)
   {
       QPixmap map = QPixmap(":/Tools Icons/camera zoom.svg");
       QCursor c   = QCursor(map) ;
       zoom(event);
   }


   QVector3D intersectionP;


   void centerToGridPlane()
   {
       QPointF center = viewRect.center();

       QRay3D ray = computeRay(center.x(), center.y() );

       QPlane3D plane(QVector3D(0,0,0),QVector3D(0,1,0));

       if(plane.intersects(ray))
       {
           float t2 = plane.intersection(ray);

           intersectionP = ray.getPointAt(t2);

           lookAt(intersectionP);
       }
   }

   virtual void mousePressEvent(QMouseEvent *event)
   {
       QCursor c;

       c.setShape(Qt::ArrowCursor);

       lastPos    = event->pos();

       QRay3D ray = computeRay(lastPos.x(), lastPos.y() );

       QPlane3D plane(QVector3D(0,0,0),QVector3D(0,1,0));

       if(plane.intersects(ray))
       {
           float t = plane.intersection(ray);

           intersectionP = ray.getPointAt(t);
       }

       qDebug()<<"Ray: Origin:"<<ray.origin();

       qDebug()<<"Ray: Direction:"<<ray.direction();

       qDebug()<<"Ray: Intersection:"<<intersectionP;

       centerToGridPlane();


       qDebug()<<"\n";
   }

   virtual void mouseMoveEvent(QMouseEvent * event)
   {

       //else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::MidButton)
       if( event->buttons() & Qt::MidButton && event->modifiers()&Qt::ShiftModifier  )
       {
           QPixmap map = QPixmap(":/Tools Icons/camera pan.svg");
           QCursor c   = QCursor(map) ;


           pan(event);  //qDebug()<<"ALT+MID";
       }
       //if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::LeftButton)
       else if(event->buttons() & Qt::MiddleButton)
       {
           QPixmap map = QPixmap(":/Tools Icons/camera rotate.svg");
           QCursor c   = QCursor(map) ;

           //if(projectionMode==ORTHO)
           {

           }
           //else
           {
               rotate(event);  //qDebug()<<"ALT+LEFT";
           }
       }
       else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::RightButton)
       {
           QPixmap map = QPixmap(":/Tools Icons/camera zoom.svg");
           QCursor c   = QCursor(map) ;


           zoom(event); //qDebug()<<"ALT+RIGHT";
       }
   }

   virtual void mouseReleaseEvent(QMouseEvent *event)
   {
       QCursor c;
       c.setShape(Qt::ArrowCursor);
   }


   class Key
   {
   public:
       QVector3D postion;
       QVector3D target;
       QVector3D up;
   };

   Key viewKey;

   QList<Key> keysFrames;

   virtual void keyPressEvent(QKeyEvent * event)
   {
       if(event->key() == Qt::Key_O)
       {
          if( projectionMode == ORTHO)
          {
              projectionMode = PERSPECTIVE;
          }
          else
          {
              projectionMode = ORTHO;
          }
       }

       if(event->key() == Qt::Key_V)
       {
           switch(currentView)
           {
           case 0:
               resetCameraToHome();

               cameraViewMode = VIEW;

               viewName = QString("View Mode");
               break;
           case 1:
               cameraViewMode = FRONT;
               viewName = QString("Front Mode");
               break;
           case 2:
               cameraViewMode = BACK;
               viewName = QString("Back Mode");
               break;
           case 3:
               cameraViewMode = RIGHT;
               viewName = QString("Right Mode");
               break;
           case 4:
               cameraViewMode = LEFT;
               viewName = QString("Left Mode");
               break;
           case 5:
               cameraViewMode = TOP;
               viewName = QString("Top Mode");
               break;
           case 6:
               cameraViewMode = BOTTOM;
               viewName = QString("Bottom Mode");
               break;
           }

           setViewAtOrigin();

           //setViewAtTarget();

           currentView++;

           if(currentView>6)
           {
               currentView = 0;
           }
       }
   }

   //void reset();
   virtual void resetCamera()
   {

      double tangent = tan( Fov_SemiAngle );

      viewportRadius = zNear * tangent;

      float distance_from_target = fudgeFactor * sceneRadius / tangent;

      computeViewportWidthAndHeight();

      // The ground vector can change if the user rolls the camera,
      // hence we reset it here.
      groundVector = initialGroundVector;

      up = groundVector;

      QVector3D v;

      if ( up.x()==0 && up.y()==1 && up.z()==0 )
          v = QVector3D( 0, 0, 1 );
      else
          v = getPerpendicularVector(up).normalized();//.choosePerpendicular().normalized();

      target   = sceneCentre;

      position = target + v * distance_from_target;
   }

   virtual void resetCameraToHome()
   {
       lookAt(QVector3D(9.23181,7.916107,11.002),QVector3D(0,0,0),QVector3D(-0.31163,0.87462,-0.37386));
   }



   // Sets the state of the camera to be an
   // interpolation of the states of the given cameras.
   // The interpolation parameter should be in the interval [0,1]
   // This method can be used for animating camera motions.

   virtual void interpolate( const QCameraTargetModel & c1, const QCameraTargetModel & c2, float u )
   {
      // FIXME I only bother to interpolate a few data members.
      // You may need to add more data members here eventually.

       position  = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(c2.position)*u );

       target    = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(c2.target)*u );

       up        = c1.up*(1-u) + c2.up*u;
   }

   /*
   // Similar to interpolate(),
   // but rather than performing a linear interpolation,
   // this routine interpolates through an
   // "overview" of what both c1 and c2 see.
   // Thus, when this routine is used for animating camera transitions
   // from one place to another (possibly distant) place,
   // at some point during the transition
   // the user can see both places simultaneously,
   // and thus gain a better idea of how they are related spatially.
   // As currently implemented, this routine assumes that
   // c1 and c2 have the same orientation and the same field-of-view.
   virtual void interpolateThroughOverview( const Camera& c1, const Camera& c2, float u )
   {
      // initialize our state with the proper orientation, field of view, etc.
      *this = c1;

      // set our state equal to the intermediate, "overview" state
      vector< QVector3D > l;
      l.push_back( c1.getPosition() );
      l.push_back( c2.getPosition() );
      framePoints( l, true );

      // compute the value of u corresponding to the "overview" state
      float length1 = ( position - c1.position ).length();
      float length2 = ( position - c2.position ).length();

      if ( length1 + length2 == 0 )
      {
         // For definiteness (e.g. to ensure our state has
         // the correct target point and other parameters)
         // set our state equal to one of the given states.
         *this = u < 0.5f ? c1 : c2;
         return;
      }

      float u_overview = length1 / ( length1 + length2 );

      // now interpolate linearly between our state and one of the end states
      if ( u < 0 )
          u = 0;
      else if ( u > 1 )
          u = 1;

      if ( u < u_overview )
      {
         if ( u_overview > 0 )
            u /= u_overview; // normalize u

         position = QVector3D( QVector3D(c1.position)*(1-u) + QVector3D(position)*u );
         target = QVector3D( QVector3D(c1.target)*(1-u) + QVector3D(target)*u );
         up = c1.up*(1-u) + up*u;
      }
      else
      {
         if ( u_overview < 1 )
            u      = (u-u_overview)/(1-u_overview); // normalize u

         position = QVector3D( QVector3D(position)*(1-u) + QVector3D(c2.position)*u );
         target   = QVector3D( QVector3D(target)*(1-u)   + QVector3D(c2.target)*u );
         up       = up*(1-u) + c2.up*u;
      }
   }

   */






signals:

    void valueChanged();

public slots:

    void updateCameraParameters()
    {
        parameters = new CameraParameters;

        zNear = parameters->zNear;
        zFar  = parameters->zFar;
        fov   = parameters->fov ;

        emit valueChanged();
    }

    void centerToModel(QBaseModel * model)
    {

    }

};





class QCameraTargetModelBackup: public QBaseModel
{
    Q_OBJECT

    const QMatrix4x4 fromRotation(float angle, Qt::Axis axis) const
    {
        QMatrix4x4 m;

        if (axis == Qt::XAxis)
            m.rotate(angle, QVector3D(1, 0, 0));
        else if (axis == Qt::YAxis)
            m.rotate(-angle, QVector3D(0, 1, 0));
        else if (axis == Qt::ZAxis)
            m.rotate(angle, QVector3D(0, 0, 1));
        return m;
    }

    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

             const float*r = mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }

    float safeTitleMargin;
    float safeActionMargin;

    QPoint lastPos;

    QPropertiesTreeWidget *properties;

public:

    //----------------------------------------------------
    //
    //           UP
    //           |
    //           |
    //           |   dir = (target - P0)
    //           P0 -------(C)---------------------->  target
    //          /
    //         /
    //        /
    //       Normal
    //
    //  C is the center point on the screen not the camera position P0
    //---------------------------------------------------------------

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateCameraParameters()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);

        properties->hide();
    }

    enum { Type = MODEL_CAMERA_TARGET};

    int type() const  { return Type; }

    CameraParameters * parameters;

    QCameraTargetModelBackup(QObject * parent = 0) : QBaseModel(parent)
    {
        archball      = new QArchBall3D(640.0f, 480.0f);

        position      = QVector3D(10, 10, 10);
        target        = QVector3D(0,0,0);
        up            = QVector3D(0,1,0);

        //key.position  = position;
        //key.target    = target;
        //key.up        = up;

        safeTitleMargin   =  0.25f;
        safeActionMargin  =  0.15f;

        parameters = new CameraParameters;

        zNear      = parameters->zNear;
        zFar       = parameters->zFar;
        fov        = parameters->fov;

        aspectRatio       =  1.0f;
        panscale          =  0.05f;
        zoomscale         = -0.5f;
        rotationScale     =  1.0f;

        addWidgets();

        cameraMode  = PERSPECTIVE;
    }

    ~QCameraTargetModelBackup()
    {
        delete properties;
    }


    class CameraKey
    {
    public:
        QVector3D position;
        QVector3D target;
        QVector3D up;
        QVector3D right;
        QVector3D forward;
    };

    CameraKey key;


    enum QCameraView
    {
        FRONT,
        BACK,
        RIGHT,
        LEFT,
        TOP,
        BOTTOM,
        PERSPECTIVE,
        ORTHO,
    };

    QCameraView cameraMode;

    QArchBall3D * archball;

    QRectF viewRect;

    QVector3D up;
    QVector3D right;
    QVector3D forward;
    QVector3D target;

    float panscale;
    float zoomscale;
    float rotationScale;

    float zFar;
    float zNear;
    float fov;
    float aspectRatio;


    QMatrix4x4 getOrthoProjection()
    {
        float maxx = std::max(fabs(0), fabs(1));
        float maxy = std::max(fabs(0), fabs(1));
        float max  = std::max(maxx, maxy);

        float r = max * aspectRatio;
        float t = max;
        float l = -r;
        float b = -t;

        QMatrix4x4 orthoProjection;

        orthoProjection.setToIdentity();

        orthoProjection.ortho(l,r,b,t,zNear,zFar);
        //orthoProjection.ortho(-1.0f,1.0f,-1.0f,1.0f,_near,_far);

        return orthoProjection;
    }

    QMatrix4x4 getPerspectiveProjection()
    {
        QMatrix4x4 perspectiveProjection;

        perspectiveProjection.setToIdentity();

        perspectiveProjection.perspective(fov, aspectRatio, zNear, zFar);

        return perspectiveProjection;
    }

    QMatrix4x4 getProjectionViewMatrix(QCameraView viewmode = FRONT,float zoom = 100.0f)
    {
        QMatrix4x4 orthoProjection       = getOrthoProjection();

        QMatrix4x4 perspectiveProjection = getPerspectiveProjection();



        QMatrix4x4 lookAtMatrix;

        lookAtMatrix.setToIdentity();

        if(viewmode == ORTHO)
        {
            lookAtMatrix.lookAt(key.position, key.target,key.up);

            QMatrix4x4 PV = orthoProjection * lookAtMatrix;

            return PV;
        }
        else if(viewmode == PERSPECTIVE)
        {
            lookAtMatrix.lookAt(key.position, key.target,key.up);

            QMatrix4x4 PV = perspectiveProjection * lookAtMatrix;

            return PV;
        }




        if(viewmode == FRONT)
        {
            position  = QVector3D(0, 0, -1*zoom);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);
        }
        else if(viewmode == BACK)
        {
            position  = QVector3D(0, 0, zoom);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(viewmode == LEFT)
        {
            position = QVector3D(-1*zoom, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(viewmode == RIGHT)
        {
            position = QVector3D(zoom, 0, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 1, 0);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(viewmode == TOP)
        {
            position  = QVector3D(0, zoom, 0);
            target    = QVector3D(0, 0, 0);
            up        = QVector3D(0, 0, 1);

            lookAtMatrix.lookAt(position, target,up);

        }
        else if(viewmode == BOTTOM)
        {
            position = QVector3D(0, -1*zoom, 0);
            target   = QVector3D(0, 0, 0);
            up       = QVector3D(0, 0, 1);

            lookAtMatrix.lookAt(position, target,up);
        }

        QMatrix4x4 PV = orthoProjection * lookAtMatrix;

        return PV;
    }


    QVector2D toScreen(QMatrix4x4 viewProjectionMatrix,const QVector3D &coordinate) const
    {
        QVector3D projected = viewProjectionMatrix.map(coordinate);

        QVector2D c(viewRect.width() * 0.5, viewRect.height() * 0.5);

        return c + c * projected.toVector2D() * QVector2D(1, -1);
    }
    QRectF toScreenRect(QMatrix4x4 projectionMatrix,QMatrix4x4 viewMatrix,const QVector<QVector3D> &coordinates) const
    {
        QVector<QVector3D> mapped;

        for (int i = 0; i < coordinates.size(); ++i)
            mapped << viewMatrix.map(coordinates.at(i));

        qreal zClip = -zNear;

        QVector<QVector3D> clipped;

        for (int i = 0; i < mapped.size(); ++i)
        {
            const QVector3D &a = mapped.at(i);
            const QVector3D &b = mapped.at((i + 1) % mapped.size());

            bool aOut = a.z() > zClip;
            bool bOut = b.z() > zClip;

            if (aOut && bOut)
                continue;

            if (!aOut && !bOut) {
                clipped << b;
                continue;
            }

            qreal t = (zClip - a.z()) / (b.z() - a.z());
            QVector3D intersection = a + t * (b - a);

            clipped << intersection;

            if (!bOut)
                clipped << b;
        }

        QRectF bounds;

        QVector2D c(viewRect.width() * 0.5, viewRect.height() * 0.5);

        for (int i = 0; i < clipped.size(); ++i)
        {
            QVector2D projected = c + c * projectionMatrix.map(clipped.at(i)).toVector2D() * QVector2D(1, -1);
            bounds = bounds.united(QRectF(projected.toPointF(), QSizeF(0.01, 0.01)));
        }

        bounds = bounds.intersected(QRectF(0, 0, viewRect.width(), viewRect.height()));

        return bounds;
    }

    QVector3D getWorldCoordinateFromScreen( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 0.9;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );

        GLdouble hx = 0, hy = 0, hz = 0;

        gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &hx, &hy, &hz );

        QVector3D worldPos(hx,hy,hz);

        return worldPos;
    }
    QVector3D getScreenCoordinateFromWorld(QVector3D worldPos)
    {
        double modelview[16], projection[16];

        int viewports[4];

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewports );

        GLdouble x,y,z;

        gluProject( worldPos.x(), worldPos.y(), worldPos.z(), modelview, projection, viewports, &x, &y, &z );

        QVector3D hitpoint(x,y,z);

        return hitpoint;

    }


    QPoint project(QVector3D position,QMatrix4x4 mainModelView)
    {
        position =  mainModelView * position;

        qreal winX = viewRect.width() * (position.x() + 1) / 2;

        qreal winY = viewRect.height() - viewRect.height() * (position.y() + 1) / 2;

        return QPoint((int)winX, (int)winY);
    }

    QVector3D unProject(int x, int y,QMatrix4x4 mainModelView)
    {

        // project click down to plane
        // about the mathematics: http://www.opengl.org/sdk/docs/man/xhtml/gluUnProject.xml
        // mainModelView should be our modelview projection matrix

        QMatrix4x4 inv = mainModelView.inverted();

        qreal coordx = 2 * (qreal) x / (qreal) viewRect.width() - 1;
        qreal coordy = 2 * (qreal) (viewRect.height() - y) / (qreal) viewRect.height() - 1;

        QVector4D nearPoint4 = inv * QVector4D(coordx, coordy, -1, 1); // winZ = 2 * 0 - 1 = -1
        QVector4D farPoint4  = inv * QVector4D(coordx, coordy, 1, 1); // win> = 2 * 1 - 1 = 1

        if(nearPoint4.w() == 0.0)
        {
            return QVector3D();
        }
        qreal w = 1.0/nearPoint4.w();

        QVector3D nearPoint = QVector3D(nearPoint4);

        nearPoint *= w;

        w = 1.0/farPoint4.w();

        QVector3D farPoint = QVector3D(farPoint4);

        farPoint *= w;

        QVector3D dir = farPoint - nearPoint;

        if (dir.z()==0.0) // if we are looking in a flat direction we won't hit the ground
            return QVector3D(0,0,0);

        qreal t = - nearPoint.z() / dir.z(); // how long it is to the ground

        QVector3D cursor = nearPoint + dir * t;

        return cursor;
    }


    virtual void drawSafeTitleRectangle(QGLWidget * widget)
    {

        float s = .75;


        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);

        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    virtual void drawSafeActionRectangle(QGLWidget * widget)
    {
        float s = .85f;


        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);


        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }



    virtual void resizeViewPort(QRectF rect)
    {
        viewRect    =  rect;

        aspectRatio = (GLfloat) viewRect.width() /(GLfloat) viewRect.height() ;

        archball->setBounds(viewRect.width(),viewRect.height());
    }

    virtual void keyPressEvent(QKeyEvent * event)
    {
        switch(event->key())
        {
        case Qt::Key_1:
            cameraMode = (FRONT);
            break;

        case Qt::Key_2:
            cameraMode =(BOTTOM);
            break;

        case Qt::Key_3:
            cameraMode =(FRONT);

            break;

        case Qt::Key_4:
           cameraMode=(BACK);
            break;

        case Qt::Key_5:
           cameraMode=(LEFT);
            break;

        case Qt::Key_6:
            cameraMode=(RIGHT);
            break;

        case Qt::Key_7:
            cameraMode=(ORTHO);
            break;

        case Qt::Key_8:
            cameraMode=(PERSPECTIVE);
            break;
        }
    }


    virtual void mousePressEvent(QMouseEvent * event)
    {
        QPoint p =  event->pos();

        lastPos = p;

        archball->mousePressEvent(event);
    }

    virtual void mouseMoveEvent(QMouseEvent * event)
    {
        if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::LeftButton)
        {
            //trackball(event);
            rotate(event);  //or use trackball(event);
        }

        else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::MidButton)
        {
            pan(event);
        }

        else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::RightButton)
        {
            zoom(event);
        }
     }

    virtual void mouseReleaseEvent(QMouseEvent * event)
    {

    }




    virtual void rotate(QMouseEvent * event)
    {
        QPoint p = event->pos();

        QPoint delta = p - lastPos;

        rotation += QVector3D(-delta.y(),-delta.x(),0);

        QMatrix4x4 mat;

        mat.setToIdentity();

        mat.rotate(-delta.x(),QVector3D(0,1,0));
        mat.rotate(-delta.y(),QVector3D(1,0,0));

        key.position =  mat * key.position;
        //key.up       =  mat * key.up;
        //key.forward  =  mat * key.forward;
        //key.right    =  mat * key.right;

        bool turnTable = true;

        if(turnTable)
        {
            //up  =  preset.up;

            float heading  =  delta.x();

            float rads =  PI/180.0;

            qDebug()<<"heading:"<<heading*rads;


            /*


            float value = cos(heading * rads) > 0 ? 1.0 : -1.0;


            qDebug()<<"New UP:"<<value;

            preset.up = QVector3D(0,1*value,0);
            */

        }
        else
        {
            key.up      = mat * key.up;

            key.forward = key.position - key.target;

            key.forward.normalize();

            key.right = QVector3D::crossProduct(forward,key.up);


        }

        up        = key.up;
        target    = key.target;
        position  = key.position;
        right     = key.right;
        forward   = key.forward;

        lastPos =  p;

        emit valueChanged();
    }

    virtual void trackball(QMouseEvent * event)
    {

        archball->mouseMoveEvent(event);

        archball->computeRotationMatrix();

        key.position = archball->newRotationMatrix * key.position;


        emit valueChanged();
    }

    virtual void pan(QMouseEvent * event)
    {
        QPoint p = event->pos();

        QPoint delta = p - lastPos;

        QVector3D dir1 = position - target;

        dir1.normalize();

        QVector3D normal = QVector3D::crossProduct(QVector3D(0,1,0),dir1);

        QVector3D nUp = QVector3D::crossProduct(normal,dir1);

        normal *= (-delta.x()*panscale);
        nUp    *= (-delta.y()*panscale);

        position += normal;
        position += nUp;

        target   += normal;
        target   += nUp;

        key.position    =  position;
        key.target =  target;
        key.up = up;

        lastPos =  p;

        emit valueChanged();
    }



    virtual void zoom(QMouseEvent * event)
    {
        QPoint p       = event->pos();
        QPoint delta   = p - lastPos;
        QVector3D dir1 = position - target;

        dir1.normalize();

        position += dir1 * -delta.x();
        target   += dir1 * -delta.x();

        lastPos       =  p;
        key.position    =  position;
        key.target =  target;
        key.up     =  up;

        emit valueChanged();

    }

    virtual void zoom(QWheelEvent * event)
    {
        float scaleDelta = 0.05f;
        QVector3D dir1 = position - target;

        dir1.normalize();

        qreal factor = qPow(1.2, event->delta() / 240.0);

        if(event->delta() <0)
            factor *= -1;

        dir1   *= factor * zoomscale ;

        position += dir1;
        target   += dir1 ;

        key.position    =  position;
        key.target =  target;
        key.up = up;
        lastPos  =  event->pos();

        emit valueChanged();
    }

signals:

    void valueChanged();

public slots:

    void updateCameraParameters()
    {
        parameters = new CameraParameters;

        zNear = parameters->zNear;
        zFar  = parameters->zFar;
        fov   = parameters->fov ;

        emit valueChanged();
    }

    void centerToModel(QBaseModel * model)
    {
        QVector3D dir =  position - target;

        dir.normalize();

        QVector3D center(0,0,0);

        foreach(QVector3D c, model->vertices)
        {
            center += c;
        }

        center /= model->vertices.size();

        float length  =  dir.length();

        if(model->boundingSphere.radius()<length)
        {

        }
        else if(model->boundingSphere.radius()>length)
        {

        }

        position = dir * model->boundingSphere.radius();

        target  = center;
    }
};


class QMeshModel: public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_MESH};

    int type() const  { return Type; }


    QColor color;


    QMeshModel( QObject * parent = 0 ) : QBaseModel(parent)
    {
        color = QColor(120, 200, 200);

        name  = QString("Mesh Model");

        clearMeshModel();

        addWidgets();
     }


    //This is for duplication of the QMeshModel
    QMeshModel( QMeshModel * model,QObject * parent = 0 ) : QBaseModel(parent)
    {
        color = QColor(120, 200, 200);
        name  = QString("Mesh Model");

        clearMeshModel();

        position = model->position;
        scale    = model->scale;
        rotation = model->rotation;

        for(int i=0;i<model->vertices.size();i++)
        {
            vertices.append(model->vertices[i]);
        }

        for(int i=0;i<model->normals.size();i++)
        {
            normals.append(model->normals[i]);
        }

        for(int i=0;i<model->texcoords.size();i++)
        {
            texcoords.append(model->texcoords[i]);
        }

        for(int i=0;i<model->indices.size();i++)
        {
            indices.append(model->indices[i]);
        }

        for(int i=0;i<model->edges.size();i++)
        {
            edges.append(model->edges[i]);
        }

        computeBounds();

        addWidgets();

     }


     ~QMeshModel()
     {
        delete properties;
     }

    void clearMeshModel()
    {        
        vertices.clear();
        normals.clear();
        texcoords.clear();
        indices.clear();
        edges.clear();
    }

signals:

public slots:

     virtual void centerMesh()
     {
         QVector3D center(0,0,0);

         QAabb box;

         for(int i=0;i<vertices.size();i++)
         {
             center += vertices[i];

             box.expand(vertices[i]);
         }

         center /= vertices.size();

         for(int i=0;i<vertices.size();i++)
         {
             vertices[i] -= center;
         }
     }
};

class QTerrainModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float width;
    float length;

    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));

        properties->addPropertyPanel(parameters->getWidget());
        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_TERRAIN};


    int type() const  { return Type; }


    PlaneParameters * parameters;

    QTerrainModel(QObject * parent =0) : QBaseModel(parent)
    {
        parameters = new PlaneParameters;

        usteps = 4;
        vsteps = 4;

        width  = 1;
        length = 1;

        parameters->usteps = usteps;
        parameters->vsteps = vsteps;
        parameters->width  = width ;
        parameters->length = length;

        name = QString("Terrain Model");

        n_grid(width,length,usteps,vsteps);

        connect(parameters,SIGNAL(valueChanged(double)),this,SLOT(updateGrid()));

        addWidgets();
    }

    ~QTerrainModel()
    {
        delete properties;
        delete parameters;
    }




    void n_grid(int width,int length, int u_steps,int v_steps)
    {
        QList< QPair<int,int> > tuples;

        vertices.clear();
        indices.clear();
        normals.clear();
        edges.clear();


        if(width<0){ width = 0;  }
        if(length<0){ length = 0; }

        if(u_steps<1){u_steps = 1;}
        if(v_steps<1){v_steps = 1;}

        QVector3D normal(0,1,0);

        float step_u = (float)width / u_steps;

        float step_v = (float)length / v_steps;

        for( int i=0;i<(u_steps + 1);i++)
        {
            //#pragma omp parallel for
            for(int j=0; j<(v_steps + 1);j++)
            {
                float x = i * step_u;

                float z = j * step_v;

                float y = 0;

                QVector3D p = QVector3D(x , y , z );

                tuples.append(QPair<int,int>(i, j));

                vertices.append(p);

                normals.append(normal);

            }
        }

        //#pragma omp parallel for
        for(int i=0;i<u_steps;i++)
        {
            //#pragma omp parallel for
            for(int j =0;j<v_steps;j++)
            {
                int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                indices.append(index_0);
                indices.append(index_1);
                indices.append(index_2);
                indices.append(index_3);

                //---latitude--rings----
                edges.append(index_0);
                edges.append(index_1);

                //---longitude--rings-------
                edges.append(index_1);
                edges.append(index_2);

                //m_edgeIndices.append(index_2);
                //m_edgeIndices.append(index_3);
                //m_edgeIndices.append(index_3);
                //m_edgeIndices.append(index_0);
            }
        }

        computeNormals();

        computeBounds();
    }

signals:

    void valueChanged();


private slots:

    void updateGrid()
    {
        usteps = parameters->usteps;
        vsteps = parameters->vsteps;
        width  = parameters->width;
        length = parameters->length;

        n_grid(width,length,usteps,vsteps);

        qDebug()<<"Parameters Changed \n";

        emit valueChanged();
    }
};

class QSplineModel : public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:


    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());
        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_SPLINE};

    int type() const  { return Type; }


    QSplineModel(QObject * parent =0) : QBaseModel(parent)
    {
        vertices.clear();

        name = QString("Spline Model");

        updateSpline();

        addWidgets();

    }

    ~QSplineModel()
    {
        delete properties;
    }

    void interpolate(float r1,float r2,int divisions)
    {
        float r = r2-r1;

        float step_r =  r/divisions;

    }

signals:

    void valueChanged(double value);

private slots:

    void updateSpline()
    {

    }
};

class QParticlesModel : public QBaseModel
{
    Q_OBJECT

    QPropertiesTreeWidget *properties;

public:

    QPropertiesTreeWidget * getWidget()
    {
        return properties;
    }

    void addWidgets()
    {
        properties = new QPropertiesTreeWidget;

        properties->addPropertyPanel(transformParameters->getWidget());

        properties->addPropertyPanel(visibilityParameters->getWidget());

        setTheme(properties);
        properties->hide();
    }

    enum { Type = MODEL_PARTICLES};

    int type() const  { return Type; }

    //QList<ParticleSystem*> particlessystems;

    //ParticleSystem *ps;

    QParticlesModel(QObject * parent =0) : QBaseModel(parent)
    {
        //ps = new ParticleSystem;

        //m_points.clear();

        name = QString("Particles Model");

        addWidgets();


    }

    ~QParticlesModel()
    {
        delete properties;
    }
};


/*
class QMetropolisItemModel : public QAbstractItemModel
{
    Q_OBJECT

    QBaseModel *nodeFromIndex(const QModelIndex &index) const
    {
        if (index.isValid())
        {
            return static_cast<QBaseModel *>(index.internalPointer());
        }
        else
        {
            return rootModel;
        }
    }

    QBaseModel *rootModel;

public:
    QMetropolisItemModel(QObject *parent = 0):QAbstractItemModel(parent)
    {
        rootModel = 0;

    }

    ~QMetropolisItemModel()
    {
        delete rootModel;
    }

    void setRootModel(QBaseModel *model)
    {
        delete rootModel;

        rootModel = model;

        reset();

    }

    QModelIndex index(int row, int column,const QModelIndex &parent) const
    {
        if (!rootModel || row < 0 || column < 0)
                return QModelIndex();

        QBaseModel *parentModel = nodeFromIndex(parent);

        QBaseModel *childModel = parentModel->children.value(row);

        if (!childModel)
            return QModelIndex();

        return createIndex(row, column, childModel);
    }


    QModelIndex parent(const QModelIndex &child) const
    {
        QBaseModel *node = nodeFromIndex(child);


        if (!node)
            return QModelIndex();

        QBaseModel *parentModel = node->parent;

        if (!parentModel)
            return QModelIndex();


        QBaseModel *grandparentModel = parentModel->parent;

        if (!grandparentModel)
            return QModelIndex();


        int row = grandparentModel->children.indexOf(parentModel);


        return createIndex(row, 0, parentModel);
    }

    int rowCount(const QModelIndex &parent) const
    {
        if (parent.column() > 0)
                return 0;

        QBaseModel *parentNode = nodeFromIndex(parent);

        if (!parentNode)
            return 0;

        return parentNode->children.count();
    }

    int columnCount(const QModelIndex &parent) const
    {
        return 2;
    }


    QVariant data(const QModelIndex &index, int role) const
    {
        if (role != Qt::DisplayRole)
            return QVariant();


        QBaseModel *model = nodeFromIndex(index);

        if (!model)
                return QVariant();


        if (index.column() == 0)
        {
            switch (model->type())
            {
                case MODEL_CONE:
                     return QString("Cone")+QString::number(model->ID);
                case MODEL_CUBE:
                    return QString("Cube")+QString::number(model->ID);
                case MODEL_DONUT:
                    return QString("Torus")+QString::number(model->ID);
                case MODEL_CAMERA_FREE:
                    return QString("Camera Free")+QString::number(model->ID);
                case MODEL_CAMERA_TARGET:
                    return QString("Camera Target")+QString::number(model->ID);
                case MODEL_CYLINDER:
                    return QString("Cylinder")+QString::number(model->ID);
                case MODEL_LIGHT:
                    return QString("Light")+QString::number(model->ID);
                case MODEL_MESH:
                    return QString("Mesh")+QString::number(model->ID);
                case MODEL_PARTICLES:
                    return QString("Particles")+QString::number(model->ID);
                case MODEL_QUAD:
                    return QString("Quad")+QString::number(model->ID);
                case MODEL_PLANE:
                    return QString("Plane")+QString::number(model->ID);
                case MODEL_GRID:
                    return QString("Grid")+QString::number(model->ID);
                case MODEL_SPHERE:
                    return QString("Sphere")+QString::number(model->ID);
                case MODEL_TERRAIN:
                    return QString("Terrain")+QString::number(model->ID);

                default:
                    return tr("Unknown");
                }

        }
        else if (index.column() == 1)
        {
            return model->getName();
        }


        return QVariant();
    }


    QVariant headerData(int section, Qt::Orientation orientation,
                        int role) const

    {
        if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        {
            if (section == 0)
            {
                return tr("Property");
            }
            else if (section == 1)
            {
                return tr("Value");
            }

        }

        return QVariant();
    }
};

*/


#endif // MODELS

