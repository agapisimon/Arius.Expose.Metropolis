 #ifndef CUSTOMNWIDGETS_H
#define CUSTOMNWIDGETS_H
#include<QtWidgets>



#include<typeinfo>


enum FRAME_RATES
{
    FPS_24 = 24,
    FPS_25 = 25,
    FPS_30 = 30,
    FPS_60 = 60,
    FPS_90 = 90,

    FPS_REALTIME,
    FPS_CUSTOMN,
};

class About : public QWidget
{
    Q_OBJECT

public:

    About(QWidget *parent = 0)
    {
        setWindowTitle(QString("About Metropolis"));
        setWindowIcon(QIcon(":/icons/metropolis.svg"));

        //QSplashScreen *logo = new QSplashScreen;
        //logo->setPixmap(QPixmap(":/icons/metropolis.svg"));

        //QSplashScreen *splash = new QSplashScreen;
        //splash->setPixmap(QPixmap(":/Resources/metropolis.png"));

        QLabel *logoLabel = new QLabel(this);
        logoLabel->setPixmap( QPixmap(":/icons/metropolis.svg"));

        QLabel *imageLabel = new QLabel(this);
        imageLabel->setPixmap( QPixmap(":/Resources/metropolis.png") );

        setFixedSize(900,400);

        QFont font;
        font.setBold(true);
        font.setPointSize(40);


        QLabel * title = new QLabel(QString("Metropolis"));
        title->setFont(font);

        QLabel *developer  = new QLabel(QString("Developer: Agapi Simon"));
        QLabel *appstr     = new QLabel(QString("Application: Metropolis"));
        QLabel *strVersion = new QLabel(QString("Version: 0.5"));
        QLabel *copystr    = new QLabel(QString("Copyright � ")+QString::number(2016));
        QLabel *emailstr   = new QLabel(QString("Email: mittisimone@gmail.com"));


        QFormLayout * h = new QFormLayout;

        h->addWidget(logoLabel);
        h->addWidget(title);
        h->addWidget(imageLabel);

        h->addWidget(developer);
        h->addWidget(appstr);
        h->addWidget(strVersion);
        h->addWidget(copystr);
        h->addWidget(emailstr);

        setLayout(h);

        QFile file(":/icons/glowBlue.stylesheet");

       // QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }
    }

    void mousePressEvent(QMouseEvent * event)
    {
        if(event->buttons()&Qt::RightButton)
        {
            this->hide();
        }
    }


public slots:

    void closeAbout()
    {
        this->showNormal();
    }
};

class LineEdit : public QLineEdit
{
    Q_OBJECT

    Q_PROPERTY( int animation READ getAnimation WRITE setAnimation)
    Q_PROPERTY(bool dirty READ getDirty WRITE setDirty)

public:

    LineEdit(QWidget* parent = 0): QLineEdit(parent)
    {
        animation=(0);
        dirty=(false);
        setAttribute(Qt::WA_MacShowFocusRect,0);
        connect( this, SIGNAL( editingFinished() ), this, SLOT( onEditingFinished() ) );
    }

    virtual ~LineEdit()
    {

    }

    int getAnimation() const
    {
        return animation;
    }

    void setAnimation(int v)
    {
        animation = v;
        style()->unpolish(this);
        style()->polish(this);
        repaint();

    }

    bool getDirty() const
    {
        return dirty;
    }

    void setDirty(bool b)
    {
        dirty = b;
        style()->unpolish(this);
        style()->polish(this);
        repaint();
    }

signals:

    void textDropped();

    void textPasted();



public slots:

    void onEditingFinished()
    {
         clearFocus();
    }

private:
    virtual void paintEvent(QPaintEvent* e)
    {
        QPalette p = this->palette();
        QColor c(200,200,200,255);

        p.setColor( QPalette::Highlight, c );
        p.setColor( QPalette::HighlightedText, c );
        this->setPalette( p );
        QLineEdit::paintEvent(e);
    }

    virtual void dropEvent(QDropEvent* e)
    {
        if ( !e->mimeData()->hasUrls() ) {
            return;
        }

        QList<QUrl> urls = e->mimeData()->urls();
        QString path;
        if (urls.size() > 0) {
            path = urls.at(0).path();
        }
        if ( !path.isEmpty() ) {
            setText(path);
            emit textDropped();
        }

    }

    virtual void dragEnterEvent(QDragEnterEvent* e)
    {
        e->accept();
    }

    virtual void dragMoveEvent(QDragMoveEvent* e)
    {
        e->accept();

    }

    virtual void dragLeaveEvent(QDragLeaveEvent* e)
    {
         e->accept();
    }

    virtual void keyPressEvent(QKeyEvent* e)
    {
        QLineEdit::keyPressEvent(e);

        if (e->matches(QKeySequence::Paste))
        {
            emit textPasted();
        }

    }

    int animation;
    bool dirty;
};

class QFloatSlider  : public QSlider
{
    Q_OBJECT

    float scale;

public:

    QFloatSlider(Qt::Orientation orientation, QWidget* parent = 0):QSlider(orientation, parent)
    {
        scale = 1.0f;
    }

    void setScale(float scale)
    {
        this->scale = scale;
    }

    void setSingleStep(float step)
    {
        this->scale = step;

        setMaximum(this->maximum()/step);
        setMinimum(this->minimum()/step);


    }

    void sliderChange(SliderChange change)
    {
        if(change==QAbstractSlider::SliderValueChange)
        {
             emit valueChanged(value()*scale);
        }
        //for completeness. Also, one could send integer and float signals
        //if desired.
        QSlider::sliderChange(change);
    }

signals:
    void valueChanged(float value);

public slots:

    void setValue(float value)
    {
        QSlider::setValue(value/scale);
    }
};

class QDoubleSlider : public QSlider
{
    Q_OBJECT

    double _scale;

public:
    QDoubleSlider(Qt::Orientation orientation, QWidget* parent = 0):QSlider(orientation, parent)
    {
        _scale =1.0f;
    }

    void setScale(double scale)
    {
        _scale = scale;
    }

    void setSingleStep(double step)
    {
        _scale=step;

        setMaximum(this->maximum()/step);
        setMinimum(this->minimum()/step);
    }

    void sliderChange(SliderChange change)
    {
        if(change==QAbstractSlider::SliderValueChange)
        {
             emit valueChanged(value()*_scale);
        }
        //for completeness. Also, one could send integer and float signals
        //if desired.
        QSlider::sliderChange(change);
    }
signals:
    void valueChanged(double value);


public slots:

    void setValue(double value)
    {
        QSlider::setValue(value/_scale);
    }
};

class QFloatWidget  : public QWidget
{
    Q_OBJECT

    QDoubleSlider * slider;
    QDoubleSpinBox * spinbox;

    QLabel * label;



public:

    void setText(QString name)
    {
        label->setText(name);
    }

    float getValue()
    {
        return spinbox->value();
    }

    void setMinMaxValue(float min,float max,float value,float step=0.01)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

        spinbox->setMinimum(min);
        spinbox->setMaximum(max);
        spinbox->setValue(value);
        spinbox->setSingleStep(step);


    }


    QFloatWidget(QWidget * parent =0):QWidget(parent)
    {
         QHBoxLayout  *layout  = new QHBoxLayout;

         slider   =  new QDoubleSlider(Qt::Horizontal);
         spinbox  =  new QDoubleSpinBox;

         label = new QLabel("Float Variable:");

         setMinMaxValue(0,10,1,0.1);


         layout->addWidget(label);
         layout->addWidget(spinbox);
         layout->addWidget(slider);


         setLayout(layout);

         connect(slider,SIGNAL(valueChanged(double)),this,SLOT(setSpinBoxValue()));
         connect(spinbox,SIGNAL(valueChanged(double)),this,SLOT(setSliderValue()));


    }

signals:
    void valueChanged(double value);

public slots:

    void setSliderValue()
    {

        slider->setValue(spinbox->value());

        emit valueChanged(spinbox->value());
    }


    void setSpinBoxValue()
    {

        spinbox->setValue(slider->value());

        emit valueChanged(slider->value());
    }


};

class QDoubleWidget : public QWidget
{
    Q_OBJECT

    QDoubleSlider * slider;

    QDoubleSpinBox * spinbox;

    QLabel * label;

public:

    double getValue()
    {
        return spinbox->value();
    }

    void setMinMaxValue(double min,double max,double value,double step /* any value below 1 wont update*/)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

        spinbox->setMinimum(min);
        spinbox->setMaximum(max);
        spinbox->setValue(value);
        spinbox->setSingleStep(step);
    }

    void setText(QString name)
    {
        label->setText(name);
    }


    QDoubleWidget(QWidget * parent =0):QWidget(parent)
    {
        QHBoxLayout  *layout  = new QHBoxLayout;

         slider   = new QDoubleSlider(Qt::Horizontal);
         spinbox =  new QDoubleSpinBox;         
         setMinMaxValue(0,10,1,0.1);

         label = new QLabel("Double Variable:");

         layout->addWidget(label);
         layout->addWidget(slider);
         layout->addWidget(spinbox);




         setLayout(layout);

         connect(slider,SIGNAL(valueChanged(double)),this,SLOT(setSpinBoxValue()));
         connect(spinbox,SIGNAL(valueChanged(double)),this,SLOT(setSliderValue()));
    }

signals:

    void valueChanged(double value);

public slots:

    void setSliderValue()
    {
        //qDebug()<<"Value changed:"<<spinbox->value();
        slider->setValue(spinbox->value());

        emit valueChanged(spinbox->value());
    }

    void setSpinBoxValue()
    {
        //qDebug()<<"Value changed:"<<slider->value();
        spinbox->setValue(slider->value());

        emit valueChanged(slider->value());
    }
};

class QIntWidget    : public QWidget
{
    Q_OBJECT

    QSlider * slider;
    QSpinBox * spinbox;
    QLabel * label;

public:


    void setText(QString name)
    {
        label->setText(name);
    }


    int getValue()
    {
        return spinbox->value();
    }

    void setMinMaxValue(int min,int max,int value,int step)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

        spinbox->setMinimum(min);
        spinbox->setMaximum(max);
        spinbox->setValue(value);
        spinbox->setSingleStep(step);
    }

    QIntWidget(QWidget * parent =0):QWidget(parent)
    {

        QHBoxLayout  *layout  = new QHBoxLayout;

        slider   = new QSlider(Qt::Horizontal);

        spinbox  = new QSpinBox;

        label    = new QLabel("Int Variable:");


        layout->addWidget(label);
        layout->addWidget(slider);
        layout->addWidget(spinbox);

        setLayout(layout);
        connect(slider,SIGNAL(valueChanged(int)),this,SLOT(setSpinBoxValue()));
        connect(spinbox,SIGNAL(valueChanged(int)),this,SLOT(setSliderValue()));
    }

signals:

    void valueChanged(int value);

private slots:

    void setSliderValue()
    {
        slider->setValue(spinbox->value());

        //qDebug()<<"Value changed:"<<slider->value();

        emit valueChanged(slider->value());
    }

    void setSpinBoxValue()
    {

        spinbox->setValue(slider->value());

        //qDebug()<<"Value changed:"<<spinbox->value();


        emit valueChanged(spinbox->value());
    }
};

class QStringWidget : public QWidget
{
    Q_OBJECT

    QLineEdit * lineEdit;

public:

    QString getValue()
    {
        return lineEdit->text();
    }

    void setString(QString string)
    {
        lineEdit->setText(string);
    }

    QStringWidget(QWidget * parent =0):QWidget(parent)
    {
         setGeometry(0,0,200,100);
         QHBoxLayout  *layout  = new QHBoxLayout;

         lineEdit  = new QLineEdit;
         layout->addWidget(lineEdit);

         setLayout(layout);

         //connect(str,SIGNAL(textChanged(QString)),this,SLOT(setSpinBoxValue()));
      }

private slots:

    void setText(QString string)
    {
        lineEdit->setText(string);
    }
};

class QBoolWidget   : public QWidget
{
    Q_OBJECT
    QCheckBox *checkbox;

    QLabel * label;
public:

    bool getValue()
    {
        return checkbox->isChecked();
    }


    void setText(QString name)
    {
        label->setText(name);
    }

    QBoolWidget(QWidget * parent =0):QWidget(parent)
    {
        checkbox = new QCheckBox;

        label  = new QLabel;

        QHBoxLayout * layout = new QHBoxLayout;

        layout->addWidget(label);

        layout->addWidget(checkbox);

        setLayout(layout);

        connect(checkbox,SIGNAL(toggled(bool)),this,SLOT(setValue(bool)));
    }

signals:
    void valueChanged(bool value);

public slots:

    void setValue(bool value)
    {
        checkbox->setEnabled(value);

        emit valueChanged(value);
    }
};

class QColorWidget  : public QFrame
{
    Q_OBJECT


    QColor color;

    QMenu * colorPresetsMenu;

public:

    QGradientStop  stop;

    qreal dt;

    QColor  getColor()
    {
        return color;
    }

    QColorWidget(QWidget * parent =0):QFrame(parent)
    {
        setFixedSize(QSize(40,25));

        color  = QColor(0,0,0,255);

        colorPresetsMenu  = new QMenu;
    }

    void paintEvent(QPaintEvent *event)
    {
        QPainter *painter = new QPainter;

        painter->begin(this);

        QBrush b(color);

        QString str = QString("Color:")+QString("R:")+QString::number(color.red())
                +QString(",")+QString("G:")+QString::number(color.green())
                +QString(",")+QString("B:")+QString::number(color.blue());

        setToolTip(str);

        painter->setBrush(b);

        painter->drawRect(rect());

        painter->end();

        update();
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {


    }


    void mouseDoubleClickEvent(QMouseEvent *event)
    {
         color =  QColorDialog::getColor(color);

         stop.second =  color;

         if(color.isValid())
         {
             stop.second =  color;

             emit valueChanged(color);
         }

       QWidget::mouseDoubleClickEvent(event);
    }

signals:
    void valueChanged(QColor color);


public slots:

    void setColor(QColor newColor)
    {
        this->color  =  newColor;
    }
};

class QColorEditorWidget: public QWidget
{
    Q_OBJECT

    QColor color;
    QLabel * label;

    QSpinBox *RSpinner;
    QSpinBox *GSpinner;
    QSpinBox *BSpinner;
    QSpinBox *ASpinner;

    QColorWidget * colorWidget;

    QString name;

public:

    void setColor(QColor newColor)
    {
        this->color  = newColor;

        RSpinner->setValue(color.red());
        GSpinner->setValue(color.green());
        BSpinner->setValue(color.blue());
        ASpinner->setValue(color.alpha());
        colorWidget->setColor(color);

        emit valueChanged(newColor);

    }

    QColor  getColor()
    {
        return color;
    }

    void setText(QString _name)
    {
        name = _name;

        label->setText(_name);
    }


    QColorEditorWidget(QWidget * parent =0):QWidget(parent)
    {
        setGeometry(0,0,150,100);

        colorWidget = new QColorWidget;
        RSpinner = new QSpinBox ;
        GSpinner = new QSpinBox ;
        BSpinner = new QSpinBox ;
        ASpinner = new QSpinBox ;
        label  = new QLabel(QString("Color:"));


        RSpinner->setRange(0,255);
        GSpinner->setRange(0,255);
        BSpinner->setRange(0,255);
        ASpinner->setRange(0,255);

        color  = QColor(0,0,0,255);

        RSpinner->setValue(color.red());
        GSpinner->setValue(color.green());
        BSpinner->setValue(color.blue());
        ASpinner->setValue(color.alpha());

        connect(RSpinner,SIGNAL(valueChanged(int)),this,SLOT(setRValue()));
        connect(GSpinner,SIGNAL(valueChanged(int)),this,SLOT(setGValue()));
        connect(BSpinner,SIGNAL(valueChanged(int)),this,SLOT(setBValue()));
        connect(ASpinner,SIGNAL(valueChanged(int)),this,SLOT(setAValue()));
        connect(colorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setRGBA()));

        QHBoxLayout * layout =  new QHBoxLayout;

        layout->addWidget(label);
        layout->addWidget(colorWidget);
        layout->addWidget(new QLabel("R:"));
        layout->addWidget(RSpinner);
        layout->addWidget(new QLabel("G:"));
        layout->addWidget(GSpinner);
        layout->addWidget(new QLabel("B:"));
        layout->addWidget(BSpinner);
        layout->addWidget(new QLabel("A:"));
        layout->addWidget(ASpinner);


        setLayout(layout);
    }

signals:
    void valueChanged(QColor);

public slots:

    void setRValue()
    {
        color.setRed(RSpinner->value());
        colorWidget->setColor(color);
        emit  valueChanged(color);

    }
    void setGValue()
    {
        color.setGreen(GSpinner->value());
        colorWidget->setColor(color);
        emit  valueChanged(color);

    }
    void setBValue()
    {
        color.setBlue(BSpinner->value());
        colorWidget->setColor(color);
        emit  valueChanged(color);

    }
    void setAValue()
    {
        color.setAlpha(ASpinner->value());
        colorWidget->setColor(color);
        emit  valueChanged(color);

    }

    void setRGBA()
    {
        color  = colorWidget->getColor();       

        RSpinner->setValue(color.red());
        GSpinner->setValue(color.green());
        BSpinner->setValue(color.blue());
        ASpinner->setValue(color.alpha());

        emit  valueChanged(color);
    }
};

/*
class QColorWheel : public QWidget
{
    Q_OBJECT

public:
    QImage m_image;

    QColor m_color;

    QSize m_initialSize;

    QPoint m_lastPoint;

    int m_margin;
    int m_sliderWidth;

    QRegion m_wheelRegion;
    QRegion m_sliderRegion;

    bool m_isInWheel;
    bool m_isInSquare;
    bool m_isMouseDown;

    QColorWheel(QWidget *parent =0): QWidget(parent)
    {
        m_initialSize = QSize(300,300);
        this->m_isMouseDown = false;
        this->m_margin =5;
        this->m_sliderWidth = 30;

        this->m_color = QColor(Qt::white);
        this->m_isInWheel = false;
        this->m_isInSquare = false;

        resize(m_initialSize);
        setMinimumSize(100,100);
        setMaximumSize(m_initialSize);

        setCursor(Qt::CrossCursor);



    }

    int wheelSize()
    {
        return qMin(width() - m_sliderWidth, height());

    }

    QColor colorForPoint(QPoint & point)
    {
        if (! m_image.valid(point)) return QColor();
            if (m_isInWheel) {
                qreal w = wheelSize();
                qreal xf = qreal(point.x()) / w;
                qreal yf = 1.0 - qreal(point.y()) / w;
                qreal xp = 2.0 * xf - 1.0;
                qreal yp = 2.0 * yf - 1.0;
                qreal rad = qMin(hypot(xp, yp), 1.0);
                qreal theta = qAtan2(yp, xp);
                theta -= 105.0 / 360.0 * 2.0 * M_PI;
                if (theta < 0.0)
                    theta += 2.0 * M_PI;
                qreal hue = (theta * 180.0 / M_PI) / 360.0;
                return QColor::fromHsvF( hue, rad, m_color.valueF() );
            }
            if (m_isInSquare) {
                qreal value = 1.0 - qreal(point.y() - m_margin) / (wheelSize() - m_margin * 2);
                return QColor::fromHsvF( m_color.hueF(), m_color.saturationF(), value);
            }
            return QColor();
    }

    void drawWheel()
    {

        int r = wheelSize();
        QPainter painter(&m_image);
        painter.setRenderHint(QPainter::Antialiasing);
        m_image.fill(0); // transparent

        QConicalGradient conicalGradient;
        conicalGradient.setColorAt(        0.0, Qt::red);
        conicalGradient.setColorAt( 60.0/360.0, Qt::yellow);
        conicalGradient.setColorAt(135.0/360.0, Qt::green);
        conicalGradient.setColorAt(180.0/360.0, Qt::cyan);
        conicalGradient.setColorAt(240.0/360.0, Qt::blue);
        conicalGradient.setColorAt(315.0/360.0, Qt::magenta);
        conicalGradient.setColorAt(        1.0, Qt::red);

        QRadialGradient radialGradient(0.0, 0.0, r/2);
        radialGradient.setColorAt(0.0, Qt::white);
        radialGradient.setColorAt(1.0, Qt::transparent);

        painter.translate(r / 2, r / 2);
        painter.rotate(-105);

        QBrush hueBrush(conicalGradient);
        painter.setPen(Qt::NoPen);
        painter.setBrush(hueBrush);
        painter.drawEllipse(QPoint(0, 0), r/2-m_margin, r/2-m_margin);

        QBrush saturationBrush(radialGradient);
        painter.setBrush(saturationBrush);
        painter.drawEllipse(QPoint(0, 0), r/2-m_margin, r/2-m_margin);

        m_wheelRegion = QRegion(r/2, r/2, r-2*m_margin, r-2*m_margin, QRegion::Ellipse);
        m_wheelRegion.translate(-(r-2*m_margin)/2, -(r-2*m_margin)/2);
    }

    void drawWheelDot(QPainter & painter)
    {
        int r = wheelSize() / 2;
           QPen pen(Qt::white);
           pen.setWidth(2);
           painter.setPen(pen);
           painter.setBrush(Qt::black);
           painter.translate(r, r);
           painter.rotate(360.0 - m_color.hue());
           painter.rotate(-105);
       //    r -= margin;
           painter.drawEllipse(QPointF(m_color.saturationF() * r, 0.0), 4, 4);
           painter.resetTransform();
    }

    void drawSliderBar(QPainter & painter)
    {
        qreal value = 1.0 - m_color.valueF();
           int ws = wheelSize();
           qreal scale = qreal(ws + m_sliderWidth) / maximumWidth();
           int w = m_sliderWidth * scale;
           int h = ws - m_margin * 2;
           QPen pen(Qt::white);
           pen.setWidth(2);
           painter.setPen(pen);
           painter.setBrush(Qt::black);
           painter.translate(ws, m_margin + value * h);
           painter.drawRect(0, 0, w, 4);
           painter.resetTransform();
    }

    void drawSlider()
    {
        QPainter painter(&m_image);
           painter.setRenderHint(QPainter::Antialiasing);
           int ws = wheelSize();
           qreal scale = qreal(ws + m_sliderWidth) / maximumWidth();
           int w = m_sliderWidth * scale;
           int h = ws - m_margin * 2;
           QLinearGradient gradient(0, 0, w, h);
           gradient.setColorAt(0.0, Qt::white);
           gradient.setColorAt(1.0, Qt::black);
           QBrush brush(gradient);
           painter.setPen(Qt::NoPen);
           painter.setBrush(brush);
           painter.translate(ws, m_margin);
           painter.drawRect(0, 0, w, h);
           m_sliderRegion = QRegion(ws, m_margin, w, h);
    }


    QSize sizeHint()
    {
        return QSize(height(),height());
    }

    QSize minimumSizeHint()
    {
        return QSize(100, 100);
    }

    QColor color()
    {
        return m_color;

    }

    void setColor( QColor & color)
    {

        m_color = color;
    }

signals:
    void colorChanged(QColor & color)
    {


    }
public slots:

    void changeColor(QColor & color)
    {
        m_color = color;
            drawWheel();
            drawSlider();
            update();
            emit colorChanged(m_color);

    }

protected:

    void mousePressEvent(QMouseEvent * event)
    {
        m_lastPoint = event->pos();
           if (m_wheelRegion.contains(m_lastPoint)) {
               m_isInWheel = true;
               m_isInSquare = false;
               QColor color = colorForPoint(m_lastPoint);
               changeColor(color);
           } else if (m_sliderRegion.contains(m_lastPoint)) {
               m_isInWheel = false;
               m_isInSquare = true;
               QColor color = colorForPoint(m_lastPoint);
               changeColor(color);
           }
           m_isMouseDown = true;
    }

    void mouseMoveEvent(QMouseEvent * event)
    {
        m_lastPoint = event->pos();
            if (!m_isMouseDown) return;
            if (m_wheelRegion.contains(m_lastPoint) && m_isInWheel) {
                QColor color = colorForPoint(m_lastPoint);
                changeColor(color);
            } else if(m_sliderRegion.contains(m_lastPoint) && m_isInSquare) {
                QColor color = colorForPoint(m_lastPoint);
                changeColor(color);
            }
    }
    void mouseReleaseEvent(QMouseEvent * event)
    {
        Q_UNUSED(event)
            m_isMouseDown = false;
            m_isInWheel = false;
            m_isInSquare = false;
    }

    void resizeEvent(QResizeEvent * event)
    {
        m_image = QImage(event->size(), QImage::Format_ARGB32_Premultiplied);
           m_image.fill(palette().background().color().rgb());

           drawWheel();
           drawSlider();
           update();
    }

    void paintEvent(QPaintEvent * event)
    {
        Q_UNUSED(event)
           QPainter painter(this);
       //    QStyleOption opt;
       //    opt.init(this);
           painter.setRenderHint(QPainter::Antialiasing);
           painter.drawImage(0, 0, m_image);
           drawWheelDot(painter);
           drawSliderBar(painter);
       //    style()->drawPrimitive(QStyle::PE_Widget, &opt, &painter, this);

    }


};
*/

class QRamp : public QWidget
{
    Q_OBJECT

    QLinearGradient gradient;

    QList<QColorWidget*> colorwidgets;

    QRect gradientRect;
    QRect slidersRect;

    QColorWidget *child;
public:
    QLinearGradient  getGradient()
    {
        return gradient;
    }


    void setGradient(QLinearGradient gradient)
    {
        this->gradient  =  gradient;
    }


    QRamp(QWidget * parent=0):QWidget(parent)
    {
        setMinimumWidth(200);
        setMinimumHeight(60);

        gradient.setColorAt(0,	Qt::blue);
        gradient.setColorAt(0.2,Qt::green);
        gradient.setColorAt(0.4,Qt::red);
        gradient.setColorAt(0.75,Qt::yellow);
        gradient.setColorAt(1,Qt::cyan);
        computeGradientRect();

        addstops();
    }


    void computeGradientRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().topRight();

        QPoint p3 = rect().topLeft();
        QPoint p4 = rect().topRight();

        p1 += QPoint(20,0);
        p2 -= QPoint(20,0);
        p2 += QPoint(0,40);

        gradientRect = QRect(p1,p2);

        p3 += QPoint(20,40);
        p4 -= QPoint(20,40);

        p4 += QPoint(0,20);

        slidersRect = QRect(p3,p4);

        gradient.setStart(gradientRect.topLeft());
        gradient.setFinalStop(gradientRect.topRight());
        gradient.setInterpolationMode(QGradient::ColorInterpolation);


    }

    void addstops()
    {
        QGradientStops stops = gradient.stops();

        for(int i = 0;i<stops.count();i++)
        {
            QGradientStop stop= stops[i];

            QColorWidget *colorwidget = new QColorWidget(this);
            colorwidget->setFixedSize(8,8);

            QRect r = QRect(0,0,8,8);



            colorwidget->setFrameRect(r);

            colorwidget->setColor(stop.second);

            colorwidget->stop =  stop;

            float dx = stop.first* slidersRect.width();

            QPoint p = QPoint(dx,0)+slidersRect.topLeft();

            colorwidget->move(p);
            colorwidget->show();

            colorwidgets.append(colorwidget);

        }
    }


    void addStop(QMouseEvent *event)
    {
        if(event->modifiers()==Qt::ControlModifier && event->button()==Qt::LeftButton)
        {
            QPointF p = QPointF(event->pos());

            if(gradientRect.contains(p.x(),p.y(),true))
            {
                float dx = (float)( p.x()- gradientRect.topLeft().x())/ gradientRect.width();

                gradient.setColorAt(dx,Qt::white);

                QGradientStop stop;

                stop.first = dx;
                stop.second = Qt::white;

                addStopSlider(stop);

                emit valueChanged(gradient);

            }
        }
    }

    void addStopSlider(QGradientStop _stop)
    {
        QColorWidget *colorwidget = new QColorWidget(this);

        colorwidget->setFixedSize(8,8);

        //QRect r = QRect(-4,-4,8,8);
        QRect r = QRect(0,0,8,8);

        colorwidget->setFrameRect(r);

        colorwidget->setColor(_stop.second);

        colorwidget->stop =  _stop;

        float dx = _stop.first* slidersRect.width();

        QPoint p = QPoint(dx,0)+slidersRect.topLeft();


        colorwidget->move(p);

        colorwidget->show();

        colorwidgets.append(colorwidget);
    }

    void deleteStope(QMouseEvent *event)
    {
      if(event->modifiers()==Qt::AltModifier && event->button()==Qt::LeftButton)
      {
          //if(QString::fromStdString(typeid(child).name()).endsWith("QColorWidget"))
          //{
              if(child->stop.first = 0)
              {

              }
              else if(child->stop.first==1)
              {

              }
              else
              {
                  colorwidgets.removeAt(colorwidgets.indexOf(child));

                  delete child;


              }
          //}
       }
    }

    void resizeEvent(QResizeEvent *event)
    {
        computeGradientRect();
    }


    void mousePressEvent(QMouseEvent *event)
    {
        getGetColorWidgetAndStop(event);

        deleteStope(event);
        addStop(event);
    }

    void getGetColorWidgetAndStop(QMouseEvent *event)
    {
        //child = static_cast<QColorWidget*>(childAt(event->pos()));

        child = dynamic_cast<QColorWidget*>(childAt(event->pos()));


    }



    void mouseMoveEvent(QMouseEvent *event)
    {
        if(child )
        {
            float dy =  child->pos().y();
            float dx =  event->pos().x();

            QPoint p = QPoint(dx,dy);

            if(slidersRect.contains(p))
            {

                if(child->stop.first ==0)
                {

                }
                else if(child->stop.first ==1)
                {

                }
                else
                {
                    child->move(p);
                    update();
                    emit valueChanged(child->dt);
                }


            }
        }
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        if(child)
        {
            child = NULL;
        }
    }

    void paintEvent(QPaintEvent *event)
    {
        QList<qreal> list;

        foreach(QColorWidget * w,colorwidgets)
        {
            qreal d =(qreal)(w->pos().x()-20)/gradientRect.width();

            w->dt = d;

            list.append(d);
        }

        qSort(list);

        QGradientStops _stops;

        QGradientStop _stop;

        _stop.first = colorwidgets[0]->dt;
        _stop.second = colorwidgets[0]->getColor();

        _stops.prepend(_stop);

        for(int i =0;i<list.size();i++)
        {
            foreach(QColorWidget * w,colorwidgets)
            {
                if(list[i] = w->dt)
                {
                    QGradientStop _stop;

                    _stop.first = list[i];
                    _stop.second = w->getColor();

                    _stops.append(_stop);
                }
            }
        }

        QPainter painter(this);

        gradient.setStops(_stops);

        gradient.setSpread(QGradient::PadSpread);

        QBrush b(gradient);

        painter.setBrush(b);

        painter.drawRect(gradientRect);

        update();
    }

signals:
    void valueChanged(float dt);
    void valueChanged(QLinearGradient grad);

};

class QGradientRampWidget: public QWidget
{
    Q_OBJECT
    QRamp * ramp;
public:

    void setGradient(QLinearGradient gradient)
    {
        ramp->setGradient(gradient);
    }

    QLinearGradient  getGradient()
    {
        return ramp->getGradient();
    }

    QGradientRampWidget(QWidget * parent =0):QWidget(parent)
    {
        setMinimumWidth(250);
        setMinimumWidth(100);

        QVBoxLayout * layout  = new QVBoxLayout;
        QHBoxLayout * hlayout = new QHBoxLayout;

        QGroupBox * group =  new QGroupBox(QString("Gradient Ramp"));
        ramp = new QRamp(this);
        layout->addWidget(ramp);

        group->setLayout(layout);

        hlayout->addWidget(group);
        setLayout(hlayout);
    }
private slots:

};

class QVector3DWidget: public QWidget
{
    Q_OBJECT

    QVector3D _vector;
    //QLabel * label;

    QSpinBox * XSpinner;
    QSpinBox * YSpinner;
    QSpinBox * ZSpinner;

public:

    void setVector(QVector3D vector)
    {
        _vector  =  vector;

        emit valueChanged(_vector);
    }

    QVector3D  getVector()
    {
        return _vector;
    }

    QVector3DWidget(QWidget * parent =0) : QWidget(parent)
    {
        setGeometry(0,0,150,100);

        XSpinner = new QSpinBox ;
        YSpinner = new QSpinBox ;
        ZSpinner = new QSpinBox ;

        //label  = new QLabel(QString("Color"));

        XSpinner->setRange(-10000,10000);
        YSpinner->setRange(-10000,10000);
        ZSpinner->setRange(-10000,10000);

        _vector  = QVector3D(0,0,0);

        connect(XSpinner,SIGNAL(valueChanged(int)),this,SLOT(setXValue()));
        connect(YSpinner,SIGNAL(valueChanged(int)),this,SLOT(setYValue()));
        connect(ZSpinner,SIGNAL(valueChanged(int)),this,SLOT(setZValue()));

        connect(this,SIGNAL(valueChanged(QVector3D)),this,SLOT(setXYZ()));


        QHBoxLayout * layout =  new QHBoxLayout;

        //layout->addWidget(label,0,0);
        layout->addWidget(new QLabel("X:"));
        layout->addWidget(XSpinner);
        layout->addWidget(new QLabel("Y:"));
        layout->addWidget(YSpinner);
        layout->addWidget(new QLabel("Z:"));
        layout->addWidget(ZSpinner);

        setLayout(layout);
    }
private slots:
    void setXValue()
    {
        _vector.setX(XSpinner->value());
           }
    void setYValue()
    {
        _vector.setY(YSpinner->value());

    }
    void setZValue()
    {
        _vector.setZ(ZSpinner->value());

    }

    void setXYZ()
    {
        XSpinner->setValue(_vector.x());
        YSpinner->setValue(_vector.y());
        ZSpinner->setValue(_vector.x());
    }
signals:
    void valueChanged(QVector3D v);
};

class QVector2DWidget: public QWidget
{
    Q_OBJECT

    QVector2D _vector;

    QSpinBox *XSpinner;
    QSpinBox *YSpinner;


public:

    void setVector(QVector2D vector)
    {
        this->_vector  =  vector;

        emit valueChanged(_vector);
    }

    QVector2D  getVector()
    {
        return _vector;
    }

    QVector2DWidget(QWidget * parent =0):QWidget(parent)
    {
        setGeometry(0,0,150,100);


        XSpinner = new QSpinBox ;
        YSpinner = new QSpinBox ;

        //label  = new QLabel(QString("Color"));

        XSpinner->setRange(-10000,10000);
        YSpinner->setRange(-10000,10000);

        _vector  = QVector2D(0,0);

        connect(XSpinner,SIGNAL(valueChanged(int)),this,SLOT(setXValue()));
        connect(YSpinner,SIGNAL(valueChanged(int)),this,SLOT(setYValue()));

        connect(this,SIGNAL(valueChanged(QVector2D)),this,SLOT(setXY()));


        QHBoxLayout * layout =  new QHBoxLayout;

        //layout->addWidget(label,0,0);
        layout->addWidget(new QLabel("X:"));
        layout->addWidget(XSpinner);
        layout->addWidget(new QLabel("Y:"));
        layout->addWidget(YSpinner);

        setLayout(layout);
    }
private slots:
    void setXValue()
    {
        _vector.setX(XSpinner->value());
           }
    void setYValue()
    {
        _vector.setY(YSpinner->value());

    }


    void setXY()
    {
        XSpinner->setValue(_vector.x());
        YSpinner->setValue(_vector.y());

    }
signals:
    void valueChanged(QVector2D v);
};

class QRampCurveWidget : public QWidget
{
    Q_OBJECT

    QList<QColorWidget*> knots;
    QPolygonF polygon;

    QRect polygonRect;

    QColorWidget *child;

public:
    QList<QPointF>  getPoints()
    {
        polygon.clear();

        foreach(QColorWidget * w,knots)
        {
            polygon.append(QPointF(w->pos()));
        }

        return polygon.toList();
    }


    void setGradient(QList<QPointF> points)
    {
        polygon.fromList(points);
    }


    QRampCurveWidget(QWidget * parent=0):QWidget(parent)
    {
        setMinimumWidth(200);
        setMinimumHeight(100);

        computePolygonRect();

        addstops();
    }


    void computePolygonRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().bottomRight();

        p1 += QPoint(5,5);
        p2 -= QPoint(5,5);

        polygonRect = QRect(p1,p2);

    }

    void addstops()
    {
        QList<QPointF> points =  polygon.toList();

        for(int i = 0;i<points.count();i++)
        {
            QColorWidget *knot = new QColorWidget(this);
            knot->setFixedSize(8,8);
            knot->setDisabled(true);


            QPoint p = points[i].toPoint();
            knot->move(p);
            knot->show();

            knots.append(knot);

        }
    }


    void addStop(QMouseEvent *event)
    {
        if(event->modifiers()==Qt::ControlModifier && event->button()==Qt::LeftButton)
        {
            QPointF p = QPointF(event->pos());

            if(polygonRect.contains(p.x(),p.y(),true))
            {
                addStopSlider(p);

                emit valueChanged(polygon);

            }
        }
    }

    void addStopSlider(QPointF p)
    {
        QColorWidget *knot = new QColorWidget(this);

        knot->setFixedSize(8,8);
        knot->move(p.toPoint());
        knot->setDisabled(true);

        knot->show();

        knots.append(knot);
    }

    void deleteStope(QMouseEvent *event)
    {
      if(event->modifiers()==Qt::AltModifier && event->button()==Qt::LeftButton)
      {
          knots.removeAt(knots.indexOf(child));

          delete child;
       }
    }

    void resizeEvent(QResizeEvent *event)
    {
        computePolygonRect();
    }


    void mousePressEvent(QMouseEvent *event)
    {
        getGetColorWidgetAndStop(event);

        deleteStope(event);
        addStop(event);
    }

    void getGetColorWidgetAndStop(QMouseEvent *event)
    {

        child = dynamic_cast<QColorWidget*>(childAt(event->pos()));


    }



    void mouseMoveEvent(QMouseEvent *event)
    {
        if(child )
        {
            QPoint p =  event->pos();
            if(polygonRect.contains(p))
            {
                child->move(p);

                update();

                emit valueChanged(child->pos());
            }
        }
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        if(child)
        {
            child = NULL;
        }
    }

    void paintEvent(QPaintEvent *event)
    {

        polygon.clear();

        foreach(QColorWidget * w,knots)
        {
            polygon.append(QPointF(w->pos()));
        }

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setPen(QPen(QColor(5,5,5),2));
        painter.drawRect(rect());

        painter.setPen(QPen(QColor(150,150,150),2));
        painter.drawRect(polygonRect);
        painter.setPen(QPen(QColor(25,25,25),2));
        painter.setBrush(QBrush(QColor(93,93,93),Qt::SolidPattern));
        painter.drawPolygon(polygon);

        update();
    }

signals:
    void valueChanged(QPoint p);
    void valueChanged(QPolygonF  poly);

};

class QTimeLineFrame : public QWidget
{
    Q_OBJECT

    int startFrame;
    int currentFrame;
    int endFrame;

    int totalFrames;

    int fps;

    int LoopCount;
    int currentLoop;

    /*
    bool isRealtime;
    bool isplaying;
    int step;
    */

    QPoint indexPos;

    //QList<QTimeLine *> timelines;

    float interval;

    int ticks = 1000;//1000ms = 1s;

    QTimer * timer;

    //QSlider *sliderTimeLine;

    QRectF timelineRect;

    bool isPlaying;


public:

    QTimer* getTimer()
    {
        return timer;
    }
    /*
    QSlider* getQProgressBar()
    {
        return sliderTimeLine;
    }
    */

    void setTimeLine(QTimer * _timer)
    {
        timer =  _timer;
    }

    int getStartFrame()
    {
        return startFrame;
    }

    int getEndFrame()
    {
        return endFrame;
    }

    int getCurrentFrame()
    {
       return currentFrame;
    }


    int getLoopCount()
    {
        return LoopCount;
    }
    void setLoopCount(int count)
    {
        LoopCount = count;
    }

    void setFrameRate(int FrameRate = FPS_24)
    {
        if(FrameRate = FPS_24)
        {
            fps =  24;
            interval = (float)1/24 * ticks;
        }
        else if(FrameRate = FPS_25)
        {
            fps= 25;
            interval = (float)1/25 * ticks;
        }
        else if(FrameRate = FPS_30)
        {
            fps =  30;
            interval = (float)1/30 * ticks;
        }
        else if(FrameRate = FPS_60)
        {
            fps = 60;
            interval = (float)1/60 * ticks;
        }
        else if(FrameRate = FPS_90)
        {
            fps = 90;
            interval = (float)1/90 * ticks;
        }
        else if(FrameRate = FPS_REALTIME)
        {
            fps = -1;
            interval = 0;
        }
        else if(FrameRate = FPS_CUSTOMN)
        {
            fps = 120;
            interval = (float)1/120 * ticks;
        }

        timer->setInterval(interval);

    }

    void setStartFrame(int frame=0)
    {
        startFrame =  frame;
    }

    void setEndFrame(int frame=0)
    {
        endFrame = frame;
    }

    void setCurrentFrame(int frame)
    {
        currentFrame = frame;
    }
    void setClipFrame()
    {
        /*
        if(startFrame>endFrame)
        {
            startFrame =  endFrame;
        }

        if(startFrame<endFrame)
        {
            endFrame =  startFrame;
        }
        */


        if(currentFrame<startFrame)
        {
            //currentFrame = startFrame;
            //currentLoop -= 1;

            goToLastFrame();
        }
        else if(currentFrame>endFrame)
        {
            //currentFrame = endFrame;
            //currentLoop+= 1;

            //currentLoop+= 1;

            goToStartFrame();

            /*

            if(currentLoop>=LoopCount)
            {
                this->timer->stop();
            }
            else
            {
                goToStartFrame();

            }
            */
        }

        //setProgress();

        emit valueChanged(currentFrame);
    }

    void setFrameRange(int start,int end)
    {
        startFrame = start;
        endFrame = end;
    }





public:

    QTimeLineFrame(QWidget *parent = 0): QWidget(parent)
    {
        indexPos     = QPoint(0,0);
        startFrame   = 0;
        currentFrame = 0;
        endFrame     = 150;
        fps          = 25;
        LoopCount    = 5;
        currentLoop  = 0;
        totalFrames  = endFrame - startFrame;

        timer = new QTimer(this);

        isPlaying =  false;

        //sliderTimeLine = new QSlider(this);
        //sliderTimeLine->setTickInterval(5);
        //sliderTimeLine->setTickPosition(QSlider::TicksBelow);

        //sliderTimeLine->hide();



        /*
        step = 1;

        isRealtime = false;
        isplaying = false;
        */



        this->setFrameRate(FPS_24);
        this->setFrameRange(startFrame,endFrame);
        this->setLoopCount(5);

        //sliderTimeLine->setMinimum(startFrame);
        //sliderTimeLine->setMaximum(endFrame);
        //sliderTimeLine->setRange(startFrame,endFrame);
        //sliderTimeLine->setOrientation(Qt::Horizontal);

        setMinimumSize(1, 30);

        //connect(timer, SIGNAL(timeout()), this, SLOT(setProgress()));
        connect(timer,SIGNAL(timeout()),this,SLOT(playForward()));

        //connect(sliderTimeLine,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameFromProgress()));



        computeTimelineRect();
    }

    void computeTimelineRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().bottomRight();

        p1 += QPoint(25,5);
        p2 -= QPoint(25,5);

        timelineRect = QRect(p1,p2);

    }

    void wheelEvent(QWheelEvent *event)
    {
        positionIndex(event);
    }

    /*

    enum FRAMERATES
    {
        FPS_25,
        FPS_30,
        FPS_60,
        FPS_REALTIME,
        FPS_CUSTOMN,
    };
    */

    void paintEvent( QPaintEvent * event)
    {
        computeTimelineRect();

        QPainter painter(this);


        painter.setPen(QPen(QColor(25,25,25),2));
        painter.setBrush(QBrush(QColor(93,93,93),Qt::SolidPattern));

        painter.drawRect(rect());
        painter.setPen(QPen(QColor(5,5,5,20),2));
        painter.drawRect(timelineRect);

        totalFrames = endFrame- startFrame;

        drawIndexMarker();
        drawRuler();


        update();
    }

    float computeFrameWidth()
    {
        float dx = timelineRect.width()* (currentFrame-startFrame)/totalFrames;

        return dx;

    }

    void drawIndexMarker()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );

        p.setFont(f);
        p.setPen(Qt::cyan);
        p.setBrush(QBrush(QColor(Qt::cyan)));

        QRect indexRect(1,0,2,timelineRect.height());

        float dx  = computeFrameWidth();

        QPointF _p  = timelineRect.topLeft();

        _p+= QPointF(dx,0);

        indexRect.moveTo(_p.toPoint());

        p.drawRect(indexRect);


    }

    void positionIndex(QWheelEvent *event)
    {
        if(isPlaying==false)
        {
            if(timelineRect.contains(event->pos()))
            {
                qDebug()<<"delta"<<event->delta();

                float dl = event->delta();

                if( dl < 0 )
                {
                    //currentFrame -= 1;
                    goToPreviousFrame();

                }
                else if( dl > 0 )
                {
                    goToNextFrame();
                    //currentFrame += 1;
                }

                //playForward();
            }
        }

        update();

    }

    void positionIndex(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton)
        {
            if(isPlaying==false)
            {
                if(timelineRect.contains(event->pos()))
                {
                    QPointF _p =  QPointF(event->pos());

                    float dx = _p.x() - timelineRect.topLeft().x();

                    float fr = totalFrames *dx/timelineRect.width();

                    currentFrame = (int)floor(fr);

                    qDebug()<<"Pos:"<<event->pos()<<"Frame:"<<currentFrame;

                    playForward();
                }
            }
        }
        update();
    }

    /*
    void drawFrameRange()
    {
        QPainter p(this);
        p.setPen(Qt::black);

        float dx1 = width()*(currentFrame- startFrame)/totalFrames;
        float dx2 = width()*(currentFrame- startFrame)/totalFrames;
        QRectF rec(0,0);
        p.drawRect();
    }
    */

    void drawRuler()
    {
        QFont f( "Courier", 8, QFont::Normal );

        QPainter p(this);
        p.setPen(Qt::black);
        p.setFont(f);


        int stepFrames = (int)totalFrames/25;

        for(int i=0;i<=totalFrames;i+=stepFrames)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* i/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);


            e += QPoint(ddx,0);

            e -= QPoint(0,10);
            e -= QPoint(0,2);

            p.drawLine(s,e);

            p.setPen(Qt::black);
            p.drawText(e,QString::number(i+startFrame));


        }



        for(int j=0;j<totalFrames;j+=1)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* j/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);


            e += QPoint(ddx,0);

            e -= QPoint(0,4);
            e -= QPoint(0,2);

            p.drawLine(s,e);

        }


    }

    void resizeEvent(QResizeEvent *event)
    {
        //sliderTimeLine->resize(width(),20);

        QWidget::resizeEvent(event);
    }




    void mousePressEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

signals:
    void valueChanged(int frame);

public slots:



    void play()
    {
        isPlaying = true;
        timer->start();
    }

    void stop()
    {
        isPlaying = false;
        timer->stop();
    }

    void goToNextFrame()
    {
        currentFrame += 1;
        setClipFrame();

    }
    void goToPreviousFrame()
    {
        currentFrame -= 1;
        setClipFrame();
    }

    void goToLastFrame()
    {
        currentFrame  =  endFrame;
        setClipFrame();
    }
    void goToStartFrame()
    {
        currentFrame  =  startFrame;
        setClipFrame();
    }

    void playForward()
    {

         currentFrame += 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }
    void playBackWard()
    {

         currentFrame -= 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }

    /*

    void setProgress()
    {
        sliderTimeLine->setValue(currentFrame);
    }

    void setCurrentFrameFromProgress()
    {
        currentFrame =sliderTimeLine->value();
    }
    */
};

class QTimeLineWidget : public QWidget
{
    Q_OBJECT

    QTimeLineFrame *timelineframe;

    QSpinBox * spinBoxStartFrame;
    QSpinBox * spinBoxEndFrame;
    QSpinBox * spinBoxCurrentFrame;
    QComboBox * cbox;

public:

    QTimeLineWidget (QWidget *parent=0) : QWidget(parent)
    {
        timelineframe = new QTimeLineFrame;
        spinBoxCurrentFrame  = new QSpinBox();

        QVBoxLayout *vlayout = new QVBoxLayout;
        QHBoxLayout *layout = new QHBoxLayout;

        /*
        enum FRAME_RATES
        {
            FPS_24 = 24,
            FPS_25 = 25,
            FPS_30 = 30,
            FPS_60 = 60,
            FPS_90 = 90,

            FPS_REALTIME,
            FPS_CUSTOMN,
        };
        */

        cbox = new  QComboBox;

        cbox->addItem(QString("fps 24"));
        cbox->addItem(QString("fps 25"));
        cbox->addItem(QString("fps 30"));
        cbox->addItem(QString("fps 60"));
        cbox->addItem(QString("fps 90"));
        cbox->addItem(QString("fps RealTime"));


        cbox->setMinimumWidth(50);

        QPushButton * firstbutton =  new QPushButton(QString("|<"));
        QPushButton * prevbutton =  new QPushButton(QString("<<"));
        QPushButton * playbutton =  new QPushButton(QString(">"));
        QPushButton * nextbutton =  new QPushButton(QString(">>"));
        QPushButton * lastbutton =  new QPushButton(QString(">|"));
        QPushButton * pausebutton =  new QPushButton(QString("||"));
        QPushButton * stopbutton =  new QPushButton(QString("|o|"));


        spinBoxCurrentFrame->setValue(timelineframe->getCurrentFrame());


        //currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));

        layout->addWidget(new QLabel("Frame:"));
        layout->addWidget(spinBoxCurrentFrame);

        layout->addWidget(firstbutton);
        layout->addWidget(prevbutton);
        layout->addWidget(playbutton);
        layout->addWidget(pausebutton);
        layout->addWidget(stopbutton);
        layout->addWidget(nextbutton);
        layout->addWidget(lastbutton);

        layout->addWidget(new QLabel("Frames/Seconds:"));
        layout->addWidget(cbox);


        connect(firstbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToStartFrame()));
        connect(lastbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToLastFrame()));
        connect(prevbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToPreviousFrame()));
        connect(playbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(play()));
        connect(nextbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToNextFrame()));
        connect(pausebutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));
        connect(stopbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));

        connect(timelineframe,SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),this,SLOT(setLabel()));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));


                /*

        setStartFrame = new QLineEdit();
        QValidator *svalidator = new QIntValidator(0, 10000, this);
        setStartFrame->setValidator(svalidator);

        setEndFrame = new QLineEdit();
        QValidator *evalidator = new QIntValidator(0, 10000, this);
        setEndFrame->setValidator(evalidator);

                */
        spinBoxStartFrame = new QSpinBox();
        spinBoxEndFrame = new QSpinBox();



        spinBoxCurrentFrame->setRange(0,10000);
        spinBoxEndFrame->setRange(0,10000);
        spinBoxStartFrame->setRange(0,10000);


        layout->addWidget(new QLabel(QString("Start Frame:")));
        layout->addWidget(spinBoxStartFrame);

        layout->addWidget(new QLabel(QString("End Frame:")));
        layout->addWidget(spinBoxEndFrame);

        /*

        layout->addWidget(new QLabel(QString("   Current Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Frames Per Second:")));
        layout->addWidget(cbox);
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Total Frames:")));
        layout->addWidget(new QLineEdit());


        layout->addWidget(new QLabel(QString("set Loop Frames")));
        layout->addWidget(new QRadioButton());

        layout->addWidget(new QLabel(QString("set Frame Range")));
        layout->addWidget(new QRadioButton());
        */

        connect(spinBoxEndFrame,SIGNAL(editingFinished()),this,SLOT(setEndFrameLabel()));
        connect(spinBoxStartFrame,SIGNAL(editingFinished()),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(editingFinished()),this,SLOT(setCurrentFrameLabel()));

        //connect(spinBoxEndFrame,SIGNAL(valueChanged(int)),this,SLOT(setEndFrameLabel()));
        //connect(spinBoxStartFrame,SIGNAL(valueChanged(int)),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameLabel()));

        connect(cbox,SIGNAL(currentIndexChanged(int)),this,SLOT(setFrameRate()));


        vlayout->addWidget(timelineframe);
        vlayout->addLayout(layout);

        spinBoxStartFrame->setValue(timelineframe->getStartFrame());
        spinBoxEndFrame->setValue(timelineframe->getEndFrame());


        setLayout(vlayout);
    }

private slots:

    void setFrameRate()
    {
        //cbox->currentIndex();
        //cbox->currentText();
       //cbox->itemText()

        timelineframe->stop();


        if(cbox->currentText() =="fps 24")
        {
            timelineframe->setFrameRate(FPS_24);

        }
        else if(cbox->currentText() =="fps 25")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 30")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 60")
        {
            timelineframe->setFrameRate(FPS_60);
        }
        else if(cbox->currentText() =="fps 90")
        {
            timelineframe->setFrameRate(FPS_90);

        }
        else if(cbox->currentText() =="fps RealTime")
        {
            timelineframe->setFrameRate(FPS_REALTIME);
        }
        //timelineframe->setClipFrame();

        timelineframe->stop();
    }

    void setLabel()
    {
       // currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));
    }

    void setCurrentFrameLabel()
    {
        timelineframe->setCurrentFrame(spinBoxCurrentFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setStartFrameLabel()
    {
        timelineframe->setStartFrame(spinBoxStartFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setEndFrameLabel()
    {
        timelineframe->setEndFrame(spinBoxEndFrame->text().toInt());
        timelineframe->setClipFrame();
    }
};

class TimeLineFrame : public QWidget
{
    Q_OBJECT

    bool isPlaying;

    int startFrame;
    int currentFrame;
    int endFrame;
    int totalFrames;
    int fps;
    int LoopCount;
    int currentLoop;
    int ticks = 1000;//1000ms = 1s;

    float interval;

    QPoint indexPos;
    QTimer * timer;
    QRectF timelineRect;

public:

    QTimer* getTimer()
    {
        return timer;
    }   

    float getFrameWidth()
    {
        float dx = timelineRect.width()* (currentFrame-startFrame)/totalFrames;

        return dx;

    }

    QRectF getTimelineRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().bottomRight();

        p1 += QPoint(25,5);
        p2 -= QPoint(25,5);

        timelineRect = QRectF(p1,p2);

        return timelineRect;
    }

    int getStartFrame()
    {
        return startFrame;
    }

    int getEndFrame()
    {
        return endFrame;
    }

    int getCurrentFrame()
    {
       return currentFrame;
    }

    int getLoopCount()
    {
        return LoopCount;
    }

    TimeLineFrame(QWidget *parent = 0): QWidget(parent)
    {
        indexPos     = QPoint(0,0);
        startFrame   = 0;
        currentFrame = 0;
        endFrame     = 150;
        fps          = 25;
        LoopCount    = 5;
        currentLoop  = 0;
        totalFrames  = endFrame - startFrame;

        timer = new QTimer(this);

        isPlaying =  false;

        this->setFrameRate(FPS_24);
        this->setFrameRange(startFrame,endFrame);
        this->setLoopCount(5);

        setMinimumSize(1, 30);

        //connect(timer, SIGNAL(timeout()), this, SLOT(setProgress()));
        connect(timer,SIGNAL(timeout()),this,SLOT(playForward()));

        //connect(sliderTimeLine,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameFromProgress()));



        getTimelineRect();
    }

    void paintEvent( QPaintEvent * event)
    {
        getTimelineRect();

        QPainter painter(this);


        painter.setPen(QPen(QColor(25,25,25),2));
        painter.setBrush(QBrush(QColor(93,93,93),Qt::SolidPattern));

        painter.drawRect(rect());
        painter.setPen(QPen(QColor(5,5,5,20),2));
        painter.drawRect(timelineRect);

        totalFrames = endFrame- startFrame;

        drawIndexMarker();
        drawRuler();


        update();
    }

    virtual void drawIndexMarker()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );

        p.setFont(f);
        p.setPen(Qt::cyan);
        p.setBrush(QBrush(QColor(Qt::cyan)));

        QRect indexRect(1,0,2,timelineRect.height());

        float dx  = getFrameWidth();

        QPointF _p  = timelineRect.topLeft();

        _p += QPointF(dx,0);

        indexRect.moveTo(_p.toPoint());

        p.drawRect(indexRect);


    }

    virtual void drawRuler()
    {
        QFont f( "Courier", 8, QFont::Normal );

        QPainter p(this);

        p.setPen(Qt::black);
        p.setFont(f);


        int stepFrames = (int)totalFrames/25;

        for(int i=0;i<=totalFrames;i+=stepFrames)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* i/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);
            e += QPoint(ddx,0);
            e -= QPoint(0,10);
            e -= QPoint(0,2);

            p.drawLine(s,e);
            p.setPen(Qt::black);
            p.drawText(e,QString::number(i+startFrame));
        }

        for(int j=0;j<totalFrames;j+=1)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* j/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);
            e += QPoint(ddx,0);
            e -= QPoint(0,4);
            e -= QPoint(0,2);

            p.drawLine(s,e);
        }
    }

    virtual void positionIndex(QWheelEvent *event)
    {
        if(isPlaying==false)
        {
            if(timelineRect.contains(event->pos()))
            {
                qDebug()<<"delta"<<event->delta();

                float dl = event->delta();

                if( dl < 0 )
                {
                    //currentFrame -= 1;
                    goToPreviousFrame();

                }
                else if( dl > 0 )
                {
                    goToNextFrame();
                    //currentFrame += 1;
                }

                //playForward();
            }
        }

        update();

    }

    virtual void positionIndex(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton)
        {
            if(isPlaying==false)
            {
                if(timelineRect.contains(event->pos()))
                {
                    QPointF _p =  QPointF(event->pos());

                    float dx = _p.x() - timelineRect.topLeft().x();

                    float fr = totalFrames *dx/timelineRect.width();

                    currentFrame = (int)floor(fr);

                    qDebug()<<"Pos:"<<event->pos()<<"Frame:"<<currentFrame;

                    playForward();
                }
            }
        }
        update();
    }


    void wheelEvent(QWheelEvent *event)
    {
        positionIndex(event);
    }

    void resizeEvent(QResizeEvent *event)
    {
        //sliderTimeLine->resize(width(),20);

        QWidget::resizeEvent(event);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

signals:
    void valueChanged(int frame);

public slots:

    void setTimeLine(QTimer * _timer)
    {
        timer =  _timer;
    }

    void setLoopCount(int count)
    {
        LoopCount = count;
    }

    void setFrameRate(int FrameRate = FPS_24)
    {
        if(FrameRate = FPS_24)
        {
            fps =  24;
            interval = (float)1/24 * ticks;
        }
        else if(FrameRate = FPS_25)
        {
            fps= 25;
            interval = (float)1/25 * ticks;
        }
        else if(FrameRate = FPS_30)
        {
            fps =  30;
            interval = (float)1/30 * ticks;
        }
        else if(FrameRate = FPS_60)
        {
            fps = 60;
            interval = (float)1/60 * ticks;
        }
        else if(FrameRate = FPS_90)
        {
            fps = 90;
            interval = (float)1/90 * ticks;
        }
        else if(FrameRate = FPS_REALTIME)
        {
            fps = -1;
            interval = 0;
        }
        else if(FrameRate = FPS_CUSTOMN)
        {
            fps = 120;
            interval = (float)1/120 * ticks;
        }

        timer->setInterval(interval);

    }

    void setStartFrame(int frame=0)
    {
        startFrame =  frame;
    }

    void setEndFrame(int frame=0)
    {
        endFrame = frame;
    }

    void setCurrentFrame(int frame)
    {
        currentFrame = frame;
    }

    void setFrameRange(int start,int end)
    {
        startFrame = start;
        endFrame = end;
    }

    void setClipFrame()
    {
        if(currentFrame<startFrame)
        {
            goToLastFrame();
        }
        else if(currentFrame>endFrame)
        {
            goToStartFrame();
        }

        emit valueChanged(currentFrame);
    }

    void play()
    {
        isPlaying = true;
        timer->start();
    }

    void stop()
    {
        isPlaying = false;
        timer->stop();
    }

    void goToNextFrame()
    {
        currentFrame += 1;
        setClipFrame();
    }

    void goToPreviousFrame()
    {
        currentFrame -= 1;
        setClipFrame();
    }

    void goToLastFrame()
    {
        currentFrame  =  endFrame;
        setClipFrame();
    }

    void goToStartFrame()
    {
        currentFrame  =  startFrame;
        setClipFrame();
    }

    void playForward()
    {
         currentFrame += 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }

    void playBackWard()
    {
         currentFrame -= 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }


};

class TimeLineWidget : public QWidget
{
    Q_OBJECT

    TimeLineFrame *timelineframe;

    QSpinBox * spinBoxStartFrame;
    QSpinBox * spinBoxEndFrame;
    QSpinBox * spinBoxCurrentFrame;
    QComboBox * cbox;

public:

    TimeLineWidget (QWidget *parent=0) : QWidget(parent)
    {
        timelineframe        = new TimeLineFrame;
        spinBoxCurrentFrame  = new QSpinBox();

        QVBoxLayout *vlayout = new QVBoxLayout;
        QHBoxLayout *layout = new QHBoxLayout;

        /*
        enum FRAME_RATES
        {
            FPS_24 = 24,
            FPS_25 = 25,
            FPS_30 = 30,
            FPS_60 = 60,
            FPS_90 = 90,

            FPS_REALTIME,
            FPS_CUSTOMN,
        };
        */

        cbox = new  QComboBox;

        cbox->addItem(QString("fps 24"));
        cbox->addItem(QString("fps 25"));
        cbox->addItem(QString("fps 30"));
        cbox->addItem(QString("fps 60"));
        cbox->addItem(QString("fps 90"));
        cbox->addItem(QString("fps RealTime"));


        cbox->setMinimumWidth(50);

        QPushButton * firstbutton =  new QPushButton(QString("|<"));
        QPushButton * prevbutton =  new QPushButton(QString("<<"));
        QPushButton * playbutton =  new QPushButton(QString(">"));
        QPushButton * nextbutton =  new QPushButton(QString(">>"));
        QPushButton * lastbutton =  new QPushButton(QString(">|"));
        QPushButton * pausebutton =  new QPushButton(QString("||"));
        QPushButton * stopbutton =  new QPushButton(QString("|o|"));


        spinBoxCurrentFrame->setValue(timelineframe->getCurrentFrame());


        //currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));

        layout->addWidget(new QLabel("Frame:"));
        layout->addWidget(spinBoxCurrentFrame);

        layout->addWidget(firstbutton);
        layout->addWidget(prevbutton);
        layout->addWidget(playbutton);
        layout->addWidget(pausebutton);
        layout->addWidget(stopbutton);
        layout->addWidget(nextbutton);
        layout->addWidget(lastbutton);

        layout->addWidget(new QLabel("Frames/Seconds:"));
        layout->addWidget(cbox);


        connect(firstbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToStartFrame()));
        connect(lastbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToLastFrame()));
        connect(prevbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToPreviousFrame()));
        connect(playbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(play()));
        connect(nextbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToNextFrame()));
        connect(pausebutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));
        connect(stopbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));

        connect(timelineframe,SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),this,SLOT(setLabel()));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));


                /*

        setStartFrame = new QLineEdit();
        QValidator *svalidator = new QIntValidator(0, 10000, this);
        setStartFrame->setValidator(svalidator);

        setEndFrame = new QLineEdit();
        QValidator *evalidator = new QIntValidator(0, 10000, this);
        setEndFrame->setValidator(evalidator);

                */
        spinBoxStartFrame = new QSpinBox();
        spinBoxEndFrame   = new QSpinBox();

        spinBoxCurrentFrame->setRange(0,10000);
        spinBoxEndFrame->setRange(0,10000);
        spinBoxStartFrame->setRange(0,10000);


        layout->addWidget(new QLabel(QString("Start Frame:")));
        layout->addWidget(spinBoxStartFrame);

        layout->addWidget(new QLabel(QString("End Frame:")));
        layout->addWidget(spinBoxEndFrame);

        /*

        layout->addWidget(new QLabel(QString("   Current Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Frames Per Second:")));
        layout->addWidget(cbox);
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Total Frames:")));
        layout->addWidget(new QLineEdit());


        layout->addWidget(new QLabel(QString("set Loop Frames")));
        layout->addWidget(new QRadioButton());

        layout->addWidget(new QLabel(QString("set Frame Range")));
        layout->addWidget(new QRadioButton());
        */

        connect(spinBoxEndFrame,SIGNAL(editingFinished()),this,SLOT(setEndFrameLabel()));
        connect(spinBoxStartFrame,SIGNAL(editingFinished()),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(editingFinished()),this,SLOT(setCurrentFrameLabel()));

        //connect(spinBoxEndFrame,SIGNAL(valueChanged(int)),this,SLOT(setEndFrameLabel()));
        //connect(spinBoxStartFrame,SIGNAL(valueChanged(int)),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameLabel()));

        connect(cbox,SIGNAL(currentIndexChanged(int)),this,SLOT(setFrameRate()));


        vlayout->addWidget(timelineframe);
        vlayout->addLayout(layout);

        spinBoxStartFrame->setValue(timelineframe->getStartFrame());
        spinBoxEndFrame->setValue(timelineframe->getEndFrame());


        setLayout(vlayout);
    }

private slots:

    void setFrameRate()
    {
        //cbox->currentIndex();
        //cbox->currentText();
       //cbox->itemText()

        timelineframe->stop();


        if(cbox->currentText() =="fps 24")
        {
            timelineframe->setFrameRate(FPS_24);

        }
        else if(cbox->currentText() =="fps 25")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 30")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 60")
        {
            timelineframe->setFrameRate(FPS_60);
        }
        else if(cbox->currentText() =="fps 90")
        {
            timelineframe->setFrameRate(FPS_90);

        }
        else if(cbox->currentText() =="fps RealTime")
        {
            timelineframe->setFrameRate(FPS_REALTIME);
        }
        //timelineframe->setClipFrame();

        timelineframe->stop();
    }

    void setLabel()
    {
       // currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));
    }

    void setCurrentFrameLabel()
    {
        timelineframe->setCurrentFrame(spinBoxCurrentFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setStartFrameLabel()
    {
        timelineframe->setStartFrame(spinBoxStartFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setEndFrameLabel()
    {
        timelineframe->setEndFrame(spinBoxEndFrame->text().toInt());
        timelineframe->setClipFrame();
    }
};

class TimeLineWidgetEx : public QWidget
{
    Q_OBJECT



    QSpinBox * spinBoxStartFrame;
    QSpinBox * spinBoxEndFrame;
    QSpinBox * spinBoxCurrentFrame;
    QComboBox * cbox;

public:

    TimeLineFrame *timelineframe;

    QToolBar * timelineToolBar;

    void createToolBars()
    {

        timelineToolBar = new QToolBar(QString("Meshes Toolbar"));


        QAction * a0 = new QAction(QIcon(":/Tools Icons/mesh cylinder.svg"),QString("Add Cylinder: SHIFT + 0"),this);
        QAction * a1 = new QAction(QIcon(":/Tools Icons/mesh camera.svg"),QString("Add Camera: SHIFT + 1"),this);
        QAction * a2 = new QAction(QIcon(":/Tools Icons/mesh particles.svg"),QString("Add Particles: SHIFT + 2"),this);
        QAction * a3 = new QAction(QIcon(":/Tools Icons/mesh light.svg"),QString("Add Light: SHIFT + 3"),this);
        QAction * a4 = new QAction(QIcon(":/Tools Icons/mesh cone.svg"),QString("Add Cone: SHIFT + 4"),this);
        QAction * a5 = new QAction(QIcon(":/Tools Icons/mesh grid.svg"),QString("Add Grid: SHIFT + 5"),this);
        QAction * a6 = new QAction(QIcon(":/Tools Icons/mesh plane.svg"),QString("Add Plane: SHIFT + 6"),this);

        a0->setCheckable(true);a0->setShortcut(Qt::SHIFT|Qt::Key_1);
        a1->setCheckable(true);a1->setShortcut(Qt::SHIFT|Qt::Key_1);
        a2->setCheckable(true);a2->setShortcut(Qt::SHIFT|Qt::Key_2);
        a3->setCheckable(true);a3->setShortcut(Qt::SHIFT|Qt::Key_3);
        a4->setCheckable(true);a4->setShortcut(Qt::SHIFT|Qt::Key_4);
        a5->setCheckable(true);a5->setShortcut(Qt::SHIFT|Qt::Key_5);
        a6->setCheckable(true);a6->setShortcut(Qt::SHIFT|Qt::Key_6);

        connect(a0, SIGNAL(triggered(bool)), this, SLOT(addCylinderModel()));
        connect(a1, SIGNAL(triggered(bool)), this, SLOT(addCameraModel()));
        connect(a2, SIGNAL(triggered(bool)), this, SLOT(addParticlesModel()));
        connect(a3, SIGNAL(triggered(bool)), this, SLOT(addLightModel()));
        connect(a4, SIGNAL(triggered(bool)), this, SLOT(addConeModel()));
        connect(a5, SIGNAL(triggered(bool)), this, SLOT(addPlaneModel()));
        connect(a6, SIGNAL(triggered(bool)), this, SLOT(addQuadModel()));


        QActionGroup *actiongroups =  new QActionGroup(this);


        actiongroups->addAction(a1);
        actiongroups->addAction(a2);
        actiongroups->addAction(a3);
        actiongroups->addAction(a4);
        actiongroups->addAction(a5);
        actiongroups->addAction(a6);


        actiongroups->setExclusive(true);


        timelineToolBar->addActions(actiongroups->actions());
        timelineToolBar->addSeparator();

    }


    TimeLineWidgetEx (QWidget *parent=0) : QWidget(parent)
    {
        timelineToolBar = new QToolBar(QString("Play Back Control"));

        timelineframe   = new TimeLineFrame;

        spinBoxCurrentFrame  = new QSpinBox();

        QVBoxLayout *vlayout = new QVBoxLayout;
        QHBoxLayout *layout  = new QHBoxLayout;

        /*
        enum FRAME_RATES
        {
            FPS_24 = 24,
            FPS_25 = 25,
            FPS_30 = 30,
            FPS_60 = 60,
            FPS_90 = 90,

            FPS_REALTIME,
            FPS_CUSTOMN,
        };
        */

        cbox = new  QComboBox;

        cbox->addItem(QString("fps 24"));
        cbox->addItem(QString("fps 25"));
        cbox->addItem(QString("fps 30"));
        cbox->addItem(QString("fps 60"));
        cbox->addItem(QString("fps 90"));
        cbox->addItem(QString("fps RealTime"));


        cbox->setMinimumWidth(50);



        QPushButton * firstbutton =  new QPushButton(QIcon(QString(":/Tools Icons/timeline start.svg")),QString(""));
        QPushButton * prevbutton  =  new QPushButton(QIcon(QString(":/Tools Icons/timeline step back.svg")),QString(""));
        QPushButton * playbutton  =  new QPushButton(QIcon(QString(":/Tools Icons/timeline play.svg")),QString(""));
        QPushButton * nextbutton  =  new QPushButton(QIcon(QString(":/Tools Icons/timeline step forward.svg")),QString(""));
        QPushButton * lastbutton  =  new QPushButton(QIcon(QString(":/Tools Icons/timeline end.svg")),QString(""));
        QPushButton * pausebutton =  new QPushButton(QIcon(QString(":/Tools Icons/timeline pause.svg")),QString(""));
        QPushButton * stopbutton  =  new QPushButton(QIcon(QString(":/Tools Icons/timeline stop.svg")),QString(""));

        firstbutton->setToolTip("Start");
        prevbutton->setToolTip("Previous Frame");
        playbutton->setToolTip("Play");
        nextbutton->setToolTip("Next Frame");
        lastbutton->setToolTip("End");
        pausebutton->setToolTip("Pause");
        stopbutton->setToolTip("Stop");
        /*
        QPushButton * firstbutton =  new QPushButton(QIcon(QString(":/Tool Icons/timeline start.svg")),QString("|<"));
        QPushButton * prevbutton  =  new QPushButton(QIcon(QString(":/Tool Icons/timeline step back.svg")),QString("<<"));
        QPushButton * playbutton  =  new QPushButton(QIcon(QString(":/Tool Icons/timeline play.svg")),QString(">"));
        QPushButton * nextbutton  =  new QPushButton(QIcon(QString(":/Tool Icons/timeline step forward.svg")),QString(">>"));
        QPushButton * lastbutton  =  new QPushButton(QIcon(QString(":/Tool Icons/timeline end.svg")),QString(">|"));
        QPushButton * pausebutton =  new QPushButton(QIcon(QString(":/Tool Icons/timeline pause.svg")),QString("||"));
        QPushButton * stopbutton  =  new QPushButton(QIcon(QString(":/Tool Icons/timeline stop.svg")),QString("|o|"));
        */

        spinBoxCurrentFrame->setValue(timelineframe->getCurrentFrame());


        //currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));

        layout->addWidget(new QLabel("Frame:"));
        layout->addWidget(spinBoxCurrentFrame);

        layout->addWidget(firstbutton);
        layout->addWidget(prevbutton);
        layout->addWidget(playbutton);
        layout->addWidget(pausebutton);
        layout->addWidget(stopbutton);
        layout->addWidget(nextbutton);
        layout->addWidget(lastbutton);

        layout->addWidget(new QLabel("Frames/Seconds:"));
        layout->addWidget(cbox);


        connect(firstbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToStartFrame()));
        connect(lastbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToLastFrame()));
        connect(prevbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToPreviousFrame()));
        connect(playbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(play()));
        connect(nextbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToNextFrame()));
        connect(pausebutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));
        connect(stopbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));

        connect(timelineframe,SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),this,SLOT(setLabel()));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));


        /*

        setStartFrame = new QLineEdit();
        QValidator *svalidator = new QIntValidator(0, 10000, this);
        setStartFrame->setValidator(svalidator);

        setEndFrame = new QLineEdit();
        QValidator *evalidator = new QIntValidator(0, 10000, this);
        setEndFrame->setValidator(evalidator);

        */
        spinBoxStartFrame = new QSpinBox();
        spinBoxEndFrame   = new QSpinBox();

        spinBoxCurrentFrame->setRange(0,10000);
        spinBoxEndFrame->setRange(0,10000);
        spinBoxStartFrame->setRange(0,10000);


        layout->addWidget(new QLabel(QString("Start Frame:")));
        layout->addWidget(spinBoxStartFrame);

        layout->addWidget(new QLabel(QString("End Frame:")));
        layout->addWidget(spinBoxEndFrame);

        /*

        layout->addWidget(new QLabel(QString("   Current Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Frames Per Second:")));
        layout->addWidget(cbox);
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Total Frames:")));
        layout->addWidget(new QLineEdit());


        layout->addWidget(new QLabel(QString("set Loop Frames")));
        layout->addWidget(new QRadioButton());

        layout->addWidget(new QLabel(QString("set Frame Range")));
        layout->addWidget(new QRadioButton());
        */

        connect(spinBoxEndFrame,SIGNAL(editingFinished()),this,SLOT(setEndFrameLabel()));
        connect(spinBoxStartFrame,SIGNAL(editingFinished()),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(editingFinished()),this,SLOT(setCurrentFrameLabel()));

        //connect(spinBoxEndFrame,SIGNAL(valueChanged(int)),this,SLOT(setEndFrameLabel()));
        //connect(spinBoxStartFrame,SIGNAL(valueChanged(int)),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameLabel()));

        connect(cbox,SIGNAL(currentIndexChanged(int)),this,SLOT(setFrameRate()));


        vlayout->addWidget(timelineframe);
        vlayout->addLayout(layout);

        spinBoxStartFrame->setValue(timelineframe->getStartFrame());
        spinBoxEndFrame->setValue(timelineframe->getEndFrame());


        setLayout(vlayout);
    }

    void enterEvent(QEvent *event)
    {
        qDebug()<<"Enter Window";

        setFocus();
    }

    void leaveEvent(QEvent * event)
    {
        qDebug()<<"Left Window";
    }


signals:

public slots:

    void setFrameRate()
    {
        //cbox->currentIndex();
        //cbox->currentText();
       //cbox->itemText()

        timelineframe->stop();


        if(cbox->currentText() =="fps 24")
        {
            timelineframe->setFrameRate(FPS_24);

        }
        else if(cbox->currentText() =="fps 25")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 30")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 60")
        {
            timelineframe->setFrameRate(FPS_60);
        }
        else if(cbox->currentText() =="fps 90")
        {
            timelineframe->setFrameRate(FPS_90);

        }
        else if(cbox->currentText() =="fps RealTime")
        {
            timelineframe->setFrameRate(FPS_REALTIME);
        }
        //timelineframe->setClipFrame();

        timelineframe->stop();
    }

    void setLabel()
    {
       // currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));
    }

    void setCurrentFrameLabel()
    {
        timelineframe->setCurrentFrame(spinBoxCurrentFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setStartFrameLabel()
    {
        timelineframe->setStartFrame(spinBoxStartFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setEndFrameLabel()
    {
        timelineframe->setEndFrame(spinBoxEndFrame->text().toInt());
        timelineframe->setClipFrame();
    }

};

class ScreenCapture : public QWidget
{
    Q_OBJECT

    QTimer *timer;

    int frameCount;
    int frameCounter;
    int fps;

    float  msec;

    QWidget * source;

public:

    ScreenCapture(QWidget* parent=0):QWidget(parent)
    {
        frameCount = 100;
        fps = 25;
        msec = 1000.0f/fps;
        timer  = new QTimer;
        timer->setInterval(msec);
        frameCounter = 0;
    }

    ~ScreenCapture()
    {
        delete timer;
        delete source;
    }


    void setCaptureSource(QWidget * _source)
    {
        source = _source;
    }

    void captureFrameRange()
    {
        for(int i=0;i<frameCount;i++)
        {
            QPixmap piximage = QPixmap::grabWidget(source,source->rect());

            QString fileName = "Image"+QString::number(i)+".png";

            piximage.save(fileName);

            //piximage.save(QString(":/"));
        }
    }

public slots:

    void startCapture()
    {
        timer->start();
        frameCounter = 0;
    }

    void stopCapture()
    {
        timer->stop();
        frameCounter = 0;
    }

    void capturePerFrame()
    {
        frameCounter += 1;

        QPixmap piximage = QPixmap::grabWidget(source,source->rect());

        QString fileName = "Image"+QString::number(frameCounter)+".png";

        piximage.save(fileName);
    }

protected:

    void timerEvent(QTimerEvent *event)
    {
        if(timer)
            capturePerFrame();

        QWidget::timerEvent(event);
    }
};

class NodesConsole : public QListView
{
    QStringListModel * model;
    QStringList stringList;

public:

    NodesConsole(QWidget* parent =0):QListView(parent)
    {
        model = new QStringListModel;

        stringList.append(QString(">>Node tree Console Ready"));
        stringList.append(QString(">> Start Time:" + QTime::currentTime().toString()));

        this->setModel(model);

        model->setStringList(stringList);
    }
    ~NodesConsole()
    {
        delete model;
    }

    void printToConsole(QString message)
    {
        stringList.append(">>"+message);
    }

    void clearConsole()
    {
        foreach(QString str, stringList)
        {
           stringList.removeAll(str);
        }

        stringList.clear();
    }

};

class ToolsWidget : public QWidget
{
    QStringList primitiveslist;
    QStringList cameralist;
    QStringList helperlist;
    QStringList lightlist;
    QStringList curveslist;
    QStringList surfacelist;


    Q_OBJECT
public:

    QList<QStandardItemModel*> models;

    explicit ToolsWidget(QWidget *parent = 0);

    void initStringList()
    {

        primitiveslist.append(QString("Cube"));
        primitiveslist.append(QString("Sphere"));
        primitiveslist.append(QString("Torus"));
        primitiveslist.append(QString("Capsule"));
        primitiveslist.append(QString("Plane"));
        primitiveslist.append(QString("Container"));
        primitiveslist.append(QString("Cone"));
        primitiveslist.append(QString("Pyramid"));
        primitiveslist.append(QString("Cylinder"));
        primitiveslist.append(QString("Tube"));
        primitiveslist.append(QString("Platonic"));
        primitiveslist.append(QString("Lego"));
        primitiveslist.append(QString("Dull"));

        cameralist.append(QString("Perspective Camera"));
        cameralist.append(QString("Ortho"));
        cameralist.append(QString("Camera"));

        helperlist.append(QString("Point"));
        helperlist.append(QString("Cross"));
        helperlist.append(QString("Cube"));
        helperlist.append(QString("Sphere"));
        helperlist.append(QString("Circle"));
        helperlist.append(QString("Mover"));
        helperlist.append(QString("Text"));
        helperlist.append(QString("Svg"));

        lightlist.append(QString("sun"));
        lightlist.append(QString("Rect"));
        lightlist.append(QString("Point"));
        lightlist.append(QString("Sphere"));
        lightlist.append(QString("Infinite"));
        lightlist.append(QString("Object"));
        lightlist.append(QString("Spot"));

        curveslist.append(QString("Bezier"));
        curveslist.append(QString("Rect"));
        curveslist.append(QString("Circle"));
        curveslist.append(QString("Text"));
        curveslist.append(QString("Pie"));
        curveslist.append(QString("Spiral"));
        curveslist.append(QString("Coil"));
        curveslist.append(QString("L-Junction"));

        surfacelist.append(QString("Bezier"));
        surfacelist.append(QString("Rect"));
        surfacelist.append(QString("Circle"));
        surfacelist.append(QString("Text"));



    }

    void initUI()
    {
        initStringList();

        /*
        QTreeWidget * widgetQToolBox =  new QTreeWidget;
        widgetQToolBox->addTopLevelItem(new QTreeWidgetItem());
        */


        QToolBox *widgetQToolBox     = new QToolBox;
        QTextEdit *textEditQTextEdit = new QTextEdit;

        QListView *listPrimitivesQListView = new QListView;
        QListView *listCamerasQListView = new QListView;
        QListView *listHelpersQListView = new QListView;
        QListView*listLightsQListView   = new QListView;
        QListView *listCurvesQListView  = new QListView;
        QListView *listSurfacesQListView = new QListView;

        populateQListView(listPrimitivesQListView,primitiveslist);
        populateQListView(listCamerasQListView, cameralist);
        populateQListView(listHelpersQListView, helperlist);
        populateQListView(listLightsQListView, lightlist);
        populateQListView(listCurvesQListView, curveslist);
        populateQListView(listSurfacesQListView, surfacelist);


        widgetQToolBox->addItem(listPrimitivesQListView, "Primitives");
        widgetQToolBox->addItem(listCamerasQListView, "Cameras");
        widgetQToolBox->addItem(listHelpersQListView, "Helpers");
        widgetQToolBox->addItem(listLightsQListView, "Lights");
        widgetQToolBox->addItem(listCurvesQListView, "Curves");
        widgetQToolBox->addItem(listSurfacesQListView, "Surfaces");
        widgetQToolBox->addItem(textEditQTextEdit, "ScriptCommand");

        QVBoxLayout * layout = new QVBoxLayout;

        layout->addWidget(widgetQToolBox);

        setLayout(layout);
    }


    void populateQListView(QListView *list, QStringList dataList)
    {
        QIcon icon(":/mainicon.svg");

        // Create an empty model for the list's data
        QStandardItemModel *model = new QStandardItemModel;

        models.append(model);

        //Add some textual items
        for(int i =0;i<dataList.length();i++)
        {
           //create an item with a caption
           QStandardItem *item = new QStandardItem(dataList[i]);

           item->setIcon(icon);

           //Add the item to the model
           model->appendRow(item);
        }

        list->setViewMode(QListView::IconMode);

        //Apply the model to the list view
        list->setModel(model);
    }



signals:

public slots:
};

class QToolBarScrollable : public QToolBar
{
    QScrollArea* scrollArea;

public:

    QToolBarScrollable(QString name,QWidget*parent =0) : QToolBar(name,parent)
    {
        scrollArea = new QScrollArea(this);

        this->addWidget(scrollArea);
    }

    virtual void swapWidget(QWidget* widget)
    {
        scrollArea->setWidget(widget);
    }
};


class QFormWidget : public QWidget
{
    Q_OBJECT

    QFormLayout * layout;

public:

    QFormWidget(QWidget * parent =0) : QWidget(parent)
    {
        layout = new QFormLayout;
    }

    void addWidget(QWidget * widget)
    {
        layout->addWidget(widget);

        setLayout(layout);
    }

signals:

public slots:

};

class QSceneTreeView : public QTreeView//QTreeWidget
{
    Q_OBJECT

    QStringListModel * model;
    QStandardItemModel * m;


public:
    QSceneTreeView(QWidget * parent =0) : QTreeView(parent)
    {

        model = new QStringListModel;
        m     = new QStandardItemModel(0, 2);

       //setColumnCount(4);

       //column 1 = nameOfobject;
       //column 2 = hideFromView;
       //column 3 = freezeSelection;
       //column 4 = hideFromRender

       QStringList headerLabels;
       headerLabels.append(QString("Name:"));
       headerLabels.append(QString("Visibility:"));
       headerLabels.append(QString("Freeze:"));
       headerLabels.append(QString("Renderable:"));


       //setHeaderLabels(headerLabels);
       setAlternatingRowColors(true);

       //model->setStringList(headerLabels);
       this->setModel(m);

       m->setColumnCount(4);

       for(int i=0;i<20;i++)
       {
           addItems(i);
       }

       /*


       for(int i=0;i<20;i++)
       {

           QStringList labels;
           labels.append(QString("Cone"));
           QTreeWidgetItem * item1 = new QTreeWidgetItem(labels);


           item1->setText(0,QString("Cone"));
           item1->setIcon(0,QIcon(QString(":/icons/cubeomniverse.svg")));


           setItemWidget(item1, 1, new QRadioButton());
           setItemWidget(item1, 2, new QRadioButton());
           setItemWidget(item1, 3, new QRadioButton());


           //item1->setText(0,QString("Cone"));
           addTopLevelItem(item1);



       }
       */

       //addTopLevelItems();
       //addTopLevelItem();

       show();

    }

    void addItems(int n)
    {

        QString str = QString("Cone")+QString::number(n);

        QStandardItem *item = new QStandardItem(str);

        item->setIcon(QIcon(QString(":/icons/cubeomniverse.svg")));

        //QPushButton * itemWidget = new QPushButton(QString("Cone")+QString::number(n));
        //QModelIndex modelIndex = m->index(n, 2);

        //setIndexWidget(modelIndex, itemWidget);
        //m->setItem(n, 0, item);

        m->appendRow(item);

        setIndexWidget(m->index(n, 1),new QRadioButton("A",this));

     /*

               if n == 2:
                   std_item_child = QStandardItem('child');
                   std_item.appendRow(std_item_child);

                   node_widget_child = QPushButton('petit button');
                   qindex_widget_child = self._datamodel.index(n, 1, QModelIndex());
                   self.setIndexWidget(qindex_widget_child, node_widget_child);

                   */
    }





    void resizeEvent(QResizeEvent *event)
    {
        //setGeometry(this->rect());
        showMaximized();

        QTreeView::resizeEvent(event);
    }
    /*



    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);
        QTreeWidget::mouseReleaseEvent(event);
    }


    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        QTreeWidget::selectionChanged(selected,deselected);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);
        QTreeWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QTreeWidget::mouseMoveEvent(event);
    }



    void dragEnterEvent(QDragEnterEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QTreeWidget::dragEnterEvent(event);
    }
    */

};

class QNodesListView1 : public QListWidget
{
    Q_OBJECT

    bool _debug = false;

public:

    void setDebugging(bool print = false)
    {
      _debug = print;
    }

    QNodesListView1(QWidget* parent =0):QListWidget(parent)
    {
        setIconSize(QSize(15,15));

        //setAcceptDrops(true);

        //setDragDropMode(DropOnly);

        connect(this,SIGNAL(itemSelectionChanged()),this,SLOT(printselection()));


    }

    void resizeEvent(QResizeEvent *event)
    {
        //setGeometry(this->rect());
        showMaximized();

        QListWidget::resizeEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);

        QListWidget::mouseReleaseEvent(event);
    }

    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        QListWidget::selectionChanged(selected,deselected);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);

        QListWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)
            qDebug()<<"Selection Change:"<<index;

        if(_debug)
            qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();

        setCursor(Qt::OpenHandCursor);

        QListWidget::mouseMoveEvent(event);
    }

    /*
    void dragEnterEvent(QDragEnterEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QListWidget::dragEnterEvent(event);
    }
    */

private slots:

    void printselection()
    {
        qDebug()<<"Selection change";

    }
};

class QSearchEx1 : public QFrame
{
    Q_OBJECT

    QIcon  icon;

    QString selectedText;

    QStringList nodeslists;

    QStringList hitslist;

    QStringListModel * model;

    QLineEdit * lineEdit;

    QListView * listview;


public:


    QWidget * metropolisToolBox;



    QNodesListView1 * listviewWidget;


    QString getSelectedText()
    {
        return selectedText;
    }


    void _search(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    QSearchEx1(QStringList list,QWidget *parent = 0) : QFrame(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        nodeslists =  list;

        init();

        //setWindowFlags(Qt::FramelessWindowHint);

        //setAttribute(Qt::WA_NoSystemBackground);
    }

    void init()
    {
        setMaximumHeight(150);
        //list.removeDuplicates();
        nodeslists.sort();

        lineEdit = new QLineEdit;
        listview = new QListView;
        listviewWidget = new QNodesListView1;


        QPushButton * button =  new QPushButton;
        button->setIcon(QIcon(QString(":/icons/search_icon.svg")));
        button->setDisabled(true);

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        QWidget * sframe  = new QWidget;
        sframe->setLayout(slayout);


        QHBoxLayout * hlayout =  new QHBoxLayout;

        QWidget * frame  = new QWidget;

        QVBoxLayout * layout =  new QVBoxLayout;

        //layout->addWidget(lineEdit);
        layout->addWidget(sframe);
        layout->addWidget(listview);

        frame->setLayout(layout);

        QSplitter * splitter = new QSplitter(Qt::Horizontal);

        splitter->addWidget(frame);
        splitter->addWidget(listviewWidget);
        //hlayout->addLayout(layout);
        //hlayout->addWidget(listviewWidget);

        hlayout->addWidget(splitter);
        //setLayout(hlayout);
        setLayout(hlayout);


        //--------------->

        //metropolisToolBox = new QWidget;
        //QVBoxLayout * metro_hlayout =  new QVBoxLayout;
        //metro_hlayout->addWidget(sframe);
        //metro_hlayout->addWidget(listviewWidget);
        //metropolisToolBox->setLayout(metro_hlayout);

        //------------------->

        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(getSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(getSearchResults()));

        model = new QStringListModel;
        model->setStringList(nodeslists);
        listview->setModel(model);

        listviewWidget->clear();

        foreach(QString nodename,nodeslists)
        {
            listviewWidget->addItem(new QListWidgetItem(icon,nodename));
        }

        listviewWidget->setViewMode(QListView::IconMode);

    }

    void setFocus()
    {
        lineEdit->setFocus();

        lineEdit->setCursorPosition(0);
    }

signals:

    void valueChanged(QString filter);

private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            delete model;
            model = new QStringListModel;
            model->setStringList(nodeslists);


            foreach(QString nodename,nodeslists)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }
        else
        {
            _search(lineEdit->text());

            delete model;

            model = new QStringListModel;
            model->setStringList(hitslist);

            listviewWidget->clear();

            foreach(QString nodename,hitslist)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }

        listviewWidget->setViewMode(QListView::IconMode);
        //listviewWidget->setMaximumHeight(150);

        listview->setModel(model);

    }

    void getSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        qDebug()<< index.data().toString();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        //hide();

        emit valueChanged(selectedText);

        //lineEdit->setText(QString(""));
        //listview->reset();
        //listview->clearSelection();
    }

};


//Customn QCompleter
class QSearchCommands : public QWidget
{
    Q_OBJECT

    QIcon  icon;

    QStandardItemModel * itemModel;

    //QStringListModel * model;

    QLineEdit * lineEdit;
    QListView * listview;

    QPushButton * button;
    QPushButton * applyButton;

    QString selectedText;

    QStringList hitslist;

public:

    QStringList nodeslists;

    QList<QAction*> commandActions;

    QSearchCommands(QWidget *parent = 0) : QWidget(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        lineEdit = new QLineEdit;
        listview = new QListView;
        listview->setMaximumHeight(150);

        button =  new QPushButton;
        button->setIcon(QIcon(QString(":/icons/search_icon.svg")));
        button->setDisabled(true);

        applyButton = new QPushButton;
        applyButton->setIcon(QIcon(QString(":/Tools Icons/apply.svg")));
        applyButton->setText(QString("apply"));

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        slayout->addWidget(applyButton);

        QVBoxLayout * layout =  new QVBoxLayout;
        layout->addLayout(slayout);
        layout->addWidget(listview);

        setLayout(layout);

        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(processSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(processSearchResults()));
        connect(applyButton,SIGNAL(clicked(bool)),this,SLOT(processSearchResults()));

        //model     = new QStringListModel;

        itemModel = new QStandardItemModel;

        setWindowTitle(QString("Run Command"));

        setWindowFlags(Qt::FramelessWindowHint);

        setAttribute(Qt::WA_NoSystemBackground);

        setTheme();

        lineEdit->setFocusPolicy(Qt::StrongFocus);

        setFocusPolicy(Qt::ClickFocus);
    }

    ~QSearchCommands()
    {
        delete lineEdit;
        delete listview;
        delete button;
        delete applyButton;
    }

    void setTheme()
    {
        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }

        qDebug()<<"Styles Loaded";
    }

    void setFocus()
    {
        lineEdit->setFocus();

        lineEdit->setCursorPosition(0);
    }

    QString getSelectedText()
    {
        return selectedText;
    }



    virtual void setModels(QStringList list)
    {
        nodeslists =  list;

        nodeslists.sort();

        if(itemModel)
        {
            QList<QStandardItem *> items;

            int index =0;

            foreach(QString comm,nodeslists)
            {
                QStandardItem *item = new QStandardItem(comm);

                for(int i =0;i<commandActions.size();i++)
                {
                      if(comm.startsWith(commandActions[i]->text()))
                      {
                          item->setIcon(commandActions[i]->icon());
                      }
                }

                items.append(item);

                index++;
            }

            itemModel->clear();

            itemModel->appendColumn(items);

        }
        /*
        else if(model)
        {
            model->setStringList(nodeslists);
        }
        */


        if(itemModel)
        {
            listview->setModel(itemModel);
        }
        /*
        else if(model)
        {
            listview->setModel(model);
        }
        */
    }

signals:

    void valueChanged(QString filter);

private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            if(itemModel)
            {
                QList<QStandardItem *> items;

                int index =0;

                foreach(QString comm,nodeslists)
                {
                    QStandardItem *item = new QStandardItem(comm);

                    for(int i =0;i<commandActions.size();i++)
                    {
                        if(comm.startsWith(commandActions[i]->text()))
                        {
                            item->setIcon(commandActions[i]->icon());
                        }
                    }

                    items.append(item);

                    index++;
                }

                itemModel->clear();

                itemModel->appendColumn(items);

            }
            /*
            else if(model)
            {
                model->setStringList(nodeslists);
            }
            */
        }
        else
        {
            searchByFilter(lineEdit->text());

            if(itemModel)
            {
                QList<QStandardItem *> items;

                int index =0;

                foreach(QString comm,hitslist)
                {
                    QStandardItem *item = new QStandardItem(comm);

                    for(int i =0;i<commandActions.size();i++)
                    {
                        if(comm.startsWith(commandActions[i]->text()))
                        {
                            item->setIcon(commandActions[i]->icon());
                        }
                    }

                    items.append(item);

                    index++;
                }

                itemModel->clear();

                itemModel->appendColumn(items);

            }
            /*
            else if(model)
                model->setStringList(hitslist);
            */
        }


        if(itemModel)
        {
            listview->setModel(itemModel);
        }
        /*
        else if(model)
        {
           listview->setModel(model);
        }
        */
    }

    void searchByFilter(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    void processSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        foreach(QAction * action,commandActions)
        {
            if(action->text().startsWith(selectedText))
            {
                action->trigger();

                break;
            }
        }

        qDebug()<< index.data().toString();

        this->hide();

        emit valueChanged(selectedText);
    }
};


class QPropertiesTreeWidget : public QTreeWidget
{
    Q_OBJECT
public:

    QList<QTreeWidgetItem*> itemList;

    QPropertiesTreeWidget(bool test = false,QWidget * parent = 0): QTreeWidget(parent)
    {
        QFile file(":/icons/glowBlue.stylesheet");

        //QFile file(":/icons/styleMain.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }

        setColumnCount(1);

        setHeaderLabel("Properties Editor");

        verticalScrollBar()->setSingleStep(1);

        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

        setAlternatingRowColors(true);

        if(test)
        {

            for(int i = 0;i<3;i++)
            {
                QColorEditorWidget * cs  = new QColorEditorWidget;
                cs->setWindowTitle("Color Widget");
                addPropertyPanel(cs);

                QGradientRampWidget *ge = new QGradientRampWidget;
                ge->setWindowTitle("Gradient Ramp");
                addPropertyPanel(ge);

                QVector3DWidget *k =  new QVector3DWidget;
                k->setWindowTitle("Vector 3D");
                addPropertyPanel(k);

                QVector2DWidget *m =  new QVector2DWidget;
                m->setWindowTitle("Vector 2D");
                addPropertyPanel(m);

                QRampCurveWidget *curv =  new QRampCurveWidget;
                curv->setWindowTitle("QRamp Curve Widget");
                addPropertyPanel(curv);
            }
        }
    }

    ~QPropertiesTreeWidget()
    {
        qDeleteAll(itemList);
    }

    virtual void addPropertyPanel(QWidget * panel)
    {
        bool istree = true;

        if(istree)
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(this);

            item->setText(0, panel->windowTitle());

            QTreeWidgetItem * childItem = new QTreeWidgetItem(item);

            setItemWidget(childItem, 0, panel);

            itemList.append(item);
        }
    }

    virtual void removePropertyPanel(QWidget * panel)
    {
        for(int i=0;i<itemList.size();i++)
        {
            QString itemName =  itemList[i]->text(0);

            if(itemName.startsWith(panel->windowTitle()))
            {
                removeItemWidget(itemList[i],0);

                itemList.removeAt(i);

                break;
            }
        }
    }

};
class QPropertiesTreeViewWidget : public QTreeView
{
    Q_OBJECT
public:

    //QList<QTreeWidgetItem*> itemList;

    QList<QStandardItem*> standardItemList;

    QStandardItemModel * model;

    int row;

    QPropertiesTreeViewWidget(bool test = false,QWidget * parent = 0): QTreeView(parent)
    {
        row = 0;
        model = new QStandardItemModel( 0, 2);



        QFile file(":/icons/glowBlue.stylesheet");

        //QFile file(":/icons/styleMain.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }


        //setColumnCount(1);

        //setHeaderLabel("Properties Editor");

        verticalScrollBar()->setSingleStep(1);

        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

        //setAlternatingRowColors(true);

        if(test)
        {

            for(int i = 0;i<3;i++)
            {
                QGradientRampWidget *ge = new QGradientRampWidget;
                ge->setWindowTitle("Gradient Ramp");
                addPropertyPanel(ge);

                QVector3DWidget *k =  new QVector3DWidget;
                k->setWindowTitle("Vector 3D");
                addPropertyPanel(k);

                QVector2DWidget *m =  new QVector2DWidget;
                m->setWindowTitle("Vector 2D");
                addPropertyPanel(m);

                QRampCurveWidget *curv =  new QRampCurveWidget;
                curv->setWindowTitle("QRamp Curve Widget");
                addPropertyPanel(curv);

                QColorEditorWidget * cs  = new QColorEditorWidget;
                cs->setWindowTitle("Color Widget");
                addPropertyPanel(cs);
            }
        }
    }

    ~QPropertiesTreeViewWidget()
    {
        qDeleteAll(standardItemList);
    }

    virtual void addPropertyPanel(QWidget * panel,bool children = true)
    {
        QStandardItem * topLevelItem = new QStandardItem( panel->windowTitle() + QString(": Paremeters") );

        model->appendRow(topLevelItem);

        //model->setItem(row, 0, item);
        //QModelIndex  modelindex= model->index(row, 1, QModelIndex());

        //setIndexWidget(modelindex, panel);

        if(children)
        {
            QList<QStandardItem *> childItems;

            QStandardItem * item1 = new QStandardItem(QString("Parameter"));

            QStandardItem * item2 = new QStandardItem;

            childItems.append(item1);

            childItems.append(item2);

            topLevelItem->appendRow(childItems);

            setIndexWidget(item2->index(), panel);
        }

        setModel(model);

        row++;
    }

    virtual void removePropertyPanel(QWidget * panel)
    {
    }

};


//include search of parameters
class QPropertiesWidget : public QWidget
{
    Q_OBJECT

    QIcon  icon;

    QStandardItemModel * itemModel;

    //QStringListModel * model;

    QLineEdit * lineEdit;
    QListView * listview;
    QTreeWidget * treewidget;

    QPushButton * button;
    QPushButton * applyButton;

    QString selectedText;

    QStringList hitslist;

public:

    QStringList nodeslists;

    QList<QAction*> commandActions;

    QPropertiesWidget(QWidget *parent = 0) : QWidget(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        lineEdit = new QLineEdit;
        listview = new QListView;
        listview->setMaximumHeight(150);
        treewidget = new QTreeWidget;

        button =  new QPushButton;
        button->setIcon(QIcon(QString(":/icons/search_icon.svg")));
        button->setDisabled(true);

        applyButton = new QPushButton;
        applyButton->setIcon(QIcon(QString("../Tools Icons/apply.svg")));
        applyButton->setText(QString("apply"));

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        slayout->addWidget(applyButton);

        QVBoxLayout * layout =  new QVBoxLayout;
        layout->addLayout(slayout);
        layout->addWidget(listview);
        layout->addWidget(treewidget);

        setLayout(layout);

        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(processSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(processSearchResults()));
        connect(applyButton,SIGNAL(clicked(bool)),this,SLOT(processSearchResults()));

        //model     = new QStringListModel;

        itemModel = new QStandardItemModel;

        setWindowTitle(QString("Run Command"));

        setWindowFlags(Qt::FramelessWindowHint);

        setAttribute(Qt::WA_NoSystemBackground);

        setTheme();

        lineEdit->setFocusPolicy(Qt::StrongFocus);

        setFocusPolicy(Qt::ClickFocus);
    }

    ~QPropertiesWidget()
    {
        delete lineEdit;
        delete listview;
        delete button;
        delete applyButton;
    }

    void setTheme()
    {
        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }

        qDebug()<<"Styles Loaded";
    }

    void setFocus()
    {
        lineEdit->setFocus();

        lineEdit->setCursorPosition(0);
    }

    QString getSelectedText()
    {
        return selectedText;
    }



    virtual void setModels(QStringList list)
    {
        nodeslists =  list;

        nodeslists.sort();

        if(itemModel)
        {
            QList<QStandardItem *> items;

            int index =0;

            foreach(QString comm,nodeslists)
            {
                QStandardItem *item = new QStandardItem(comm);

                for(int i =0;i<commandActions.size();i++)
                {
                      if(comm.startsWith(commandActions[i]->text()))
                      {
                          item->setIcon(commandActions[i]->icon());
                      }
                }

                items.append(item);

                index++;
            }

            itemModel->clear();

            itemModel->appendColumn(items);
        }


        if(itemModel)
        {
            listview->setModel(itemModel);
        }
    }

signals:

    void valueChanged(QString filter);

private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            if(itemModel)
            {
                QList<QStandardItem *> items;

                int index =0;

                foreach(QString comm,nodeslists)
                {
                    QStandardItem *item = new QStandardItem(comm);

                    for(int i =0;i<commandActions.size();i++)
                    {
                        if(comm.startsWith(commandActions[i]->text()))
                        {
                            item->setIcon(commandActions[i]->icon());
                        }
                    }

                    items.append(item);

                    index++;
                }

                itemModel->clear();

                itemModel->appendColumn(items);

            }
            /*
            else if(model)
            {
                model->setStringList(nodeslists);
            }
            */
        }
        else
        {
            searchByFilter(lineEdit->text());

            if(itemModel)
            {
                QList<QStandardItem *> items;

                int index =0;

                foreach(QString comm,hitslist)
                {
                    QStandardItem *item = new QStandardItem(comm);

                    for(int i =0;i<commandActions.size();i++)
                    {
                        if(comm.startsWith(commandActions[i]->text()))
                        {
                            item->setIcon(commandActions[i]->icon());
                        }
                    }

                    items.append(item);

                    index++;
                }

                itemModel->clear();

                itemModel->appendColumn(items);

            }
            /*
            else if(model)
                model->setStringList(hitslist);
            */
        }


        if(itemModel)
        {
            listview->setModel(itemModel);
        }
        /*
        else if(model)
        {
           listview->setModel(model);
        }
        */

    }

    void searchByFilter(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    void processSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        foreach(QAction * action,commandActions)
        {
            if(action->text().startsWith(selectedText))
            {
                action->trigger();

                break;
            }
        }

        qDebug()<< index.data().toString();

        this->hide();

        emit valueChanged(selectedText);
    }
};


/*
class QBalloonTip : public QWidget
{
    Q_OBJECT

    QPixmap pixmap;
    int timerId;

    QString _message;
    QString _title;

    QLabel *titleLabel;
    //QPushButton *closeButton;
    QLabel *msgLabel;

public:

    void showBalloon(QPoint p,const QString& title,  const QString& message, int timeout, bool showArrow =true)
    {

        hide();
        _message = message;
        _title = title;

        if(titleLabel)
        {
            titleLabel->setText(_title);
        }
        if(msgLabel)
        {
            msgLabel->setText(_message);
        }


        int limit = QApplication::desktop()->availableGeometry(msgLabel).size().width() / 3;
        if (msgLabel->sizeHint().width() > limit)
        {
            msgLabel->setWordWrap(true);
            msgLabel->setFixedSize(limit, msgLabel->heightForWidth(limit));
        }



        if (timeout < 0)
        timeout = 10000;
        balloon(timeout, showArrow);

        //move(p);
    }

    void showBalloon(int timeout =1000, bool showArrow =true)
    {
        if (timeout < 0)
            timeout = 10000;
        balloon(timeout, showArrow);

        //move(p);
    }

    void hideBalloon()
    {
        hide();
    }

    QBalloonTip(const QString& title, const QString& message,QWidget* parent=0)
        : QWidget(parent, Qt::ToolTip), timerId(-1)
    {
        _message = message;
        _title = title;

        setAttribute(Qt::WA_DeleteOnClose);
        setObjectName(  "QBalloonTip" );

        //QFile File(":/icons/BallonStyle.qss");
        //File.open(QFile::ReadOnly);
        //QString StyleSheet = QString::fromUtf8(File.readAll().data());
        //File.close();
        //setStyleSheet(StyleSheet);


        titleLabel = new QLabel;
        titleLabel->installEventFilter(this);
        titleLabel->setText(_title);
        QFont f = titleLabel->font();
        f.setBold(true);
        titleLabel->setFont(f);
        titleLabel->setTextFormat(Qt::PlainText);

        //closeButton = new QPushButton;
        //closeButton->setIcon(style()->standardIcon(QStyle::SP_DockWidgetCloseButton));
        //closeButton->setIconSize(QSize(18, 18));
        //closeButton->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        //closeButton->setFixedSize(18, 18);
        //QObject::connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));

        msgLabel = new QLabel;
        msgLabel->installEventFilter(this);
        msgLabel->setText(_message);
        msgLabel->setTextFormat(Qt::PlainText);
        msgLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);

        int limit = QApplication::desktop()->availableGeometry(msgLabel).size().width() / 3;
        if (msgLabel->sizeHint().width() > limit)
        {
            msgLabel->setWordWrap(true);
            msgLabel->setFixedSize(limit, msgLabel->heightForWidth(limit));
        }

        QGridLayout *layout = new QGridLayout;

        layout->addWidget(titleLabel, 0, 0, 1, 2);
        //layout->addWidget(closeButton, 0, 2);
        layout->addWidget(msgLabel, 1, 0, 1, 3);
        layout->setSizeConstraint(QLayout::SetFixedSize);
        layout->setMargin(3);

        setLayout(layout);

        QPalette pal = palette();

        pal.setColor(QPalette::Window, QColor(0xff, 0xff, 0xe1));
        setPalette(pal);
    }

    ~QBalloonTip()
    {

    }

private:
    void balloon(int msecs, bool showArrow,QRect rect= QApplication::desktop()->availableGeometry())
    {
        QSize size = sizeHint();
        //QRect desktopRect = QApplication::desktop()->availableGeometry();
        //QRect desktopRect = rect;

        //QPoint bottomRight = desktopRect.bottomRight();
        //const QPoint& pos = mapToGlobal(desktopRect.bottomRight());
        const QPoint& localpos = mapToGlobal(rect.bottomRight());//QPoint(pos);
        const QPoint& pos  = localpos;
        const QRect& prect = rect;

        QRect scr = prect;

        const int border = 1;
        const int ah = 18, ao = 18, aw = 18, rc = 7;

        bool arrowAtTop = (localpos.y() - size.height() - ah < 0);//scr.height());
        bool arrowAtLeft = (localpos.x() + size.width() - ao < scr.width());

        setContentsMargins(border + 3, border + (arrowAtTop ? ah : 0) + 2, border + 3, border + (arrowAtTop ? 0 : ah) + 2);
        updateGeometry();
        size = sizeHint();

        int ml, mr, mt, mb;

        QSize sz = sizeHint();

        if (!arrowAtTop)
        {
            ml = mt = 0;
            mr = sz.width() - 1;
            mb = sz.height() - ah - 1;
        }
        else
        {
            ml = 0;
            mt = ah;
            mr = sz.width() - 1;
            mb = sz.height() - 1;
        }

        QPainterPath path;
        path.moveTo(ml + rc, mt);

        if (arrowAtTop && arrowAtLeft)
        {
            if (showArrow)
            {
                path.lineTo(ml + ao, mt);
                path.lineTo(ml + ao, mt - ah);
                path.lineTo(ml + ao + aw, mt);
            }
            move(qMax(pos.x() - ao, scr.left() + 2), pos.y());

        }
        else if (arrowAtTop && !arrowAtLeft)
        {
            if (showArrow)
            {
                path.lineTo(mr - ao - aw, mt);
                path.lineTo(mr - ao, mt - ah);
                path.lineTo(mr - ao, mt);
            }
            move(qMin(pos.x() - size.width() + ao, scr.right() - size.width() - 2), pos.y());
        }
        path.lineTo(mr - rc, mt);
        path.arcTo(QRect(mr - rc*2, mt, rc*2, rc*2), 90, -90);
        path.lineTo(mr, mb - rc);
        path.arcTo(QRect(mr - rc*2, mb - rc*2, rc*2, rc*2), 0, -90);

        if (!arrowAtTop && !arrowAtLeft)
        {
            if (showArrow)
            {
                path.lineTo(mr - ao, mb);
                path.lineTo(mr - ao, mb + ah);
                path.lineTo(mr - ao - aw, mb);
            }
            move(qMin(pos.x() - size.width() + ao, scr.right() - size.width() - 2),
                        pos.y() - size.height());
        }
        else if (!arrowAtTop && arrowAtLeft)
        {
            if (showArrow)
            {
                path.lineTo(ao + aw, mb);
                path.lineTo(ao, mb + ah);
                path.lineTo(ao, mb);
            }
            move(qMax(pos.x() - ao, scr.x() + 2), pos.y() - size.height());
        }
        path.lineTo(ml + rc, mb);
        path.arcTo(QRect(ml, mb - rc*2, rc*2, rc*2), -90, -90);
        path.lineTo(ml, mt + rc);
        path.arcTo(QRect(ml, mt, rc*2, rc*2), 180, -90);


        if (msecs > 0)
        {
            timerId = startTimer(msecs);
        }
        show();
    }

protected:
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter(this);
        painter.drawPixmap(rect(), pixmap);
    }

    void resizeEvent(QResizeEvent *event)
    {
        QWidget::resizeEvent(event);
    }

    void mousePressEvent(QMouseEvent *e)
    {
        close();
    }

    void timerEvent(QTimerEvent *e)
    {
        if (e->timerId() == timerId)
        {
                killTimer(timerId);

                if (!underMouse())
                    close();
                return;
        }
        QWidget::timerEvent(e);
    }
};


class QBalloonTipEx : public QWidget
{
    Q_OBJECT
public:
    QBalloonTipEx(QWidget *parent = 0):QWidget(parent)
    {
        setAttribute(Qt::WA_TranslucentBackground);
        setWindowFlags(Qt::Window |Qt::FramelessWindowHint);
        resize(200,100);
    }

    ~QBalloonTipEx()
    {

    }

protected:
    void paintEvent(QPaintEvent*)
    {
        QPainter painter(this);
        QPen pen( QColor("orange") );
        pen.setWidth(5);
        painter.setPen(pen);
        QBrush brush(QColor("lightblue"));
        painter.setBrush(brush);

        painter.drawRect(0,0,this->width(), this->height()-50);
        painter.drawRect(0,0,60,this->height());

        pen.setColor(QColor("black"));
        painter.setPen(pen);
        painter.drawText(20,30, "This is a tooltip!");

    }
};

*/

/*
QScopedPointer..

From the Qt 4.6 documentation,

The QScopedPointer class stores a pointer to a
dynamically allocated object, and deletes it
 upon destruction. Managing heap allocated objects
manually is hard and error prone, with the common
result that code leaks memory and is hard to maintain.
QScopedPointer is a small utility class that heavily
simplifies this by assigning stack-based memory ownership
to heap allocations, more generally called resource
acquisition is initialization(RAII).

For Example,

You will use,

QScopedPointer<QWidget> p(new QWidget());
instead of

QWidget *p = new QWidget();
and add the QScopedPointer into your QList
without worrying about memory leak and
dangling pointers.


so the inner loop looks like this:
QScopedPointer<MyObject> obj(new MyObject());
if (obj->Init(map.values(i)) { list.append(obj.take()); } ...



The scoped ptr still OWNS the instance,
thats why i used .take().

QScopedPointer is non-copyable and can therefore not be added to a QList.


Qt’s smart pointer classes are neatly grouped now as follows:

///Shared data
QSharedDataPointer,
QExplicitlySharedDataPointer
Sharing of data (not of pointers),
implicitly and explicitly. Also known as “intrusive pointers”.


Shared pointers
QSharedPointer,
QWeakPointer	Thread-safe sharing pointers,
like C++11′s std::shared_ptr only with a nice Qt API


Scoped pointers
QScopedPointer,
QScopedPointerArray	For RAII usage:
takes ownership of a pointer and ensures it is
properly deleted at the end of the scope. No sharing.


Tracking
QObjects
QPointer
Tracks the lifetime of a given QObject instance

*/



#endif // CUSTOMNWIDGETS_H













