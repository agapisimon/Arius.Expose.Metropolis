#ifndef HANDLES_HPP
#define HANDLES_HPP

#include<QtWidgets>
#include<geometry.hpp>
#include<models.hpp>



class QSelectionInfo : public QObject
{
    Q_OBJECT

    QQueue<QBaseModel *> queue;

public:

    QSelectionInfo(QObject * parent =0):QObject(parent){}

    ~QSelectionInfo()
    {
        qDeleteAll(queue);
    }

    QVector3D getSelectionCenter()
    {
        QVector3D center(0,0,0);

        for(int i=0;i<queue.size();i++)
        {
            QBaseModel * model = queue[i];

            center+= model->position;
        }

        center/= queue.size();

        return center;
    }

    int size()
    {
        return queue.size();
    }

    QBaseModel * getSelectedModel()
    {
        return queue.last();
    }

    QVector<QBaseModel *> getSelectedModels()
    {
        return queue.toVector();
    }

signals:

    void selectionChanged();

    void selectionCleared();

public slots:

    void addSelectedModel(QBaseModel * model)
    {
        bool found = false;

        foreach(QBaseModel * m,queue.toVector())
        {
            if(m->ID ==model->ID)
            {
                found = true;
            }
        }

        if(found== false)
        {
            queue.append(model);

            qDebug()<<"Selected Models:"<<queue.size();
        }

        emit selectionChanged();
    }

    void addModels(QList<QBaseModel *>&models)
    {
        if(models.size()>0 && queue.size()==0)
        {
            clearSelection();

            foreach(QBaseModel * m,models)
            {
                queue.append(m);
            }
        }
        else if(queue.size()>0)
        {
            clearSelection();
        }

        emit selectionChanged();
    }

    void clearSelection()
    {
        //qDeleteAll(queue);
        queue.clear();

        emit selectionCleared();
    }
};


class HandleController : public QObject
{
    Q_OBJECT


public:

    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

            const float*r = mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }



    enum SCREEN_SPACE
    {
        LOCATE_VIEW,
        LOCATE_WORLD,
        LOCATE_LOCAL,
    };




    QTransformMode TransformMode;

    QTrans PlaneAXesMode;

    bool mousePressed;


    QAabb Xbox;
    QAabb Ybox;
    QAabb Zbox;

    QAabb XZbox;
    QAabb YZbox;
    QAabb XYbox;

    QAabb SCREENbox;

    QList<QBaseModel *> models;

    QSelectionInfo * currentSelection;

    QVector3D prevhitpoint;
    QVector3D alternateCenter;

    QVector3D position;
    QVector3D rotation;
    QVector3D scale;

    HandleController(QObject * parent =0):QObject(parent) { }

    ~HandleController()
    {
        delete currentSelection;
    }


    virtual void setTransformMode( QTransformMode & TransformMode)
    {
        this->TransformMode =  TransformMode;
    }
    virtual void setTransPlaneAxes( QTrans & PlaneAXesMode)
    {
        this->PlaneAXesMode =  PlaneAXesMode;
    }
    virtual void setModelsList( QList<QBaseModel *> & models)
    {
        this->models = models;
    }
    virtual void setHitInfo( QSelectionInfo * currentSelectionInfo)
    {
        this->currentSelection = currentSelectionInfo;
    }


    virtual void rayPlaneIntersection(int x, int y)
    {

    }
    virtual void rayBoxAXesIntersection(int x, int y)
    {

    }
    virtual void rayPlaneIntersection(QPoint delta)
    {

    }

    virtual void drawSelectionQAaBB()
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);

        if(mousePressed)
        {
            if(PlaneAXesMode ==X)
            {
                this->Xbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Z)
            {
                this->Zbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Y)
            {
                this->Ybox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==XY)
            {
                this->XYbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==ZX)
            {
                this->XZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==YZ)
            {
                this->YZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==SCREEN)
            {
                this->SCREENbox.draw(Qt::cyan);
            }
        }
        else
        {
            this->Xbox.draw(Qt::cyan);
            this->Zbox.draw(Qt::cyan);
            this->Ybox.draw(Qt::cyan);

            this->XYbox.draw(Qt::cyan);
            this->XZbox.draw(Qt::cyan);
            this->YZbox.draw(Qt::cyan);

            this->SCREENbox.draw(Qt::cyan);
        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }
    virtual void screenfactorScale()
    {

    }
    virtual void drawGizmo(QGLWidget* widget)
    {        
    }

    virtual void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
    }

    /*
    void DrawCircle(const QVector3D &orig,float r,float g,float b,const QVector3D &vtx,const QVector3D &vty)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor4f(r,g,b,1);

        glBegin(GL_LINE_LOOP);

        for (int i = 0; i < 50 ; i++)
        {
            QVector3D vt;

            vt  = vtx * cos((2*M_PI/50)*i);
            vt += vty * sin((2*M_PI/50)*i);
            vt += orig;

            glVertex3f(vt.x(),vt.y(),vt.z());
        }
        glEnd();
    }


    void DrawCircleHalf(const QVector3D &orig,
                        float r,float g,float b,
                        const QVector3D &vtx,
                        const QVector3D &vty,
                        QPlane &camPlan)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor4f(r,g,b,1);

        glBegin(GL_LINE_STRIP);

        for (int i = 0; i < 30 ; i++)
        {
            QVector3D vt;

            vt = vtx * cos((M_PI/30)*i);
            vt += vty * sin((M_PI/30)*i);
            vt +=orig;

            if (camPlan.DotNormal(vt))
            {
                glVertex3f(vt.x(),vt.y(),vt.z());
            }
        }
        glEnd();
    }

    void DrawAxis(const QVector3D &orig,
                  const QVector3D &axis,
                  const QVector3D &vtx,
                  const QVector3D &vty,
                  float fct,float fct2,
                  const QColor &color)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor4f(color.redF(),color.greenF(),color.blueF(),color.alphaF());
        glBegin(GL_LINES);
        glVertex3f(orig.x(),orig.y(),orig.z());
        glVertex3f(orig.x()+axis.x(),orig.y()+axis.y(),orig.z()+axis.z());
        glEnd();

        glBegin(GL_TRIANGLE_FAN);

        for (int i=0;i<=30;i++)
        {
            QVector3D pt;
            pt = vtx * cos(((2*M_PI)/30.0f)*i)*fct;
            pt+= vty * sin(((2*M_PI)/30.0f)*i)*fct;

            pt+=axis*fct2;
            pt+=orig;
            glVertex3f(pt.x(),pt.y(),pt.z());
            pt = vtx * cos(((2*M_PI)/30.0f)*(i+1))*fct;
            pt+= vty * sin(((2*M_PI)/30.0f)*(i+1))*fct;
            pt+=axis*fct2;
            pt+=orig;
            glVertex3f(pt.x(),pt.y(),pt.z());
            glVertex3f(orig.x()+axis.x(),orig.y()+axis.y(),orig.z()+axis.z());

        }
        glEnd();

    }

    void DrawCamem(const QVector3D& orig,const QVector3D& vtx,const QVector3D& vty,float ng)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        int i = 0 ;
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDisable(GL_CULL_FACE);


        glColor4f(1,1,0,0.5f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(orig.x(),orig.y(),orig.z());
        for (i = 0 ; i <= 50 ; i++)
        {
            QVector3D vt;
            vt = vtx * cos(((ng)/50)*i);
            vt += vty * sin(((ng)/50)*i);
            vt+=orig;
            glVertex3f(vt.x(),vt.y(),vt.z());
        }
        glEnd();

        glDisable(GL_BLEND);


        glColor4f(1,1,0.2f,1);
        QVector3D vt;
        glBegin(GL_LINE_LOOP);

        glVertex3f(orig.x(),orig.y(),orig.z());
        for ( i = 0 ; i <= 50 ; i++)
        {
            QVector3D vt;
            vt = vtx * cos(((ng)/50)*i);
            vt += vty * sin(((ng)/50)*i);
            vt+=orig;
            glVertex3f(vt.x(),vt.y(),vt.z());
        }

        glEnd();
    }

    void DrawQuad(const QVector3D& orig, float size, bool bSelected, const QVector3D& axisU, const QVector3D &axisV)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDisable(GL_CULL_FACE);

        QVector3D pts[4];
        pts[0] = orig;
        pts[1] = orig + (axisU * size);
        pts[2] = orig + (axisU + axisV)*size;
        pts[3] = orig + (axisV * size);

        if (!bSelected)
            glColor4f(1,1,0,0.5f);
        else
            glColor4f(1,1,1,0.6f);

        glBegin(GL_QUADS);
        glVertex3f(pts[0].x(),pts[0].y(),pts[0].z());
        glVertex3f(pts[1].x(),pts[1].y(),pts[1].z());
        glVertex3f(pts[2].x(),pts[2].y(),pts[2].z());
        glVertex3f(pts[3].x(),pts[3].y(),pts[3].z());
        glEnd();

        if (!bSelected)
            glColor4f(1,1,0.2f,1);
        else
            glColor4f(1,1,1,0.6f);

        glBegin(GL_LINE_STRIP);
        glVertex3f(pts[0].x(),pts[0].y(),pts[0].z());
        glVertex3f(pts[1].x(),pts[1].y(),pts[1].z());
        glVertex3f(pts[2].x(),pts[2].y(),pts[2].z());
        glVertex3f(pts[3].x(),pts[3].y(),pts[3].z());
        glEnd();

        glDisable(GL_BLEND);
    }
    void DrawTri(const QVector3D& orig, float size, bool bSelected, const QVector3D& axisU, const QVector3D& axisV)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDisable(GL_CULL_FACE);

        QVector3D pts[3];
        pts[0] = orig;

        pts[1] = (axisU );
        pts[2] = (axisV );

        pts[1]*=size;
        pts[2]*=size;
        pts[1]+=orig;
        pts[2]+=orig;

        if (!bSelected)
            glColor4f(1,1,0,0.5f);
        else
            glColor4f(1,1,1,0.6f);

        glBegin(GL_TRIANGLES);
        glVertex3f(pts[0].x(),pts[0].y(),pts[0].z());
        glVertex3f(pts[1].x(),pts[1].y(),pts[1].z());
        glVertex3f(pts[2].x(),pts[2].y(),pts[2].z());
        glVertex3f(pts[3].x(),pts[3].y(),pts[3].z());
        glEnd();

        if (!bSelected)
            glColor4f(1,1,0.2f,1);
        else
            glColor4f(1,1,1,0.6f);

        glBegin(GL_LINE_STRIP);
        glVertex3f(pts[0].x(),pts[0].y(),pts[0].z());
        glVertex3f(pts[1].x(),pts[1].y(),pts[1].z());
        glVertex3f(pts[2].x(),pts[2].y(),pts[2].z());
        glEnd();

        glDisable(GL_BLEND);
    }

    */

};
class HandleMoveController : public HandleController
{
public:

    enum MOVETYPE
    {
        MOVE_X,
        MOVE_Y,
        MOVE_Z,

        MOVE_XY,
        MOVE_XZ,
        MOVE_YZ,

        MOVE_XYZ,
        MOVE_NONE,
    };

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;

    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleMoveController(QObject * parent): HandleController(parent)
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |(0,0,0)
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //------------------------------

        QVector3D v0 = QVector3D(0,0,0);
        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);

        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);

        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);

        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));

        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));

        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));

        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-0.5,-0.5,-0.5),QVector3D(0.5,0.5,0.5));

        //XZbox.reScale(1.5);
        //XYbox.reScale(1.5);
        //YZbox.reScale(1.5);

        //SCREENbox.reScale(0.05);
    }

    ~HandleMoveController() { }


    QPoint lastP;

    //----- Ray plane intersection--------------------------
    void rayPlaneIntersection(int x,int y)
    {
        QPoint pp(x,y);

        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QPlane plane;
            plane.center = model->position;
            plane.axesAlignment = PlaneAXesMode;

            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
            }

            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            if(PlaneAXesMode==SCREEN)
            {
                plane.normal = (-1.0f * ray.direction);
            }


            QVector3D hitPoint = ray.getRayPlaneIntersection(plane);

            if(ray.hitStatus == 1)
            {
                //printf("Plane Intersection x:%f,y:%f,z:%f \n",hitPoint.x,hitPoint.y,hitPoint.z);

                QVector3D prev = model->position;

                //prev = alternateCenter - prev;

                if(PlaneAXesMode==X)
                {
                    model->position = QVector3D(hitPoint.x(),prev.y(),prev.z());
                }

                if(PlaneAXesMode==Y)
                {
                    model->position = QVector3D(prev.x(),hitPoint.y(),prev.z());
                }

                if(PlaneAXesMode==Z)
                {
                    model->position = QVector3D(prev.x(),prev.y(),hitPoint.z());
                }

                if(PlaneAXesMode==ZX||PlaneAXesMode==XY||PlaneAXesMode==YZ||PlaneAXesMode ==SCREEN)
                {
                    model->position = hitPoint;
                }
            }            
        }
    }
    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D r = model->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);


            bool  intersected = box.intersectRay(view.p0,view.direction);

            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }

            lastP = QPoint(x,y);
        }
    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );
            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);
            glVertex3f(0,0,0);

            glEnd();


            if( TransformMode == MOVE)
            {
                 drawTranslationGizmo(widget);

                 drawSelectionQAaBB();
            }

            glPopMatrix();           

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }

    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            QBaseModel * model = currentSelection->getSelectedModel();

            QMatrix4x4 PVM  = PV * model->worldMatrix;

            qMultMatrix(PVM);

            //QVector3D v = model->position;
            //QVector3D s = model->scale;
            //QVector3D r = model->rotation;

            //glTranslatef( v.x(), v.y(), v.z() );

            //glRotatef(r.x(),1,0,0);
            //glRotatef(r.y(),0,1,0);
            //glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            //glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();


            if( TransformMode == MOVE )
            {
                 drawTranslationGizmo(widget);

                 drawSelectionQAaBB();
            }

            glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }


    virtual void drawTranslationGizmo(QGLWidget* widget, bool drawarrows = true)
    {
        QArrow arrow;

        if(drawarrows)
        {
            arrow.drawArrow(XY);
            arrow.drawArrow(ZX);
            arrow.drawArrow(YZ);
        }

        if(axesplanes.size() >0)
        {
            for(int i =0;i<axesplanes.size();i++)
            {
                axesplanes[i].drawPlane();
            }
        }

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);


        glLineWidth(3);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[1].x(),vertices[1].y(),vertices[1].z());

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[2].x(),vertices[2].y(),vertices[2].z());

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[3].x(),vertices[3].y(),vertices[3].z());
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr("X");
        QString ystr("Y");
        QString zstr("Z");

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.3f, 0.0f, 0.0f,xstr,font);

        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.3f, 0.0f,ystr,font);

        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.3f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }


};
class HandleScaleController : public HandleController
{
public:

    enum SCALETYPE
    {        
        SCALE_X,
        SCALE_Y,
        SCALE_Z,
        SCALE_XY,
        SCALE_XZ,
        SCALE_YZ,
        SCALE_XYZ,
        SCALE_NONE,
    };

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;


    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleScaleController(QObject * parent):HandleController(parent)
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //----------------------------


        QVector3D v0 = QVector3D(0,0,0);

        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);

        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);

        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);


        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));


        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));


        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));



        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-.5,-.5,-.5),QVector3D(0.5,0.5,0.5));



        XZbox.reScale();
        XYbox.reScale();
        YZbox.reScale();

    }

    ~HandleScaleController()
    {
        //qDeleteAll(axesplanes);
        //qDeleteAll(vertices);
    }





    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;

            QPoint p = QCursor::pos();
            QRay view;
            view.rayCastScene(p.x(),p.y());

            QPlane plane;
            plane.center = v;
            plane.axesAlignment = PlaneAXesMode;


            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = X;
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = Y;
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = Z;
            }

            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = ZX;
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = XY;
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
                plane.axesAlignment = YZ;
            }

            if(PlaneAXesMode==SCREEN || PlaneAXesMode==UNIFORM)
            {
                plane.normal = (-1.0f*view.direction);
                plane.axesAlignment = SCREEN;
            }

            QVector3D pScale = model->scale;

            float scale  = QVector2D(delta.x(),delta.y()).length();

            float sign;

            if(delta.x() ==0)
            {
            }
            else
            {
                sign =  (float)delta.x()/fabs((float)delta.x());
            }

            scale *= 0.01f;
            scale *= sign;

            qDebug()<<"Delta Scale:"<<scale<<"sign:"<<sign;

            if(PlaneAXesMode==X)
            {
                model->scale = pScale + QVector3D(1,0,0) *scale;
            }

            if(PlaneAXesMode==Y)
            {
                model->scale = pScale + QVector3D(0,1,0)  *scale;
            }

            if(PlaneAXesMode==Z)
            {
                model->scale = pScale + QVector3D(0,0,1)  *scale;
            }

            if(PlaneAXesMode==ZX)
            {
                model->scale = pScale + QVector3D(1,0,1)  *scale;
            }

            if(PlaneAXesMode==XY)
            {
                model->scale = pScale + QVector3D(1,1,0)  *scale;
            }

            if(PlaneAXesMode==YZ)
            {
                model->scale = pScale + QVector3D(0,1,1)  *scale;
            }

            if(PlaneAXesMode ==SCREEN)
            {
                QVector3D viewDirection = (-1.0f*view.direction);

                model->scale = pScale + viewDirection *scale;
            }

            if(PlaneAXesMode ==UNIFORM)
            {
               model->scale =  pScale + QVector3D(1,1,1)  *scale;

            }

            model->computeBounds();
        }
    }

    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D r = model->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);
            bool  intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }
        }
    }


    void drawScaleGizmo(QGLWidget* widget)
    {
        //sdisk.drawDisk(true,ZX);
        //sdisk.drawDisk(true,XY);
        //sdisk.drawDisk(true,YZ);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(2);


        glBegin(GL_LINES);
            glColor3f(1.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(1.0f, 0.0f, 0.0f);

            glColor3f(0.0f, 1.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 1.0f, 0.0f);

            glColor3f(0.0f, 0.0f, 1.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 1.0f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.0f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.0f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.0f,zstr,font);


        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );



            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==SCALE)
            {
                drawScaleGizmo(widget);
                drawSelectionQAaBB();
            }

            glPopMatrix();           

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }    


    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            //QBaseModel * model = currentSelection->getSelectedModel();

            //QVector3D v = model->position;
            //QVector3D s = model->scale;
            //QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            //glTranslatef( v.x(), v.y(), v.z() );

            //glRotatef(r.x(),1,0,0);
            //glRotatef(r.y(),0,1,0);
            //glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            //glScalef( 1, 1, 1 );

            QBaseModel * model = currentSelection->getSelectedModel();

            QMatrix4x4 PVM  = PV * model->localMatrix ;

            qMultMatrix(PVM);


            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==SCALE)
            {
                drawScaleGizmo(widget);
                drawSelectionQAaBB();
            }

            glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }


};
class HandleRotationController : public HandleController
{
public:

    enum ROTATETYPE
    {
        ROTATE_X,
        ROTATE_Y,
        ROTATE_Z,        
        ROTATE_SCREEN,
        ROTATE_TRACKBALL,
        ROTATE_NONE,
    };

    QList<QVector3D>YAxisCircle;
    QList<QVector3D>XAxisCircle;
    QList<QVector3D>ZAxisCircle;

    QList<QVector3D>SCREENCircle;

    HandleRotationController(QObject * parent):HandleController(parent)
    {
        mousePressed = false;

        float Count  = 90.0f;

        float radius = 1.0f;

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius*sin(angle);
            float y = 0;
            float z = radius*cos(angle);

            QVector3D p = QVector3D(x,y,z);

            YAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = 0;
            float y = radius * sin(angle);
            float z = radius * cos(angle);

            QVector3D p = QVector3D(x,y,z);

            XAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius * cos(angle);
            float y = radius * sin(angle);
            float z = 0;

            QVector3D p = QVector3D(x,y,z);

            ZAxisCircle.append(p);
        }

        /*

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius * sin(angle);
            float y = radius * cos(angle);
            float z = 0;

            QVector3D p = QVector3D(x,y,z);

            SCREENCircle.append(p);
        }

        printf("SCREENCircle vertices Count: %i",SCREENCircle.size());

        */

    }


    ~HandleRotationController(){}


    void generateScreenCircle()
    {
        SCREENCircle.clear();

        float Count  = 90.0f;
        float radius = 1.0f;

        QRay ray;
        ray.rayCastScene(100.0f,100.0f);

        QVector3D normal =  QVector3D::crossProduct(QVector3D(0,1,0),ray.direction);

        for(float i=0;i<Count;i+=1)
        {
            float angle      = 360.0f * i/Count;

            QQuaternion quat = QQuaternion::fromAxisAndAngle(ray.direction,angle);

            QVector3D p      = quat.rotatedVector(normal);

            SCREENCircle.append(p);
        }
    }
    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
           QBaseModel * model = currentSelection->getSelectedModel();

           QVector3D prevRotation = model->rotation;

           QVector3D pScale       = model->scale;

           float rot  = QVector2D(delta.x(),delta.y()).length();

           float sign;

           if(delta.x() ==0)
           {
           }
           else
           {
               sign =  (float)delta.x()/fabs((float)delta.x());
           }

           rot *= 0.5f;
           rot *= sign;


           //float length = sqrt(delta.x()*delta.x()+delta.y()*delta.y());


           if(PlaneAXesMode==X)
           {
               model->rotation = prevRotation + QVector3D(0,rot,0);
           }

           if(PlaneAXesMode==Y)
           {
               model->rotation = prevRotation + QVector3D(rot,0,0);
           }

           if(PlaneAXesMode==Z)
           {
                model->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode ==SCREEN)
           {
                //model->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode == TRACKBALL)
           {
               model->rotation = prevRotation + QVector3D(delta.y(),delta.x(),0);

           }
        }
    }

    void rayBoxAXesIntersection(int x,int y)
    {
        float cursorselectionRadius = 0.2f;

        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D p = model->position;

            QRay view;

            view.rayCastScene(x,y);

            QVector3D r = model->rotation;


            QMatrix4x4 rotMat;
            rotMat.setToIdentity();
            rotMat.rotate(r.x(),QVector3D(1,0,0));
            rotMat.rotate(r.y(),QVector3D(0,1,0));
            rotMat.rotate(r.z(),QVector3D(0,0,1));


            foreach( QVector3D v, YAxisCircle)
            {
               QVector3D vert = rotMat*v+p;

               if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
               {
                   PlaneAXesMode = X;

                   mousePressed = true;

                   qDebug()<<"Y-Axis Rotation";

                   return;
               }
            }

            foreach( QVector3D v, XAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Y;

                    mousePressed = true;

                    qDebug()<<"X-Axis Rotation";
                    return;
                }
            }

            foreach( QVector3D v, ZAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Z;                    
                    mousePressed = true;

                    qDebug()<<"Z-Axis Rotation";
                    return;
                }

            }

            /*



            foreach( QVector3D v, SCREENCircle)
            {
                QRay CamView;

                CamView.rayCastScene(x,y);



                QMatrix4x4 m;

                m.setToIdentity();

                m.rotate(QQuaternion(,CamView.direction));

                QVector3D vert = m*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = SCREEN;

                    mousePressed = true;

                    qDebug()<<"SCREEN-Axis Rotation";

                    return;
                }

            }

            */
        }
    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==ROTATION)
            {
                drawRotationGizmo(widget);
            }

            glPopMatrix();

            /*

            glColor3f( .3, .3, .3 );
            QString str("Pos:(");

            str += QString::number(v.x());str +=QString(",");
            str += QString::number(v.y());str +=QString(",");
            str += QString::number(v.z());str +=QString(")");

            widget->renderText(v.x()-1,v.y(),v.z(),str);

            */

            glEnable(GL_DEPTH_TEST);

            glEnable(GL_LIGHTING);
        }
    }

    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            //QVector3D v = model->position;
            //QVector3D s = model->scale;
            //QVector3D r = model->rotation;

            //glTranslatef( v.x(), v.y(), v.z() );

            //glRotatef(r.x(),1,0,0);
           // glRotatef(r.y(),0,1,0);
            //glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            //glScalef( 1, 1, 1 );

            QBaseModel * model = currentSelection->getSelectedModel();

            QMatrix4x4 PVM  = PV * model->localMatrix ;

            qMultMatrix(PVM);

            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==ROTATION)
            {
                drawRotationGizmo(widget);
            }

            glPopMatrix();

            /*

            glColor3f( .3, .3, .3 );
            QString str("Pos:(");

            str += QString::number(v.x());str +=QString(",");
            str += QString::number(v.y());str +=QString(",");
            str += QString::number(v.z());str +=QString(")");

            widget->renderText(v.x()-1,v.y(),v.z(),str);

            */

            glEnable(GL_DEPTH_TEST);

            glEnable(GL_LIGHTING);
        }
    }


    void drawRotationGizmo(QGLWidget* widget)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(1);

        if(PlaneAXesMode==Y)
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,0,0),false);
        }


        if(PlaneAXesMode==X)
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(0,1,0),false);

        }


        if(PlaneAXesMode==Z)
        {

            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(0,0,1),false);

        }


        /*

        if(PlaneAXesMode==SCREEN)
        {

            generateScreenCircle();


            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {

            generateScreenCircle();

            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(0,1,1),false);

        }

        */


        glLineWidth(2);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.5f, 0.0f, 0.0f);

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.5f, 0.0f);

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.5f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(0.5f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 0.5f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 0.5f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    void drawCirle( QList<QVector3D> &points,
                    QVector3D center = QVector3D(0,0,0),
                    QColor color     = QColor(1,1,1),
                    bool selected   = false,
                    bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);
        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }


        //glEnable(GL_CULL_FACE);

        glBegin(GL_LINE_LOOP);

        for(int i=0;i<points.size();i++)
        {
            QVector3D p = points[i]+center;

            glVertex3f(p.x(),p.y(),p.z());
        }

        glEnd();
        //glDisable(GL_CULL_FACE);


        if(drawPoints)
        {
           glPointSize(2.0f);

           glBegin(GL_POINTS);

           for(int i=0;i<points.size();i++)
           {
               QVector3D p = points[i]+center;

               glVertex3f(p.x(),p.y(),p.z());
           }

           glEnd();
        }
    }

    void drawScreen( QList<QVector3D> &points,
                     QVector3D center = QVector3D(0,0,0),
                     QColor color = QColor(1,1,1),
                     bool selected = false,
                     bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);
        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }

        glBegin(GL_LINE_LOOP);

        for(int i=0;i<points.size();i++)
        {
           QVector3D p =  points[i] + center;

           glVertex3f(p.x(),p.y(),p.z());
        }

        glEnd();
    }
};
class AxesTransformer : public QObject
{
    Q_OBJECT

public:

    HandleController *gizmo,*gizmoMove,*gizmoScale,*gizmoRotation;

    QActionGroup * handlesActiongroups;

    QString feedBack;
    QIcon icon;

    QTrans PlaneAXesMode;
    QTransformMode TransformMode;

    QMenu transformsAxisMenu;
    QMenu transformMenu;

    //QVector3D p0;

    void createActions()
    {
        handlesActiongroups = new QActionGroup(this);

        QAction * b1 = new QAction(QIcon(":/Tools Icons/select.svg"),QString("Select: Shift+G"),this);

        QAction * b2 = new QAction(QIcon(":/Tools Icons/Translate.svg"),QString("Move: Shift+T"),this);
        QAction * b3 = new QAction(QIcon(":/Tools Icons/Scale.svg"),QString("Scale: Shift+R"),this);
        QAction * b4 = new QAction(QIcon(":/Tools Icons/Rotate.svg"),QString("Rotate: Shift+S"),this);
        QAction * b5 = new QAction(QIcon(":/Tools Icons/icon pivot.svg"),QString("set Pivot: Shift+P"),this);

        b1->setCheckable(true); b1->setShortcut(Qt::SHIFT|Qt::Key_G);

        b2->setCheckable(true); b2->setShortcut(Qt::SHIFT|Qt::Key_T);
        b3->setCheckable(true); b3->setShortcut(Qt::SHIFT|Qt::Key_R);
        b4->setCheckable(true); b4->setShortcut(Qt::SHIFT|Qt::Key_S);
        b5->setCheckable(true); b5->setShortcut(Qt::SHIFT|Qt::Key_P);

        connect(b1, SIGNAL(triggered(bool)), this, SLOT(setSelect()));

        connect(b2, SIGNAL(triggered(bool)), this, SLOT(setMove()));
        connect(b3, SIGNAL(triggered(bool)), this, SLOT(setScale()));
        connect(b4, SIGNAL(triggered(bool)), this, SLOT(setRotation()));
        connect(b5, SIGNAL(triggered(bool)), this, SLOT(setPivot()));


        b1->setEnabled(true);
        b1->setChecked(true);

        handlesActiongroups->addAction(b1);

        handlesActiongroups->addAction(b2);
        handlesActiongroups->addAction(b3);
        handlesActiongroups->addAction(b4);
        handlesActiongroups->addAction(b5);

        handlesActiongroups->setExclusive(true);
    }

    void createTransformMenues()
    {
        transformMenu.addAction(icon,QString("Move"),this,SLOT(setMove()),QKeySequence(Qt::Key_T));
        transformMenu.addAction(icon,QString("Rotation"),this,SLOT(setRotation()),QKeySequence(Qt::Key_R));
        transformMenu.addAction(icon,QString("Scale"),this,SLOT(setScale()),QKeySequence(Qt::Key_E));
        transformMenu.addAction(icon,QString("Freeze"),this,SLOT(setFreeze()),QKeySequence(Qt::Key_Q));

        transformMenu.setTitle(QString("Set Transform Mode"));
        transformMenu.setIcon(icon);

        setTheme(transformMenu);

    }

    void createAxisTransformMenues()
    {
        transformsAxisMenu.addAction(icon,QString("X"),this,SLOT(setAxisX()));
        transformsAxisMenu.addAction(icon,QString("Y"),this,SLOT(setAxisY()));
        transformsAxisMenu.addAction(icon,QString("Z"),this,SLOT(setAxisZ()));

        transformsAxisMenu.addAction(icon,QString("XY"),this,SLOT(setAxisXY()));
        transformsAxisMenu.addAction(icon,QString("XZ"),this,SLOT(setAxisXZ()));
        transformsAxisMenu.addAction(icon,QString("YZ"),this,SLOT(setAxisYZ()));

        transformsAxisMenu.addAction(icon,QString("Screen"),this,SLOT(setAxisScreen()));
        transformsAxisMenu.addAction(icon,QString("UNIFORM"),this,SLOT(setAxisUniform()));

        transformsAxisMenu.setTitle(QString("Set Axis Transform Mode"));
        transformsAxisMenu.setIcon(icon);

        setTheme(transformsAxisMenu);
    }


    AxesTransformer(QObject *parent=0):QObject(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        TransformMode = MOVE;
        PlaneAXesMode = ZX;

        feedBack.append("Move:");

        gizmoMove     = new HandleMoveController(parent);
        gizmoScale    = new HandleScaleController(parent);
        gizmoRotation = new HandleRotationController(parent);

        gizmoMove->TransformMode      = TransformMode;
        gizmoScale->TransformMode     = TransformMode;
        gizmoRotation->TransformMode  = TransformMode;

        gizmo = gizmoMove;

        createAxisTransformMenues();
        createTransformMenues();
        createActions();
        //setFeedBack();
    }



    void setTheme(QWidget & widget)
    {
        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           widget.setStyleSheet(style);
        }

        file.close();
    }


    virtual void drawGizmo(QGLWidget * parentWidget)
    {
        if(handlesActiongroups->actions()[0]->isChecked())
        {

        }
        else if(handlesActiongroups->actions()[1]->isChecked()||
                handlesActiongroups->actions()[2]->isChecked())
        {
            gizmo->drawGizmo(parentWidget);
        }
        else if(handlesActiongroups->actions()[3]->isChecked())
        {
            //gizmo->drawGizmo(parentWidget);

            drawPivot();

        }
    }


    virtual void drawGizmo(QMatrix4x4 PV,QGLWidget * parentWidget)
    {
        if(handlesActiongroups->actions()[0]->isChecked())
        {

        }
        else if(handlesActiongroups->actions()[1]->isChecked()||
                handlesActiongroups->actions()[2]->isChecked())
        {
            gizmo->drawGizmo(PV,parentWidget);
        }
        else if(handlesActiongroups->actions()[3]->isChecked())
        {
            //gizmo->drawGizmo(parentWidget);

            drawPivot();

        }
    }


    QVector3D pivotPositon;
    QPlane pivotPlane;

    void computePivot()
    {
        QRay ray;

        pivotPositon = ray.getRayPlaneIntersection(pivotPlane);

        qDebug()<<"Pivot Point"<<pivotPositon;
    }

    void drawPivot()
    {
        pivotPlane.axesAlignment = ZX;
        pivotPlane.normal = QVector3D(0,1,0);
        pivotPlane.center = pivotPositon;
        pivotPlane.drawPlane(2.0f);
    }

    virtual void computeGizimo( QList<QBaseModel*> &models,QPoint lastPos,QSelectionInfo * currentSelectionInfo)
    {
        if(handlesActiongroups->actions()[0]->isChecked())
        {

        }
        else if(handlesActiongroups->actions()[1]->isChecked()||
                handlesActiongroups->actions()[2]->isChecked())
        {
            gizmo->mousePressed =  true;

            gizmo->setTransPlaneAxes(PlaneAXesMode);
            gizmo->setHitInfo(currentSelectionInfo);
            gizmo->setModelsList(models);
            gizmo->rayBoxAXesIntersection(lastPos.x(),lastPos.y());
        }
        else if(handlesActiongroups->actions()[3]->isChecked())
        {
            computePivot();
        }
    }

    virtual void gizmoRelease()
    {
        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->mousePressed =  false;
        }
    }

    virtual void getGizmoTransforms(QMouseEvent* event,QPoint delta)
    {
        QPoint c = event->pos();

        if(event->buttons() & Qt::LeftButton  && event->modifiers() & Qt::ShiftModifier)
        //if(event->buttons() & Qt::LeftButton  && event->modifiers() & Qt::ControlModifier)
        {
            //QApplication::desktop()->setCursor(Qt::SizeAllCursor);

            if(!handlesActiongroups->actions()[0]->isChecked())
            {
                if(TransformMode==MOVE||TransformMode==ROTATION)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE)
                {
                    //qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }
            }
        }
        else if(event->buttons() & Qt::LeftButton )
        {
            if(!handlesActiongroups->actions()[0]->isChecked())
            {
                /*
                if(PlaneAXesMode==SCREEN || PlaneAXesMode == UNIFORM)
                {
                    QApplication::desktop()->setCursor(Qt::SizeAllCursor);
                }
                else if(PlaneAXesMode==XYZ_NONE)
                {

                    QApplication::desktop()->setCursor(Qt::ArrowCursor);
                }
                else
                {
                    QApplication::desktop()->setCursor(Qt::BlankCursor);
                }

                //QTextCursor cursor(editor->textCursor());
                //gizmo->rayPlaneIntersection(c.x(),c.y());

                */
                if(TransformMode==MOVE)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE||TransformMode==ROTATION)
                {
                    //qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }


            }
        }
    }

    virtual void setTransformMode(QKeyEvent * event)
    {
        feedBack.clear();

        if(event->key()==Qt::Key_Q)
        {
            setSelect();
        }
        else if(event->key()==Qt::Key_R)
        {
            setRotation();
        }
        else if(event->key()==Qt::Key_T)
        {
            setMove();
        }
        else if(event->key()==Qt::Key_E)
        {
            setScale();
        }
    }

    virtual void setAxisTransformMode(QKeyEvent * event)
    {
        if(event->key()==Qt::Key_X)
        {
           setAxisX();
        }
        if(event->key()==Qt::Key_Y)
        {
            setAxisY();
        }
        if(event->key()==Qt::Key_Z)
        {
            setAxisZ();
        }

        if(event->key()==Qt::Key_S)
        {
            setAxisScreen();
        }
        if(event->key()==Qt::Key_X &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisYZ();
        }
        if(event->key()==Qt::Key_Y &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXZ();
        }
        if(event->key()==Qt::Key_Z &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXY();
        }
        if(event->key()==Qt::Key_W)
        {
            PlaneAXesMode = UNIFORM;

            printf("Perform selection UNIFORM-Plane \n");
        }

        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->setTransPlaneAxes(PlaneAXesMode);
        }
    }

signals:

    void setSelectChanged();
    void setMoveChanged();
    void setRotationChanged();
    void setScaleChanged();

public slots:

    void setSelect()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);

        gizmo = 0;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/select.svg")));

        emit setSelectChanged();
    }

    void setMove()
    {
        TransformMode = MOVE;

        gizmoMove->setTransformMode(TransformMode);

        gizmo = gizmoMove;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Translate.svg")));

        emit setMoveChanged();
    }
    void setRotation()
    {
        TransformMode = ROTATION;

        gizmoRotation->setTransformMode(TransformMode);

        gizmo = gizmoRotation;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Rotate.svg")));

        emit setRotationChanged();
    }
    void setScale()
    {
        TransformMode = SCALE;

        gizmoScale->setTransformMode(TransformMode);

        gizmo = gizmoScale;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Scale.svg")));

        emit setScaleChanged();
    }

    void setPivot()
    {

    }

    void setFreeze()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);

        //setFeedBack();
    }

    void setAxisX()
    {
        PlaneAXesMode = X;
        printf("Perform selection X-Axis \n");
        //setFeedBack();
    }
    void setAxisY()
    {
        PlaneAXesMode = Y;
        printf("Perform selection Y-Axis \n");
        //setFeedBack();
    }
    void setAxisZ()
    {
        PlaneAXesMode = Z;

        printf("Perform selection Z-Axis \n");
        //setFeedBack();
    }

    void setAxisYZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = YZ;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = X;
        }

        printf("Perform selection YZ-plane \n");
        //setFeedBack();
    }
    void setAxisXZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = ZX;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Y;
        }
        printf("Perform selection ZX-plane \n");
        //setFeedBack();
    }
    void setAxisXY()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = XY;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Z;
        }

        printf("Perform selection XY-plane \n");
        //setFeedBack();

    }
    void setAxisUniform()
    {
         PlaneAXesMode = UNIFORM;

         printf("Perform selection SCREEN-Plane \n");
         //setFeedBack();

    }
    void setAxisScreen()
    {
         PlaneAXesMode = SCREEN;

         printf("Perform selection SCREEN-Plane \n");

         //setFeedBack();
    }

};






class GizmoController : public QObject
{
    Q_OBJECT

public:

    void qMultMatrix(const QMatrix4x4 &mat)
    {
        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());

    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif
        else
        {
            GLfloat fmat[16];

            const float*r= mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }
    }

    enum MATRIX_SPACE
    {
        LOCATE_VIEW,
        LOCATE_WORLD,
        LOCATE_LOCAL,
    };

    QTransformMode TransformMode;
    QTrans PlaneAXesMode;

    QVector3D prevhitpoint;
    QVector3D alternateCenter;

    QVector3D position;
    QVector3D rotation;
    QVector3D scale;

    QSelectionInfo * currentSelection;

    bool mousePressed;

    float alpha;
    float lineWidth;
    float lineWidthOutline;


    GizmoController(QSelectionInfo * currentSelectionInfo,QObject * parent =0):QObject(parent)
    {
        currentSelection = currentSelectionInfo;

        alpha = 0.5f;
        lineWidth = 5.0f;
        lineWidthOutline = 1.0f;
    }

    ~GizmoController()
    {
        delete currentSelection;
    }


    virtual void setTransformMode( QTransformMode & TransformMode)
    {
        this->TransformMode =  TransformMode;
    }
    virtual void setAxesAndPlanes(const QTrans & PlaneAXesMode)
    {
        this->PlaneAXesMode =  PlaneAXesMode;
    }

    virtual void rayPlaneIntersection(int x,int y)
    {
    }
    virtual void rayIntersectGizimo(QMatrix4x4 PV,int x, int y,bool useBbox = false)
    {
    }

    virtual void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {

    }

    virtual void drawGizmoAxis(QMatrix4x4 PV,QVector3D p0,QVector3D p1,QColor color,bool drawArrow = false)
    {
        //----------------------------
        //
        //           Y UP(0,1,0)
        //           |
        //           |angle
        //           |
        //         (p0)---------> newUp
        //        /   \  PI/2
        //       /     \
        //      /       \
        //    axis      (p1)
        //
        //--------------------------------

        //  direction = (p1-p0).normalize(); lookat

        //  v0   = origin;

        //  up   = QVector3D(0,1,0);

        //  axis = cross(up,direction);

        // theta = dot(up,direction);

        // if(theta>PI/2)
        // {
        //   angle = theta - PI/2;
        // }

        // float cosangle =  acosf(angle);

        // rotate(angle,axis);

        //------------------------------

        /*
        float angle = 24f;
        // Distance along the normal direction
        float distance= 0f;

        GameObject obj;

        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, 1000))
        {
            Vector3 normal = hit.normal;

            Quaternion q1 = Quaternion.AngleAxis(rotation, normal);
            Quaternion q2 = Quaternion.FromToRotation(Vector3.up, normal);
            Quaternion quat =  q1 * q2;

            obj.transform.position = hit.point + normal * distance;
            obj.transform.rotation = quat;
        }
        flag

        */

        GLUquadric * pointer;

        pointer = gluNewQuadric();

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        glLineWidth(lineWidth);

        glColor3f(color.redF(), color.greenF(), color.blueF());

        glBegin(GL_LINES);

        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());

        glEnd();

        if(currentSelection->size()>0 && drawArrow == true)
        {
            glPushMatrix();

            QVector3D up = QVector3D(0,1,0);

            QVector3D direction = p1 - p0;
            direction.normalize();

            QVector3D axis = QVector3D::crossProduct(direction,up);
            float theta    = QVector3D::dotProduct(direction,up );

            float angle =0;

            if(theta > M_PI/2)
            {
                angle = theta - M_PI/2;
            }
            else
            {
                angle = theta;

            }

            float degreesAngle = acosf(angle);

            QMatrix4x4 mat;
            mat.setToIdentity();
            mat.rotate(degreesAngle *M_PI/180,up); //PI = 180, 1 = PI/180;

            QVector3D newUp =  mat * up;

            /*

            //qDebug()<<"Angle:"<<angle;

            QMatrix4x4 mat;
            mat.setToIdentity();

            QMatrix4x4 mat2;
            mat.setToIdentity();
            //mat.lookAt(p0,p1,QVector3D(0,1,0));
            //mat = PV * mat;
            mat.translate(p1);
            mat2.rotate(angle,axis);

            QMatrix4x4  nMat = PV * currentSelection->getSelectedModel()->localMatrix*mat;

            qMultMatrix(nMat);

            */

            QMatrix4x4 MT;
            MT.setToIdentity();
            MT.lookAt(p0,p1,newUp);
            QMatrix4x4 PVM = PV * MT;

            qMultMatrix(PVM);

            gluCylinder (pointer, .08f,0,0.5f,6,1);

            glPopMatrix();

        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }



    virtual void drawLine(QVector3D p0,QVector3D p1,QColor color)
    {
        glLineWidth(lineWidth);

        glColor3f(color.redF(), color.greenF(), color.blueF());

        glBegin(GL_LINES);

        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());

        glEnd();
    }

    virtual void drawQuad(QVector3D p0,QVector3D p1,QVector3D p2,QVector3D p3,QColor fill,QColor outline)
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glColor4f(fill.redF(),fill.greenF(),fill.blueF(),alpha);

        glBegin(GL_QUADS);

        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());
        glVertex3f(p2.x(),p2.y(),p2.z());
        glVertex3f(p3.x(),p3.y(),p3.z());

        glEnd();

        glDisable(GL_BLEND);

        glLineWidth(lineWidthOutline);

        glColor3f(outline.redF(),outline.greenF(),outline.blueF());

        glBegin(GL_LINE_LOOP);

        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());
        glVertex3f(p2.x(),p2.y(),p2.z());
        glVertex3f(p3.x(),p3.y(),p3.z());

        glEnd();

    }

    virtual void drawTriangle(QVector3D p0,QVector3D p1,QVector3D p2,QColor fill,QColor outline)
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glColor4f(fill.redF(),fill.greenF(),fill.blueF(),alpha);

        glBegin(GL_TRIANGLES);
        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());
        glVertex3f(p2.x(),p2.y(),p2.z());
        glEnd();

        glDisable(GL_BLEND);

        glLineWidth(lineWidthOutline);
        glColor3f(outline.redF(),outline.greenF(),outline.blueF());
        glBegin(GL_LINE_LOOP);
        glVertex3f(p0.x(),p0.y(),p0.z());
        glVertex3f(p1.x(),p1.y(),p1.z());
        glVertex3f(p2.x(),p2.y(),p2.z());
        glEnd();

    }

    virtual void drawText(QString text,QVector3D p0,QColor color,QGLWidget* widget)
    {
        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        glColor3f(color.redF(),color.greenF(), color.blueF());
        widget->renderText(p0.x(), p0.y(), p0.z(),text,font);
    }






    float getShortestDistanceBtnLines( QVector3D v0, QVector3D v1,  QVector3D p0, QVector3D p1)
    {
        // Get the 3D minimum distance between 2 lines
        // Input:  two 3D lines L1 and L2
        // Return: the shortest distance between L1 and L2

        QVector3D   u = v1 - v1;
        QVector3D   v = p1 - p0;
        QVector3D   w = v0 - p0;

        float    a = QVector3D::dotProduct(u,u);         // always >= 0
        float    b = QVector3D::dotProduct(u,v);
        float    c = QVector3D::dotProduct(v,v);         // always >= 0
        float    d = QVector3D::dotProduct(u,w);
        float    e = QVector3D::dotProduct(v,w);

        float    D = a*c - b*b;        // always >= 0
        float    sc, tc;

        // compute the line parameters of the two closest points
        if (D < 0.0001)
        {
            // the lines are almost parallel
            sc = 0.0;
            tc = (b>c ? d/b : e/c);    // use the largest denominator
        }
        else {
            sc = (b*e - c*d) / D;
            tc = (a*e - b*d) / D;
        }

        // get the difference of the two closest points
        QVector3D   dP = w + (sc * u) - (tc * v);  // =  L1(sc) - L2(tc)

        return dP.length();   // return the closest distance
    }

    float getDistanceBtnSegmentToSegment( QVector3D v0, QVector3D v1,  QVector3D p0, QVector3D p1)
    {
        // Get the 3D minimum distance between 2 segments
        // Input:  two 3D line segments S1 and S2
        // Return: the shortest distance between S1 and S2


        float SMALL_NUM  = 0.0001;

        QVector3D   u = v1 - v0;

        QVector3D   v = p1 - p0;

        QVector3D   w = v0 - p0;


        float    a = QVector3D::dotProduct(u,u);         // always >= 0
        float    b = QVector3D::dotProduct(u,v);
        float    c = QVector3D::dotProduct(v,v);         // always >= 0
        float    d = QVector3D::dotProduct(u,w);
        float    e = QVector3D::dotProduct(v,w);

        float    D = a*c - b*b;        // always >= 0
        float    sc, sN, sD = D;       // sc = sN / sD, default sD = D >= 0
        float    tc, tN, tD = D;       // tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < SMALL_NUM) { // the lines are almost parallel
            sN = 0.0;         // force using point P0 on segment S1
            sD = 1.0;         // to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else {                 // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0) {        // sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
            else if (sN > sD) {  // sc > 1  => the s=1 edge is visible
                sN = sD;
                tN = e + b;
                tD = c;
            }
        }

        if (tN < 0.0) {            // tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else if (-d > a)
                sN = sD;
            else {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD) {      // tc > 1  => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else if ((-d + b) > a)
                sN = sD;
            else {
                sN = (-d +  b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < SMALL_NUM ? 0.0 : sN / sD);
        tc = (abs(tN) < SMALL_NUM ? 0.0 : tN / tD);

        // get the difference of the two closest points
        QVector3D   dP = w + (sc * u) - (tc * v);  // =  S1(sc) - S2(tc)

        return dP.length();   // return the closest distance
    }

    float getDistPointToLine(QVector3D origin, QVector3D direction, QVector3D point)
    {
        QVector3D point2origin = origin - point;

        QVector3D point2closestPointOnLine = point2origin - QVector3D::dotProduct(point2origin,direction) * direction;

        return point2closestPointOnLine.length();
    }

    bool intersectPlane(const QVector3D &n, const QVector3D &p0, const QVector3D &l0, const QVector3D &l, float &t)
    {
        // assuming vectors are all normalized
        float denom = QVector3D::dotProduct(n, l);

        if (denom > 1e-6)
        {
            QVector3D p0l0 = p0 - l0;

            t = QVector3D::dotProduct(p0l0, n) / denom;

            return (t >= 0);
        }

        return false;
    }

    bool intersectDisk(const QVector3D &n, const QVector3D &p0, const QVector3D &l0, const QVector3D &l, const float &radius)
    {
        float t = 0;

        if (intersectPlane(n, p0, l0, l, t))
        {
            QVector3D p = l0 + l * t;

            QVector3D v = p - p0;

            float d2 = QVector3D::dotProduct(v, v);

            return (sqrtf(d2) <= radius);
            // or you can use the following optimisation (and precompute radius^2)
            // return d2 <= radius2; // where radius2 = radius * radius
         }

         return false;
    }



    QVector3D getPointOnLine(QVector3D p0, QVector3D direction,float t)
    {
        return p0 + direction * t;
    }

    QVector3D getPointOnLineIntersectingthePlane(QVector3D p0, QVector3D direction,float t)
    {
        return p0 + direction * t;
    }

};

class GizmoMoveController  : public GizmoController
{
public:

    enum MOVETYPE
    {
        MOVE_X,
        MOVE_Y,
        MOVE_Z,

        MOVE_XY,
        MOVE_XZ,
        MOVE_YZ,

        MOVE_XYZ,
        MOVE_NONE,
    };


    GizmoMoveController(QSelectionInfo * currentSelectionInfo,QObject * parent): GizmoController(currentSelectionInfo,parent)
    {
        //----------------------------
        //
        //           Y v2(0,1,0) p2
        //           |
        //           |   plane-XY
        // plane-YZ  |(0,0,0)
        //           v0 --------  X v1(1,0,0) p1
        //          /p0
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0) p3
        //
        //------------------------------
    }

    ~GizmoMoveController() { }


    QPoint lastP;



    //-------Ray plane intersection--------
    void rayPlaneIntersection(int x,int y)
    {

        qDebug()<<"Ray plane Intersection";

        QPoint pp(x,y);

        if(currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QPlane plane;
            plane.center = model->position;
            plane.axesAlignment = PlaneAXesMode;

            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
            }

            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            if(PlaneAXesMode==SCREEN)
            {
                plane.normal = (-1.0f * ray.direction);
            }

            QVector3D hitPoint = ray.getRayPlaneIntersection(plane);

            if(ray.hitStatus == INTERSECTS)
            {
                qDebug()<<"Plane Intersection Point:"<<hitPoint;

                QVector3D prev = model->position;

                if(PlaneAXesMode == X)
                {
                    model->position = QVector3D(hitPoint.x(),prev.y(),prev.z());
                }

                if(PlaneAXesMode == Y)
                {
                    model->position = QVector3D(prev.x(),hitPoint.y(),prev.z());
                }

                if(PlaneAXesMode == Z)
                {
                    model->position = QVector3D(prev.x(),prev.y(),hitPoint.z());
                }

                if(PlaneAXesMode==ZX||PlaneAXesMode==XY||PlaneAXesMode==YZ||PlaneAXesMode ==SCREEN)
                {
                    model->position = hitPoint;
                }
            }
        }
    }


    virtual bool RectContainsPoint(QVector3D p,QVector3D p0,QVector3D p1,QVector3D p2,QVector3D p3)
    {
        //         w
        //  p0-------------p1
        //  |              |
        //  |     p        | h
        //  |              |
        //  |              |
        //  p3-------------p2

        // w = (p1-p0).length
        // h = (p3-p0).length
        //
        // deltaP = p-p0
        //
        // if( deltaP.x<w && deltaP.x>0 &&deltaP.y<h&&deltaP.y>0 )
        // {
        //   contains = true
        // }

        float w = (p1-p0).length();
        float h = (p3-p0).length();

        QVector3D deltaP = p - p0;

        if(deltaP.x()<=w && deltaP.x()>=0 &&deltaP.y()<=h&&deltaP.y()>=0)
        {
            return true;
        }

        return false;
    }

    virtual void rayIntersectGizimo(QMatrix4x4 PV,int x, int y,bool useBbox = true)
    {
        //------------------------------------------//
        //                                          //
        //           Y v2(0,1,0) p2                 //
        //           |                              //
        //           |   plane-XY                   //
        // plane-YZ  |(0,0,0)                       //
        //           v0 --------  X v1(1,0,0) p1    //
        //          /p0                             //
        //         /    plane-ZX                    //
        //        /                                 //
        //       Z  v3(0,0,1) p3                    //
        //                                          //
        //------------------------------------------//

        QVector3D p0,p1,p2,p3;

        QVector3D n,dir1,dir2;

        if(currentSelection->size()>0)
        {
            bool intersected = false;

            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            qDebug()<<"Ray:"<<ray.p0<<","<<ray.p1<<"Direction,"<<ray.direction;

            QBaseModel * model =  currentSelection->getSelectedModel();

            float gscale = 2.0f;

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1*gscale,0,0);
            QVector3D v2 = QVector3D(0,1*gscale,0);
            QVector3D v3 = QVector3D(0,0,1*gscale);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;

            float t = 0;//the value ray plane intersection

            //------Intersect x,y,z axis-----

            if(!intersected)
            {
                QAabb box;
                box.expand(v0);
                box.expand(v1);

                QVector3D norm = QVector3D::crossProduct(QVector3D(0,1,0),(v1-v0).normalized());
                norm.normalize();
                box.expand(norm*.0001+v1);

                if(box.intersectRay(ray.p0,ray.direction))
                {
                    PlaneAXesMode==X;
                    setAxesAndPlanes(X);
                    intersected = true;

                   qDebug()<<"Intersects: X";

                   return;

                }
            }

            if(!intersected)
            {
                QAabb box;
                box.expand(v0);
                box.expand(v2);

                QVector3D norm = QVector3D::crossProduct(QVector3D(0,1,0),(v2-v0).normalized());
                norm.normalize();
                box.expand(norm*.0001+v2);


                if(box.intersectRay(ray.p0,ray.direction))
                {
                    PlaneAXesMode==Y;
                    setAxesAndPlanes(Y);
                    intersected = true;

                   qDebug()<<"Intersects: Y";
                   return;

                }
            }

            if(!intersected)
            {
                QAabb box;
                box.expand(v0);
                box.expand(v3);

                QVector3D norm = QVector3D::crossProduct(QVector3D(0,1,0),(v3-v0).normalized());
                norm.normalize();
                box.expand(norm*.0001+v3);


                if(box.intersectRay(ray.p0,ray.direction))
                {
                    PlaneAXesMode==Y;
                    setAxesAndPlanes(Y);
                    intersected = true;

                   qDebug()<<"Intersects: Y";
                   return;

                }
            }




            v0 = QVector3D(0,0,0);
            v1 = QVector3D(1,0,0);
            v2 = QVector3D(0,1,0);
            v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;


            //------Intersect ZX,XY,YZ planes-----


            if(!intersected) //Plane XY
            {
                p0 = v0;
                p1 = v1;
                p2 = v1+v2-v0;
                p3 = v2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(!useBbox)
                {
                    QPlane plane;
                    plane.center += (p0+p1+p2+p3);
                    plane.center /= 4;
                    plane.normal =  n;

                    QVector3D p = ray.getRayPlaneIntersection(plane);

                    if(ray.hitStatus == INTERSECTS&& RectContainsPoint(p,p0,p1,p2,p3)==true)
                    {
                        PlaneAXesMode = XY;

                        setAxesAndPlanes(XY);

                        intersected = true;

                        qDebug()<<"Intersects: ==>XY";
                        return;
                    }

                }
                else
                {
                    QAabb box;
                    box.expand(p0);
                    box.expand(p1);
                    box.expand(p2);
                    box.expand(p3);
                    box.expand(n*.0001+p0);

                    if(box.intersectRay(ray.p0,ray.direction))
                    {
                        PlaneAXesMode = XY;

                        setAxesAndPlanes(XY);

                        intersected = true;

                        qDebug()<<"Intersects: XY";

                        return;
                    }
                }
            }

            if(!intersected) //Plane YZ
            {
                p0 = v0;
                p1 = v2;
                p2 = v3+v2-v0;
                p3 = v3;
                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(!useBbox)
                {
                    QPlane plane;
                    plane.center += (p0+p1+p2+p3);
                    plane.center /= 4;
                    plane.normal =  n;

                    QVector3D p = ray.getRayPlaneIntersection(plane);

                    if(ray.hitStatus == INTERSECTS&& RectContainsPoint(p,p0,p1,p2,p3)==true)
                    {
                        PlaneAXesMode = YZ;

                        setAxesAndPlanes(YZ);

                        intersected = true;

                        qDebug()<<"Intersects: ==>YZ";

                        return;
                    }

                }
                else
                {
                    QAabb box;
                    box.expand(p0);
                    box.expand(p1);
                    box.expand(p2);
                    box.expand(p3);
                    box.expand(n*.0001+p0);

                    if(box.intersectRay(ray.p0,ray.direction))
                    {
                        PlaneAXesMode = YZ;

                        setAxesAndPlanes(YZ);

                        intersected = true;

                        qDebug()<<"Intersects: YZ";

                        return;
                    }

                }
            }

            if(!intersected) //Plane ZX
            {
                //float t =0;//the value ray plane intersection

                QVector3D p0 = v0;
                QVector3D p1 = v1;
                QVector3D p2 = v3+v1-v0;
                QVector3D p3 = v3;
                QVector3D n,dir1,dir2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(!useBbox)
                {
                    QPlane plane;
                    plane.center += (p0+p1+p2+p3);
                    plane.center /= 4;
                    plane.normal =  n;

                    QVector3D p = ray.getRayPlaneIntersection(plane);

                    if(ray.hitStatus == INTERSECTS  && RectContainsPoint(p,p0,p1,p2,p3)==true)
                    {
                        PlaneAXesMode = ZX;

                        setAxesAndPlanes(ZX);

                        intersected = true;

                        qDebug()<<"Intersects: ==>ZX";

                        return;
                    }

                }
                else
                {
                    QAabb box;
                    box.expand(p0);
                    box.expand(p1);
                    box.expand(p2);
                    box.expand(p3);
                    box.expand(n*.0001+p0);

                    if(box.intersectRay(ray.p0,ray.direction))
                    {
                        PlaneAXesMode = ZX;

                        setAxesAndPlanes(ZX);

                        intersected = true;

                        qDebug()<<"Intersects: ZX";

                        return;
                    }

                }

            }

            if(!intersected) //Plane XYZ
            {
                PlaneAXesMode = XYZ_NONE;

                this->setAxesAndPlanes(XYZ_NONE);
            }

            if(intersected)
            {
                if(PlaneAXesMode==X)
                {

                }
                if(PlaneAXesMode==Y)
                {

                }
                if(PlaneAXesMode==Z)
                {

                }
                if(PlaneAXesMode==ZX)
                {

                }
                if(PlaneAXesMode==XY)
                {

                }
                if(PlaneAXesMode==YZ)
                {

                }
            }
        }
    }

    virtual void drawTranslationGizmo(QMatrix4x4 PV,QGLWidget* widget, bool drawarrows = true)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        if(currentSelection->size()>0)
        {
            QBaseModel * model =  currentSelection->getSelectedModel();

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1,0,0);
            QVector3D v2 = QVector3D(0,1,0);
            QVector3D v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;


            if(PlaneAXesMode==ZX)
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::white),QColor(Qt::white));  //xz plane
            }
            else
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //xz plane
            }

            if(PlaneAXesMode==XY)
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::white),QColor(Qt::white));  //xy plane
            }
            else
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::yellow),QColor(Qt::yellow));  //xy plane
            }


            if(PlaneAXesMode == YZ)
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::white),QColor(Qt::white));  //yz plane
            }
            else
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //yz plane
            }

            if(PlaneAXesMode == SCREEN)
            {
            }
            else
            {

            }

            float gscale = 2.0f;


            QVector3D p0 = QVector3D(0,0,0);
            QVector3D p1 = QVector3D(1*gscale,0,0);
            QVector3D p2 = QVector3D(0,1*gscale,0);
            QVector3D p3 = QVector3D(0,0,1*gscale);

            p0 = PV * model->localMatrix * p0;
            p1 = PV * model->localMatrix * p1;
            p2 = PV * model->localMatrix * p2;
            p3 = PV * model->localMatrix * p3;

            if(PlaneAXesMode == XYZ_NONE)
            {
            }

            if(PlaneAXesMode==X)
            {
                drawGizmoAxis(PV,p0,p1,QColor(Qt::white));   //x-axis
            }
            else
            {
                drawGizmoAxis(PV,p0,p1,QColor(Qt::red));   //x-axis
            }

            if(PlaneAXesMode==Y)
            {
                drawGizmoAxis(PV,p0,p2,QColor(Qt::white)); //y-axis
            }
            else
            {
                drawGizmoAxis(PV,p0,p2,QColor(Qt::green)); //y-axis
            }

            if(PlaneAXesMode==Z)
            {
                drawGizmoAxis(PV,p0,p3,QColor(Qt::white));  //z-axis
            }
            else
            {
                drawGizmoAxis(PV,p0,p3,QColor(Qt::blue));  //z-axis
            }

            drawText(QString("X"),p1,QColor(Qt::red)  ,widget);
            drawText(QString("Y"),p2,QColor(Qt::green),widget);
            drawText(QString("Z"),p3,QColor(Qt::blue) ,widget);
        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(currentSelection->size()>0)
        {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            if( TransformMode == MOVE )
            {
                 drawTranslationGizmo(PV,widget);
            }

            //glPushMatrix( );

            //QBaseModel * model = currentSelection->getSelectedModel();

            //QMatrix4x4 PVM  = PV * model->worldMatrix;

            //qMultMatrix(PVM);

            //glBegin(GL_POINTS);

            //glVertex3f(0,0,0);

            //glEnd();

            //glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }
};

class GizmoScaleController    : public GizmoController
{
public:

    enum SCALETYPE
    {
        SCALE_X,
        SCALE_Y,
        SCALE_Z,
        SCALE_XY,
        SCALE_XZ,
        SCALE_YZ,
        SCALE_XYZ,
        SCALE_NONE,
    };

    /*
    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;


    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    */

    GizmoScaleController(QSelectionInfo * currentSelectionInfo,QObject * parent):GizmoController(currentSelectionInfo,parent)
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //----------------------------

        /*

        QVector3D v0 = QVector3D(0,0,0);

        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);

        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);

        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);


        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));


        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));


        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));



        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-.5,-.5,-.5),QVector3D(0.5,0.5,0.5));



        XZbox.reScale();
        XYbox.reScale();
        YZbox.reScale();

        */

    }

    ~GizmoScaleController()
    {
        //qDeleteAll(axesplanes);
        //qDeleteAll(vertices);
    }


    /*



    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;

            QPoint p = QCursor::pos();
            QRay view;
            view.rayCastScene(p.x(),p.y());

            QPlane plane;
            plane.center = v;
            plane.axesAlignment = PlaneAXesMode;


            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = X;
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = Y;
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = Z;
            }

            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = ZX;
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = XY;
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
                plane.axesAlignment = YZ;
            }

            if(PlaneAXesMode==SCREEN || PlaneAXesMode==UNIFORM)
            {
                plane.normal = (-1.0f*view.direction);
                plane.axesAlignment = SCREEN;
            }

            QVector3D pScale = model->scale;

            float scale  = QVector2D(delta.x(),delta.y()).length();

            float sign;

            if(delta.x() ==0)
            {
            }
            else
            {
                sign =  (float)delta.x()/fabs((float)delta.x());
            }

            scale *= 0.01f;
            scale *= sign;

            qDebug()<<"Delta Scale:"<<scale<<"sign:"<<sign;

            if(PlaneAXesMode==X)
            {
                model->scale = pScale + QVector3D(1,0,0) *scale;
            }

            if(PlaneAXesMode==Y)
            {
                model->scale = pScale + QVector3D(0,1,0)  *scale;
            }

            if(PlaneAXesMode==Z)
            {
                model->scale = pScale + QVector3D(0,0,1)  *scale;
            }

            if(PlaneAXesMode==ZX)
            {
                model->scale = pScale + QVector3D(1,0,1)  *scale;
            }

            if(PlaneAXesMode==XY)
            {
                model->scale = pScale + QVector3D(1,1,0)  *scale;
            }

            if(PlaneAXesMode==YZ)
            {
                model->scale = pScale + QVector3D(0,1,1)  *scale;
            }

            if(PlaneAXesMode ==SCREEN)
            {
                QVector3D viewDirection = (-1.0f*view.direction);

                model->scale = pScale + viewDirection *scale;
            }

            if(PlaneAXesMode ==UNIFORM)
            {
               model->scale =  pScale + QVector3D(1,1,1)  *scale;

            }

            model->computeBounds();
        }
    }

    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D r = model->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);
            bool  intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }
        }
    }


    void drawScaleGizmo(QGLWidget* widget)
    {
        //sdisk.drawDisk(true,ZX);
        //sdisk.drawDisk(true,XY);
        //sdisk.drawDisk(true,YZ);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(2);


        glBegin(GL_LINES);
            glColor3f(1.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(1.0f, 0.0f, 0.0f);

            glColor3f(0.0f, 1.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 1.0f, 0.0f);

            glColor3f(0.0f, 0.0f, 1.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 1.0f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.0f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.0f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.0f,zstr,font);


        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );



            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==SCALE)
            {
                drawScaleGizmo(widget);
                drawSelectionQAaBB();
            }

            glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }


    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            //QBaseModel * model = currentSelection->getSelectedModel();

            //QVector3D v = model->position;
            //QVector3D s = model->scale;
            //QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            //glTranslatef( v.x(), v.y(), v.z() );

            //glRotatef(r.x(),1,0,0);
            //glRotatef(r.y(),0,1,0);
            //glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            //glScalef( 1, 1, 1 );

            QBaseModel * model = currentSelection->getSelectedModel();

            QMatrix4x4 PVM  = PV * model->localMatrix ;

            qMultMatrix(PVM);


            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==SCALE)
            {
                drawScaleGizmo(widget);
                drawSelectionQAaBB();
            }

            glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }

    */


    virtual void rayIntersectGizimo(QMatrix4x4 PV,int x, int y)
    {
        //------------------------------------------//
        //                                          //
        //           Y v2(0,1,0) p2                 //
        //           |                              //
        //           |   plane-XY                   //
        // plane-YZ  |(0,0,0)                       //
        //           v0 --------  X v1(1,0,0) p1    //
        //          /p0                             //
        //         /    plane-ZX                    //
        //        /                                 //
        //       Z  v3(0,1,0) p3                    //
        //                                          //
        //------------------------------------------//

        QVector3D p0,p1,p2,p3;

        QVector3D n,dir1,dir2;

        if(currentSelection->size()>0)
        {
            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            QBaseModel * model =  currentSelection->getSelectedModel();

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1,0,0);
            QVector3D v2 = QVector3D(0,1,0);
            QVector3D v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;


            bool intersected = false;

            float t =0;//the value ray plane intersection


            //------Intersect x,y,z axis-----

            if(!intersected)
            {
                float dist1 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist1<0.01)
                {
                    PlaneAXesMode==X;

                    intersected = true;
                }
            }

            if(!intersected)
            {
                float dist2 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist2<0.01)
                {
                    PlaneAXesMode==Y;
                    intersected = true;
                }
            }

            if(!intersected)
            {
                float dist3 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist3<0.01)
                {
                    PlaneAXesMode==Z;
                    intersected = true;
                }
            }


            //------Intersect ZX,XY,YZ planes-----

            if(!intersected)//Plane ZX
            {
                //float t =0;//the value ray plane intersection

                QVector3D p0 = v0;
                QVector3D p1 = v1;
                QVector3D p2 = v3+v1-v0;
                QVector3D p3 = v3;
                QVector3D n,dir1,dir2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);


                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = ZX;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }

            }

            if(!intersected) //Plane XY
            {
                p0 = v0;
                p1 = v1;
                p2 = v1+v2-v0;
                p3 = v2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = XY;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }
            }


            if(!intersected) //Plane YZ
            {
                p0 = v0;
                p1 = v2;
                p2 = v3+v2-v0;
                p3 = v3;
                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = YZ;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }
            }

            if(!intersected) //Plane YZ
            {
                PlaneAXesMode = XYZ_NONE;
            }


            if(intersected)
            {
                if(PlaneAXesMode==X)
                {

                }
                if(PlaneAXesMode==Y)
                {

                }
                if(PlaneAXesMode==Z)
                {

                }
                if(PlaneAXesMode==ZX)
                {

                }
                if(PlaneAXesMode==XY)
                {

                }
                if(PlaneAXesMode==YZ)
                {

                }
            }
        }


        qDebug()<<"rayIntersectGizimo:"<<x<<","<<y;


    }


    virtual void drawTranslationGizmo(QMatrix4x4 PV,QGLWidget* widget, bool drawarrows = true)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        if(currentSelection->size()>0)
        {
            QBaseModel * model =  currentSelection->getSelectedModel();

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1,0,0);
            QVector3D v2 = QVector3D(0,1,0);
            QVector3D v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;

            if(PlaneAXesMode == XYZ_NONE)
            {
            }

            if(PlaneAXesMode==X)
            {
               drawLine(v0,v1,QColor(Qt::white));   //x-axis

            }
            else
            {
                drawLine(v0,v1,QColor(Qt::red));   //x-axis
            }

            if(PlaneAXesMode==Y)
            {
                drawLine(v0,v2,QColor(Qt::green)); //y-axis
            }
            else
            {
                drawLine(v0,v2,QColor(Qt::white)); //y-axis
            }

            if(PlaneAXesMode==Z)
            {
                drawLine(v0,v3,QColor(Qt::white));  //z-axis
            }
            else
            {
                drawLine(v0,v3,QColor(Qt::blue));  //z-axis

            }

            if(PlaneAXesMode==ZX)
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::white),QColor(Qt::white));  //xz plane
            }
            else
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //xz plane
            }



            if(PlaneAXesMode==XY)
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::white),QColor(Qt::white));  //xy plane
            }
            else
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::yellow),QColor(Qt::yellow));  //xy plane
            }


            if(PlaneAXesMode == YZ)
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::white),QColor(Qt::white));  //yz plane
            }
            else
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //yz plane
            }

            if(PlaneAXesMode == SCREEN)
            {
            }



            QArrow arrow;

            if(drawarrows)
            {
                arrow.drawArrow(XY);
                arrow.drawArrow(ZX);
                arrow.drawArrow(YZ);
            }

            drawText(QString("X"),v1,QColor(Qt::red)  ,widget);
            drawText(QString("Y"),v2,QColor(Qt::green),widget);
            drawText(QString("Z"),v3,QColor(Qt::blue) ,widget);
        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }


    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(currentSelection->size()>0)
        {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            if( TransformMode == MOVE )
            {
                 drawTranslationGizmo(PV,widget);
            }

            //glPushMatrix( );

            //QBaseModel * model = currentSelection->getSelectedModel();

            //QMatrix4x4 PVM  = PV * model->worldMatrix;

            //qMultMatrix(PVM);

            //glBegin(GL_POINTS);

            //glVertex3f(0,0,0);

            //glEnd();

            //glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }





};

class GizmoRotationController : public GizmoController
{
public:

    enum ROTATETYPE
    {
        ROTATE_X,
        ROTATE_Y,
        ROTATE_Z,
        ROTATE_SCREEN,
        ROTATE_TRACKBALL,
        ROTATE_NONE,
    };


    GizmoRotationController(QSelectionInfo * currentSelectionInfo,QObject * parent):GizmoController(currentSelectionInfo,parent)
    {
        mousePressed = false;
    }

    ~GizmoRotationController(){}


    virtual void rayIntersectGizimo(QMatrix4x4 PV,int x, int y)
    {
        //------------------------------------------//
        //                                          //
        //           Y v2(0,1,0) p2                 //
        //           |                              //
        //           |   plane-XY                   //
        // plane-YZ  |(0,0,0)                       //
        //           v0 --------  X v1(1,0,0) p1    //
        //          /p0                             //
        //         /    plane-ZX                    //
        //        /                                 //
        //       Z  v3(0,1,0) p3                    //
        //                                          //
        //------------------------------------------//

        QVector3D p0,p1,p2,p3;

        QVector3D n,dir1,dir2;

        if(currentSelection->size()>0)
        {
            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            QBaseModel * model =  currentSelection->getSelectedModel();

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1,0,0);
            QVector3D v2 = QVector3D(0,1,0);
            QVector3D v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;


            bool intersected = false;

            float t =0;//the value ray plane intersection


            //------Intersect x,y,z axis-----

            if(!intersected)
            {
                float dist1 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist1<0.01)
                {
                    PlaneAXesMode==X;

                    intersected = true;
                }
            }

            if(!intersected)
            {
                float dist2 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist2<0.01)
                {
                    PlaneAXesMode==Y;
                    intersected = true;
                }
            }

            if(!intersected)
            {
                float dist3 = getShortestDistanceBtnLines(ray.p0,ray.p1,v0,v2);

                if(dist3<0.01)
                {
                    PlaneAXesMode==Z;
                    intersected = true;
                }
            }


            //------Intersect ZX,XY,YZ planes-----

            if(!intersected)//Plane ZX
            {
                //float t =0;//the value ray plane intersection

                QVector3D p0 = v0;
                QVector3D p1 = v1;
                QVector3D p2 = v3+v1-v0;
                QVector3D p3 = v3;
                QVector3D n,dir1,dir2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);


                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = ZX;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }

            }

            if(!intersected) //Plane XY
            {
                p0 = v0;
                p1 = v1;
                p2 = v1+v2-v0;
                p3 = v2;

                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = XY;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }
            }


            if(!intersected) //Plane YZ
            {
                p0 = v0;
                p1 = v2;
                p2 = v3+v2-v0;
                p3 = v3;
                dir1 = p1-p0; dir1.normalize();
                dir2 = p3-p0; dir2.normalize();
                n = QVector3D::crossProduct(dir1,dir2);

                if(intersectPlane(n,p0,ray.p0,ray.p1,t))
                {
                    PlaneAXesMode = YZ;

                    QVector3D hitpoint = getPointOnLineIntersectingthePlane(ray.p0,ray.direction,t);

                    intersected = true;
                }
            }

            if(!intersected) //Plane YZ
            {
                PlaneAXesMode = XYZ_NONE;
            }


            if(intersected)
            {
                if(PlaneAXesMode==X)
                {

                }
                if(PlaneAXesMode==Y)
                {

                }
                if(PlaneAXesMode==Z)
                {

                }
                if(PlaneAXesMode==ZX)
                {

                }
                if(PlaneAXesMode==XY)
                {

                }
                if(PlaneAXesMode==YZ)
                {

                }
            }
        }


        qDebug()<<"rayIntersectGizimo:"<<x<<","<<y;


    }

    virtual void drawTranslationGizmo(QMatrix4x4 PV,QGLWidget* widget, bool drawarrows = true)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        if(currentSelection->size()>0)
        {
            QBaseModel * model =  currentSelection->getSelectedModel();

            QVector3D v0 = QVector3D(0,0,0);
            QVector3D v1 = QVector3D(1,0,0);
            QVector3D v2 = QVector3D(0,1,0);
            QVector3D v3 = QVector3D(0,0,1);

            v0 = PV * model->localMatrix * v0;
            v1 = PV * model->localMatrix * v1;
            v2 = PV * model->localMatrix * v2;
            v3 = PV * model->localMatrix * v3;

            if(PlaneAXesMode == XYZ_NONE)
            {
            }

            if(PlaneAXesMode==X)
            {
               drawLine(v0,v1,QColor(Qt::white));   //x-axis

            }
            else
            {
                drawLine(v0,v1,QColor(Qt::red));   //x-axis
            }

            if(PlaneAXesMode==Y)
            {
                drawLine(v0,v2,QColor(Qt::green)); //y-axis
            }
            else
            {
                drawLine(v0,v2,QColor(Qt::white)); //y-axis
            }

            if(PlaneAXesMode==Z)
            {
                drawLine(v0,v3,QColor(Qt::white));  //z-axis
            }
            else
            {
                drawLine(v0,v3,QColor(Qt::blue));  //z-axis

            }

            if(PlaneAXesMode==ZX)
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::white),QColor(Qt::white));  //xz plane
            }
            else
            {
                drawQuad(v0,v1,v3+v1-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //xz plane
            }



            if(PlaneAXesMode==XY)
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::white),QColor(Qt::white));  //xy plane
            }
            else
            {
                drawQuad(v0,v1,v1+v2-v0,v2,QColor(Qt::yellow),QColor(Qt::yellow));  //xy plane
            }


            if(PlaneAXesMode == YZ)
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::white),QColor(Qt::white));  //yz plane
            }
            else
            {
                drawQuad(v0,v2,v3+v2-v0,v3,QColor(Qt::yellow),QColor(Qt::yellow));  //yz plane
            }

            if(PlaneAXesMode == SCREEN)
            {
            }



            QArrow arrow;

            if(drawarrows)
            {
                arrow.drawArrow(XY);
                arrow.drawArrow(ZX);
                arrow.drawArrow(YZ);
            }

            drawText(QString("X"),v1,QColor(Qt::red)  ,widget);
            drawText(QString("Y"),v2,QColor(Qt::green),widget);
            drawText(QString("Z"),v3,QColor(Qt::blue) ,widget);
        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

    void drawGizmo(QMatrix4x4 PV,QGLWidget* widget)
    {
        if(currentSelection->size()>0)
        {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            if( TransformMode == MOVE )
            {
                 drawTranslationGizmo(PV,widget);
            }

            //glPushMatrix( );

            //QBaseModel * model = currentSelection->getSelectedModel();

            //QMatrix4x4 PVM  = PV * model->worldMatrix;

            //qMultMatrix(PVM);

            //glBegin(GL_POINTS);

            //glVertex3f(0,0,0);

            //glEnd();

            //glPopMatrix();

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }
};



class GizimoAxesTransformer    : public QObject
{
    Q_OBJECT

public:

    QIcon icon;

    QGLWidget * parentWidget;

    GizmoController *gizmo,*gizmoMove,*gizmoScale,*gizmoRotation;

    QSelectionInfo * currentSelection;

    QActionGroup * handlesActions;



    QVector3D pivotPositon;
    QPlane pivotPlane;
    QMatrix4x4 PV;

    QTrans PlaneAXesMode;
    QTransformMode TransformMode;

    QMenu transformsAxisMenu;
    QMenu transformMenu;

    bool mousePressed;

    void createActions()
    {
        handlesActions = new QActionGroup(this);

        QAction * b1 = new QAction(QIcon(":/Tools Icons/select.svg"),QString("Select: Shift+G"),this);
        QAction * b2 = new QAction(QIcon(":/Tools Icons/Translate.svg"),QString("Move: Shift+T"),this);
        QAction * b3 = new QAction(QIcon(":/Tools Icons/Scale.svg"),QString("Scale: Shift+R"),this);
        QAction * b4 = new QAction(QIcon(":/Tools Icons/Rotate.svg"),QString("Rotate: Shift+S"),this);
        QAction * b5 = new QAction(QIcon(":/Tools Icons/icon pivot.svg"),QString("set Pivot: CTRL+P"),this);

        b1->setCheckable(true); b1->setShortcut(Qt::SHIFT|Qt::Key_G);
        b2->setCheckable(true); b2->setShortcut(Qt::SHIFT|Qt::Key_T);
        b3->setCheckable(true); b3->setShortcut(Qt::SHIFT|Qt::Key_R);
        b4->setCheckable(true); b4->setShortcut(Qt::SHIFT|Qt::Key_S);
        b5->setCheckable(true); b5->setShortcut(Qt::CTRL|Qt::Key_P);

        connect(b1, SIGNAL(triggered(bool)), this, SLOT(setSelect()));

        connect(b2, SIGNAL(triggered(bool)), this, SLOT(setMove()));
        connect(b3, SIGNAL(triggered(bool)), this, SLOT(setScale()));
        connect(b4, SIGNAL(triggered(bool)), this, SLOT(setRotation()));
        connect(b5, SIGNAL(triggered(bool)), this, SLOT(setPivot()));


        b1->setEnabled(true);
        b1->setChecked(true);

        handlesActions->addAction(b1);

        handlesActions->addAction(b2);
        handlesActions->addAction(b3);
        handlesActions->addAction(b4);
        handlesActions->addAction(b5);

        handlesActions->setExclusive(true);
    }

    void createTransformMenues()
    {
        transformMenu.addAction(icon,QString("Move"),this,SLOT(setMove()),QKeySequence(Qt::Key_T));
        transformMenu.addAction(icon,QString("Rotation"),this,SLOT(setRotation()),QKeySequence(Qt::Key_R));
        transformMenu.addAction(icon,QString("Scale"),this,SLOT(setScale()),QKeySequence(Qt::Key_E));
        transformMenu.addAction(icon,QString("Freeze"),this,SLOT(setFreeze()),QKeySequence(Qt::Key_Q));

        transformMenu.setTitle(QString("Set Transform Mode"));
        transformMenu.setIcon(icon);

        setTheme(transformMenu);

    }

    void createAxisTransformMenues()
    {
        transformsAxisMenu.addAction(icon,QString("X"),this,SLOT(setAxisX()));
        transformsAxisMenu.addAction(icon,QString("Y"),this,SLOT(setAxisY()));
        transformsAxisMenu.addAction(icon,QString("Z"),this,SLOT(setAxisZ()));

        transformsAxisMenu.addAction(icon,QString("XY"),this,SLOT(setAxisXY()));
        transformsAxisMenu.addAction(icon,QString("XZ"),this,SLOT(setAxisXZ()));
        transformsAxisMenu.addAction(icon,QString("YZ"),this,SLOT(setAxisYZ()));

        transformsAxisMenu.addAction(icon,QString("Screen"),this,SLOT(setAxisScreen()));
        transformsAxisMenu.addAction(icon,QString("UNIFORM"),this,SLOT(setAxisUniform()));

        transformsAxisMenu.setTitle(QString("Set Axis Transform Mode"));
        transformsAxisMenu.setIcon(icon);

        setTheme(transformsAxisMenu);
    }

    void setTheme(QWidget & widget)
    {
        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           widget.setStyleSheet(style);
        }

        file.close();
    }


    GizimoAxesTransformer(QSelectionInfo * selectionInfo,QGLWidget * qglWidget=0,QObject *parent=0):QObject(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        parentWidget =  qglWidget;

        currentSelection = selectionInfo;

        gizmo         = new GizmoController(currentSelection,parent);
        gizmoMove     = new GizmoMoveController(currentSelection,parent);
        gizmoScale    = new GizmoScaleController(currentSelection,parent);
        gizmoRotation = new GizmoRotationController(currentSelection,parent);

        gizmoMove->setTransformMode(TransformMode);
        gizmoScale->setTransformMode(TransformMode);
        gizmoRotation->setTransformMode(TransformMode);

        setSelect();

        createAxisTransformMenues();
        createTransformMenues();
        createActions();

        mousePressed = false;
    }

    ~GizimoAxesTransformer()
    {
       delete gizmo;
       delete gizmoMove;
       delete gizmoScale;
       delete gizmoRotation;

       delete currentSelection;
       delete handlesActions;
       delete parentWidget;
    }

    virtual void setPVmatrix(const QMatrix4x4 & pv)
    {
        PV = pv;
    }

    virtual void mousePressEvent(QMouseEvent* event)
    {
        mousePressed = true;

        if(currentSelection->size()>0)
        {
            gizmo->mousePressed =  true;
        }
    }

    virtual void mouseMoveEvent(QMouseEvent* event)
    {
        if(event->buttons() & Qt::LeftButton)
        {
            if(currentSelection->size()>0)
            {
                QPoint c = (event->pos());

                gizmo->mousePressed =  true;

                //gizmo->rayPlaneIntersection(c.x(),c.y());

                gizmo->rayIntersectGizimo( PV , c.x() , c.y() );
            }
        }

        if(event->buttons() & Qt::RightButton)
        {
            QPoint c = (event->pos());

            //gizmo->rayPlaneIntersection(c.x(),c.y());
        }
    }

    virtual void mouseReleaseEvent(QMouseEvent* event)
    {
        mousePressed = false;
    }

    virtual void keyPressEvent(QKeyEvent * event)
    {
        if(event->key()==Qt::Key_Q)
        {
            setSelect();
        }
        else if(event->key()==Qt::Key_R)
        {
            setRotation();
        }
        else if(event->key()==Qt::Key_T)
        {
            setMove();
        }
        else if(event->key()==Qt::Key_S)
        {
            setScale();
        }

        if(event->key()==Qt::Key_X)
        {
           setAxisX();
        }
        if(event->key()==Qt::Key_Y)
        {
            setAxisY();
        }
        if(event->key()==Qt::Key_Z)
        {
            setAxisZ();
        }

        if(event->modifiers() & Qt::ShiftModifier &&event->key()==Qt::Key_X)
        {
            setAxisYZ();
        }
        if(event->modifiers() & Qt::ShiftModifier &&event->key()==Qt::Key_Y )
        {
            setAxisXZ();
        }
        if(event->modifiers() & Qt::ShiftModifier && event->key()==Qt::Key_Z )
        {
            setAxisXY();
        }
        if(event->modifiers() & Qt::ShiftModifier && event->key()==Qt::Key_S)
        {
            setAxisScreen();
        }
        if(event->modifiers() & Qt::ShiftModifier && event->key()==Qt::Key_W)
        {
            setAxisUniform();
        }
    }


    virtual void drawGizmo()
    {
        if(currentSelection->size()>0)
        {
            gizmo->drawGizmo(PV,parentWidget);
        }
    }

    virtual void computePivot()
    {
        //The standard rotation matrices pivot the object
        //about an axis through the origin
        //what if we want the pivot to some where else
        //the following transformation performs a
        //z-axis rotation pivoted at point P

        // M = T(P) * Rz( angle) * T(-P)
    }

    virtual void drawPivot()
    {

    }



signals:

    void setSelectChanged();
    void setMoveChanged();
    void setRotationChanged();
    void setScaleChanged();
    void setPivotChanged();

public slots:

    void setSelect()
    {
        TransformMode = NONE;
        PlaneAXesMode = XYZ_NONE;

        gizmo = new GizmoController(currentSelection,this);

        gizmo->setTransformMode(TransformMode);

        gizmo->setAxesAndPlanes(PlaneAXesMode);

        qDebug()<<"Selection Mode set";
        emit setSelectChanged();
    }
    void setMove()
    {
        TransformMode = MOVE;
        PlaneAXesMode = ZX;

        gizmo = gizmoMove;

        gizmo->setTransformMode(TransformMode);
        gizmo->setAxesAndPlanes(ZX);

        qDebug()<<"Move Mode set";
        emit setMoveChanged();
    }
    void setRotation()
    {
        TransformMode = ROTATION;
        PlaneAXesMode = Y;

        gizmoRotation->setTransformMode(TransformMode);
        gizmoRotation->setAxesAndPlanes(Y);

        gizmo = gizmoRotation;

        qDebug()<<"Rotation Mode set";
        emit setRotationChanged();
    }
    void setScale()
    {
        TransformMode = SCALE;
        PlaneAXesMode = UNIFORM;

        gizmoScale->setTransformMode(TransformMode);
        gizmoScale->setAxesAndPlanes(UNIFORM);

        gizmo = gizmoScale;

         qDebug()<<"Scale Mode set";
        emit setScaleChanged();
    }
    void setPivot()
    {
        qDebug()<<"Pivot Mode set";
        emit setPivotChanged();
    }
    void setFreeze()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);


    }

    void setAxisX()
    {
        PlaneAXesMode = X;
        printf("Perform selection X-Axis \n");

    }
    void setAxisY()
    {
        PlaneAXesMode = Y;
        printf("Perform selection Y-Axis \n");

    }
    void setAxisZ()
    {
        PlaneAXesMode = Z;

        printf("Perform selection Z-Axis \n");
    }

    void setAxisYZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = YZ;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = X;
        }

        printf("Perform selection YZ-plane \n");

    }
    void setAxisXZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = ZX;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Y;
        }
        printf("Perform selection ZX-plane \n");

    }
    void setAxisXY()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = XY;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Z;
        }

        printf("Perform selection XY-plane \n");


    }
    void setAxisUniform()
    {
         PlaneAXesMode = UNIFORM;

         printf("Perform selection SCREEN-Plane \n");


    }
    void setAxisScreen()
    {
         PlaneAXesMode = SCREEN;

         printf("Perform selection SCREEN-Plane \n");


    }

};








#endif // HANDLES_HPP
