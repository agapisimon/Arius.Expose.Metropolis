#ifndef CURVES_HPP
#define CURVES_HPP

#include <QtWidgets>
#include <QtOpenGL>
#include <QGLWidget>
#include <GL/glu.h>


class QCurvePoint3D
{
    public:

    QVector3D C0;
         QVector3D left;

         QVector3D P;

         QVector3D right;
         QVector3D C1;

         QCurvePoint3D(QVector3D p)
         {
            P = p;

            right = QVector3D(0,0,1);
            left = QVector3D(0,0,-1);

            C0 = P + left;
            C1 = P + right;
         }

         QCurvePoint3D()
         {
            P = QVector3D(0.0,0.0,0.0);

            right = QVector3D(0.0,0.0,1.0);
            left  = QVector3D(0.0,0.0,-1.0);

            C0 = P + left;
            C1 = P + right;
         }

         void offsetPoint(QVector3D delta)
         {
             P  += delta;

             C0 += delta;
             C1 += delta;

             left = C0 -P;
             right = C1 -P;
         }

         void setPoint(QVector3D p)
         {
             P = p;

             right = QVector3D(0.0,0,1);
             left  = QVector3D(0.0,0,-1);

             C0 = P + left;
             C1 = P + right;
         }

         void rotateHandle()
         {
             QVector3D dir  = C1-C0;
             /*
             QVector3D dir = target-pos;
             QQuaternion u = QQuaternion::fromAxisAndAngle(QVector3D(0,1,0),-1*delta.x());
             QQuaternion v = QQuaternion::fromAxisAndAngle(QVector3D(1,0,0),-1*delta.y());
             QVector3D newDir   = u.rotatedVector(dir);
             QVector3D finalDir = v.rotatedVector(newDir);

             pos = target- finalDir;
             */
         }
};

class QCurve3D: public QObject
{
         Q_OBJECT

         QColor lightcyan;

         QList<QVector3D> allpoints;

         QList<QCurvePoint3D> points;

         QTimer timer;

         int count =0;

         int numVerticesAroundCurve;

         float profileRadius;

public:

         QCurve3D(QObject * parent): QObject(parent)
         {
             lightcyan = QColor(9,232,214);

             QCurvePoint3D p;
             p.setPoint(QVector3D(0.0,0.0,0.0));
             points.append(p);


             QCurvePoint3D p1;
             p1.setPoint(QVector3D(0.0,2.0,1.0));
             points.append(p1);

             QCurvePoint3D p3;
             p3.setPoint(QVector3D(0.0,0.0,3.0));
             points.append(p3);


             QCurvePoint3D p4;
             p4.setPoint(QVector3D(0.0,3.0,4.0));
             points.append(p4);


             QCurvePoint3D p5;
             p5.setPoint(QVector3D(2.0,0.0,2.0));
             points.append(p5);

             QCurvePoint3D p6;
             p6.setPoint(QVector3D(0.5,0.0,0.1));
             points.append(p6);

             numVerticesAroundCurve = 6;

         }

         QVector3D bezierInterpolate3D(qreal t, const QVector3D &P0, const QVector3D &P1, const QVector3D &P2, const QVector3D &P3)
         {
             //cubic bezier curves
             //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

             qreal c0 = pow((1 - t), 3);

             qreal c1 = 3 * t * (1 - t) * (1 - t);
             qreal c2 = 3 * t * t * (1 - t);

             qreal c3 = pow(t, 3);

             qreal x = P0.x() * c0 + P1.x() * c1 + P2.x() * c2 + P3.x() * c3;
             qreal y = P0.y() * c0 + P1.y() * c1 + P2.y() * c2 + P3.y() * c3;
             qreal z = P0.z() * c0 + P1.z() * c1 + P2.z() * c2 + P3.z() * c3;

             QVector3D P(x,y,z);

             return P;
         }



         void getAllInterpolatedPoints(const int & resolution)
         {
             for(int i=0;i<points.length()-1;i++)
             {
                 QCurvePoint3D v = points[i];
                 QCurvePoint3D u = points[i+1];

                 QVector3D P0 = v.P;
                 QVector3D P1 = v.C1;
                 QVector3D P2 = u.C0;
                 QVector3D P3 = u.P;

                 //cubic bezier curves
                 //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

                 qreal step = (qreal)1 / resolution;

                 for(int i=0;i<(resolution + 1);i++)
                 {
                    qreal t = i * step;

                    QVector3D p = bezierInterpolate3D(t, P0, P1, P2, P3);

                    allpoints.append(p);
                 }
             }
         }

         void computeBTN()
         {/*
             QVector3D p0 = allpoints[0];


             for(short j=0;j<allpoints.size();j++)
             {
                 for(short i=0;i<numVerticesAroundCurve;i++)
                 {
                     float rotAngle =i* 2* M_PI / numVerticesAroundCurve ;

                     QMatrix4x4 M = rotateAroundAxis(tangents[j],rotAngle);

                     QVector3D rotatedNormal = M * normals[j];

                     generatedPositions.add(positions[j] + rotatedNormal * radius);
                     generatedNormals.add(rotatedNormal);
                 }
             }
             */
         }

         /*

         void clearAllPoints()
         {
             //allpoints.clear();
         }

         void addPoints(QList<QVector3D> _points)
         {
             points.clear();

             foreach (QVector3D v, _points)
             {
                 CurvePoint3D p;

                 p.setPoint(v);

                 points.append(p);
             }
         }

         void addPoints(QList<CurvePoint3D> _curvepoints)
         {
             points.clear();

             foreach (CurvePoint3D v, _curvepoints)
             {
                 points.append(v);
             }
         }

         void clearPoints()
         {
             points.clear();
         }

         void addPoint(QVector3D p)
         {
             CurvePoint3D c;
             c.setPoint(p);
             points.append(c);
         }

         void getPointAT(qreal t)
         {

         }


         QList<QVector3D> BezierSpecial(QVector3D A, QVector3D B,int resolution=25)
         {
             QVector3D P0 = A;
             QVector3D P1 = QVector3D(0, 0,0);
             QVector3D P2 = QVector3D(0, 0,0);
             QVector3D P3 = B;

             QVector3D vec = B-A;

             qreal offset = 35;

             qreal dx = qMax(offset, vec.x());
             qreal dy = qMax(offset, vec.y());
             qreal dz = qMax(offset, vec.z());

             //cubic bezier curves
             //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

             //d/dx of(P(t))


             qreal step = (qreal)1 / resolution;



             for(int i=0;i<(resolution + 1);i++)
             {
                qreal t = i * step;

                QVector3D p = bezierInterpolate3D(t, P0, P1, P2, P3);

                 points.append(p);
             }

             return points;
         }



         void drawCurve3D(Curve3D _curve)
         {
             glBegin(GL_LINES);

             glColor3f(lightcyan[0]/255,lightcyan[1]/255,lightcyan[2]/255);

             foreach(QVector3D v, _curve.getAllInterpolatedPoints())
             {
                 glVertex3f(v.x(),v.y(),v.z());
             }

             glEnd();

         }
         */


         void  selectControlPoints()
         {
           for(int i=0;i<points.length();i++)
           {
               glColor3f(0,255,0);

               QVector3D v = points[i].P;

               glLoadName(i);
               glBegin(GL_POINTS);
               glVertex3f(v.x(),v.y(),v.z());
               glEnd();
           }
         }

         void drawControlPoints()
         {
             glEnable(GL_POINT_SMOOTH);
             glPointSize(10);
             glBegin(GL_POINTS);
             float ligthorange[3] = {225,177,109};

             for(int i=0;i<points.length();i++)
             {
                 glColor3f((qreal)ligthorange[0]/255,(qreal)ligthorange[1]/255,(qreal)ligthorange[2]/255);

                 QVector3D v = points[i].P;
                 glVertex3f(v.x(),v.y(),v.z());
                 //qDebug()<<"vertex"<<v;
             }

             glEnd();
             glDisable(GL_POINT_SMOOTH);
         }

         void drawHandles()
         {
             glPointSize(5);
             glBegin(GL_POINTS);

             for(int i=0;i<points.length();i++)
             {
                QVector3D v = points[i].C0;
                QVector3D u = points[i].C1;

                glColor3f((qreal)200/255,(qreal)200/255,(qreal)200/255);

                glVertex3f(v.x(),v.y(),v.z());
                glVertex3f(u.x(),u.y(),u.z());
             }

             glEnd();

             glBegin(GL_LINES);

             for(int i=0;i<points.length();i++)
             {
                QVector3D v = points[i].C0;
                QVector3D u = points[i].C1;

                glColor3f((qreal)100/255,(qreal)232/255,(qreal)214/255);

                glVertex3f(v.x(),v.y(),v.z());
                glVertex3f(u.x(),u.y(),u.z());
             }

             glEnd();

         }

         void drawCurveStrip()
         {
             glBegin(GL_LINE_STRIP);

             //for(int i=0;i<allpoints.length();i++)
             for(int i=0;i<count;i++)
             {
                 QVector3D v = allpoints[i];

                 glColor3f((qreal)9/255,(qreal)232/255,(qreal)214/255);

                 glVertex3f(v.x(),v.y(),v.z());
             }

             glEnd();

             if(count<allpoints.length())
                 count += 1;
             else
                 count =0;

             //qDebug()<<"finished Drawing Curve";
         }

         void drawCurve3D()
         {
             int resolution = 50;

             if(allpoints.length()==0)
                 getAllInterpolatedPoints(resolution);

             drawCurveStrip();

             drawHandles();

             drawControlPoints();
         }
};



#endif // CURVES_HPP

