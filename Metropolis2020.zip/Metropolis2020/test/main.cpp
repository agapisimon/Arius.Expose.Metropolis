#include<QtGui>
#include<../globals.hpp>
#include<../widgets.hpp>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    QWidget w;
    QVBoxLayout * layout = new QVBoxLayout;

    QIntWidget * v1 = new QIntWidget;
    v1->setText(QString("V1"));
    v1->setMinMaxValue(0,100,1,1);
    QIntWidget * v2 = new QIntWidget;
    v2->setText(QString("V2"));
    v2->setMinMaxValue(0,100,1,1);
    QIntWidget * v3 = new QIntWidget;
    v3->setText(QString("V3"));
    v3->setMinMaxValue(0,100,1,1);

    layout->addWidget(v1);
    layout->addWidget(v2);
    layout->addWidget(v3);
    w.setLayout(layout);

    w.show();

    return a.exec();
}
