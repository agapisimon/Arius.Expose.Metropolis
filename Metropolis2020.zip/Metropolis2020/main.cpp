#include<QtWidgets>

#include<metropolis.hpp>
#include<metropolismainwindow.hpp>

class QColorWheel : public QWidget
{
    Q_OBJECT
public:
    QImage m_image;

    QColor m_color;

    QSize m_initialSize;

    QPoint m_lastPoint;

    int m_margin;
    int m_sliderWidth;

    QRegion m_wheelRegion;
    QRegion m_sliderRegion;

    bool m_isInWheel;
    bool m_isInSquare;
    bool m_isMouseDown;



    QSize sizeHint()
    {
        return QSize(height(),height());
    }

    QSize minimumSizeHint()
    {
        return QSize(100, 100);
    }

    QColor color()
    {
        return m_color;

    }

    void setColor( QColor & color)
    {

        m_color = color;
    }

    int wheelSize()
    {
        return qMin(width() - m_sliderWidth, height());

    }

    QColor colorForPoint(QPoint & point)
    {
        if (! m_image.valid(point)) return QColor();
            if (m_isInWheel) {
                qreal w = wheelSize();
                qreal xf = qreal(point.x()) / w;
                qreal yf = 1.0 - qreal(point.y()) / w;
                qreal xp = 2.0 * xf - 1.0;
                qreal yp = 2.0 * yf - 1.0;
                qreal rad = qMin(hypot(xp, yp), 1.0);
                qreal theta = qAtan2(yp, xp);
                theta -= 105.0 / 360.0 * 2.0 * M_PI;
                if (theta < 0.0)
                    theta += 2.0 * M_PI;
                qreal hue = (theta * 180.0 / M_PI) / 360.0;
                return QColor::fromHsvF( hue, rad, m_color.valueF() );
            }
            if (m_isInSquare) {
                qreal value = 1.0 - qreal(point.y() - m_margin) / (wheelSize() - m_margin * 2);
                return QColor::fromHsvF( m_color.hueF(), m_color.saturationF(), value);
            }
            return QColor();
    }




    QColorWheel(QWidget *parent =0): QWidget(parent)
    {
        m_initialSize = QSize(300,300);
        this->m_isMouseDown = false;
        this->m_margin =5;
        this->m_sliderWidth = 30;

        this->m_color = QColor(Qt::white);
        this->m_isInWheel = false;
        this->m_isInSquare = false;

        resize(m_initialSize);
        setMinimumSize(100,100);
        setMaximumSize(m_initialSize);

        setCursor(Qt::CrossCursor);



    }






public:


    void drawWheel()
    {

        int r = wheelSize();
        QPainter painter(&m_image);
        painter.setRenderHint(QPainter::Antialiasing);
        m_image.fill(0); // transparent

        QConicalGradient conicalGradient;
        conicalGradient.setColorAt(        0.0, Qt::red);
        conicalGradient.setColorAt( 60.0/360.0, Qt::yellow);
        conicalGradient.setColorAt(135.0/360.0, Qt::green);
        conicalGradient.setColorAt(180.0/360.0, Qt::cyan);
        conicalGradient.setColorAt(240.0/360.0, Qt::blue);
        conicalGradient.setColorAt(315.0/360.0, Qt::magenta);
        conicalGradient.setColorAt(        1.0, Qt::red);

        QRadialGradient radialGradient(0.0, 0.0, r/2);
        radialGradient.setColorAt(0.0, Qt::white);
        radialGradient.setColorAt(1.0, Qt::transparent);

        painter.translate(r / 2, r / 2);
        painter.rotate(-105);

        QBrush hueBrush(conicalGradient);
        painter.setPen(Qt::NoPen);
        painter.setBrush(hueBrush);
        painter.drawEllipse(QPoint(0, 0), r/2-m_margin, r/2-m_margin);

        QBrush saturationBrush(radialGradient);
        painter.setBrush(saturationBrush);
        painter.drawEllipse(QPoint(0, 0), r/2-m_margin, r/2-m_margin);

        m_wheelRegion = QRegion(r/2, r/2, r-2*m_margin, r-2*m_margin, QRegion::Ellipse);
        m_wheelRegion.translate(-(r-2*m_margin)/2, -(r-2*m_margin)/2);
    }

    void drawWheelDot(QPainter & painter)
    {
        int r = wheelSize() / 2;
           QPen pen(Qt::white);
           pen.setWidth(2);
           painter.setPen(pen);
           painter.setBrush(Qt::black);
           painter.translate(r, r);
           painter.rotate(360.0 - m_color.hue());
           painter.rotate(-105);
       //    r -= margin;
           painter.drawEllipse(QPointF(m_color.saturationF() * r, 0.0), 4, 4);
           painter.resetTransform();
    }

    void drawSliderBar(QPainter & painter)
    {
        qreal value = 1.0 - m_color.valueF();
           int ws = wheelSize();
           qreal scale = qreal(ws + m_sliderWidth) / maximumWidth();
           int w = m_sliderWidth * scale;
           int h = ws - m_margin * 2;
           QPen pen(Qt::white);
           pen.setWidth(2);
           painter.setPen(pen);
           painter.setBrush(Qt::black);
           painter.translate(ws, m_margin + value * h);
           painter.drawRect(0, 0, w, 4);
           painter.resetTransform();
    }

    void drawSlider()
    {
        QPainter painter(&m_image);
           painter.setRenderHint(QPainter::Antialiasing);
           int ws = wheelSize();
           qreal scale = qreal(ws + m_sliderWidth) / maximumWidth();
           int w = m_sliderWidth * scale;
           int h = ws - m_margin * 2;
           QLinearGradient gradient(0, 0, w, h);
           gradient.setColorAt(0.0, Qt::white);
           gradient.setColorAt(1.0, Qt::black);
           QBrush brush(gradient);
           painter.setPen(Qt::NoPen);
           painter.setBrush(brush);
           painter.translate(ws, m_margin);
           painter.drawRect(0, 0, w, h);
           m_sliderRegion = QRegion(ws, m_margin, w, h);
    }




    void mousePressEvent(QMouseEvent * event)
    {
        m_lastPoint = event->pos();
           if (m_wheelRegion.contains(m_lastPoint)) {
               m_isInWheel = true;
               m_isInSquare = false;
               QColor color = colorForPoint(m_lastPoint);
               changeColor(color);
           } else if (m_sliderRegion.contains(m_lastPoint)) {
               m_isInWheel = false;
               m_isInSquare = true;
               QColor color = colorForPoint(m_lastPoint);
               changeColor(color);
           }
           m_isMouseDown = true;
    }

    void mouseMoveEvent(QMouseEvent * event)
    {
        m_lastPoint = event->pos();
            if (!m_isMouseDown) return;
            if (m_wheelRegion.contains(m_lastPoint) && m_isInWheel) {
                QColor color = colorForPoint(m_lastPoint);
                changeColor(color);
            } else if(m_sliderRegion.contains(m_lastPoint) && m_isInSquare) {
                QColor color = colorForPoint(m_lastPoint);
                changeColor(color);
            }
    }

    void mouseReleaseEvent(QMouseEvent * event)
    {
        Q_UNUSED(event)
            m_isMouseDown = false;
            m_isInWheel = false;
            m_isInSquare = false;
    }

    void resizeEvent(QResizeEvent * event)
    {
        m_image = QImage(event->size(), QImage::Format_ARGB32_Premultiplied);
           m_image.fill(palette().background().color().rgb());

           drawWheel();
           drawSlider();
           update();
    }

    void paintEvent(QPaintEvent * event)
    {
        Q_UNUSED(event)
           QPainter painter(this);
       //    QStyleOption opt;
       //    opt.init(this);
           painter.setRenderHint(QPainter::Antialiasing);
           painter.drawImage(0, 0, m_image);
           drawWheelDot(painter);
           drawSliderBar(painter);
       //    style()->drawPrimitive(QStyle::PE_Widget, &opt, &painter, this);

    }

signals:
    void colorChanged(QColor & color);

 public slots:

    void changeColor(QColor & color)
    {
        m_color = color;
        drawWheel();
        drawSlider();
        update();
        emit colorChanged(m_color);
    }
};
//#include"main.moc"
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.setAttribute( Qt::AA_UseDesktopOpenGL );

    qsrand(QDateTime().currentDateTime().time().msec());

    QString filename = QApplication::applicationDirPath() + QString(":/Resources/metropolis splash.png");

    qDebug()<<filename;

    QPixmap pixmap = QPixmap(":/Resources/metropolis splash.png");

    //QColorWheel wheel;
    //wheel.show();


    app.processEvents();


    MetropolisMainWindow * mainwindow = new MetropolisMainWindow;
    mainwindow->showMaximized();
    mainwindow->hide();
    mainwindow->setWindowIcon(QIcon(":/icons/metropolis.svg"));

    //QRect viewport = mainwindow->view3d->view->rect();    

    QSplashScreen *splash = new QSplashScreen(pixmap, Qt::WindowStaysOnTopHint);
    splash->setMask(pixmap.mask());


    QRect viewport = mainwindow->rect();

    int x =  (viewport.width()  - splash->width())*0.5;
    int y =  (viewport.height() - splash->height())*0.5;

    splash->setGeometry(x,y,splash->width(),splash->height());
    splash->show();
    splash->showMessage("Loading Metroplis");


    //SoundWidget s;
    //s.show();

    QTimer::singleShot(50, mainwindow, SLOT(showMaximized()));
    QTimer::singleShot(50, splash, SLOT(show()));
    QTimer::singleShot(10000, splash, SLOT(hide()));

    //mainwindow->showMaximized();

    //splash->finish( mainwindow );

    //delete splash;

    return app.exec();
}
