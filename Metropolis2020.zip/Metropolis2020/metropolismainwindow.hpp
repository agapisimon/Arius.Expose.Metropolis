#ifndef METROPOLISMAINWINDOW_HPP
#define METROPOLISMAINWINDOW_HPP

#include<QtWidgets>
#include<widgets.hpp>
#include<view3d.hpp>
#include<uveditor.hpp>
//#include<sound.hpp>


class MetropolisMainWindow : public QMainWindow
{
    Q_OBJECT

    QDockWidget * TimeLineEditorDoc;
    QDockWidget * nodeEditorDoc;
    QDockWidget * propertiesEditorDoc;
    QDockWidget * ToolBoxEditorDock;
    QDockWidget * scenegraphDock;
    QDockWidget * materialEditorDock;
    QDockWidget * curveEditorDock;
    QDockWidget * libraryEditorDock;
    QDockWidget * uvEditorDock;
    QDockWidget * propertiesTabDock;

    QAction *exitAction;

    About *about;






public:

    //nodeTreeEditor *nodetree;

    QStringList modelsList;

    QSearchEx1 * search;

    QView3D * view;

    QUVeditor * uveditor;

    QOutlinerWidget * outliner;

    //QTabBar * propertiesTab;


    void createLibrary()
    {
        modelsList.append(QString("Airports"));
        modelsList.append(QString("Bridges"));
        modelsList.append(QString("BusStations"));
        modelsList.append(QString("ElectricityLines"));
        modelsList.append(QString("Estates"));
        modelsList.append(QString("Farms"));
        modelsList.append(QString("FibreOpticalLines"));
        modelsList.append(QString("FireStations"));
        modelsList.append(QString("Forest"));
        modelsList.append(QString("GabageManagementStations"));
        modelsList.append(QString("HighSchools"));
        modelsList.append(QString("Hospitals"));
        modelsList.append(QString("Lakes"));
        modelsList.append(QString("Monuments"));
        modelsList.append(QString("NurserySchools"));
        modelsList.append(QString("Parks"));
        modelsList.append(QString("PoliceStations"));
        modelsList.append(QString("PrimarySchools"));
        modelsList.append(QString("PublicLibrary"));
        modelsList.append(QString("Residences"));
        modelsList.append(QString("Roads"));
        modelsList.append(QString("Rocks"));
        modelsList.append(QString("SeweragesPipes"));
        modelsList.append(QString("Stadiums"));
        modelsList.append(QString("Supermarkets"));
        modelsList.append(QString("Terrain"));
        modelsList.append(QString("TrashInsenerators"));
        modelsList.append(QString("Universities"));
        //modelsList.append(QString("Stadiums"));
        modelsList.append(QString("WaterPipes"));
        modelsList.append(QString("Train"));
        modelsList.append(QString("SkyRises"));
        modelsList.sort();
    }

    MetropolisMainWindow(QWidget * parent=0)
    {
        setWindowTitle(QString("Metropolis"));

        setWindowIcon(QIcon(":/icons/metropolis.svg"));

        setFocusPolicy(Qt::ClickFocus);

        about = new About;

        about->hide();

        createLibrary();

        search   = new QSearchEx1(modelsList,this);

        view     = new QView3D(this);

        uveditor = new QUVeditor(view->scenegraph,this);

        setCentralWidget(view);       

        CreateMenue();
        CreateDockWindows();
        CreateStatusBar();
        CreateToolBar();
        setTheme();

        this->showMaximized();

        //this->statusBar()->addWidget(view->scenegraph->progressbar);


        //propertiesTab = new QTabBar;
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Render Settings"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Scene"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Transforms"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Constraints"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Modifiers"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Forces"));
        //propertiesTab->addTab(QIcon(":/icons/metropolis.svg"),QString("Materials"));
        //propertiesTab->show();


    }

    ~MetropolisMainWindow()
    {
        delete TimeLineEditorDoc;
        delete nodeEditorDoc;
        delete propertiesEditorDoc;
        delete ToolBoxEditorDock;
        delete scenegraphDock;
        delete materialEditorDock;
        delete curveEditorDock;
        delete libraryEditorDock;
        //delete nodetree;
        //delete CentralWidget;
        delete exitAction;

        delete uvEditorDock;
    }



    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");


        //QFile file(":/appleseed.qss");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }


        qDebug()<<"Styles Loaded";
    }


    void CreateMenue()
    {
        QKeySequence shortcut;

        QIcon icon(":/icons/metropolis.svg");

        exitAction = new QAction(icon, QString("Exit"), this);
        //exitAction->setShortcut('Ctrl+Q');
        exitAction->setShortcut(shortcut.New);
        exitAction->setStatusTip(QString("Exit application"));
        //self.exitAction.triggered.connect(self.close);

        QMenuBar *menubar = this->menuBar();
        //this->menuBar()->addMenu(QString("&File"));

        QMenu  * fileMenu = menubar->addMenu(QString("&File"));
        QAction *openaction = fileMenu->addAction(icon, QString("Open"));
        fileMenu->addAction(icon, QString("Save"));
        fileMenu->addAction(icon, QString("Save As"));
        QAction *importaction= fileMenu->addAction(icon, QString("Import"));


         fileMenu->addAction(icon, QString("Export"));
         QAction *quitaction= fileMenu->addAction(icon, QString("Quit"));


         QMenu  *HelpMenu = menubar->addMenu(QString("&Help"));

         QAction *aboutaction = HelpMenu->addAction(icon,QString("&About"));
         //QAction *quitaction  = HelpMenu->addAction(icon,QString("&Quit"));
         HelpMenu->addAction(quitaction);

         connect(aboutaction,SIGNAL(triggered(bool)),this,SLOT(closeAbout()));
         connect(quitaction,SIGNAL(triggered(bool)),this,SLOT(close()));
         connect(importaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));
         connect(openaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));

         qDebug()<<"main menues created";
    }

public slots:

    void closeAbout()
    {
        about->showNormal();
    }

    void importDialog()
    {
        QStringList stringlist;
        stringlist.append(QString("Metropolis File (*.metro)"));
        stringlist.append(QString("Mesh File (*.cube *.obj *.md5 *.md2)"));
        stringlist.append(QString("Images (*.png *.xpm *.jpg)"));
        stringlist.append(QString("Vectors Images (*.svg *.pdf *.eps)"));
        stringlist.append(QString("Text files (*.txt)"));
        stringlist.append(QString("XML files (*.xml)"));




        QFileDialog dialog;
        QDir dir;
        dir.entryList(stringlist);

        dialog.setFilter(dir.filter());

        dialog.show();

        QStringList fileNames;

        if (dialog.exec())
        {
            fileNames = dialog.selectedFiles();

            qDebug()<<fileNames;

            statusBar()->showMessage(fileNames[0]);
        }
    }

public:

    void CreateToolBar()
    {

        this->addToolBar(Qt::LeftToolBarArea,view->scenegraph->mainToolBar);

        //this->addToolBar(Qt::RightToolBarArea,view->scenegraph->parametersToolBar);

        this->addToolBar(Qt::TopToolBarArea,view->scenegraph->modelsToolBar);

        this->addToolBar(Qt::BottomToolBarArea,view->scenegraph->lowerToolBar);


        //view3d->search->showMaximized();

        //ToolBoxEditorDock->setWidget(view3d->search->listviewWidget);

    }


    void keyPressEvent(QKeyEvent * event)
    {
        view->keyPressEvent(event);

    }

    void CreateStatusBar()
    {
       this->statusBar()->showMessage("Ready");
    }

    void CreateDockWindows()
    {
        propertiesEditorDoc  = new QDockWidget(QString("Properties Editor"));
        ToolBoxEditorDock    = new QDockWidget(QString("Tool Box"));
        nodeEditorDoc        = new QDockWidget(QString("Node Editor"));
        TimeLineEditorDoc    = new QDockWidget(QString("Time Line"));
        scenegraphDock       = new QDockWidget(QString("Outliner Tree"));
        materialEditorDock   = new QDockWidget(QString("Material Editor"));
        curveEditorDock      = new QDockWidget(QString("Curve Editor"));
        libraryEditorDock    = new QDockWidget(QString("Library"));
        uvEditorDock         = new QDockWidget(QString("UVeditor"));
        //propertiesTabDock  = new QDockWidget(QString("Scene Properties"));

        curveEditorDock->hide();
        materialEditorDock->hide();
        //scenegraphDock->hide();
        ToolBoxEditorDock->hide();
        propertiesEditorDoc->hide();
        nodeEditorDoc->hide();
        //TimeLineEditorDoc->hide();
        libraryEditorDock->hide();
        uvEditorDock->hide();
        //propertiesTabDock->hide();

        propertiesEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        ToolBoxEditorDock->setWindowFlags(Qt::WindowTitleHint );
        nodeEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        TimeLineEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        scenegraphDock->setWindowFlags(Qt::WindowTitleHint );
        materialEditorDock->setWindowFlags(Qt::WindowTitleHint );
        curveEditorDock->setWindowFlags(Qt::WindowTitleHint );
        libraryEditorDock->setWindowFlags(Qt::WindowTitleHint );
        uvEditorDock->setWindowFlags(Qt::WindowTitleHint);
        //propertiesTabDock->setWindowFlags(Qt::WindowTitleHint);

        QWidget * nodeEditor = new QWidget;
        nodeEditor->showMaximized();

        //QWidget * timelinewidget = new QWidget;
        //timelinewidget->showMaximized();

        //QWidget * scenegraphWidget = new QWidget;
        //scenegraphWidget->showMaximized();


        QPropertiesTreeViewWidget *properties = new QPropertiesTreeViewWidget(true);

        //QMainWindow * testwindow =  new QMainWindow;

        //testwindow->setCentralWidget(properties);

        propertiesEditorDoc->setWidget(view->scenegraph->propertiesEditor);
        //propertiesEditorDoc->setWidget(properties);
        //ToolBoxEditorDock->setWidget(view->scenegraph->propertiesEditor);
        //ToolBoxEditorDock->setWidget(new QWidget());
        ToolBoxEditorDock->setWidget(properties);

        nodeEditorDoc->setWidget(nodeEditor);
        //TimeLineEditorDoc->setWidget(timelinewidget);
        TimeLineEditorDoc->setWidget(view->scenegraph->timeline);

        outliner = new QOutlinerWidget(view->scenegraph,this);

        scenegraphDock->setWidget(outliner);

        //this->addToolBar(Qt::BottomToolBarArea,outliner->toolbar);


        libraryEditorDock->setWidget(search);
        uvEditorDock->setWidget(uveditor);
        //propertiesTabDock->setWidget(propertiesTab);


        TimeLineEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea );
        this->addDockWidget(Qt::BottomDockWidgetArea, TimeLineEditorDoc);

        propertiesEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, propertiesEditorDoc);

        ToolBoxEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, ToolBoxEditorDock);

        nodeEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, nodeEditorDoc);

        scenegraphDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, scenegraphDock);

        materialEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, materialEditorDock);

        curveEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, curveEditorDock);

        libraryEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::BottomDockWidgetArea, libraryEditorDock);

        uvEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, uvEditorDock);


        //propertiesTabDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        //this->addDockWidget(Qt::RightDockWidgetArea, propertiesTabDock);

        this->tabifyDockWidget(ToolBoxEditorDock,propertiesEditorDoc);
        this->tabifyDockWidget(propertiesEditorDoc,nodeEditorDoc);
        this->tabifyDockWidget(nodeEditorDoc,scenegraphDock);
        this->tabifyDockWidget(scenegraphDock,materialEditorDock);
        this->tabifyDockWidget(materialEditorDock,curveEditorDock);       
        this->tabifyDockWidget(curveEditorDock,uvEditorDock);
        //this->tabifyDockWidget(uvEditorDock,propertiesTabDock);


        //nodeEditorDock->raise();
        //ToolBoxEditorDock->raise();
        this->setDockOptions(QMainWindow::VerticalTabs);
        this->setTabPosition(Qt::TopDockWidgetArea,QTabWidget::North);

        /*
        nodetree = new nodeTreeEditor;
        propertiesEditorDoc->setWidget(nodetree->propertiesWidget);
        TimeLineEditorDoc->setWidget(nodetree->timeline);
        nodeEditorDoc->setWidget(nodetree);
        */
    }
};





#endif // METROPOLISMAINWINDOW_HPP
