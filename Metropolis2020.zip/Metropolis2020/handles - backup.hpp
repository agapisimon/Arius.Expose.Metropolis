#ifndef HANDLES_HPP
#define HANDLES_HPP

#include<QtGui>
#include<geometry.hpp>
#include<models.hpp>

class QSelectionInfo
{
    QQueue<QBaseModel *> queue;    
public:

    QSelectionInfo(){}

    ~QSelectionInfo()
    {
        qDeleteAll(queue);
    }

    QVector3D getSelectionCenter()
    {
        QVector3D center(0,0,0);

        for(int i=0;i<queue.size();i++)
        {
            QBaseModel * model = queue[i];

            center+= model->position;
        }

        center/= queue.size();

        return center;
    }

    int size()
    {
        return queue.size();
    }


    QBaseModel * getSelectedModel()
    {
        return queue.last();
    }

    QVector<QBaseModel *> getSelectedModels()
    {
        return queue.toVector();
    }


    void addSelectedModel(QBaseModel * model)
    {
        bool found = false;

        foreach(QBaseModel * m,queue.toVector())
        {
            if(m->ID ==model->ID)
            {
                found = true;
            }
        }

        if(found== false)
        {
            queue.append(model);

            qDebug()<<"Selected Models:"<<queue.size();
        }
    }


    void addModels(QList<QBaseModel *>&models)
    {
        if(models.size()>0 && queue.size()==0)
        {
            clearSelection();

            foreach(QBaseModel * m,models)
            {
                queue.append(m);
            }
        }
        else if(queue.size()>0)
        {
            clearSelection();
        }
    }

    void clearSelection()
    {
        //qDeleteAll(queue);
        queue.clear();
    }

};



class HandleController : public QObject
{
    Q_OBJECT

public:

    enum SCREEN_SPACE
    {
        LOCATE_VIEW,
        LOCATE_WORLD,
        LOCATE_LOCAL,
    };

    QTransformMode TransformMode;

    QTrans PlaneAXesMode;

    bool mousePressed;


    QAabb Xbox;
    QAabb Ybox;
    QAabb Zbox;

    QAabb XZbox;
    QAabb YZbox;
    QAabb XYbox;

    QAabb SCREENbox;

    QList<QBaseModel *> models;

    QSelectionInfo * currentSelection;

    QVector3D prevhitpoint;
    QVector3D alternateCenter;

    QVector3D position;
    QVector3D rotation;
    QVector3D scale;

    HandleController(QObject * parent =0):QObject(parent) { }

    ~HandleController()
    {
        delete currentSelection;
    }


    virtual void setTransformMode( QTransformMode & TransformMode)
    {
        this->TransformMode =  TransformMode;
    }
    virtual void setTransPlaneAxes( QTrans & PlaneAXesMode)
    {
        this->PlaneAXesMode =  PlaneAXesMode;
    }
    virtual void setModelsList( QList<QBaseModel *> & models)
    {
        this->models = models;
    }
    virtual void setHitInfo( QSelectionInfo * currentSelectionInfo)
    {
        this->currentSelection = currentSelectionInfo;
    }


    virtual void rayPlaneIntersection(int x, int y)
    {

    }
    virtual void rayBoxAXesIntersection(int x, int y)
    {

    }
    virtual void rayPlaneIntersection(QPoint delta)
    {

    }

    virtual void drawSelectionQAaBB()
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);

        if(mousePressed)
        {
            if(PlaneAXesMode ==X)
            {
                this->Xbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Z)
            {
                this->Zbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Y)
            {
                this->Ybox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==XY)
            {
                this->XYbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==ZX)
            {
                this->XZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==YZ)
            {
                this->YZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==SCREEN)
            {
                this->SCREENbox.draw(Qt::cyan);
            }
        }
        else
        {
            this->Xbox.draw(Qt::cyan);
            this->Zbox.draw(Qt::cyan);
            this->Ybox.draw(Qt::cyan);

            this->XYbox.draw(Qt::cyan);
            this->XZbox.draw(Qt::cyan);
            this->YZbox.draw(Qt::cyan);

            this->SCREENbox.draw(Qt::cyan);
        }

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }
    virtual void screenfactorScale()
    {

    }
    virtual void drawGizmo(QGLWidget* widget)
    {        
    }
};

class HandleMoveController : public HandleController
{
public:

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;

    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleMoveController(QObject * parent): HandleController(parent)
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |(0,0,0)
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //------------------------------

        QVector3D v0 = QVector3D(0,0,0);
        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);

        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);

        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);

        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));

        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));

        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));

        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-0.5,-0.5,-0.5),QVector3D(0.5,0.5,0.5));

        //XZbox.reScale(1.5);
        //XYbox.reScale(1.5);
        //YZbox.reScale(1.5);

        //SCREENbox.reScale(0.05);
    }

    ~HandleMoveController() { }


    QPoint lastP;

    //----- Ray plane intersection--------------------------
    void rayPlaneIntersection(int x,int y)
    {
        QPoint pp(x,y);

        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QPlane plane;
            plane.center = model->position;
            plane.axesAlignment = PlaneAXesMode;

            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
            }
            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
            }
            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
            }

            QRay ray;

            ray.rayCastScene(x,y);//compute direction

            if(PlaneAXesMode==SCREEN)
            {
                plane.normal = (-1.0f * ray.direction);
            }


            QVector3D hitPoint = ray.getRayPlaneIntersection(plane);

            if(ray.hitStatus == 1)
            {
                //printf("Plane Intersection x:%f,y:%f,z:%f \n",hitPoint.x,hitPoint.y,hitPoint.z);

                QVector3D prev = model->position;

                //prev = alternateCenter - prev;

                if(PlaneAXesMode==X)
                {
                    model->position = QVector3D(hitPoint.x(),prev.y(),prev.z());
                }

                if(PlaneAXesMode==Y)
                {
                    model->position = QVector3D(prev.x(),hitPoint.y(),prev.z());
                }

                if(PlaneAXesMode==Z)
                {
                    model->position = QVector3D(prev.x(),prev.y(),hitPoint.z());
                }

                if(PlaneAXesMode==ZX||PlaneAXesMode==XY||PlaneAXesMode==YZ||PlaneAXesMode ==SCREEN)
                {
                    model->position = hitPoint;
                }
            }            
        }
    }
    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D r = model->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);


            bool  intersected = box.intersectRay(view.p0,view.direction);

            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }

            lastP = QPoint(x,y);
        }
    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );
            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);
            glVertex3f(0,0,0);

            glEnd();


            if( TransformMode == MOVE)
            {
                 drawTranslationGizmo(widget);

                 drawSelectionQAaBB();
            }

            glPopMatrix();           

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }

    virtual void drawTranslationGizmo(QGLWidget* widget, bool drawarrows = true)
    {
        QArrow arrow;

        if(drawarrows)
        {
            arrow.drawArrow(XY);
            arrow.drawArrow(ZX);
            arrow.drawArrow(YZ);
        }

        if(axesplanes.size() >0)
        {
            for(int i =0;i<axesplanes.size();i++)
            {
                axesplanes[i].drawPlane();
            }
        }

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);


        glLineWidth(3);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[1].x(),vertices[1].y(),vertices[1].z());

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[2].x(),vertices[2].y(),vertices[2].z());

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[3].x(),vertices[3].y(),vertices[3].z());
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr("X");
        QString ystr("Y");
        QString zstr("Z");

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.3f, 0.0f, 0.0f,xstr,font);

        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.3f, 0.0f,ystr,font);

        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.3f,zstr,font);



        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

};

class HandleScaleController : public HandleController
{
public:

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;


    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleScaleController(QObject * parent):HandleController(parent)
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //----------------------------


        QVector3D v0 = QVector3D(0,0,0);

        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);



        //-----------------------------
        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        //-----------------------------
        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        //-----------------------------
        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);


        //-----------------------------
        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        //-----------------------------
        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        //-----------------------------
        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        //-----------------------------
        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        //-----------------------------


        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);

        //--------------------------------------


        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        //--------------------------------------



        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));

        //--------------------------------------


        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));

        //--------------------------------------



        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));


        //--------------------------------------

        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-.5,-.5,-.5),QVector3D(0.5,0.5,0.5));



        XZbox.reScale();
        XYbox.reScale();
        YZbox.reScale();

    }

    ~HandleScaleController()
    {
        //qDeleteAll(axesplanes);
        //qDeleteAll(vertices);
    }





    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {

            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;

            QPoint p = QCursor::pos();
            QRay view;
            view.rayCastScene(p.x(),p.y());

            QPlane plane;
            plane.center = v;
            plane.axesAlignment = PlaneAXesMode;


            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = X;
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = Y;
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = Z;
            }


            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = ZX;
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = XY;
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
                plane.axesAlignment = YZ;
            }

            if(PlaneAXesMode==SCREEN || PlaneAXesMode==UNIFORM)
            {
                plane.normal = (-1.0f*view.direction);
                plane.axesAlignment = SCREEN;
            }

            QVector3D pScale = model->scale;

            float scale  = QVector2D(delta.x(),delta.y()).length();

            float sign;

            if(delta.x() ==0)
            {
            }
            else
            {
                sign =  (float)delta.x()/fabs((float)delta.x());
            }

            scale *= 0.01f;
            scale *= sign;

            qDebug()<<"Delta Scale:"<<scale<<"sign:"<<sign;

            if(PlaneAXesMode==X)
            {
                model->scale = pScale + QVector3D(1,0,0) *scale;
            }

            if(PlaneAXesMode==Y)
            {
                model->scale = pScale + QVector3D(0,1,0)  *scale;
            }

            if(PlaneAXesMode==Z)
            {
                model->scale = pScale + QVector3D(0,0,1)  *scale;
            }

            if(PlaneAXesMode==ZX)
            {
                model->scale = pScale + QVector3D(1,0,1)  *scale;
            }

            if(PlaneAXesMode==XY)
            {
                model->scale = pScale + QVector3D(1,1,0)  *scale;
            }

            if(PlaneAXesMode==YZ)
            {
                model->scale = pScale + QVector3D(0,1,1)  *scale;
            }

            if(PlaneAXesMode ==SCREEN)
            {
                QVector3D viewDirection = (-1.0f*view.direction);

                model->scale = pScale + viewDirection *scale;
            }

            if(PlaneAXesMode ==UNIFORM)
            {
               model->scale =  pScale + QVector3D(1,1,1)  *scale;

            }

            model->computeBounds();
        }
    }

    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D r = model->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);
            bool  intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }
        }
    }


    void drawScaleGizmo(QGLWidget* widget)
    {
        //sdisk.drawDisk(true,ZX);
        //sdisk.drawDisk(true,XY);
        //sdisk.drawDisk(true,YZ);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(2);


        glBegin(GL_LINES);
            glColor3f(1.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(1.0f, 0.0f, 0.0f);

            glColor3f(0.0f, 1.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 1.0f, 0.0f);

            glColor3f(0.0f, 0.0f, 1.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 1.0f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.0f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.0f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.0f,zstr,font);


        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==SCALE)
            {
                drawScaleGizmo(widget);
                drawSelectionQAaBB();
            }

            glPopMatrix();           

            glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }
    }    
};

class HandleRotationController : public HandleController
{
public:

    QList<QVector3D>YAxisCircle;
    QList<QVector3D>XAxisCircle;
    QList<QVector3D>ZAxisCircle;

    QList<QVector3D>SCREENCircle;

    HandleRotationController(QObject * parent):HandleController(parent)
    {
        mousePressed = false;

        float Count  = 90.0f;

        float radius = 1.0f;

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius*sin(angle);
            float y = 0;
            float z = radius*cos(angle);

            QVector3D p = QVector3D(x,y,z);

            YAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = 0;
            float y = radius * sin(angle);
            float z = radius * cos(angle);

            QVector3D p = QVector3D(x,y,z);

            XAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius * cos(angle);
            float y = radius * sin(angle);
            float z = 0;

            QVector3D p = QVector3D(x,y,z);

            ZAxisCircle.append(p);
        }

        /*

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI * (float)i/Count;

            float x = radius * sin(angle);
            float y = radius * cos(angle);
            float z = 0;

            QVector3D p = QVector3D(x,y,z);

            SCREENCircle.append(p);
        }

        printf("SCREENCircle vertices Count: %i",SCREENCircle.size());

        */

    }


    ~HandleRotationController(){}


    void generateScreenCircle()
    {
        SCREENCircle.clear();

        float Count  = 90.0f;
        float radius = 1.0f;

        QRay ray;
        ray.rayCastScene(100.0f,100.0f);

        QVector3D normal =  QVector3D::crossProduct(QVector3D(0,1,0),ray.direction);

        for(float i=0;i<Count;i+=1)
        {
            float angle      = 360.0f * i/Count;

            QQuaternion quat = QQuaternion::fromAxisAndAngle(ray.direction,angle);

            QVector3D p      = quat.rotatedVector(normal);

            SCREENCircle.append(p);
        }
    }
    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
           QBaseModel * model = currentSelection->getSelectedModel();

           QVector3D prevRotation = model->rotation;

           QVector3D pScale       = model->scale;

           float rot  = QVector2D(delta.x(),delta.y()).length();

           float sign;

           if(delta.x() ==0)
           {
           }
           else
           {
               sign =  (float)delta.x()/fabs((float)delta.x());
           }

           rot *= 0.5f;
           rot *= sign;


           //float length = sqrt(delta.x()*delta.x()+delta.y()*delta.y());


           if(PlaneAXesMode==X)
           {
               model->rotation = prevRotation + QVector3D(0,rot,0);
           }

           if(PlaneAXesMode==Y)
           {
               model->rotation = prevRotation + QVector3D(rot,0,0);
           }

           if(PlaneAXesMode==Z)
           {
                model->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode ==SCREEN)
           {
                //model->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode == TRACKBALL)
           {
               model->rotation = prevRotation + QVector3D(delta.y(),delta.x(),0);

           }
        }
    }

    void rayBoxAXesIntersection(int x,int y)
    {
        float cursorselectionRadius = 0.2f;

        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D p = model->position;

            QRay view;

            view.rayCastScene(x,y);

            QVector3D r = model->rotation;


            QMatrix4x4 rotMat;
            rotMat.setToIdentity();
            rotMat.rotate(r.x(),QVector3D(1,0,0));
            rotMat.rotate(r.y(),QVector3D(0,1,0));
            rotMat.rotate(r.z(),QVector3D(0,0,1));


            foreach( QVector3D v, YAxisCircle)
            {
               QVector3D vert = rotMat*v+p;

               if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
               {
                   PlaneAXesMode = X;

                   mousePressed = true;

                   qDebug()<<"Y-Axis Rotation";

                   return;
               }
            }

            foreach( QVector3D v, XAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Y;

                    mousePressed = true;

                    qDebug()<<"X-Axis Rotation";
                    return;
                }
            }

            foreach( QVector3D v, ZAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Z;                    
                    mousePressed = true;

                    qDebug()<<"Z-Axis Rotation";
                    return;
                }

            }

            /*



            foreach( QVector3D v, SCREENCircle)
            {
                QRay CamView;

                CamView.rayCastScene(x,y);



                QMatrix4x4 m;

                m.setToIdentity();

                m.rotate(QQuaternion(,CamView.direction));

                QVector3D vert = m*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = SCREEN;

                    mousePressed = true;

                    qDebug()<<"SCREEN-Axis Rotation";

                    return;
                }

            }

            */
        }
    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0 && currentSelection->size()>0)
        {
            QBaseModel * model = currentSelection->getSelectedModel();

            QVector3D v = model->position;
            QVector3D s = model->scale;
            QVector3D r = model->rotation;

            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glTranslatef( v.x(), v.y(), v.z() );

            glRotatef(r.x(),1,0,0);
            glRotatef(r.y(),0,1,0);
            glRotatef(r.z(),0,0,1);

            //glScalef( s.x, s.y, s.z );
            glScalef( 1, 1, 1 );

            glBegin(GL_POINTS);

            glVertex3f(0,0,0);

            glEnd();

            if( TransformMode ==ROTATION)
            {
                drawRotationGizmo(widget);
            }

            glPopMatrix();

            /*

            glColor3f( .3, .3, .3 );
            QString str("Pos:(");

            str += QString::number(v.x());str +=QString(",");
            str += QString::number(v.y());str +=QString(",");
            str += QString::number(v.z());str +=QString(")");

            widget->renderText(v.x()-1,v.y(),v.z(),str);

            */

            glEnable(GL_DEPTH_TEST);

            glEnable(GL_LIGHTING);
        }
    }


    void drawRotationGizmo(QGLWidget* widget)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(1);

        if(PlaneAXesMode==Y)
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,0,0),false);
        }


        if(PlaneAXesMode==X)
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(0,1,0),false);

        }


        if(PlaneAXesMode==Z)
        {

            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(0,0,1),false);

        }


        /*

        if(PlaneAXesMode==SCREEN)
        {

            generateScreenCircle();


            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {

            generateScreenCircle();

            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(0,1,1),false);

        }

        */


        glLineWidth(2);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.5f, 0.0f, 0.0f);

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.5f, 0.0f);

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.5f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(0.5f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 0.5f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 0.5f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }

    void drawCirle( QList<QVector3D> &points,
                    QVector3D center = QVector3D(0,0,0),
                    QColor color     = QColor(1,1,1),
                    bool selected   = false,
                    bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);
        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }


        //glEnable(GL_CULL_FACE);

        glBegin(GL_LINE_LOOP);

        for(int i=0;i<points.size();i++)
        {
            QVector3D p = points[i]+center;

            glVertex3f(p.x(),p.y(),p.z());
        }

        glEnd();
        //glDisable(GL_CULL_FACE);


        if(drawPoints)
        {
           glPointSize(2.0f);

           glBegin(GL_POINTS);

           for(int i=0;i<points.size();i++)
           {
               QVector3D p = points[i]+center;

               glVertex3f(p.x(),p.y(),p.z());
           }

           glEnd();
        }
    }

    void drawScreen( QList<QVector3D> &points,
                     QVector3D center = QVector3D(0,0,0),
                     QColor color = QColor(1,1,1),
                     bool selected = false,
                     bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);
        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }

        glBegin(GL_LINE_LOOP);

        for(int i=0;i<points.size();i++)
        {
           QVector3D p =  points[i] + center;

           glVertex3f(p.x(),p.y(),p.z());
        }

        glEnd();
    }
};


class AxesTransformer : public QObject
{
    Q_OBJECT

public:

    HandleController *gizmo,*gizmoMove,*gizmoScale,*gizmoRotation;

    QActionGroup * handlesActiongroups;

    QString feedBack;
    QIcon icon;

    QTrans PlaneAXesMode;
    QTransformMode TransformMode;

    QMenu transformsAxisMenu;
    QMenu transformMenu;

    //QVector3D p0;

    void createActions()
    {
        handlesActiongroups = new QActionGroup(this);

        QAction * b1 = new QAction(QIcon(":/Tools Icons/select.svg"),QString("Select: Shift+G"),this);

        QAction * b2 = new QAction(QIcon(":/Tools Icons/Translate.svg"),QString("Move: Shift+T"),this);
        QAction * b3 = new QAction(QIcon(":/Tools Icons/Scale.svg"),QString("Scale: Shift+R"),this);
        QAction * b4 = new QAction(QIcon(":/Tools Icons/Rotate.svg"),QString("Rotate: Shift+S"),this);
        QAction * b5 = new QAction(QIcon(":/Tools Icons/icon pivot.svg"),QString("set Pivot: Shift+P"),this);

        b1->setCheckable(true); b1->setShortcut(Qt::SHIFT|Qt::Key_G);

        b2->setCheckable(true); b2->setShortcut(Qt::SHIFT|Qt::Key_T);
        b3->setCheckable(true); b3->setShortcut(Qt::SHIFT|Qt::Key_R);
        b4->setCheckable(true); b4->setShortcut(Qt::SHIFT|Qt::Key_S);
        b5->setCheckable(true); b5->setShortcut(Qt::SHIFT|Qt::Key_P);

        connect(b1, SIGNAL(triggered(bool)), this, SLOT(setSelect()));

        connect(b2, SIGNAL(triggered(bool)), this, SLOT(setMove()));
        connect(b3, SIGNAL(triggered(bool)), this, SLOT(setScale()));
        connect(b4, SIGNAL(triggered(bool)), this, SLOT(setRotation()));
        connect(b5, SIGNAL(triggered(bool)), this, SLOT(setPivot()));


        b1->setEnabled(true);
        b1->setChecked(true);

        handlesActiongroups->addAction(b1);

        handlesActiongroups->addAction(b2);
        handlesActiongroups->addAction(b3);
        handlesActiongroups->addAction(b4);
        handlesActiongroups->addAction(b5);

        handlesActiongroups->setExclusive(true);
    }

    void createTransformMenues()
    {
        transformMenu.addAction(icon,QString("Move"),this,SLOT(setMove()),QKeySequence(Qt::Key_T));
        transformMenu.addAction(icon,QString("Rotation"),this,SLOT(setRotation()),QKeySequence(Qt::Key_R));
        transformMenu.addAction(icon,QString("Scale"),this,SLOT(setScale()),QKeySequence(Qt::Key_E));
        transformMenu.addAction(icon,QString("Freeze"),this,SLOT(setFreeze()),QKeySequence(Qt::Key_Q));

        transformMenu.setTitle(QString("Set Transform Mode"));
        transformMenu.setIcon(icon);

        setTheme(transformMenu);

    }

    void createAxisTransformMenues()
    {
        transformsAxisMenu.addAction(icon,QString("X"),this,SLOT(setAxisX()));
        transformsAxisMenu.addAction(icon,QString("Y"),this,SLOT(setAxisY()));
        transformsAxisMenu.addAction(icon,QString("Z"),this,SLOT(setAxisZ()));

        transformsAxisMenu.addAction(icon,QString("XY"),this,SLOT(setAxisXY()));
        transformsAxisMenu.addAction(icon,QString("XZ"),this,SLOT(setAxisXZ()));
        transformsAxisMenu.addAction(icon,QString("YZ"),this,SLOT(setAxisYZ()));

        transformsAxisMenu.addAction(icon,QString("Screen"),this,SLOT(setAxisScreen()));
        transformsAxisMenu.addAction(icon,QString("UNIFORM"),this,SLOT(setAxisUniform()));

        transformsAxisMenu.setTitle(QString("Set Axis Transform Mode"));
        transformsAxisMenu.setIcon(icon);

        setTheme(transformsAxisMenu);
    }


    AxesTransformer(QObject *parent=0):QObject(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        TransformMode = MOVE;
        PlaneAXesMode = ZX;

        feedBack.append("Move:");

        gizmoMove     = new HandleMoveController(parent);
        gizmoScale    = new HandleScaleController(parent);
        gizmoRotation = new HandleRotationController(parent);

        gizmoMove->TransformMode      = TransformMode;
        gizmoScale->TransformMode     = TransformMode;
        gizmoRotation->TransformMode  = TransformMode;

        gizmo = gizmoMove;

        createAxisTransformMenues();
        createTransformMenues();
        createActions();
        //setFeedBack();
    }



    void setTheme(QWidget & widget)
    {
        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           widget.setStyleSheet(style);
        }

        file.close();
    }


    virtual void drawGizmo(QGLWidget * parentWidget)
    {
        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->drawGizmo(parentWidget);            
        }
    }

    virtual void computeGizimo( QList<QBaseModel*> &models,QPoint lastPos,QSelectionInfo * currentSelectionInfo)
    {
        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->mousePressed =  true;

            gizmo->setTransPlaneAxes(PlaneAXesMode);
            gizmo->setHitInfo(currentSelectionInfo);
            gizmo->setModelsList(models);
            gizmo->rayBoxAXesIntersection(lastPos.x(),lastPos.y());
        }
    }

    virtual void gizmoRelease()
    {
        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->mousePressed =  false;
        }
    }

    virtual void getGizmoTransforms(QMouseEvent* event,QPoint delta)
    {
        QPoint c = event->pos();

        if(event->buttons() & Qt::LeftButton  && event->modifiers() & Qt::ShiftModifier)
        {
            //QApplication::desktop()->setCursor(Qt::SizeAllCursor);

            if(!handlesActiongroups->actions()[0]->isChecked())
            {
                if(TransformMode==MOVE||TransformMode==ROTATION)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE)
                {
                    //qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }
            }
        }
        else if(event->buttons() & Qt::LeftButton )
        {
            if(!handlesActiongroups->actions()[0]->isChecked())
            {
                /*
                if(PlaneAXesMode==SCREEN || PlaneAXesMode == UNIFORM)
                {
                    QApplication::desktop()->setCursor(Qt::SizeAllCursor);
                }
                else if(PlaneAXesMode==XYZ_NONE)
                {

                    QApplication::desktop()->setCursor(Qt::ArrowCursor);
                }
                else
                {
                    QApplication::desktop()->setCursor(Qt::BlankCursor);
                }

                //QTextCursor cursor(editor->textCursor());
                //gizmo->rayPlaneIntersection(c.x(),c.y());

                */
                if(TransformMode==MOVE)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE||TransformMode==ROTATION)
                {
                    //qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }


            }
        }
    }

    virtual void setTransformMode(QKeyEvent * event)
    {
        feedBack.clear();

        if(event->key()==Qt::Key_Q)
        {
            setSelect();
        }
        else if(event->key()==Qt::Key_R)
        {
            setRotation();
        }
        else if(event->key()==Qt::Key_T)
        {
            setMove();
        }
        else if(event->key()==Qt::Key_E)
        {
            setScale();
        }
    }

    virtual void setAxisTransformMode(QKeyEvent * event)
    {
        if(event->key()==Qt::Key_X)
        {
           setAxisX();
        }
        if(event->key()==Qt::Key_Y)
        {
            setAxisY();
        }
        if(event->key()==Qt::Key_Z)
        {
            setAxisZ();
        }

        if(event->key()==Qt::Key_S)
        {
            setAxisScreen();
        }
        if(event->key()==Qt::Key_X &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisYZ();
        }
        if(event->key()==Qt::Key_Y &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXZ();
        }
        if(event->key()==Qt::Key_Z &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXY();
        }
        if(event->key()==Qt::Key_W)
        {
            PlaneAXesMode = UNIFORM;

            printf("Perform selection UNIFORM-Plane \n");
        }

        if(!handlesActiongroups->actions()[0]->isChecked())
        {
            gizmo->setTransPlaneAxes(PlaneAXesMode);
        }        
    }

signals:

    void setSelectChanged();
    void setMoveChanged();
    void setRotationChanged();
    void setScaleChanged();

public slots:

    void setSelect()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);

        gizmo = 0;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/select.svg")));

        emit setSelectChanged();
    }

    void setMove()
    {
        TransformMode = MOVE;

        gizmoMove->setTransformMode(TransformMode);

        gizmo = gizmoMove;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Translate.svg")));

        emit setMoveChanged();
    }
    void setRotation()
    {
        TransformMode = ROTATION;

        gizmoRotation->setTransformMode(TransformMode);

        gizmo = gizmoRotation;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Rotate.svg")));

        emit setRotationChanged();
    }
    void setScale()
    {
        TransformMode = SCALE;

        gizmoScale->setTransformMode(TransformMode);

        gizmo = gizmoScale;

        //setFeedBack();

        QApplication::desktop()->setCursor(QCursor(QPixmap(":/Tools Icons/Scale.svg")));

        emit setScaleChanged();
    }

    void setPivot()
    {

    }

    void setFreeze()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);

        //setFeedBack();
    }

    void setAxisX()
    {
        PlaneAXesMode = X;
        printf("Perform selection X-Axis \n");
        //setFeedBack();
    }
    void setAxisY()
    {
        PlaneAXesMode = Y;
        printf("Perform selection Y-Axis \n");
        //setFeedBack();
    }
    void setAxisZ()
    {
        PlaneAXesMode = Z;

        printf("Perform selection Z-Axis \n");
        //setFeedBack();
    }

    void setAxisYZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = YZ;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = X;
        }

        printf("Perform selection YZ-plane \n");
        //setFeedBack();
    }
    void setAxisXZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = ZX;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Y;
        }
        printf("Perform selection ZX-plane \n");
        //setFeedBack();
    }
    void setAxisXY()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = XY;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Z;
        }

        printf("Perform selection XY-plane \n");
        //setFeedBack();

    }
    void setAxisUniform()
    {
         PlaneAXesMode = UNIFORM;

         printf("Perform selection SCREEN-Plane \n");
         //setFeedBack();

    }
    void setAxisScreen()
    {
         PlaneAXesMode = SCREEN;

         printf("Perform selection SCREEN-Plane \n");

         //setFeedBack();
    }

};


#endif // HANDLES_HPP
