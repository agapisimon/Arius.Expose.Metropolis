#ifndef DEFORMERS_HPP
#define DEFORMERS_HPP


#include<QtWidgets>

enum QDeformerTypes
{
    DEFORMER_BASE,
    DEFORMER_BEND,
    DEFORMER_TWIST,
    DEFORMER_WAVE,
    DEFORMER_SPLINE,
    DEFORMER_PATH,
    DEFORMER_NOISE,
    DEFORMER_TEXTURE,
    DEFORMER_DISPLACEMENT,
};


class QBaseDeformer: public QObject
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_BASE};

    virtual int type() const  { return Type; }

    QBaseDeformer(QObject * parent =0): QObject(parent)
    {

    }

    virtual void computeDeformer()
    {

    }
};

class QBendDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_BEND};

    virtual int type() const  { return Type; }

    QBendDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QTwistDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_TWIST};

    virtual int type() const  { return Type; }

    QTwistDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QWaveDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_WAVE};

    virtual int type() const  { return Type; }

    QWaveDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QSplineDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_SPLINE};

    virtual int type() const  { return Type; }

    QSplineDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QPathDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_PATH};

    virtual int type() const  { return Type; }

    QPathDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QNoiseDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_NOISE};

    virtual int type() const  { return Type; }

    QNoiseDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QTextureDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_TEXTURE};

    virtual int type() const  { return Type; }

    QTextureDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};

class QDisplacementDeformer: public QBaseDeformer
{
    Q_OBJECT

public:

    enum { Type = DEFORMER_DISPLACEMENT};

    virtual int type() const  { return Type; }

    QDisplacementDeformer(QObject * parent =0): QBaseDeformer(parent)
    {

    }

    void computeDeformer()
    {

    }
};


#endif // DEFORMERS_HPP
