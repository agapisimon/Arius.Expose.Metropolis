#ifndef UVEDITOR_HPP
#define UVEDITOR_HPP

#include<QtOpenGL>
#include<QGLWidget>
#include<GL/gl.h>
#include<GL/glu.h>

#include<scene.hpp>



class QUVeditor :  public QGLWidget
{
    Q_OBJECT

public:

    QToolBar * uvToolBar;

    QImage texture;

    QSceneGraph *scenegraph;

    QSize minimumSizeHint() const
    {
        return QSize(50, 50);
    }

    QSize sizeHint() const
    {
        return QSize(width(),height());
    }

    void resizeGL(int width, int height)
    {
       if (height==0)									// Prevent A Divide By Zero By
       {
           height=1;										// Making Height Equal One
       }

       glViewport(0,0,width,height);// Reset The Current Viewport

       updateGL();
    }

    void initializeGL()
    {
        QColor m_backgroundColor(Qt::gray);

        glClearColor(m_backgroundColor.redF(),m_backgroundColor.greenF(),m_backgroundColor.blueF(),m_backgroundColor.alphaF());
        // Depth Buffer Setup

        glClearDepth(1.0f);
    }

    QUVeditor(QSceneGraph *pscenegraph=0, QWidget * parent=0) : QGLWidget(parent)
    {
        setAcceptDrops(true);

        setWindowTitle(QString("UV Editor"));

        //setFormat(QGLFormat(QGL::SampleBuffers));

        QGLFormat format;
        format.setVersion(4, 5);
        format.setOption(QGL::SampleBuffers);
        format.setProfile(QGLFormat::CompatibilityProfile);
        format.setSwapInterval(0);

        setFormat(format);

        this->scenegraph = pscenegraph ;

        setFocusPolicy(Qt::ClickFocus);
    }

    ~QUVeditor()
    {
        delete scenegraph;
    }

    virtual void drawGrid()
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        //QMatrix4x4 PVM   = PV;

        //qMultMatrix(PVM);


        float divisions = scenegraph->floorParameters->divisions;
        float step      = scenegraph->floorParameters->step;

        float scale     = divisions * step;
        float halfscale =  0.5 * scale;

        if(scenegraph->floorParameters->showGrid ==true)
        {
            //glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glColor4f(.3f,.3f,.3f,.2f );

            glLineWidth(2);

            float x1 =  divisions * step  * 0.5;
            float y1 =  0;
            //float z1 =  0;

            float x2 =  divisions * step  * -0.5;
            float y2 =  0;
            //float z2 =  0;

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            //glColor4f(1.0f,0.0f,1.0f,0.2f);

            glColor4f( 1, 0, 0,1.0f  );

            glBegin( GL_LINES );
            //glVertex3f(x1, y1, z1);
            //glVertex3f(x2, y2, z2);

            glVertex2f(x1, y1);
            glVertex2f(x2, y2);

            glEnd( );



            x1 =  0;
            y1 =  divisions * step  * 0.5;
            //z1 =  0;

            x2 =  0;
            y2 =  divisions * step  * -0.5;
            //z2 =  0;


            glColor4f( 0, 0, 1 ,1.0f );
            glBegin( GL_LINES );
            //glVertex3f(x1, y1, z1);
            //glVertex3f(x2, y2, z2);
            glVertex2f(x1, y1);
            glVertex2f(x2, y2);
            glEnd( );

            //parentWidget->renderText(x1,y1,z1,QString("Z-axis"));

            glPushMatrix( );

            glTranslatef(-halfscale,0,-halfscale);
            glLineWidth(1);
            glColor4f( .1, .1, .1,.2f  );
            glBegin( GL_LINES );

            for (float i=0;i<divisions+1;i+= 1)
            {
                float x =  i * step;
                float y =  0;
                //float z =  0;

                //glVertex3f( x, y,  z  );

                glVertex2f( x, y);

                x =  i * step;
                y =  divisions * step;
               // z =  0;

                //glVertex3f( x, y, z  );
                glVertex2f( x, y );
            }

            for (float i=0;i<divisions+1;i+= 1)
            {
                float x =  0;
                float y =  i * step;
                //float z =  i * step;


                //glVertex3f( x, y,  z  );
                glVertex2f( x, y );

                x =  divisions * step;
                y =  i * step;
                //z =  0;

                //glVertex3f( x, y, z  );
                glVertex2f( x, y  );
            }


            glEnd( );

            glDisable(GL_BLEND);

            glPopMatrix( );

            //glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);

        }


        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    virtual void drawTexureImage()
    {

    }

    virtual void drawUVSurface(QBaseModel * model)
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        if(model->edges.size()>0&&model->texcoords.size()>0&&model->indices.size()>0)
        {
            glEnable(GL_DEPTH_TEST);

            QColor edgeColor(Qt::cyan);

            glColor4f(edgeColor.redF(),edgeColor.greenF(),edgeColor.blueF(),.2f );

            glLineWidth(2);

            glEnable(GL_BLEND);

            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

            for(int i =0;i<model->indices.size();i+=4)
            {
                glBegin(GL_QUADS);

                QVector2D uv = model->texcoords[i];

                glVertex2f(uv.x(),uv.y());

                uv = model->texcoords[i+1];

                glVertex2f(uv.x(),uv.y());

                uv = model->texcoords[i+2];

                glVertex2f(uv.x(),uv.y());

                uv = model->texcoords[i+3];

                glVertex2f(uv.x(),uv.y());

                glEnd();
            }

            glDisable(GL_BLEND);

            glDisable(GL_DEPTH_TEST);
        }


        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();

    }

    virtual void drawUVEdges(QBaseModel * model)
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        if(model->edges.size()>0&&model->texcoords.size()>0)
        {
            glDisable(GL_LIGHTING);

            glEnable(GL_DEPTH_TEST);

            glLineWidth(2);

            for(int i =0;i<model->edges.size();i+=4)
            {
                int index0 =  model->edges[i];
                int index1 =  model->edges[i+1];
                int index2 =  model->edges[i+2];
                int index3 =  model->edges[i+3];

                glBegin(GL_LINES);

                QVector2D v = model->texcoords[index0];

                glVertex2f(v.x(),v.y());

                v = model->texcoords[index1];

                glVertex2f(v.x(),v.y());

                v = model->texcoords[index2];

                glVertex2f(v.x(),v.y());

                v = model->texcoords[index3];

                glVertex2f(v.x(),v.y());

                glEnd();
            }


            /*

            glEnableClientState(GL_VERTEX_ARRAY);
            glEnable(GL_COLOR_MATERIAL);

            //QColor Ccyan(71,206,218);

            //QColor edgeColor(Qt::cyan);
            //QColor edgeColor(Qt::magenta);
            //QColor edgeColor(Qt::green);
            //QColor edgeColor(Qt::darkGreen);

            //QColor edgeColor(Qt::gray);
            //QColor edgeColor(Qt::black);
            //QColor edgeColor(Qt::white);

            QColor edgeColor(Qt::darkBlue);
            //QColor edgeColor(Qt::yellow);

            //QColor edgeColor(Ccyan);

            glColor3f(edgeColor.redF(),edgeColor.greenF(),edgeColor.blueF());
            glLineWidth(2);

            //glVertexPointer(3, GL_FLOAT, 0, (float*)vertices.constData());
            glVertexPointer(2, GL_FLOAT, 0, (float*)model->texcoords.constData());

            glDrawElements(GL_LINES, model->edges.size(), GL_UNSIGNED_INT, model->edges.constData());

            glDisable(GL_COLOR_MATERIAL);
            glDisableClientState(GL_VERTEX_ARRAY);
            */

            glDisable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);
        }


        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    virtual void drawSafeTitleRectangle()
    {
        float w =  rect().width();

        float h =  rect().height();

        float aspect = (float)w / h;

        float s = .75;

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);


        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);

        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    virtual void drawUVs()
    {
        if(scenegraph->selectionInfo->size()>0)
        {
            QBaseModel * model = scenegraph->selectionInfo->getSelectedModel();

            if(model->type() == MODEL_BASE||
               model->type() == MODEL_CAMERA_FREE||
               model->type() == MODEL_LOCATION||
               model->type() == MODEL_CAMERA_TARGET||
               model->type() == MODEL_GROUP||
               model->type() == MODEL_SVG||
               model->type() == MODEL_IVY||
               model->type() == MODEL_LIGHT||
               model->type() == MODEL_PARTICLES||
               model->type() == MODEL_SPLINE)
            {
                return;
            }
            else
            {

                drawUVSurface(model);

                drawUVEdges(model);
            }
        }
    }


    void paintGL()
    {
        if(scenegraph->floorParameters->enableMultisample ==true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glEnable(GL_MULTISAMPLE);
        }

        QColor m_backgroundColor(Qt::gray);

        glClearColor(m_backgroundColor.redF(),m_backgroundColor.greenF(),m_backgroundColor.blueF(),m_backgroundColor.alphaF());

        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        glEnable(GL_COLOR_MATERIAL);

        drawGrid();

        drawTexureImage();

        drawUVs();

        drawSafeTitleRectangle();

        if(scenegraph->floorParameters->enableMultisample == true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glDisable(GL_MULTISAMPLE);
        }

        glDisable(GL_COLOR_MATERIAL);

        update();
    }

    void wheelEvent(QWheelEvent *event)
    {

    }

    void keyPressEvent(QKeyEvent * event)
    {

    }

    void mouseDoubleClickEvent(QMouseEvent *event)
    {

    }

    void mousePressEvent(QMouseEvent *event)
    {

    }

    void mouseMoveEvent(QMouseEvent * event)
    {

    }

    void mouseReleaseEvent(QMouseEvent * event)
    {

    }

    void dragEnterEvent(QDragEnterEvent * event)
    {
        event->acceptProposedAction();

        QGLWidget::dragEnterEvent(event);
    }

    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important

        QGLWidget::dragMoveEvent(event);
    }

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if(event->mimeData()->hasText())
        {

            qDebug()<<"Objects"<<event->mimeData()->text();
        }

        QGLWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {


    }

signals:

public slots:

};






#endif // UVEDITOR_HPP
