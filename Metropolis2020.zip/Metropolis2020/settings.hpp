#ifndef SETTINGS_HPP
#define SETTINGS_HPP

#include<widgets.hpp>


class TransformParameters : public QObject
{
    Q_OBJECT

    QDoubleWidget *posx;
    QDoubleWidget *posy;
    QDoubleWidget *posz;

    QDoubleWidget *rotx;
    QDoubleWidget *roty;
    QDoubleWidget *rotz;

    QDoubleWidget *scalex;
    QDoubleWidget *scaley;
    QDoubleWidget *scalez;

    QWidget * widget;

public:

    QWidget * getWidget()
    {
        return widget;
    }

    QVector3D position;
    QVector3D scale;
    QVector3D rotation;

    TransformParameters(QObject * parent =0):QObject(parent)
    {

        position = QVector3D(0,0,0);
        scale    = QVector3D(1,1,1);
        rotation = QVector3D(0,0,0);

        widget = new QWidget;
        widget->hide();

        widget->setWindowTitle(QString("Transforms"));

        posx = new QDoubleWidget;
        posy = new QDoubleWidget;
        posz = new QDoubleWidget;

        rotx = new QDoubleWidget;
        roty = new QDoubleWidget;
        rotz = new QDoubleWidget;

        scalex = new QDoubleWidget;
        scaley = new QDoubleWidget;
        scalez = new QDoubleWidget;

        posx->setMinMaxValue(-1000,1000,position.x(),1);posx->setText(QString("Position X:"));
        posy->setMinMaxValue(-1000,1000,position.y(),1);posy->setText(QString("Position Y:"));
        posz->setMinMaxValue(-1000,1000,position.z(),1);posz->setText(QString("Position Z:"));

        rotx->setMinMaxValue(-1000,1000,rotation.x(),1);rotx->setText(QString("Rotation X:"));
        roty->setMinMaxValue(-1000,1000,rotation.y(),1);roty->setText(QString("Rotation Y:"));
        rotz->setMinMaxValue(-1000,1000,rotation.z(),1);rotz->setText(QString("Rotation Z:"));

        scalex->setMinMaxValue(-100,100,scale.x(),1);scalex->setText(QString("Scale X:"));
        scaley->setMinMaxValue(-100,100,scale.y(),1);scaley->setText(QString("Scale Y:"));
        scalez->setMinMaxValue(-100,100,scale.z(),1);scalez->setText(QString("Scale Z:"));

        QFormLayout * layout  = new QFormLayout;

        layout->addWidget(posx);
        layout->addWidget(posy);
        layout->addWidget(posz);

        layout->addWidget(rotx);
        layout->addWidget(roty);
        layout->addWidget(rotz);

        layout->addWidget(scalex);
        layout->addWidget(scaley);
        layout->addWidget(scalez);

        widget->setLayout(layout);

        connect(posx,SIGNAL(valueChanged(double)),this,SLOT(setPos()));
        connect(posy,SIGNAL(valueChanged(double)),this,SLOT(setPos()));
        connect(posz,SIGNAL(valueChanged(double)),this,SLOT(setPos()));

        connect(scalex,SIGNAL(valueChanged(double)),this,SLOT(setScale()));
        connect(scaley,SIGNAL(valueChanged(double)),this,SLOT(setScale()));
        connect(scalez,SIGNAL(valueChanged(double)),this,SLOT(setScale()));

        connect(rotx,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));
        connect(roty,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));
        connect(rotz,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));


        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st = file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

        //qDebug()<<"Styles Loaded";



    }

    ~TransformParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(QVector3D);

public slots:

    void setPos()
    {
        position = QVector3D(posx->getValue(),posy->getValue(),posz->getValue());
        //qDebug()<<"Position:"<<position;
        emit valueChanged(position);
    }

    void setScale()
    {
        scale = QVector3D(scalex->getValue(),scaley->getValue(),scalez->getValue());
       // qDebug()<<"Scale:"<<scale;
        emit valueChanged(scale);
    }

    void setRotation()
    {
        rotation = QVector3D(rotx->getValue(),roty->getValue(),rotz->getValue());
        //qDebug()<<"Rotation:"<<rotation;
        emit valueChanged(rotation);
    }
};
class VisibilityParameters : public QObject
{
    Q_OBJECT

    QCheckBox * showWireframeBox ;
    QCheckBox * showFacesNormalsBox ;
    QCheckBox * showPointsNormalsBox ;
    QCheckBox * showSurfaceBox ;
    QCheckBox * showPointsBox ;
    QCheckBox * showCenterBox ;
    QCheckBox * showBoundingBoxBox ;
    QCheckBox * showOutlineBox ;
    QCheckBox * showSilhuoetteBox ;
    QCheckBox * showSilhuoetteOnlyBox ;
    QCheckBox * showStencilBox ;
    QCheckBox * showModelBox ;

    QPushButton * resetButton;
    QPushButton * silhuetteOnlyButton;

    QWidget * widget;

public:

    bool showWireframe;
    bool showFacesNormals;
    bool showPointsNormals;
    bool showSurface;
    bool showPoints;
    bool showCenter;
    bool showBoundingBox;
    bool showOutline;
    bool showSilhuoette;
    bool showSilhuoetteOnly;
    bool showStencil;
    bool showModel;

    QWidget * getWidget()
    {
        return widget;
    }

    VisibilityParameters(QObject * parent =0):QObject(parent)
    {
        QString modelName = QString("Visibility Parameters");

        showWireframe      = false;
        showFacesNormals   = false;
        showPointsNormals  = false;
        showPoints         = false;
        showBoundingBox    = false;
        showSilhuoette     = false;
        showStencil        = false;
        showSilhuoetteOnly = false;

        showCenter         = true;
        showModel          = true;
        showSurface        = true;
        showOutline        = false;

        widget = new QWidget;widget->hide();

        widget->setWindowTitle(QString(modelName));

        showWireframeBox     = new QCheckBox(QString("show Wireframe"));
        showFacesNormalsBox  = new QCheckBox(QString("show Faces Normals"));
        showPointsNormalsBox = new QCheckBox(QString("show Points Normals"));
        showSurfaceBox       = new QCheckBox(QString("show Surface"));
        showPointsBox        = new QCheckBox(QString("show Points"));
        showCenterBox        = new QCheckBox(QString("show Center"));
        showBoundingBoxBox   = new QCheckBox(QString("show Bounding Box"));

        showOutlineBox        =  new QCheckBox(QString("show Outline"));
        showSilhuoetteBox     =  new QCheckBox(QString("show Silhuoette"));
        showSilhuoetteOnlyBox =  new QCheckBox(QString("show SilhuoetteOnly"));
        showStencilBox        =  new QCheckBox(QString("show Stencil"));
        showModelBox = new QCheckBox(QString("show Model"));

        resetButton = new QPushButton(QString("Reset Parameters"));
        silhuetteOnlyButton = new QPushButton(QString("Silhuoette Only"));

        showWireframeBox->setChecked(showWireframe);
        showFacesNormalsBox->setChecked(showFacesNormals);
        showPointsNormalsBox->setChecked(showPointsNormals);
        showSurfaceBox->setChecked(showSurface);
        showPointsBox->setChecked(showPoints);
        showCenterBox->setChecked(showCenter);
        showBoundingBoxBox->setChecked(showBoundingBox);
        showOutlineBox->setChecked(showOutline);
        showSilhuoetteBox->setChecked(showSilhuoette);
        showSilhuoetteOnlyBox->setChecked(showSilhuoetteOnly);
        showStencilBox->setChecked(showStencil);
        showModelBox->setChecked(showModel);


        QFormLayout * layout = new QFormLayout;


        layout->addWidget(showModelBox);
        layout->addWidget(showStencilBox);

        layout->addWidget(showOutlineBox);
        layout->addWidget(showSilhuoetteBox);
        layout->addWidget(showSilhuoetteOnlyBox);

        layout->addWidget(showSurfaceBox);
        layout->addWidget(showWireframeBox);
        layout->addWidget(showPointsBox);
        layout->addWidget(showCenterBox);
        layout->addWidget(showBoundingBoxBox);

        layout->addWidget(showFacesNormalsBox);
        layout->addWidget(showPointsNormalsBox);

        layout->addWidget(resetButton);
        layout->addWidget(silhuetteOnlyButton);


        widget->setLayout(layout);

        connect(showModelBox,SIGNAL(toggled(bool)),this,SLOT(setshowModel()));
        connect(showWireframeBox,SIGNAL(toggled(bool)),this,SLOT(setshowWireframe()));
        connect(showFacesNormalsBox,SIGNAL(toggled(bool)),this,SLOT(setshowFacesNormals()));
        connect(showPointsNormalsBox,SIGNAL(toggled(bool)),this,SLOT(setshowPointsNormals()));

        connect(showSurfaceBox,SIGNAL(toggled(bool)),this,SLOT(setshowSurface()));
        connect(showPointsBox,SIGNAL(toggled(bool)),this,SLOT(setshowPoints()));
        connect(showCenterBox,SIGNAL(toggled(bool)),this,SLOT(setshowCenter()));

        connect(showBoundingBoxBox,SIGNAL(toggled(bool)),this,SLOT(setshowBoundingBox()));
        connect(showOutlineBox,SIGNAL(toggled(bool)),this,SLOT(setshowOutline()));
        connect(showSilhuoetteBox,SIGNAL(toggled(bool)),this,SLOT(setshowSilhuoette()));

        connect(showSilhuoetteOnlyBox,SIGNAL(toggled(bool)),this,SLOT(setshowSilhuoetteOnly()));
        connect(showStencilBox,SIGNAL(toggled(bool)),this,SLOT(setshowStencil()));
        connect(resetButton,SIGNAL(clicked(bool)),this,SLOT(resetParameters()));
        connect(silhuetteOnlyButton,SIGNAL(clicked(bool)),this,SLOT(setSilhueottelParameters()));


        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st = file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

       // qDebug()<<"Styles Loaded";


    }




    ~VisibilityParameters()
    {
        delete widget;
        delete showWireframeBox ;
        delete showFacesNormalsBox ;
        delete showPointsNormalsBox ;
        delete showSurfaceBox ;
        delete showPointsBox ;
        delete showCenterBox ;
        delete showBoundingBoxBox ;
        delete showOutlineBox ;
        delete showSilhuoetteBox ;
        delete showSilhuoetteOnlyBox ;
        delete showStencilBox ;
        delete showModelBox;
    }

signals:

    void valueChanged(bool);

    void parametersChanged();


public slots:

    void resetParameters()
    {
        showWireframe      = false;
        showFacesNormals   = false;
        showPointsNormals  = false;
        showPoints         = false;
        showBoundingBox    = false;
        showSilhuoette     = false;
        showStencil        = false;
        showSilhuoetteOnly = false;

        showOutline        = false;
        showCenter         = true;
        showModel          = true;
        showSurface        = true;


        showWireframeBox->setChecked(showWireframe);
        showFacesNormalsBox->setChecked(showFacesNormals);
        showPointsNormalsBox->setChecked(showPointsNormals);
        showSurfaceBox->setChecked(showSurface);
        showPointsBox->setChecked(showPoints);
        showCenterBox->setChecked(showCenter);
        showBoundingBoxBox->setChecked(showBoundingBox);
        showOutlineBox->setChecked(showOutline);
        showSilhuoetteBox->setChecked(showSilhuoette);
        showSilhuoetteOnlyBox->setChecked(showSilhuoetteOnly);
        showStencilBox->setChecked(showStencil);
        showModelBox->setChecked(showModel);

        emit parametersChanged();
    }

    void setSilhueottelParameters()
    {
        showWireframe      = false;
        showFacesNormals   = false;
        showPointsNormals  = false;
        showPoints         = false;
        showBoundingBox    = false;
        showSilhuoette     = false;
        showStencil        = false;

        showSilhuoetteOnly = true;
        showCenter         = true;
        showModel          = true;

        showSurface        = false;
        showOutline        = false;

        showWireframeBox->setChecked(showWireframe);
        showFacesNormalsBox->setChecked(showFacesNormals);
        showPointsNormalsBox->setChecked(showPointsNormals);
        showSurfaceBox->setChecked(showSurface);
        showPointsBox->setChecked(showPoints);
        showCenterBox->setChecked(showCenter);
        showBoundingBoxBox->setChecked(showBoundingBox);
        showOutlineBox->setChecked(showOutline);
        showSilhuoetteBox->setChecked(showSilhuoette);
        showSilhuoetteOnlyBox->setChecked(showSilhuoetteOnly);
        showStencilBox->setChecked(showStencil);
        showModelBox->setChecked(showModel);

        emit parametersChanged();
    }

    void outlineParameters()
    {

        showFacesNormals   = false;
        showPointsNormals  = false;
        showPoints         = false;
        showBoundingBox    = false;
        showSilhuoette     = false;
        showStencil        = false;
        showSilhuoetteOnly = false;

        showOutline        = true;
        showCenter         = true;
        showModel          = true;
        showSurface        = true;
        showWireframe      = false;

        showWireframeBox->setChecked(showWireframe);
        showFacesNormalsBox->setChecked(showFacesNormals);
        showPointsNormalsBox->setChecked(showPointsNormals);
        showSurfaceBox->setChecked(showSurface);
        showPointsBox->setChecked(showPoints);
        showCenterBox->setChecked(showCenter);
        showBoundingBoxBox->setChecked(showBoundingBox);
        showOutlineBox->setChecked(showOutline);
        showSilhuoetteBox->setChecked(showSilhuoette);
        showSilhuoetteOnlyBox->setChecked(showSilhuoetteOnly);
        showStencilBox->setChecked(showStencil);
        showModelBox->setChecked(showModel);

        emit parametersChanged();
    }


    void stencilOnlyParameters()
    {

        showFacesNormals   = false;
        showPointsNormals  = false;
        showPoints         = false;
        showBoundingBox    = false;
        showSilhuoette     = false;
        showStencil        = true;
        showSilhuoetteOnly = false;

        showOutline        = false;
        showCenter         = true;
        showModel          = true;
        showSurface        = true;
        showWireframe      = false;

        showWireframeBox->setChecked(showWireframe);
        showFacesNormalsBox->setChecked(showFacesNormals);
        showPointsNormalsBox->setChecked(showPointsNormals);
        showSurfaceBox->setChecked(showSurface);
        showPointsBox->setChecked(showPoints);
        showCenterBox->setChecked(showCenter);
        showBoundingBoxBox->setChecked(showBoundingBox);
        showOutlineBox->setChecked(showOutline);
        showSilhuoetteBox->setChecked(showSilhuoette);
        showSilhuoetteOnlyBox->setChecked(showSilhuoetteOnly);
        showStencilBox->setChecked(showStencil);
        showModelBox->setChecked(showModel);

        emit parametersChanged();
    }


    void setshowModel()
    {
        showModel =  showModelBox->isChecked();
        emit valueChanged(  showModel   );
    }

    void setshowWireframe()
    {
        showWireframe =  showWireframeBox->isChecked();
        emit valueChanged(  showWireframe   );
    }

    void setshowFacesNormals()
    {
        showFacesNormals =  showFacesNormalsBox->isChecked();
        emit valueChanged( showFacesNormals );
    }

    void setshowPointsNormals()
    {
        showPointsNormals = showPointsNormalsBox->isChecked();
        emit valueChanged(  showPointsNormals   );
    }

    void setshowSurface()
    {
        showSurface = showSurfaceBox->isChecked();
        emit valueChanged( showSurface    );
    }

    void setshowPoints()
    {
        showPoints = showPointsBox->isChecked();
        emit valueChanged(  showPoints   );
    }

    void setshowCenter()
    {
        showCenter = showCenterBox->isChecked();
        emit valueChanged( showCenter    );
    }

    void setshowBoundingBox()
    {
        showBoundingBox =  showBoundingBoxBox->isChecked();
        emit valueChanged(  showBoundingBox   );
    }

    void setshowOutline()
    {
        showOutline =  showOutlineBox->isChecked();
        emit valueChanged(   showOutline  );
    }

    void setshowSilhuoette()
    {
        showSilhuoette = showSilhuoetteBox->isChecked();
        emit valueChanged(  showSilhuoette   );
    }

    void setshowSilhuoetteOnly()
    {
        showSilhuoetteOnly =  showSilhuoetteOnlyBox->isChecked();
        emit valueChanged( showSilhuoetteOnly    );
    }

    void setshowStencil()
    {
        showStencil = showStencilBox->isChecked();
        emit valueChanged(   showStencil  );
    }
};
class FloorGridParameters : public QObject
{
    Q_OBJECT

    QFloatWidget * divisionValue;
    QFloatWidget * stepValue;
    QRadioButton * hideGridValue;
    QRadioButton * enableMultisampleValue;
    QCheckBox * showaxisBox;

    QColorEditorWidget * colorEditWidget;

    QWidget * widget;

public:

    QColor getColor()
    {
        return colorEditWidget->getColor();
    }



    QWidget * getWidget()
    {
        return widget;
    }



    float divisions;
    float step;

    bool showAxis;
    bool showGrid;
    bool enableMultisample;
    QColor backgroundColor;




    FloorGridParameters(QObject * parent =0):QObject(parent)
    {
        divisions = 10;
        step  = 1;

        showGrid = true;
        showAxis  = true;
        enableMultisample = true;

        widget  = new QWidget;
        widget->hide();

        colorEditWidget = new QColorEditorWidget;


        colorEditWidget->setColor(QColor(199,199,199,255));
        colorEditWidget->setText("Backdrop:");



        divisionValue = new QFloatWidget;
        divisionValue->setText(QString("Grid width:"));
        divisionValue->setMinMaxValue(0,50,divisions,1);


        stepValue     = new QFloatWidget;
        stepValue->setText(QString("Step Value:"));
        stepValue->setMinMaxValue(1,100,step,1);

        hideGridValue = new QRadioButton;
        hideGridValue->setCheckable(true);
        hideGridValue->setChecked(showGrid);
        hideGridValue->setText("Show Floor");

        enableMultisampleValue = new QRadioButton;
        hideGridValue->setCheckable(true);
        enableMultisampleValue->setChecked(enableMultisample);
        enableMultisampleValue->setText("Enable Multisample");

        showaxisBox = new QCheckBox(QString("Show Axis"));
        showaxisBox->setChecked(showAxis);

        QButtonGroup * gr = new QButtonGroup;
        gr->addButton(hideGridValue);
        gr->setExclusive(false);

        QFormLayout * layout = new QFormLayout();

        layout->addWidget(enableMultisampleValue);
        layout->addWidget(hideGridValue);
        layout->addWidget(showaxisBox);
        layout->addWidget(divisionValue);
        layout->addWidget(stepValue);
        layout->addWidget(colorEditWidget);

        for(int i=0;i<10;i++)
        {
            QString name =  QString("Button") + QString::number(i);

            //layout->addWidget(new QPushButton(QIcon(QString(":/icons/cubeomniverse.svg")),name));
        }


        widget->setLayout(layout);

        connect( divisionValue,SIGNAL(valueChanged(double)),SLOT(setWidthValue()) );
        connect( stepValue,    SIGNAL(valueChanged(double)),SLOT(setStepValue())  );
        connect( hideGridValue,SIGNAL(clicked(bool)),SLOT(setHideFloorValue())  );
        connect( enableMultisampleValue,SIGNAL(clicked(bool)),SLOT(setEnableMultisampleValue())  );
        connect( colorEditWidget,SIGNAL(valueChanged(QColor)),SLOT(setColorValues())  );
        connect(showaxisBox,SIGNAL(toggled(bool)),SLOT(setShowAxisValue()));
    }

signals:

public slots:

    void setWidthValue()
    {
        divisions = divisionValue->getValue();
    }

    void setStepValue()
    {
        step  = stepValue->getValue();
    }

    void setHideFloorValue()
    {
        showGrid  = hideGridValue->isChecked();
    }

    void setShowAxisValue()
    {
        showAxis  = showaxisBox->isChecked();
    }


    void setEnableMultisampleValue()
    {
        enableMultisample  = enableMultisampleValue->isChecked();
    }

    void setColorValues()
    {
        backgroundColor  = colorEditWidget->getColor();
    }
};



/*
class TransformParameters : public QObject
{
    Q_OBJECT

    QVector3DWidget * _position;
    QVector3DWidget * _rotation;
    QVector3DWidget * _scale;

    QWidget * widget;

public:

    QWidget * getWidget()
    {
        return widget;
    }

    QVector3D position;
    QVector3D scale;
    QVector3D rotation;

    TransformParameters(QObject * parent =0):QObject(parent)
    {
        widget    = new QWidget;

        position = QVector3D(0,0,0);
        scale    = QVector3D(1,1,1);
        rotation = QVector3D(0,0,0);

        _position = new QVector3DWidget;
        _rotation = new QVector3DWidget;
        _scale    = new QVector3DWidget;


        QFormLayout * layout  = new QFormLayout;

        layout->addRow(new QLabel("Position:"),_position);
        layout->addRow(new QLabel("Rotation:"),_rotation);
        layout->addRow(new QLabel("Scale:"),_scale);

        widget->setLayout(layout);
       // widget->show();

        connect(_position,SIGNAL(valueChanged(QVector3D)),this,SLOT(setPos()));
        connect(_rotation,SIGNAL(valueChanged(QVector3D)),this,SLOT(setRotation()));
        connect(_scale,SIGNAL(valueChanged(QVector3D)),this,SLOT(setScale()));



        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st = file.readAll();

            widget->setStyleSheet(st);
        }

        file.close();

        qDebug()<<"Styles Loaded";

    }


    ~TransformParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(QVector3D);

public slots:

    void setPos()
    {
        position = _position->getVector();
        emit valueChanged(position);
    }

    void setScale()
    {
        scale =  _scale->getVector();
        emit valueChanged(scale);
    }

    void setRotation()
    {
        rotation = _rotation->getVector();
        emit valueChanged(rotation);
    }
};

*/




class PlaneParameters     : public QObject
{
    Q_OBJECT

    QSlider * uslider;
    QSlider * vslider;

    QDoubleSlider * wslider;
    QDoubleSlider * lslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;

    QDoubleSpinBox * wspinBox;
    QDoubleSpinBox * lspinBox;

    QWidget * widget;


public:

    int usteps;
    int vsteps;

    float width;
    float length;

    QWidget * getWidget()
    {
        return widget;
    }

    PlaneParameters(QString modelName = QString("Plane Model"), QObject * parent =0):QObject(parent)
    {
        usteps = 10;
        vsteps = 10;

        width  = 5;
        length = 5;

        widget = new QWidget;

        widget->setWindowTitle(modelName);

        uslider = new QSlider(Qt::Horizontal);
        vslider = new QSlider(Qt::Horizontal);

        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;

        wslider  = new QDoubleSlider(Qt::Horizontal);
        lslider  = new QDoubleSlider(Qt::Horizontal);

        wspinBox = new QDoubleSpinBox;
        lspinBox = new QDoubleSpinBox;


        uslider->setMinimum(0);
        uslider->setMaximum(100);
        uslider->setSingleStep(1);


        vslider->setMinimum(0);
        vslider->setMaximum(100);
        vslider->setSingleStep(1);


        wslider->setMinimum(0);
        wslider->setMaximum(100);
        wslider->setSingleStep(1);

        lslider->setMinimum(0);
        lslider->setMaximum(100);
        lslider->setSingleStep(1);



        uspinBox->setMinimum(0);
        uspinBox->setMaximum(100);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(100);
        vspinBox->setSingleStep(1);

        lspinBox->setMinimum(0);
        lspinBox->setMaximum(100);
        lspinBox->setSingleStep(1);


        wspinBox->setMinimum(0);
        wspinBox->setMaximum(100);
        wspinBox->setSingleStep(1);


        vslider->setValue(vsteps);
        uslider->setValue(usteps);
        wslider->setValue(width);
        lslider->setValue(length);

        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);
        lspinBox->setValue(length);
        wspinBox->setValue(width);






        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Width:")));
        hlayout1->addWidget(wslider);
        hlayout1->addWidget(wspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);



        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("Length:")));
        hlayout4->addWidget(lslider);
        hlayout4->addWidget(lspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);

        layout->addWidget(qf1);
        layout->addWidget(qf4);
        layout->addWidget(qf2);
        layout->addWidget(qf3);


        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));

        connect(wspinBox,SIGNAL(valueChanged(double)),this,SLOT(setWidth()));
        connect(lspinBox,SIGNAL(valueChanged(double)),this,SLOT(setLength()));



        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));

        connect(wslider,SIGNAL(valueChanged(double)),wspinBox,SLOT(setValue(double)));
        connect(lslider,SIGNAL(valueChanged(double)),lspinBox,SLOT(setValue(double)));

        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));

        connect(lspinBox,SIGNAL(valueChanged(double)),lslider,SLOT(setValue(double)));
        connect(wspinBox,SIGNAL(valueChanged(double)),wslider,SLOT(setValue(double)));

        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st =file.readAll();

            widget->setStyleSheet(st);

           // transformWidget->setStyleSheet(st);
        }

        file.close();

        //qDebug()<<"Styles Loaded";

        widget->setLayout(layout);

    }

signals:

    void valueChanged(double);



private slots:



    void setWidth()
    {
        width = wspinBox->value();
        emit valueChanged(width);
    }

    void setLength()
    {
        length = lspinBox->value();
        emit valueChanged(length);
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged(usteps);
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();

        emit valueChanged(vsteps);
    }
};

class CylinderParameters  : public QObject
{
    Q_OBJECT

    QSlider * uslider;
    QSlider * vslider;
    QDoubleSlider * rslider;
    QDoubleSlider * hslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;
    QDoubleSpinBox * rspinBox;
    QDoubleSpinBox * hspinBox;

    QWidget * widget;


public:

    int usteps;
    int vsteps;

    float cylinderRadius;
    float cylinderHeight;

    QWidget * getWidget()
    {
        return widget;
    }

    CylinderParameters(QString modelName = QString("Cylinder Model"), QObject * parent =0):QObject(parent)
    {
        usteps = 10;
        vsteps = 10;
        //boundingSphereRadius =  1;
        cylinderRadius = 0.2f;
        cylinderHeight = 1;

        widget = new QWidget;

        widget->setWindowTitle(modelName);

        uslider = new QSlider(Qt::Horizontal);
        uslider->setValue(usteps);
        uslider->setMinimum(0);
        uslider->setMaximum(200);
        uslider->setSingleStep(1);

        vslider = new QSlider(Qt::Horizontal);
        vslider->setValue(vsteps);
        vslider->setMinimum(0);
        vslider->setMaximum(200);
        vslider->setSingleStep(1);

        rslider = new QDoubleSlider(Qt::Horizontal);
        rslider->setValue(cylinderRadius);
        rslider->setMinimum(0);
        rslider->setMaximum(200);
        rslider->setSingleStep(.01);

        hslider = new QDoubleSlider(Qt::Horizontal);
        hslider->setValue(cylinderHeight);
        hslider->setMinimum(0);
        hslider->setMaximum(200);
        hslider->setSingleStep(.01);


        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;
        rspinBox = new QDoubleSpinBox;
        hspinBox = new QDoubleSpinBox;


        uspinBox->setMinimum(0);
        uspinBox->setMaximum(200);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(200);
        vspinBox->setSingleStep(1);


        rspinBox->setMinimum(0);
        rspinBox->setMaximum(200);
        rspinBox->setSingleStep(0.01);

        hspinBox->setMinimum(0);
        hspinBox->setMaximum(200);
        hspinBox->setSingleStep(0.01);

        rspinBox->setValue(cylinderRadius);
        hspinBox->setValue(cylinderHeight);
        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Radius:")));
        hlayout1->addWidget(rslider);
        hlayout1->addWidget(rspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("Height:")));
        hlayout4->addWidget(hslider);
        hlayout4->addWidget(hspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);


        layout->addWidget(qf4);
        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);


        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(rspinBox,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));
        connect(hspinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
        connect(rslider,SIGNAL(valueChanged(double)),rspinBox,SLOT(setValue(double)));
        connect(hslider,SIGNAL(valueChanged(double)),hspinBox,SLOT(setValue(double)));

        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
        connect(rspinBox,SIGNAL(valueChanged(double)),rslider,SLOT(setValue(double)));
        connect(hspinBox,SIGNAL(valueChanged(double)),hslider,SLOT(setValue(double)));


       // widget->show();

    }
    ~CylinderParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:


    void setHeight()
    {
        cylinderHeight = hspinBox->value();
        emit valueChanged(cylinderHeight);

        qDebug()<<"Cylinder h:"<<cylinderHeight;
    }

    void setRadius()
    {
        cylinderRadius = rspinBox->value();
        emit valueChanged(cylinderRadius);
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged(usteps);
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();
        emit valueChanged(vsteps);
    }
};

class PieParameters  : public QObject
{
    Q_OBJECT

    QIntWidget * sidesWidget;
    QIntWidget * ringsWidget;

    QDoubleWidget * radiusWidget;
    QDoubleWidget * radius2Widget;

    QDoubleWidget * startangleWidget;
    QDoubleWidget * endangleWidget;

    QWidget * widget;


public:

    float radius;
    float radius2;

    float startangle;
    float endangle;

    int sides;
    int rings;

    QWidget * getWidget()
    {
        return widget;
    }

    PieParameters(QString modelName = QString("Pie Model"), QObject * parent =0):QObject(parent)
    {
        radius     = 1;
        radius2    = 3;

        sides      = 6;
        rings      = 3;

        startangle = 1;
        endangle   = 360;

        widget = new QWidget;

        widget->setWindowTitle(modelName);

        sidesWidget      = new QIntWidget;
        ringsWidget      = new QIntWidget;

        radiusWidget     = new QDoubleWidget;
        radius2Widget    = new QDoubleWidget;

        startangleWidget = new QDoubleWidget;
        endangleWidget   = new QDoubleWidget;

        sidesWidget->setText("sides:");
        ringsWidget->setText("rings:");

        radiusWidget->setText("radius:");
        radius2Widget->setText("radius2:");

        startangleWidget->setText("start angle:");
        endangleWidget->setText("end angle:");

        sidesWidget->setMinMaxValue(0,100,sides,1);
        ringsWidget->setMinMaxValue(0,100,rings,1);

        radiusWidget->setMinMaxValue(0,100,radius,1);
        radius2Widget->setMinMaxValue(0,100,radius2,1);

        startangleWidget->setMinMaxValue(0,360,startangle,1);
        endangleWidget->setMinMaxValue(0,360,endangle,1);

        QVBoxLayout * layout  = new QVBoxLayout;

        layout->addWidget(sidesWidget);
        layout->addWidget(ringsWidget);

        layout->addWidget(radiusWidget);
        layout->addWidget(radius2Widget);

        layout->addWidget(startangleWidget);
        layout->addWidget(endangleWidget);

        widget->setLayout(layout);

        connect(sidesWidget,SIGNAL(valueChanged(int)),this,SLOT(setsides()));
        connect(ringsWidget,SIGNAL(valueChanged(int)),this,SLOT(setrings()));

        connect(radiusWidget,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));
        connect(radius2Widget,SIGNAL(valueChanged(double)),this,SLOT(setRadius2()));

        connect(startangleWidget,SIGNAL(valueChanged(double)),this,SLOT(setstartangle()));
        connect(endangleWidget,SIGNAL(valueChanged(double)),this,SLOT(setendangle()));

       // widget->show();

    }
    ~PieParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);

    void valueChanged(int);

    void valueChanged();

private slots:

    void setRadius()
    {
        radius = radiusWidget->getValue();
        //emit valueChanged(radius);

        emit valueChanged();
    }

    void setRadius2()
    {
        radius2 = radius2Widget->getValue();
        //emit valueChanged(radius2);
        emit valueChanged();

    }
    void setstartangle()
    {
        startangle = startangleWidget->getValue();

        //emit valueChanged(startangle);
        emit valueChanged();

    }
    void setendangle()
    {
        endangle = endangleWidget->getValue();

        //emit valueChanged(endangle);
        emit valueChanged();

    }
    void setsides()
    {
        sides = sidesWidget->getValue();

        //qDebug()<<"Sides: "<<sides;

        //emit valueChanged(sides);
        emit valueChanged();
    }
    void setrings()
    {
        rings = ringsWidget->getValue();

        //qDebug()<<"Rings: "<<rings;

        //emit valueChanged(rings);
        emit valueChanged();
    }
};

class SphereParameters    : public QObject
{
    Q_OBJECT

    QIntWidget *uwidget;
    QIntWidget *vwidget;
    QDoubleWidget *rwidget;

    QWidget * widget;

public:

    int usteps;
    int vsteps;
    float radius;

    QWidget * getWidget()
    {
        return widget;
    }

    SphereParameters(QString modelName = QString("Sphere Model"), QObject * parent =0):QObject(parent)
    {
        usteps = 15;
        vsteps = 15;
        radius =  1;

        widget = new QWidget;
        widget->setWindowTitle(QString(modelName));

        uwidget = new QIntWidget;
        vwidget = new QIntWidget;
        rwidget = new QDoubleWidget;

        uwidget->setMinMaxValue(0,100,usteps,1);
        uwidget->setText(QString("u steps:"));

        vwidget->setMinMaxValue(0,100,vsteps,1);
        vwidget->setText(QString("v steps:"));

        rwidget->setMinMaxValue(0,100,radius,1);
        rwidget->setText(QString("radius:"));

        QVBoxLayout * layout  = new QVBoxLayout;

        layout->addWidget(uwidget);
        layout->addWidget(vwidget);
        layout->addWidget(rwidget);

        widget->setLayout(layout);

        connect(uwidget,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vwidget,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(rwidget,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));

    }

    ~SphereParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:

    void updateShere()
    {
        radius = rwidget->getValue();
        usteps = uwidget->getValue();
        vsteps = vwidget->getValue();
    }


    void setRadius()
    {
        radius = rwidget->getValue();

        emit valueChanged(radius);
    }

    void setUsteps()
    {
        usteps = uwidget->getValue();

        emit valueChanged(usteps);
    }

    void setVsteps()
    {
        vsteps = vwidget->getValue();

        emit valueChanged(vsteps);
    }
};

class ConeParameters   : public QObject
{
    Q_OBJECT

    QIntWidget * uspinBox;
    QIntWidget * hspinBox;

    QDoubleWidget * r1spinBox;
    QDoubleWidget * r2spinBox;
    QDoubleWidget * heightSpinBox;
    QWidget * widget;

public:

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;

    QWidget * getWidget()
    {
        return widget;
    }

    ConeParameters(QString modelName = QString("Cone Model"), QObject * parent =0):QObject(parent)
    {
        usteps = 27;
        hsteps = 10;
        //boundingSphereRadius =  1;

        r1 = 1.0f;
        r2 = 2.0f;
        height  = 2.0f;

        widget = new QWidget;
        widget->setWindowTitle(QString(modelName));


        uspinBox = new QIntWidget;
        hspinBox = new QIntWidget;

        r1spinBox = new QDoubleWidget;
        r2spinBox = new QDoubleWidget;;
        heightSpinBox = new QDoubleWidget;

        uspinBox->setMinMaxValue(0,100,usteps,1);
        hspinBox->setMinMaxValue(0,100,hsteps,1);

        r1spinBox->setMinMaxValue(0,100,r1,1);
        r2spinBox->setMinMaxValue(0,100,r2,1);

        heightSpinBox->setMinMaxValue(0,100,height,1);


        QVBoxLayout * layout  = new QVBoxLayout;

        r1spinBox->setText(QString("R1:"));
        r2spinBox->setText(QString("R2:"));
        heightSpinBox->setText(QString("Height:"));
        uspinBox->setText(QString("U Steps:"));
        hspinBox->setText(QString("H Steps:"));


        layout->addWidget(heightSpinBox);
        layout->addWidget(r1spinBox);
        layout->addWidget(r2spinBox);
        layout->addWidget(uspinBox);
        layout->addWidget(hspinBox);


        widget->setLayout(layout);


        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));
        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));
        connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));



       // widget->show();

    }
    ~ConeParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:


    void setR1()
    {
        r1= r1spinBox->getValue();
        emit valueChanged(r1);
    }
    void setR2()
    {
        r2 = r2spinBox->getValue();
        emit valueChanged(r2);
    }

    void setHeight()
    {
        height = heightSpinBox->getValue();
        emit valueChanged(height);
    }

    void setUsteps()
    {
        usteps = uspinBox->getValue();
        emit valueChanged(usteps);
    }

    void setHteps()
    {
        hsteps = hspinBox->getValue();
        emit valueChanged(hsteps);
    }
};

class TorusParameters  : public QObject
{
    Q_OBJECT

    //QSlider * uslider;
    //QSlider * vslider;

    //QDoubleSlider * r1slider;
    //QDoubleSlider * r2slider;

    //QSpinBox * uspinBox;
    //QSpinBox * vspinBox;

    //QDoubleSpinBox * r1spinBox;
    //QDoubleSpinBox * r2spinBox;


    QIntWidget * ustepsWidget;
    QIntWidget * vstepsWidget;

    QDoubleWidget * r1Widget;
    QDoubleWidget * r2Widget;


    QWidget * widget;

public:

    int usteps;
    int vsteps;

    float r1;
    float r2;

    QWidget * getWidget()
    {
        return widget;
    }

    TorusParameters(QString modelName = QString("Torus Model"), QObject * parent =0):QObject(parent)
    {
        widget = new QWidget;

        widget->setWindowTitle(QString(modelName));

        ustepsWidget = new QIntWidget;
        ustepsWidget->setText(QString("u steps"));

        vstepsWidget = new QIntWidget;
        vstepsWidget->setText(QString("v steps"));

        r1Widget   = new QDoubleWidget;
        r1Widget->setText(QString("R1:"));

        r2Widget   = new QDoubleWidget;
        r2Widget->setText(QString("R2:"));


        usteps = 10;
        vsteps = 10;

        //boundingSphereRadius = 1;

        r1 = 0.3;
        r2 = 1.0;

        ustepsWidget->setMinMaxValue(0,100,usteps,1);
        vstepsWidget->setMinMaxValue(0,100,vsteps,1);

        r1Widget->setMinMaxValue(0,50,r1,1);
        r2Widget->setMinMaxValue(0,50,r2,1);


        QVBoxLayout * layout = new QVBoxLayout;
        layout->addWidget(ustepsWidget);
        layout->addWidget(vstepsWidget);
        layout->addWidget(r1Widget);
        layout->addWidget(r2Widget);

        widget->setLayout(layout);

        connect(ustepsWidget,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vstepsWidget,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(r1Widget,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2Widget,SIGNAL(valueChanged(double)),this,SLOT(setR2()));




        /*

        uslider = new QSlider(Qt::Horizontal);
        uslider->setValue(usteps);
        uslider->setMinimum(0);
        uslider->setMaximum(200);
        uslider->setSingleStep(1);

        vslider = new QSlider(Qt::Horizontal);
        vslider->setValue(vsteps);
        vslider->setMinimum(0);
        vslider->setMaximum(200);
        vslider->setSingleStep(1);

        r1slider = new QDoubleSlider(Qt::Horizontal);
        r1slider->setValue(r1);
        r1slider->setMinimum(0);
        r1slider->setMaximum(200);
        r1slider->setSingleStep(.01);

        r2slider = new QDoubleSlider(Qt::Horizontal);
        r2slider->setValue(r2);
        r2slider->setMinimum(0);
        r2slider->setMaximum(200);
        r2slider->setSingleStep(.01);




        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;

        r1spinBox = new QDoubleSpinBox;
        r2spinBox = new QDoubleSpinBox;


        uspinBox->setMinimum(0);
        uspinBox->setMaximum(200);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(200);
        vspinBox->setSingleStep(1);


        r1spinBox->setMinimum(0);
        r1spinBox->setMaximum(200);
        r1spinBox->setSingleStep(.1);

        r2spinBox->setMinimum(0);
        r2spinBox->setMaximum(200);
        r2spinBox->setSingleStep(.1);


        r2spinBox->setValue(r2);
        r1spinBox->setValue(r1);
        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("R1:")));
        hlayout1->addWidget(r1slider);
        hlayout1->addWidget(r1spinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("R2:")));
        hlayout4->addWidget(r2slider);
        hlayout4->addWidget(r2spinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);


        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        //QFormLayout * form =  new QFormLayout;
        //form->addRow();



        layout->addWidget(qf1);
        layout->addWidget(qf4);
        layout->addWidget(qf2);
        layout->addWidget(qf3);

        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
        connect(r1slider,SIGNAL(valueChanged(double)),r1spinBox,SLOT(setValue(double)));
        connect(r2slider,SIGNAL(valueChanged(double)),r2spinBox,SLOT(setValue(double)));


        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
        connect(r2spinBox,SIGNAL(valueChanged(double)),r2slider,SLOT(setValue(double)));
        connect(r1spinBox,SIGNAL(valueChanged(double)),r1slider,SLOT(setValue(double)));


        */

       // widget->show();

    }
    ~TorusParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:


    void setR1()
    {

        r1 = r1Widget->getValue();
        emit valueChanged(r1);
    }

    void setR2()
    {
        r2 = r2Widget->getValue();
        emit valueChanged(r2);
    }

    void setUsteps()
    {
        usteps = ustepsWidget->getValue();
        emit valueChanged(usteps);
    }

    void setVsteps()
    {
        vsteps = vstepsWidget->getValue();;
        emit valueChanged(vsteps);
    }

};

class TubeParameters   : public QObject
{
    Q_OBJECT

    QSpinBox * uspinBox;
    QSpinBox * hspinBox;

    QDoubleSpinBox * r1spinBox;
    QDoubleSpinBox * r2spinBox;

    QDoubleSpinBox * heightSpinBox;

    QWidget * widget;

public:

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;



    QWidget * getWidget()
    {
        return widget;
    }

    TubeParameters(QString modelName = QString("Tube Model"), QObject * parent =0):QObject(parent)
    {
        widget = new QWidget;

        widget->setWindowTitle(QString(modelName));


        uspinBox = new QSpinBox;
        hspinBox = new QSpinBox;

        r1spinBox = new QDoubleSpinBox;
        r2spinBox = new QDoubleSpinBox;;
        heightSpinBox = new QDoubleSpinBox;;

        uspinBox->setMinimum(0);
        uspinBox->setMaximum(100);
        uspinBox->setSingleStep(1);

        hspinBox->setMinimum(0);
        hspinBox->setMaximum(100);
        hspinBox->setSingleStep(1);


        r1spinBox->setMinimum(0);
        r1spinBox->setMaximum(100);
        r1spinBox->setSingleStep(.05);

        r2spinBox->setMinimum(0);
        r2spinBox->setMaximum(100);
        r2spinBox->setSingleStep(.05);

        heightSpinBox->setMinimum(0);
        heightSpinBox->setMaximum(100);
        heightSpinBox->setSingleStep(.05);

        r1spinBox->setValue(r1);
        r2spinBox->setValue(r2);
        uspinBox->setValue(usteps);
        hspinBox->setValue(hsteps);
        heightSpinBox->setValue(height);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("R1:")));
        hlayout1->addWidget(r1spinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("R2:")));
        hlayout2->addWidget(r2spinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Height:")));
        hlayout3->addWidget(heightSpinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("U Steps:")));
        hlayout4->addWidget(uspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);

        QHBoxLayout * hlayout5 = new QHBoxLayout;
        hlayout5->addWidget(new QLabel(QString("H Steps:")));
        hlayout5->addWidget(hspinBox);
        QFrame * qf5 =  new QFrame;
        qf5->setLayout(hlayout5);




        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);
        layout->addWidget(qf4);
        layout->addWidget(qf5);

        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));

        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

        connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));


       // widget->show();

    }
    ~TubeParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double value);


private slots:


    void setR1()
    {
        r1 = r1spinBox->value();
        emit valueChanged(r1);
    }

    void setR2()
    {
        r2 = r2spinBox->value();
        emit valueChanged(r2);
    }

    void setHeight()
    {
        height = heightSpinBox->value();
        emit valueChanged(height);
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged(usteps);
    }

    void setHteps()
    {
        hsteps = hspinBox->value();
        emit valueChanged(hsteps);
    }

};

class RoundedCubeParameters : public QObject
{
    Q_OBJECT

    QIntWidget * Nwidget;

    QDoubleWidget * strength_widget;

    QDoubleWidget * size_widget;

    QWidget * widget;

public:

    float size;

    float strength;

    int N;

    QWidget * getWidget()
    {
        return widget;
    }

    RoundedCubeParameters(QString modelName = QString("Rounded Cube Model"), QObject * parent =0):QObject(parent)
    {
        size     = 5;
        strength = 25;
        N        = 30;

        widget = new QWidget;
        widget->setWindowTitle(QString(modelName));

        Nwidget         = new QIntWidget;
        strength_widget = new QDoubleWidget;
        size_widget     = new QDoubleWidget;

        Nwidget->setMinMaxValue(0,100,N,1);
        Nwidget->setText(QString("N steps:"));

        strength_widget->setMinMaxValue(0,400,strength,1);
        strength_widget->setText(QString("radius strength:"));

        size_widget->setMinMaxValue(0,200,size,1);
        size_widget->setText(QString("size:"));

        QVBoxLayout * layout  = new QVBoxLayout;

        layout->addWidget(Nwidget);
        layout->addWidget(size_widget);
        layout->addWidget(strength_widget);

        widget->setLayout(layout);

        connect(Nwidget,SIGNAL(valueChanged(int)),this,SLOT(setNsteps()));
        connect(size_widget,SIGNAL(valueChanged(double)),this,SLOT(setSize()));
        connect(strength_widget,SIGNAL(valueChanged(double)),this,SLOT(setStrength()));
    }

    ~RoundedCubeParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:

    void updateShere()
    {
        strength = strength_widget->getValue();

        size     = size_widget->getValue();

        N        = Nwidget->getValue();
    }

    void setStrength()
    {
        strength = strength_widget->getValue();

        emit valueChanged(strength);
    }

    void setNsteps()
    {
        N = Nwidget->getValue();

        emit valueChanged(N);
    }

    void setSize()
    {
        size = size_widget->getValue();

        emit valueChanged(size);
    }
};

class LightParameters  : public QObject
{
    Q_OBJECT

    QRadioButton * enableLight;

    QColorEditorWidget * ambientColorWidget;
    QColorEditorWidget * diffuseColorWidget;
    QColorEditorWidget * specularColorWidget;
    QColorEditorWidget * emissionColorWidget;

    QDoubleSpinBox * shininessSpinBox;

    QWidget * widget;

public:

    bool enable;

    QColor diffuseColor;
    QColor ambientColor;
    QColor specularColor;
    QColor reflectionColor;
    QColor emissionColor;


    float diffuseIntensity;
    float reflectionIntensity;
    float refractionIntensity;
    float bumpIntensity;

    float shininess;

    QWidget * getWidget()
    {
        return widget;
    }

    LightParameters(QString modelName = QString("Light Model"), QObject * parent =0):QObject(parent)
    {
        widget = new QWidget;

        widget->setWindowTitle(QString(modelName));

        diffuseColor   = QColor(0.8f, 0.8f, 0.8f ,1);
        ambientColor   = QColor(0.2f, 0.2f, 0.2f,1 );
        specularColor  = QColor(0.4f, 0.4f, 0.4f,1);
        emissionColor  = QColor(0.1f, 0.1f, 0.1f,1);
        shininess = 50.0;
        enable    = true;


        ambientColorWidget  = new QColorEditorWidget;
        diffuseColorWidget  = new QColorEditorWidget;
        specularColorWidget = new QColorEditorWidget;
        emissionColorWidget = new QColorEditorWidget;

        shininessSpinBox = new QDoubleSpinBox;

        ambientColorWidget->setColor(ambientColor);
        diffuseColorWidget->setColor(diffuseColor);
        specularColorWidget->setColor(specularColor);
        emissionColorWidget->setColor(emissionColor);

        shininessSpinBox->setMinimum(0);
        shininessSpinBox->setMaximum(100);
        shininessSpinBox->setSingleStep(.05);
        shininessSpinBox->setValue(shininess);

        QVBoxLayout * layout  = new QVBoxLayout;


        enableLight = new QRadioButton(QString("Enable Light"));
        enableLight->setEnabled(true);

        QHBoxLayout * hlayout0 = new QHBoxLayout;
        hlayout0->addWidget(enableLight);
        QFrame * qf0 =  new QFrame;
        qf0->setLayout(hlayout0);

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Ambient:")));
        hlayout1->addWidget(ambientColorWidget);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("Diffuse:")));
        hlayout2->addWidget(diffuseColorWidget);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Specular:")));
        hlayout3->addWidget(specularColorWidget);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);


        QHBoxLayout * hlayout5 = new QHBoxLayout;
        hlayout5->addWidget(new QLabel(QString("Emission:")));
        hlayout5->addWidget(emissionColorWidget);
        QFrame * qf5 =  new QFrame;
        qf5->setLayout(hlayout5);


        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("Shininess:")));
        hlayout4->addWidget(shininessSpinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);


        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);
        layout->addWidget(qf5);
        layout->addWidget(qf4);

        widget->setLayout(layout);

        ambientColorWidget  = new QColorEditorWidget;
        diffuseColorWidget  = new QColorEditorWidget;
        specularColorWidget = new QColorEditorWidget;

        shininessSpinBox = new QDoubleSpinBox;

        connect(ambientColorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setAmbient()));
        connect(diffuseColorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setDiffuse()));
        connect(specularColorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setSpecular()));
        connect(emissionColorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setEmission()));

        connect(shininessSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setShinnes()));



    }
    ~LightParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(QColor value);
    void valueChanged(double value);


private slots:


    void setAmbient()
    {
        ambientColor = this->ambientColorWidget->getColor();
        emit valueChanged(ambientColor);
    }

    void setDiffuse()
    {
        diffuseColor = this->diffuseColorWidget->getColor();
        emit valueChanged(diffuseColor);
    }

    void setSpecular()
    {
        specularColor = this->specularColorWidget->getColor();
        emit valueChanged(specularColor);
    }

    void setEmission()
    {
        emissionColor = this->emissionColorWidget->getColor();
        emit valueChanged(emissionColor);
    }

    void setShinnes()
    {
        shininess = shininessSpinBox->value();
        emit valueChanged(shininess);
    }
};

class CameraParameters : public QObject
{
    Q_OBJECT

    QDoubleSpinBox * farspinBox;
    QDoubleSpinBox * nearspinBox;
    QDoubleSpinBox * fovSpinBox;

    QWidget * widget;

public:

    float zFar;
    float zNear;
    float fov;

    QWidget * getWidget()
    {
        return widget;
    }

    CameraParameters(QString modelName = QString("Camera Model"), QObject * parent =0):QObject(parent)
    {
        widget = new QWidget;

        widget->setWindowTitle(QString(modelName));

        farspinBox  = new QDoubleSpinBox;
        nearspinBox = new QDoubleSpinBox;;
        fovSpinBox  = new QDoubleSpinBox;;

        farspinBox->setMinimum(0);
        farspinBox->setMaximum(10000);
        farspinBox->setSingleStep(0.1);

        nearspinBox->setMinimum(0);
        nearspinBox->setMaximum(10000);
        nearspinBox->setSingleStep(0.1);

        fovSpinBox->setMinimum(0);
        fovSpinBox->setMaximum(360);
        fovSpinBox->setSingleStep(0.1);

        zNear  = 0.001f;
        zFar   = 1500.0f;
        fov    = 45.0f;


        farspinBox->setValue(zFar);
        nearspinBox->setValue(zNear);
        fovSpinBox->setValue(fov);


        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Far Clip:")));
        hlayout1->addWidget(farspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("Near Clip:")));
        hlayout2->addWidget(nearspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Field of View:")));
        hlayout3->addWidget(fovSpinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);

        widget->setLayout(layout);


        connect(farspinBox,SIGNAL(valueChanged(double)),this,SLOT(setFar()));
        connect(nearspinBox,SIGNAL(valueChanged(double)),this,SLOT(seNear()));
        connect(fovSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setFov()));

       // widget->show();

    }
    ~CameraParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double value);


private slots:


    void setFar()
    {
        zFar = farspinBox->value();

        emit valueChanged(zFar);
    }

    void seNear()
    {
        zNear = nearspinBox->value();

        emit valueChanged(zNear);
    }

    void setFov()
    {
        fov = fovSpinBox->value();

        emit valueChanged(fov);
    }

};


//materials

class QPhongMaterialParameters  : public QObject
{
    Q_OBJECT


    QDoubleWidget * alphaWidget;
    QDoubleWidget * ambientWidget;
    QDoubleWidget * diffuseWidget;
    QDoubleWidget * specularWidget;
    QDoubleWidget * reflectionWidget;
    QDoubleWidget * bumpWidget;
    QDoubleWidget * refractionWidget;
    QDoubleWidget * transparencyWidget;
    QDoubleWidget * emissionWidget;


    QWidget * widget;

public:

    float alpha;
    float ambient;
    float diffuse;
    float specular;
    float reflection;
    float bump;
    float refraction;
    float transparency;
    float emission;


    QWidget * getWidget()
    {
        return widget;
    }

    QPhongMaterialParameters(QString modelName = QString("Phong Material"), QObject * parent =0):QObject(parent)
    {
        widget = new QWidget;

        widget->setWindowTitle(QString(modelName));


        alpha        = 0.1;
        ambient      = 0.1;
        diffuse      = 0.1;
        specular     = 0.1;
        reflection   = 0.1;
        bump         = 0.1;
        refraction   = 0.1;
        transparency = 0.1;
        emission     = 0.1;

        alphaWidget        = new QDoubleWidget;
        ambientWidget      = new QDoubleWidget;
        diffuseWidget      = new QDoubleWidget;
        specularWidget     = new QDoubleWidget;
        reflectionWidget   = new QDoubleWidget;
        bumpWidget         = new QDoubleWidget;
        refractionWidget   = new QDoubleWidget;
        transparencyWidget = new QDoubleWidget;
        emissionWidget     = new QDoubleWidget;

        alphaWidget->setText("alpha");
        ambientWidget->setText("ambient");
        diffuseWidget->setText("diffuse");
        specularWidget->setText("specular");
        reflectionWidget->setText("reflection");
        bumpWidget->setText("bump");
        refractionWidget->setText("refraction");
        transparencyWidget->setText("transparency");
        emissionWidget->setText("emission");

        alphaWidget->setMinMaxValue(0,1,alpha,0.01);
        ambientWidget->setMinMaxValue(0,1,ambient,0.01);
        diffuseWidget->setMinMaxValue(0,1,diffuse,0.01);
        specularWidget->setMinMaxValue(0,1,specular,0.01);
        reflectionWidget->setMinMaxValue(0,1,reflection,0.01);
        bumpWidget->setMinMaxValue(0,1,bump,0.01);
        refractionWidget->setMinMaxValue(0,1,refraction,0.01);
        transparencyWidget->setMinMaxValue(0,1,transparency,0.01);
        emissionWidget->setMinMaxValue(0,1,emission,0.01);


        QVBoxLayout * layout = new QVBoxLayout;
        layout->addWidget(alphaWidget);
        layout->addWidget(ambientWidget);
        layout->addWidget(diffuseWidget);
        layout->addWidget(specularWidget);
        layout->addWidget(reflectionWidget);
        layout->addWidget(bumpWidget);
        layout->addWidget(refractionWidget);
        layout->addWidget(transparencyWidget);
        layout->addWidget(emissionWidget);

        widget->setLayout(layout);

        connect(alphaWidget,SIGNAL(valueChanged(double)),this,SLOT(setalpha()));
        connect(ambientWidget,SIGNAL(valueChanged(double)),this,SLOT(setambient()));
        connect(diffuseWidget,SIGNAL(valueChanged(double)),this,SLOT(setdiffuse()));
        connect(specularWidget,SIGNAL(valueChanged(double)),this,SLOT(setspecular()));
        connect(reflectionWidget,SIGNAL(valueChanged(double)),this,SLOT(setreflection()));

        connect(bumpWidget,SIGNAL(valueChanged(double)),this,SLOT(setbump()));
        connect(refractionWidget,SIGNAL(valueChanged(double)),this,SLOT(setrefraction()));
        connect(transparencyWidget,SIGNAL(valueChanged(double)),this,SLOT(settransparency()));
        connect(emissionWidget,SIGNAL(valueChanged(double)),this,SLOT(setemission()));

       // widget->show();

    }
    ~QPhongMaterialParameters()
    {
        delete widget;
    }

signals:

    void valueChanged(double);


private slots:

    void  setalpha()
    {
         alpha = alphaWidget->getValue();

         emit valueChanged(alpha);
    }

    void  setambient()
    {
        ambient = ambientWidget->getValue();

        emit valueChanged(ambient);
    }

    void  setdiffuse()
    {
        diffuse = diffuseWidget->getValue();

        emit valueChanged(diffuse);
    }

    void  setspecular()
    {
        specular = specularWidget->getValue();

        emit valueChanged(specular);
    }

    void  setreflection()
    {
        reflection = reflectionWidget->getValue();

        emit valueChanged(reflection);
    }

    void  setbump()
    {
        bump = bumpWidget->getValue();

        emit valueChanged(bump);
    }

    void  setrefraction()
    {
        refraction = refractionWidget->getValue();

        emit valueChanged(refraction);
    }

    void  settransparency()
    {
        transparency = transparencyWidget->getValue();

        emit valueChanged(transparency);
    }

    void  setemission()
    {
        emission = emissionWidget->getValue();

        emit valueChanged(emission);
    }

};






#endif // SETTINGS_HPP
