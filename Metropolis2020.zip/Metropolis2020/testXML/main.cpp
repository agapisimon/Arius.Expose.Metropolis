#include<QtGui>
#include<QtXml>
#include<QtOpenGL>

class SVGstyle
{
public:
    QColor stroke;
    QColor fill;
    float fill_opacity;
    float stroke_width;

};

class SVGShape
{
public:
    QList< QPointF> points;
    QList< QString> types;
};

class SVGparse
{
public:

   // QList< QPainterPath> paths;
    QList<SVGShape> shapes;

    SVGstyle style;

    QPointF translation;

    SVGparse()
    {

        QDomDocument doc("mydocument");

        //QFile file(":/compass_shape.svg");
        QFile file(":/compass_shape1.svg");

        if (!file.open(QIODevice::ReadOnly))
            return;

        if (!doc.setContent(&file))
        {
            file.close();
            return;
        }
        file.close();

        // print out the element names of all elements that are direct children
        // of the outermost element.
        QDomElement docElem = doc.documentElement();

        QDomNode n = docElem.firstChild();

        //qDebug()<< n.toText().data();

        while(!n.isNull())
        {
            QDomElement e = n.toElement(); // try to convert the node to an element.

            if(!e.isNull())
            {
                qDebug()<<e.tagName();

                if(e.tagName().startsWith("g"))
                {
                    QString trans = e.attribute("transform");

                    foreach(QString s, trans.split(" "))
                    {
                        if(s.startsWith("translate"))
                        {
                            s.remove("translate(");
                            s.remove(")");

                            QStringList strL =  s.split(",");

                            translation = QPointF(strL[0].toFloat(),strL[1].toFloat());

                            qDebug()<<"Translate:"<<translation;
                        }
                    }

                    qDebug()<<e.attribute("transform");


                    QDomElement element = e.firstChildElement("path");

                    QString pstyle="opacity:1;fill:#008080;fill-opacity:1;stroke:#000000;stroke-width:0.5;stroke-linecap:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1";
                    QString d    ="m 132.42857,669.0755 0,16.42783 5.95176,0 0,-11.26711 8.85437,11.26711 7.01192,0 0,-16.42783 -5.95208,0 0,11.26745 -8.85406,-11.26745 z "
                                  "m 11.05417,15.96544 -4.19599,7.26728 -4.19566,7.26726 4.91158,0 0,4.52963 c -5.37083,1.35329 -9.57492,5.52989 -10.96344,10.89172 l -5.9792,0 0.0249,-5.3322 -7.28692,4.16168 -7.28661,4.16198 7.24763,4.22967 7.24763,4.22935 0.0228,-4.89974 5.77215,0 c 1.10598,5.93153 5.62657,10.64112 11.50785,11.98898 l 0,4.93247 -4.70515,-9.4e-4 4.19348,7.2682 4.19382,7.26854 4.19784,-7.26604 4.19785,-7.26604 -5.11768,-9.4e-4 0,-4.98517 c 5.71664,-1.39071 10.11102,-5.96561 11.27056,-11.73359 l 5.24303,0 -0.0664,5.5352 7.31685,-4.10838 7.31717,-4.10835 -7.21645,-4.28268 -7.21646,-4.28234 -0.0561,4.69581 -5.47252,0 c -1.36713,-5.60291 -5.79716,-9.94345 -11.42679,-11.19598 l 0,-4.42984 4.91158,0 -4.19568,-7.26727 z m 0.42094,25.48084 c 4.49764,9e-5 8.14368,3.64613 8.14377,8.14377 9e-5,4.49777 -3.646,8.14399 -8.14377,8.14408 -4.49789,9e-5 -8.14417,-3.64619 -8.14408,-8.14408 9e-5,-4.49777 3.64631,-8.14386 8.14408,-8.14377 z "
                                  "m -48.474399,4.03073 1.732393,7.2866 2.167056,0 1.30772,-5.53924 1.32267,5.53924 2.16676,0 1.71805,-7.2866 -1.78633,0 -1.25908,5.2954 -1.24942,-5.2954 -1.810658,0 -1.249088,5.2954 -1.259397,-5.2954 z "
                                  "m 85.595609,0.33332 0,8.69378 6.17814,0 0,-1.69436 -3.93626,0 0,-1.9915 3.5811,0 0,-1.69466 -3.5811,0 0,-1.61859 3.80811,0 0,-1.69467 z "
                                  "m -36.76356,40.57415 c -1.06138,0 -1.87507,0.23577 -2.44115,0.7075 -0.56607,0.47171 -0.84904,1.14607 -0.84904,2.02268 0,0.69972 0.20249,1.25572 0.60739,1.66848 0.40883,0.41277 1.05328,0.71367 1.93383,0.90236 l 0.87867,0.19457 c 0.53462,0.11798 0.89043,0.25161 1.06731,0.40099 0.18083,0.14938 0.27128,0.36153 0.27128,0.63671 0,0.30662 -0.13168,0.5427 -0.39506,0.7078 -0.26338,0.16509 -0.64278,0.24757 -1.13811,0.24757 -0.48744,0 -0.99454,-0.0749 -1.52129,-0.22419 -0.52282,-0.15331 -1.06518,-0.37942 -1.62732,-0.67817 l 0,1.91637 c 0.56214,0.20834 1.12411,0.3656 1.68625,0.47175 0.56213,0.10609 1.12243,0.15932 1.68064,0.15932 1.18324,0 2.06177,-0.23576 2.6357,-0.70748 0.57786,-0.47565 0.86683,-1.19921 0.86683,-2.17016 0,-0.73904 -0.2065,-1.30899 -0.61925,-1.70995 -0.41276,-0.40097 -1.10841,-0.69959 -2.08724,-0.89614 l -0.96722,-0.19458 c -0.45993,-0.0943 -0.77817,-0.20639 -0.95506,-0.33611 -0.17297,-0.13366 -0.25943,-0.31855 -0.25943,-0.55439 0,-0.31449 0.12969,-0.54627 0.38914,-0.69566 0.25944,-0.14936 0.66047,-0.22417 1.20295,-0.22417 0.40883,0 0.8431,0.0553 1.30303,0.16525 0.45993,0.11008 0.93177,0.27301 1.41529,0.48923 l 0,-1.86337 c -0.5464,-0.14544 -1.07513,-0.2535 -1.58617,-0.32427 -0.51102,-0.0747 -1.00845,-0.11191 -1.49197,-0.11191 z";

                    QString id   ="path4136";

                    if(element.attribute("style").size()>0)
                    {
                        //qDebug()<<element.attribute("style");

                         QString svgStyle = element.attribute("style");

                         QStringList styleList = svgStyle.split(";");

                         foreach(QString s,styleList)
                         {
                             QStringList str = s.split(":");

                             if(str[0].startsWith("fill"))
                             {
                                 style.fill = QColor(Qt::darkGreen);//str[1]

                             }
                             else if(str[0].startsWith("fill-opacity"))
                             {
                                 style.fill_opacity =str[1].toFloat();

                             }
                             else if(str[0].startsWith("stroke"))
                             {
                                 style.stroke = QColor(Qt::black);//str[1]

                             }
                             else if(str[0].startsWith("stroke-width"))
                             {
                                 style.stroke_width =str[1].toFloat();
                             }
                         }
                    }

                    if(element.attribute("d").size()>0)
                    {
                       d = element.attribute("d");

                       QStringList styleList = d.split("z m");

                       foreach( QString  node, styleList)
                       {
                           QPainterPath path;
                           node = node.trimmed();

                           if(!node.startsWith("m"))
                           {
                               node = QString("m ")+node;
                           }

                           if(!node.endsWith("z"))
                           {
                               node = node+QString(" z");
                           }

                           SVGShape s;

                           //qDebug()<<"Paths:"<<node<<"\n\n";

                           QStringList data = node.split(" ");

                           QString started;

                           foreach( QString  n, data)
                           {
                               n.trimmed();

                               if(n.startsWith("m"))
                               {
                                   started =  QString("m");
                               }
                               else if(n.startsWith("z"))
                               {
                                   started =  QString("z");
                               }
                               else if(n.startsWith("c"))
                               {
                                   started =  QString("c");
                               }
                               else if(n.startsWith("l"))
                               {
                                   started =  QString("l");
                               }
                               else if(n.startsWith("v"))
                               {
                                   started =  QString("v");
                               }
                               else if(n.startsWith("h"))
                               {
                                   started =  QString("h");
                               }


                               if(started.startsWith("m") && n.size()>1)
                               {
                                   QStringList sp = n.split(",");
                                   QPointF p = QPointF(sp[0].toFloat(),sp[1].toFloat()) ;
                                   //path.moveTo(p);
                                   qDebug()<<"Points:"<<n;
                                   qDebug()<<"M Point:"<<sp;
                                   qDebug()<<"\n\n";
                                   qDebug()<<"M Point:"<<p;

                                   s.points.append(p);
                                   s.types.append(QString("m"));

                               }
                               else if(started.startsWith("c") && n.size()>1)
                               {
                                   QStringList sp = n.split(",");
                                   QPointF p = QPointF(sp[0].toFloat(),sp[1].toFloat()) ;
                                   //path.cubicTo(p);
                                   qDebug()<<"C Point:"<<p;

                                   s.points.append(p);
                                   s.types.append(QString("c"));
                               }
                               else if(started.startsWith("l") && n.size()>1)
                               {
                                   QStringList sp = n.split(",");

                                   QPointF p = QPointF(sp[0].toFloat(),sp[1].toFloat()) ;
                                   //path.lineTo(p);

                                   qDebug()<<"lPoint:"<<p;

                                   s.points.append(p);
                                   s.types.append(QString("l"));
                               }
                               else if(started.startsWith("v") && n.size()>1)
                               {
                                   QStringList sp = n.split(",");

                                   QPointF p = QPointF(sp[0].toFloat(),sp[1].toFloat()) ;
                                   //path.lineTo(p);

                                   qDebug()<<"v Point:"<<p;

                                   s.points.append(p);
                                   s.types.append(QString("v"));

                               }
                               else if(started.startsWith("h") && n.size()>1)
                               {
                                   QStringList sp = n.split(",");

                                   QPointF p = QPointF(sp[0].toFloat(),sp[1].toFloat()) ;
                                   path.lineTo(p);
                                   qDebug()<<"h Point:"<<p;

                                   s.points.append(p);
                                   s.types.append(QString("h"));
                               }
                               else if(started.startsWith("z"))
                               {

                               }
                           }

                           if(s.points.size()>0 && s.types.size()>0)
                           {
                               shapes.append(s);
                           }
                       }
                    }

                    if(element.attribute("id").size()>0)
                    {
                        qDebug()<<element.attribute("id");
                    }
                }
            }

            n = n.nextSibling();
        }

        // Here we append a new element to the end of the document
        //QDomElement elem = doc.createElement("img");
        //elem.setAttribute("src", "myimage.png");
        //docElem.appendChild(elem);
    }
};

class testSVG : public QWidget
{
public:

    SVGparse * parse;

    testSVG(QWidget * parent = 0):QWidget(parent)
    {
        setFixedSize(600,400);

        parse = new SVGparse;

    }

    ~testSVG()
    {

    }

    void paintEvent(QPaintEvent * event)
    {
        QList<QPoint> points;

        for(int i=0;i<parse->shapes.size();i++)
        {
            SVGShape s= parse->shapes[i];

             foreach(QPointF p, s.points)
             {
                 //p*= 50;

                 //p += parse->translation;
                 //p *=-50;

                 p += QPoint(100,100);

                 points.append(p.toPoint());
             }
        }

        QPainter painter(this);


        painter.begin(this);

        int co =0;

        foreach(QPointF p, points)
        {
            painter.setPen(QPen(QBrush(Qt::SolidPattern),5));
            painter.drawPoint(p);
        }

        foreach(QPointF p, points)
        {
            painter.setPen(QPen(QBrush(Qt::SolidLine),1));

            if(co ==(points.size()-1))
            {

                QLine line(points[co],points[0]);

                painter.drawLine(line);

            }
            else
            {
                QLine line(points[co],points[co+1]);

                painter.drawLine(line);
            }

            co++;
        }

        painter.end();
    }
};




class QOutlinerWidget : public QTreeWidget
{
     Q_OBJECT

public:

    int frames;

    QMenu *contextmenu;

    QTreeWidgetItem * rootitem;

    bool doduplicate;

    //QList<QTreeWidgetItem * > pitems;

    QOutlinerWidget(QWidget * parent =0):QTreeWidget(parent)
    {
        //frames =  1500;
        setDragEnabled(true);
        setAcceptDrops(true);
        setDropIndicatorShown(true);
        setFocusPolicy(Qt::ClickFocus);
        setDefaultDropAction(Qt::MoveAction);
        setDragDropMode(QAbstractItemView::DragDrop);

        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

        //header()->setVisible(0);
        //setHeaderLabel("Models");
        QStringList str;
        str.append(QString("Models"));
        str.append(QString("Visibility"));
        str.append(QString("Selectable"));
        str.append(QString("Renderable"));
        setHeaderLabels(str);

        //setSelectionMode(QAbstractItemView::MultiSelection);

        //setAlternatingRowColors(true);

        //setSelectionMode(QAbstractItemView::ExtendedSelection);

        //setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed);

        //setExpandsOnDoubleClick(0);
        //setSortingEnabled(0);

        //verticalScrollBar()->setSingleStep(1);


        //setColumnCount(frames+1);

        //setColumnWidth(0,150);

        setColumnCount(4);

        setColumnWidth(0,200);
        setColumnWidth(1,60);
        setColumnWidth(2,60);
        setColumnWidth(3,60);


        for(int i=1;i<frames+1;i++)
        {
            //setColumnWidth(i,40);
        }

        rootitem = new QTreeWidgetItem;

        rootitem->setText(0,QString("Root"));
        //rootitem->setText(1,QString("Visibility"));

        rootitem->setIcon(0,QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

        //rootitem->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);

        for(int i=0;i<25;i++)
        {
            QTreeWidgetItem * item = new QTreeWidgetItem;

            item->setText(0,QString("Item")+QString::number(i));

            item->setIcon(0,QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

            item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);


            QTreeWidgetItem * child = new QTreeWidgetItem;

            child->setText(0,QString("child")+QString::number(i));

            child->setIcon(0,QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

            child->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);


            item->addChild(child);

            rootitem->addChild(item);


        }

        addTopLevelItem(rootitem);

        rootitem->setExpanded(true);

        createContextMenues();

        setTheme();

        //connect(this, SIGNAL(itemChanged()), this, SLOT(freezeSelection()));
        //connect(this, SIGNAL(itemSelectionChanged()), this,  SLOT(copySelection()));
        //connect(this, SIGNAL(itemExpanded()), this,  SLOT(pasteSelection()));
        //connect(this, SIGNAL(itemCollapsed()), this,  SLOT(duplicateSelection()));
        //connect(this, SIGNAL(activated()), this,  SLOT(deleteSelection()));
        //connect(this, SIGNAL(itemDoubleClicked()), this,  SLOT(hideSelection()));

        doduplicate = true;

        traverseTree(rootitem);

        connect(this,SIGNAL(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)),this,SLOT(pitemchange()));

        setMouseTracking(false);


    }

    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file("../resource/glowBlue.stylesheet");

        // QString s ="darkorange.stylesheet"

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  array =  file.readAll();

            setStyleSheet(array);

            contextmenu->setStyleSheet(array);

            file.close();
        }

        qDebug()<<"Styles Loaded";
    }

    void createContextMenues()
    {
        contextmenu = new QMenu;

        QStringList list;

        list.append(QString("Copy"));
        list.append(QString("Paste"));
        list.append(QString("Duplicate"));
        list.append(QString("Rename"));
        list.append(QString("Delete"));
        list.append(QString("Hide"));
        list.append(QString("Freeze"));
        list.append(QString("Expand Tree"));

        list.sort();

        contextmenu->setTitle(QString("Ouliner Context Menu"));

        /*
        contextmenu.addAction(QIcon("../Tools Icons/copy.svg"),QString("Copy"),this,SLOT(copySelection()));
        contextmenu.addAction(QIcon("../Tools Icons/paste.svg"),QString("Paste"),this,SLOT(pasteSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/duplicate.svg"),QString("Duplicate"),this,SLOT(duplicateSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/rename.svg"),QString("Rename"),this,SLOT(renameSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/delete.svg"),QString("Delete"),this,SLOT(deleteSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/hide.svg"),QString("Hide"),this,SLOT(hideSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/freeze.svg"),QString("Freeze"),this,SLOT(freezeSelection()));
        */

        QAction * d0 = new QAction(QIcon("../Tools Icons/copy.svg"),QString("Copy: CTRL+C"),this);
        QAction * d1 = new QAction(QIcon("../Tools Icons/paste.svg"),QString("Paste: CTRL+V"),this);
        QAction * d2 = new QAction(QIcon("../Tools Icons/duplicate.svg"),QString("Duplicate: CTRL+D"),this);
        QAction * d3 = new QAction(QIcon("../Tools Icons/rename.svg"),QString("Rename: CTRL+R"),this);
        QAction * d4 = new QAction(QIcon("../Tools Icons/delete.svg"),QString("Delete: Delete"),this);
        QAction * d5 = new QAction(QIcon("../Tools Icons/hide.svg"),QString("Hide: CTRL+H"),this);
        QAction * d6 = new QAction(QIcon("../Tools Icons/freeze.svg"),QString("Freeze: CTRL+F"),this);
        QAction * d7 = new QAction(QIcon("../Tools Icons/freeze.svg"),QString("Expand Tree: CTRL+E"),this);

        d0->setCheckable(true);d0->setShortcut(Qt::CTRL|Qt::Key_C);
        d1->setCheckable(true);d1->setShortcut(Qt::CTRL|Qt::Key_V);
        d2->setCheckable(true);d2->setShortcut(Qt::CTRL|Qt::Key_D);
        d3->setCheckable(true);d3->setShortcut(Qt::CTRL|Qt::Key_R);
        d4->setCheckable(true);d4->setShortcut(Qt::Key_Delete);
        d5->setCheckable(true);d5->setShortcut(Qt::Key_H);
        d6->setCheckable(true);d6->setShortcut(Qt::CTRL|Qt::Key_F);
        d7->setCheckable(true);d6->setShortcut(Qt::CTRL|Qt::Key_E);

        connect(d0, SIGNAL(triggered(bool)), this, SLOT(copySelection()));
        connect(d1, SIGNAL(triggered(bool)), this, SLOT(pasteSelection()));
        connect(d2, SIGNAL(triggered(bool)), this, SLOT(duplicateSelection()));
        connect(d3, SIGNAL(triggered(bool)), this, SLOT(renameSelection()));
        connect(d4, SIGNAL(triggered(bool)), this, SLOT(deleteSelection()));
        connect(d5, SIGNAL(triggered(bool)), this, SLOT(hideSelection()));
        connect(d6, SIGNAL(triggered(bool)), this, SLOT(freezeSelection()));
        connect(d7, SIGNAL(triggered(bool)), this, SLOT(collapseExpandTree()));

        QActionGroup *duplicationActions =  new QActionGroup(this);

        duplicationActions->addAction(d0);
        duplicationActions->addAction(d1);
        duplicationActions->addAction(d2);
        duplicationActions->addAction(d3);
        duplicationActions->addAction(d4);
        duplicationActions->addAction(d5);
        duplicationActions->addAction(d6);
        duplicationActions->addAction(d7);

        contextmenu->addActions(duplicationActions->actions());
    }

    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        //const QModelIndex index = selectionModel()->currentIndex();

        //QString selectedText = index.data(Qt::DisplayRole).toString();

        //qDebug()<<"Selection Change:"<<index;
        //qDebug()<<"Selection Text:"<<selectedText;
        //qDebug()<<"Selection Text:"<<selectedItems()[0]->text(0);

        qDebug()<<"Selection Changed"<<selectedItems()[0]->text(0);

        updateProperties();

        QTreeWidget::selectionChanged(selected,deselected);
    }

    /*

    void mousePressEvent(QMouseEvent * event)
    {
        if(selectedItems().size()>0)
        {
            selectedItems().clear();
        }

        QTreeWidget::mousePressEvent(event) ;
    }

    */

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if (event->keyboardModifiers() == Qt::CTRL)
        {
            duplicateAndReparentItem(event->pos());
        }
        else
        {
            reparentItem(event->pos());
        }

        return QTreeWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {
        contextmenu->exec(event->globalPos());
        //contextmenu->popup(event->globalPos());
    }

    void keyPressEvent(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::CTRL && event->key()==Qt::Key_G)
        {
            createGroupItem();
        }
    }

signals:

    void valueChanged();

public slots:

    void collapseExpandTree()
    {
        expandAll();
    }

    void pitemchange()
    {
        qDebug()<<"Current Item:"<<currentItem()->text(0);

    }


    bool itemInTree(QTreeWidgetItem *root,QString name)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                //qDebug()<<"Item name:"<<item->text(0);

                if(name.startsWith(item->text(0)))
                {
                    return true;
                }

                itemInTree(item,name);
            }
        }

        return false;
    }

    void fullyCollapse(QTreeWidgetItem *item)
    {
        for (int i = 0; i < item->childCount(); ++i)
        {
           item->child(i)->setExpanded(0);
        }
    }

    void fullyExpand(QTreeWidgetItem *item)
    {
        for (int i = 0; i < item->childCount(); ++i)
        {
            item->child(i)->setExpanded(1);
        }
    }

    void rename(QTreeWidgetItem *item, int col)
    {
        item->text(col).toStdString();
    }


    void traverseTree(QTreeWidgetItem *root)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                qDebug()<<"Item name:"<<item->text(0);

                //QRadioButton *r = new QRadioButton();
                //r->setIcon(QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

                //setItemWidget(item,1,new QRadioButton());
                //setItemWidget(item,2,new QRadioButton());
                //setItemWidget(item,3,new QRadioButton());

                traverseTree(item);
            }
        }
    }

    void recursiveHideItems(QTreeWidgetItem * root,bool hide = false)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                item->setSelected(hide);

                //recursiveHideItems(item,hide);
            }
        }
    }


    void createGroupItem()
    {
        if(selectedItems()[0]->parent())
        {
            selectedItems()[0]->parent()->removeChild(selectedItems()[0]);
        }

        removeItemWidget(selectedItems()[0],0);

        QTreeWidgetItem * cloneItem = selectedItems()[0]->clone();

        QTreeWidgetItem * group     = new QTreeWidgetItem;

        group->setIcon(0,QIcon(QString("../Tools Icons/mesh location.svg")));
        group->setText(0,QString("group"));
        group->addChild(cloneItem);
        group->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);

        rootitem->addChild(group);

        group->setSelected(true);
    }


    void duplicateAndReparentItem(QPoint pos)
    {
        //duplicate:
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(item && selectItems.size()>0 )
        {
            if(selectItems[0]->parent())
            {
                QTreeWidgetItem * duplicate =  selectItems[0]->clone();

                if(!duplicate->isExpanded())
                    duplicate->setExpanded(true);

                item->addChild(duplicate);
            }

           // qDebug()<<"drop:"<<myItem->text(0);
        }
        else
        {
            if(selectItems.size()>0 && selectItems[0]->parent())
            {
                QTreeWidgetItem *parent = selectItems[0]->parent();

                QTreeWidgetItem * duplicate =  selectItems[0]->clone();

                if(!duplicate->isExpanded())
                    duplicate->setExpanded(true);

                parent->addChild(duplicate);
            }
        }
    }


    void reparentItem(QPoint pos)
    {
        QList<QTreeWidgetItem*> pselectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(pselectItems.size()>0 )
        {
            if(item)
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                item->addChild(clone);
            }
            else
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                rootitem->addChild(clone);
            }
        }



        /*

        QList<QTreeWidgetItem*> pselectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(pselectItems.size()>0 )
        {
            if(item)
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();



                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                item->addChild(clone);
            }
            else
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                rootitem->addChild(clone);
            }
        }

    */

    }

    void reorderItem(QPoint pos)
    {
        QList<QTreeWidgetItem*> selectItems = this->selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(item && selectItems.size()>0 )
        {
            if(item->parent())
            {
                int index = item->parent()->indexOfChild(item);

                item->parent()->insertChild(index,selectItems[0]);
            }



            /*
            if(selectItems[0]->parent())
            {
                QTreeWidgetItem *parent = selectItems[0]->parent();

                parent->removeChild(selectItems[0]);

                item->addChild(selectItems[0]);
            }

           // qDebug()<<"drop:"<<myItem->text(0);

           */
        }

    }


    void copySelection()
    {
        qDebug()<<"copy Selection";
    }

    void pasteSelection()
    {
        qDebug()<<"paste Selection";
    }

    void deleteSelection()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && !selectItems[0]->text(0).startsWith("Root") )
        {
            removeItemWidget(selectItems[0],0);

            delete selectItems[0];
        }

        qDebug()<<"delete Selection";
    }

    void duplicateSelection()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && selectItems[0]->parent())
        {
            QTreeWidgetItem *parent = selectItems[0]->parent();

            //QTreeWidgetItem duplicate = QTreeWidgetItem(*selectItems[0]);


            //QTreeWidgetItem * duplicate = new QTreeWidgetItem;
            //duplicate->setText(0,selectItems[0]->text(0));
            //duplicate->setIcon(0,selectItems[0]->icon(0));
            //duplicate->addChildren(selectItems[0]->);

            QTreeWidgetItem * duplicate =  selectItems[0]->clone();

            if(!duplicate->isExpanded())
                duplicate->setExpanded(true);

            parent->addChild(duplicate);
        }

        qDebug()<<"duplicate Selection";
    }

    void duplicateTree()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && selectItems[0]->parent())
        {
            QTreeWidgetItem *parent = selectItems[0]->parent();

            QTreeWidgetItem * duplicate =  selectItems[0]->clone();

            parent->addChild(duplicate);
        }

        qDebug()<<"duplicate Selection";
    }




    void renameSelection()
    {
        qDebug()<<"rename Selection";
    }

    void freezeSelection()
    {
         qDebug()<<"freeze Selection";
    }

    void hideSelection()
    {
         qDebug()<<"hide Selection";
    }

    void updateProperties()
    {

    }
};


class CPropertyEditorData
{
    //CPropertyEditor* propEditor;

    QTreeWidget * propEditor;

public:
    CPropertyEditorData(QTreeWidget * parent = 0) : object(0)
    {
        propEditor = parent;
    }

    QObject* object;

    bool initializing;

    void initFromObject()
    {
        if(!object)
            return;

        const QMetaObject* mo = object->metaObject();

        int propCount = mo->propertyCount();

        qDebug()<<"Property Count"<<propCount;

        for(int i=1; i<propCount; i++)
        {
            QMetaProperty prop = mo->property(i);

            if(!prop.isWritable() || prop.isEnumType())
                continue;

            QString propName(prop.name());
            QVariant propValue = prop.read(object);

            QTreeWidgetItem* item = new QTreeWidgetItem(propEditor);

            item->setData(0, Qt::DisplayRole, propName);
            item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEditable|Qt::ItemIsEnabled);

            if(prop.type() == QVariant::List)
                createForList(item, propValue);
            else
                item->setData(1, Qt::DisplayRole, propValue);
        }
    }

    void createForList(QTreeWidgetItem* parent, const QVariant value)
    {
        QString pName = parent->text(0);
        QList<QVariant> list = value.toList();
        for(int i=0; i<list.count(); i++)
        {
            QTreeWidgetItem* item = new QTreeWidgetItem(parent);
            item->setData(0, Qt::DisplayRole, QString("%1[%2]").arg(pName).arg(i));
            item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEditable|Qt::ItemIsEnabled);

            QVariant val = list[i];
            if(val.type() == QVariant::List)
                createForList(item, val);
            else
                item->setData(1, Qt::DisplayRole, val);
        }

        parent->setExpanded(true);
    }

    QVariant constructValueFrom(QTreeWidgetItem* item)
    {
        if(item->childCount())
        {
            QList<QVariant> ret;

            for(int i=0; i<item->childCount(); i++)
            {
                ret << constructValueFrom(item->child(i));
            }

            return ret;
        }

        return item->data(1, Qt::DisplayRole);
    }
};


class CPropertyEditor : public QTreeWidget
{
    Q_OBJECT

protected:
    void drawBranches(QPainter* , const QRect &, const QModelIndex &) const { }


    CPropertyEditorData* propertyData;

public:
    CPropertyEditor(QWidget* parent =0): QTreeWidget(parent)
    {
        propertyData = new CPropertyEditorData(this);
        //d->propEditor = this;

        QStringList cols;
        cols << "Name" << "Value";

        setColumnCount(cols.count());
        setHeaderLabels(cols);

        connect(this, SIGNAL(itemChanged(QTreeWidgetItem*,int)),
                this, SLOT(on_itemChanged(QTreeWidgetItem*,int)));

        QFont f(font());

        f.setPointSizeF(f.pointSizeF() * 1.2f);

        setFont(f);

        setAlternatingRowColors(true);
    }

    ~CPropertyEditor()
    {
        delete propertyData;
    }

    QObject* object() const
    {
        return propertyData->object;
    }

public slots:


    void setObject(QObject* object)
    {
        if(propertyData->object == object)
            return;

        clear();

        if(propertyData->object)
            disconnect(propertyData->object, 0, this, 0);

        propertyData->object = object;

        if(object)
            connect(object, SIGNAL(destroyed(QObject*)), this, SLOT(on_object_destroyed()));

        propertyData->initializing = true;

        propertyData->initFromObject();

        propertyData->initializing = false;

    }

private slots:

    void on_itemChanged(QTreeWidgetItem* item, int column)
    {

        if(!item || !propertyData->object || column!=1 || propertyData->initializing)
            return;

        QTreeWidgetItem* item2 = item;

        while(item2->parent())
            item2 = item2->parent();

        QString name = item2->text(0);
        QVariant value = propertyData->constructValueFrom(item2);
        propertyData->object->setProperty(name.toStdString().data(), value);

    }

    void on_object_destroyed()
    {
        setObject(0);

    }
};

class Parameter : public QObject
{
    Q_OBJECT
public:
    QVector3D pos;

    QColor color;

    Parameter()
    {
        pos =  QVector3D(0,0,4);

        color = QColor(29,30,40);

    }
};


class pMain : public QWidget
{
public:
    pMain(QWidget * parent =0): QWidget(parent)
    {
         //testSVG * w = new testSVG(this);

         QOutlinerWidget * tm = new QOutlinerWidget(this);

         //CPropertyEditor * propertyEditor = new  CPropertyEditor(this);

         //QVariant v;
         //v.fromValue(QVector3D(1,1,1));

         //Parameter * param = new Parameter;
         //propertyEditor->setObject(param);

        // QSplitter * splitter = new QSplitter(Qt::Vertical);


         //splitter->addWidget(tm);
         //splitter->addWidget(propertyEditor);

         //QSplitter * hsplitter = new QSplitter(Qt::Horizontal);

         QHBoxLayout * layout  = new QHBoxLayout;

         layout->addWidget(tm);

         //layout->addWidget(w);
         //layout->addWidget(splitter);
         //layout->addWidget(tm);

         setLayout(layout);

         //hsplitter->addWidget(w);
         //hsplitter->addWidget(splitter);

         //QVBoxLayout * layout  = new QVBoxLayout;
         //layout->addWidget(hsplitter);
         //setLayout(layout);



         setTheme();

    }

    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file("../resource/glowBlue.stylesheet");

        // QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  array =  file.readAll();

            setStyleSheet(array);


            file.close();
        }


        qDebug()<<"Styles Loaded";
    }
};






int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //SVGparse* parse =  new SVGparse();

    pMain * w = new pMain;

    w->showMaximized();

    /*
    QMatrix4x4 mat;
    mat.setToIdentity();
    mat.translate(QVector3D(0,1,45));

    QVector3D p =  mat * QVector3D(0,0,0);
    qDebug()<<"pos:"<<p;
    */

    return a.exec();
}

#include "main.moc"
