 #ifndef SCENE_HPP
#define SCENE_HPP


#include<geometry.hpp>
#include<models.hpp>
#include<handles.hpp>
#include<settings.hpp>
//#include<sound.hpp>
#include<tools.hpp>
#include<widgets.hpp>

//#include<materials.hpp>



/*
class MetroFile
{
public:
    bool fromDomElement (QDomElement e, float& v)
    {
       bool ok = true;
      if (e.attributeNode ("type").value () == "float")
      {
          v = e.text ().toFloat (&ok);
      }
      return ok;
    }

    bool fromDomElement (QDomElement e, int& v)
    {
      bool ok = true;

      if(e.attributeNode ("type").value () == "integer")
      {
          v = e.text ().toInt (&ok);
      }
      return ok;
    }

    bool fromDomElement (QDomElement e, bool& v)
    {
        bool ok = true;
      if (e.attributeNode ("type").value () == "boolean")
      {

      v = e.text ().toInt (&ok) != 0;
      }
      return ok;
    }

    bool fromDomElement (QDomElement e, QVector3D& v)
    {
        bool okX, okY, okZ;
      if (e.attributeNode ("type").value () == "QVector3D")
      {

       okX = fromDomElement (e.firstChildElement ("x"), v.x());
       okY = fromDomElement (e.firstChildElement ("y"), v.y());
       okZ = fromDomElement (e.firstChildElement ("z"), v.z());
      }

      return okX && okY && okZ;
    }

    bool fromDomElement (QDomElement e, QVector2D& v)
    {
        bool okX, okY;
      if (e.attributeNode ("type").value () == "QVector2D")
      {

       okX = fromDomElement (e.firstChildElement ("x"), v.x());
       okY = fromDomElement (e.firstChildElement ("y"), v.y());

      }

      return okX && okY ;
    }
    bool fromDomElement (QDomElement e, QColor& v)
    {
        bool okR,okG,okB;

        if(e.attributeNode ("type").value () == "QColor")
        {

          float tmp;
           okR =fromDomElement (e.firstChildElement ("r"), tmp);
          v.setRedF( (tmp);
           okG = fromDomElement (e.firstChildElement ("g"), tmp);
          v.setGreenF( (tmp);
           okB = fromDomElement (e.firstChildElement ("b"), tmp);
          v.setBlueF(tmp);
        }
      return okR && okG && okB;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const float& v)
    {
      elem.setAttribute ("type", "float");
      elem.appendChild  (doc.createTextNode (std::to_string (v).c_str ()));
      return elem;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const int& v)
    {
      elem.setAttribute ("type", "integer");
      elem.appendChild  (doc.createTextNode (std::to_string (v).c_str ()));
      return elem;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const bool& v)
    {
      elem.setAttribute ("type", "boolean");
      elem.appendChild  (doc.createTextNode (std::to_string (v ? 1 : 0).c_str ()));
      return elem;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const glm::vec3& v)
    {
      elem.setAttribute ("type", "vector3f");
      QDomElement x = doc.createElement ("x");
      QDomElement y = doc.createElement ("y");
      QDomElement z = doc.createElement ("z");
      elem.appendChild (toDomElement (doc, x, v.x));
      elem.appendChild (toDomElement (doc, y, v.y));
      elem.appendChild (toDomElement (doc, z, v.z));
      return elem;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const glm::ivec2& v)
    {
      elem.setAttribute ("type", "vector2i");
      QDomElement x = doc.createElement ("x");
      QDomElement y = doc.createElement ("y");
      elem.appendChild (toDomElement (doc, x, v.x));
      elem.appendChild (toDomElement (doc, y, v.y));
      return elem;
    }

    QDomElement&  toDomElement ( QDomDocument& doc, QDomElement& elem
                                               , const Color& v)
    {
      elem.setAttribute ("type", "color");
      QDomElement r = doc.createElement ("r");
      QDomElement g = doc.createElement ("g");
      QDomElement b = doc.createElement ("b");

      elem.appendChild (toDomElement (doc, r, v.r ()));
      elem.appendChild (toDomElement (doc, g, v.g ()));
      elem.appendChild (toDomElement (doc, b, v.b ()));
      return elem;
    }
};

*/


class QMouseDragSelection : public  QObject
{
    Q_OBJECT

public:

    QRectF selectionRect;

    float radius;

    QPointF point;

    float safeTitleMargin;
    float safeActionMargin;

    QCameraTargetModel * camera;

    QMouseDragSelection( QCameraTargetModel * selectedCamera=0,QObject * parent = 0 ) : QObject(parent)
    {
        this->camera = selectedCamera;

        safeTitleMargin  = 0.25f;

        safeActionMargin = 0.15f;

        radius = 0.0;

        selectionRect =  QRect(0,0,400,400);

    }

    /*

    QVector2D toScreen(QMatrix4x4 viewProjectionMatrix,const QVector3D &coordinate) const
    {
        QVector3D projected = viewProjectionMatrix.map(coordinate);

        QVector2D c(viewport.width() * 0.5, viewport.height() * 0.5);

        return c + c * projected.toVector2D() * QVector2D(1, -1);
    }
    QRectF toScreenRect(QMatrix4x4 projectionMatrix,QMatrix4x4 viewMatrix,const QVector<QVector3D> &coordinates) const
    {
        QVector<QVector3D> mapped;

        for (int i = 0; i < coordinates.size(); ++i)
            mapped << viewMatrix.map(coordinates.at(i));

        qreal zClip = -zNear;

        QVector<QVector3D> clipped;

        for (int i = 0; i < mapped.size(); ++i)
        {
            const QVector3D &a = mapped.at(i);
            const QVector3D &b = mapped.at((i + 1) % mapped.size());

            bool aOut = a.z() > zClip;
            bool bOut = b.z() > zClip;

            if (aOut && bOut)
                continue;

            if (!aOut && !bOut)
            {
                clipped << b;
                continue;
            }

            qreal t = (zClip - a.z()) / (b.z() - a.z());
            QVector3D intersection = a + t * (b - a);

            clipped << intersection;

            if (!bOut)
                clipped << b;
        }

        QRectF bounds;

        QVector2D c(viewport.width() * 0.5, viewport.height() * 0.5);

        for (int i = 0; i < clipped.size(); ++i)
        {
            QVector2D projected = c + c * projectionMatrix.map(clipped.at(i)).toVector2D() * QVector2D(1, -1);
            bounds = bounds.united(QRectF(projected.toPointF(), QSizeF(0.01, 0.01)));
        }

        bounds = bounds.intersected(QRectF(0, 0, viewport.width(), viewport.height()));

        return bounds;
    }

    */


    void drawSelectionCircle(QGLWidget * widget)
    {
        QRect ScreenRect = widget->rect();

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glColor4f(1.0f,1.0f,1.0f,1.0f);
        glBegin(GL_LINE_LOOP);

        float w = ScreenRect.width();
        float h = ScreenRect.height();

        for(float i = 0.0; i<36.0 ;i++)
        {
            float angle =  i/36.0 *2.0 * PI;

            float x =  radius * cos(angle) + w * 0.5;

            float y =  radius * sin( angle) + h * 0.5;

            glVertex4f(x,y,0.0f,1.0f);
        }

        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    void drawSelectionRectangle(QGLWidget * widget)
    {
        QRect ScreenRect = widget->rect();

        float ScreenCentreX = (float)(ScreenRect.right() - ScreenRect.left()) / 2.0f;
        float ScreenCentreY = (float)(ScreenRect.bottom() - ScreenRect.top()) / 2.0f;

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);
        glVertex4f((selectionRect.left()-ScreenCentreX)/ScreenCentreX, (selectionRect.top()-ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        glVertex4f((selectionRect.right()-ScreenCentreX)/ScreenCentreX, (selectionRect.top()-ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        glVertex4f((selectionRect.right()-ScreenCentreX)/ScreenCentreX, (selectionRect.bottom()-ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        glVertex4f((selectionRect.left()-ScreenCentreX)/ScreenCentreX, (selectionRect.bottom()-ScreenCentreY)/-ScreenCentreY, 0.0f, 1.0f);
        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }



    void drawSafeTitleRectangle(QGLWidget * widget)
    {
        float w =  widget->rect().width();
        float h =  widget->rect().height();

        QPoint TL = widget->rect().topLeft();
        QPoint BR = widget->rect().bottomRight();

        QPoint offset = QPoint(w*safeTitleMargin, h*safeTitleMargin);

        TL += offset;
        BR -= offset;

        QRect ScreenRect;

        ScreenRect.setTopLeft(TL);
        ScreenRect.setBottomRight(BR);

        /*

        qDebug()<<"Window Rect:"<<widget->rect();

        qDebug()<<"Safe Titles Rect:"<<ScreenRect;

        qDebug()<<"TL:"<<ScreenRect.topLeft();
        qDebug()<<"TR:"<<ScreenRect.topRight();
        qDebug()<<"BR:"<<ScreenRect.bottomRight();
        qDebug()<<"BL:"<<ScreenRect.bottomLeft();
        */

        float ScreenCentreX = (float)(ScreenRect.right() - ScreenRect.left()) / 2.0f;
        float ScreenCentreY = (float)(ScreenRect.bottom() - ScreenRect.top()) / 2.0f;

        float aspect = (float)w / h;

        float s = .75;


        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        //glVertex4f((ScreenRect.left() -ScreenCentreX)/ScreenCentreX, (ScreenRect.top()   -ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        //glVertex4f((ScreenRect.right()-ScreenCentreX)/ScreenCentreX, (ScreenRect.top()   -ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        //glVertex4f((ScreenRect.right()-ScreenCentreX)/ScreenCentreX, (ScreenRect.bottom()-ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);
        //glVertex4f((ScreenRect.left() -ScreenCentreX)/ScreenCentreX, (ScreenRect.bottom()-ScreenCentreY)/-ScreenCentreY,0.0f, 1.0f);

        //glVertex4f(ScreenRect.topLeft().x(),ScreenRect.topLeft().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.topRight().x(),ScreenRect.topRight().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.bottomRight().x(),ScreenRect.bottomRight().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.bottomLeft().x(),ScreenRect.bottomLeft().y(),0.0f, 1.0f);


        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);

        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    void drawSafeActionRectangle(QGLWidget * widget)
    {
        float s = .85f;
        float w =  widget->rect().width();
        float h =  widget->rect().height();

        QPoint TL = widget->rect().topLeft();
        QPoint BR = widget->rect().bottomRight();

        QPoint offset = QPoint(w*safeActionMargin, h*safeActionMargin);

        TL += offset;
        BR -= offset;

        QRect ScreenRect;

        ScreenRect.setTopLeft(TL);
        ScreenRect.setBottomRight(BR);


        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        glLineWidth(1.0f);
        glBegin(GL_QUADS);
        glColor4f(1.0f,1.0f,1.0f,1.0f);
        //glVertex4f(ScreenRect.topLeft().x(),ScreenRect.topLeft().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.topRight().x(),ScreenRect.topRight().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.bottomRight().x(),ScreenRect.bottomRight().y(),0.0f, 1.0f);
        //glVertex4f(ScreenRect.bottomLeft().x(),ScreenRect.bottomLeft().y(),0.0f, 1.0f);

        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);


        glEnd();

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }


    virtual void mousePressEvent(QMouseEvent * event)
    {
        point = event->pos();
    }

    virtual void mouseMoveEvent(QMouseEvent * event)
    {
        radius = QVector2D(event->pos() - point).length();
    }

    virtual void mouseReleaseEvent(QMouseEvent * event)
    {

    }
};

class QSceneGraph;

class QSceneStorage : public QObject
{
    Q_OBJECT

    QSceneGraph * scenegraph;

public:

    QSceneStorage(QSceneGraph * scenegraph = 0 ,QObject * parent =0):QObject(parent)
    {
        this->scenegraph = scenegraph;
    }

    virtual void openScene(QString filename)
    {

    }

    virtual void saveScene(QString filename)
    {

    }
};


class QSceneGraph : public QObject
{
    Q_OBJECT

    qreal c  = (qreal)76/255;
    qreal c1 = (qreal)199/255;

    QStringList modelsList;
    QStringList allnodes;

    QIcon icon;

    QGLWidget * parentWidget;

    QMouseDragSelection * dragselection;

public:
    //QList<QGLWidget*> views;
    QPoint lastPos;

    QVector3D ray;
    QVector3D prevhitpoint;
    QVector3D lastRayOrigin;
    QVector3D rayscreenOffset;

    //AxesTransformer * axesTransformer;
    GizimoAxesTransformer * axesTransformer;
    QSelectionInfo * selectionInfo;

   // SoundTools * psoundTools;
    penTools   * pentools;
    selectionTools * pselectTools;

    //QList< QGroupModel *> groups;
    QList< QBaseModel*> cameras;
    QList< QBaseModel*> lights;
    QList< QBaseModel*> meshes;
    QList< QBaseModel*> models;

    QList< GLuint > textures;
    QList< QImage > images;

    //QList<QBaseMaterial * > materials;

    //MATERIAL_TYPES materialType;

    GLuint matCapTexturePointer; //texture reflection

    /*
    virtual void setMaterialType(MATERIAL_TYPES shader)
    {
        materialType = shader;

        switch(materialType)
        {

        case MATERIAL_BASE:
            break;
        case MATERIAL_PHONG:
            break;
        case MATERIAL_COOK_TORRANCE:
             break;
        case MATERIAL_LAMBERT:
             break;
        case MATERIAL_BLINN:
             break;
        case MATERIAL_COLOR:
             break;
        case MATERIAL_MATCAP:
             break;
        case MATERIAL_WIREFRAME:
             break;
        case MATERIAL_XRAY:
             break;

        }
    }

    */


    QMainWindow * propertiesEditor;
    //QWidget * propertiesEditor;


    FloorGridParameters * floorParameters;

    QToolBar * modelsToolBar;
    QToolBar * mainToolBar;
    QToolBar * lowerToolBar;

    //QToolBarScrollable * parametersToolBar;

    QMenu mainContextmenu;
    QMenu addModelsMenu;

    bool isSelectbyColor;
    bool useDefaultLights;

    GLint _texture;

    TimeLineWidgetEx * timeline;

    QSearchCommands * commands;

    QActionGroup *parentingActions;
    QActionGroup *duplicationActions;
    QActionGroup *addmodelsActionGroups;


    QRootModel * rootModel;

    int currentCameraIndex=0;

    void createToolBarsAndActions()
    {
        //parametersToolBar  =  new QToolBarScrollable(QString("Parameters Toolbar"));
        mainToolBar        =  new QToolBar(QString("Tools Toolbar"));
        modelsToolBar      =  new QToolBar(QString("Meshes Toolbar"));
        lowerToolBar       =  new QToolBar(QString("Selection and Pens"));

        QAction * d0 = new QAction(QIcon(":/Tools Icons/duplication duplicate.svg"),QString("Duplicate Model: SHIFT + D"),this);
        QAction * d1 = new QAction(QIcon(":/Tools Icons/duplication duplicate linked.svg"),QString("Duplicate Linked: CTRL + D"),this);
        QAction * d2 = new QAction(QIcon(":/Tools Icons/duplication delete.svg"),QString("Delete: DELETE"),this);

        //d0->setParent(parentWidget->parent());

        d0->setCheckable(true);d0->setShortcut(Qt::SHIFT|Qt::Key_D);
        d1->setCheckable(true);d1->setShortcut(Qt::CTRL|Qt::Key_D);
        d2->setCheckable(true);d2->setShortcut(Qt::Key_Delete);

        connect(d0, SIGNAL(triggered(bool)), this, SLOT(duplicateSelectedModel()));
        connect(d1, SIGNAL(triggered(bool)), this, SLOT(duplicateSelectedModelReference()));
        connect(d2, SIGNAL(triggered(bool)), this, SLOT(deleteModel()));

        duplicationActions =  new QActionGroup(this);

        duplicationActions->addAction(d0);
        duplicationActions->addAction(d1);
        duplicationActions->addAction(d2);

        duplicationActions->setExclusive(true);


        mainToolBar->addActions(axesTransformer->handlesActions->actions());
        mainToolBar->addSeparator();

        mainToolBar->addActions(duplicationActions->actions());
        mainToolBar->addSeparator();

        lowerToolBar->addActions(pselectTools->toolsActiongroups->actions());
        lowerToolBar->addSeparator();

        lowerToolBar->addActions(pentools->toolsActiongroups->actions());
        lowerToolBar->addSeparator();


        QAction * a0  = new QAction(QIcon(":/Tools Icons/mesh cylinder.svg"),QString("Add Cylinder: SHIFT + 0"),this);
        QAction * a1  = new QAction(QIcon(":/Tools Icons/mesh camera.svg"),QString("Add Camera: SHIFT + 1"),this);
        QAction * a2  = new QAction(QIcon(":/Tools Icons/mesh particles.svg"),QString("Add Particles: SHIFT + 2"),this);
        QAction * a3  = new QAction(QIcon(":/Tools Icons/mesh light.svg"),QString("Add Light: SHIFT + 3"),this);
        QAction * a4  = new QAction(QIcon(":/Tools Icons/mesh cone.svg"),QString("Add Cone: SHIFT + 4"),this);
        QAction * a5  = new QAction(QIcon(":/Tools Icons/mesh grid.svg"),QString("Add Grid: SHIFT + 5"),this);
        QAction * a6  = new QAction(QIcon(":/Tools Icons/mesh plane.svg"),QString("Add Plane: SHIFT + 6"),this);
        QAction * a7  = new QAction(QIcon(":/Tools Icons/mesh sphere.svg"),QString("Add Sphere: SHIFT + 7"),this);
        QAction * a8  = new QAction(QIcon(":/Tools Icons/mesh torus.svg"),QString("Add Torus: SHIFT + 8"),this);
        QAction * a9  = new QAction(QIcon(":/Tools Icons/mesh box.svg"),QString("Add Box: SHIFT + 9"),this);
        QAction * a10 = new QAction(QIcon(":/Tools Icons/mesh terrain.svg"),QString("Add Terrain: CTRL + T"),this);
        QAction * a11 = new QAction(QIcon(":/Tools Icons/mesh import.svg"),QString("Import Mesh: SHIFT + I"),this);
        QAction * a12 = new QAction(QIcon(":/Tools Icons/mesh svg.svg"),QString("Import SVG: SHIFT + W"),this);
        QAction * a13 = new QAction(QIcon(":/Tools Icons/mesh location.svg"),QString("Add Location: SHIFT + L"),this);
        QAction * a14 = new QAction(QIcon(":/Tools Icons/mesh box rounded.svg"),QString("Add Rounded Box: SHIFT + 10"),this);
        QAction * a15 = new QAction(QIcon(":/Tools Icons/mesh pie.svg"),QString("Add Pie: SHIFT + 10"),this);
        QAction * a16 =  new QAction(QIcon(":/Tools Icons/convert mesh.svg"),QString("Convert Model: SHIFT + C"),this);

        QAction * a17 =  new QAction(QIcon(":/Tools Icons/explode model.svg"),QString("Explode Model: SHIFT + E"),this);

        a0->setCheckable(true);a0->setShortcut(Qt::SHIFT|Qt::Key_1);
        a1->setCheckable(true);a1->setShortcut(Qt::SHIFT|Qt::Key_1);
        a2->setCheckable(true);a2->setShortcut(Qt::SHIFT|Qt::Key_2);
        a3->setCheckable(true);a3->setShortcut(Qt::SHIFT|Qt::Key_3);
        a4->setCheckable(true);a4->setShortcut(Qt::SHIFT|Qt::Key_4);
        a5->setCheckable(true);a5->setShortcut(Qt::SHIFT|Qt::Key_5);
        a6->setCheckable(true);a6->setShortcut(Qt::SHIFT|Qt::Key_6);
        a7->setCheckable(true);a7->setShortcut(Qt::SHIFT|Qt::Key_7);
        a8->setCheckable(true);a8->setShortcut(Qt::SHIFT|Qt::Key_8);
        a9->setCheckable(true);a9->setShortcut(Qt::SHIFT|Qt::Key_9);
        a10->setCheckable(true);a10->setShortcut(Qt::CTRL|Qt::Key_T);
        a11->setCheckable(true);a11->setShortcut(Qt::SHIFT|Qt::Key_I);
        a12->setCheckable(true);a12->setShortcut(Qt::SHIFT|Qt::Key_W);
        a13->setCheckable(true);a13->setShortcut(Qt::SHIFT|Qt::Key_L);

        a14->setCheckable(true);a14->setShortcut(Qt::SHIFT|Qt::Key_0);

        a15->setCheckable(true);a15->setShortcut(Qt::SHIFT|Qt::Key_0);
        a16->setCheckable(true);a16->setShortcut(Qt::SHIFT|Qt::Key_C);

        a17->setCheckable(true);a17->setShortcut(Qt::SHIFT|Qt::Key_E);


        connect(a0, SIGNAL(triggered(bool)), this, SLOT(addCylinderModel()));
        connect(a1, SIGNAL(triggered(bool)), this, SLOT(addCameraFreeModel()));
        connect(a2, SIGNAL(triggered(bool)), this, SLOT(addParticlesModel()));
        connect(a3, SIGNAL(triggered(bool)), this, SLOT(addLightModel()));
        connect(a4, SIGNAL(triggered(bool)), this, SLOT(addConeModel()));
        connect(a5, SIGNAL(triggered(bool)), this, SLOT(addPlaneModel()));
        connect(a6, SIGNAL(triggered(bool)), this, SLOT(addQuadModel()));
        connect(a7, SIGNAL(triggered(bool)), this, SLOT(addSphereModel()));
        connect(a8, SIGNAL(triggered(bool)), this, SLOT(addTorusModel()));
        connect(a9, SIGNAL(triggered(bool)), this, SLOT(addCubeModel()));
        connect(a10, SIGNAL(triggered(bool)), this, SLOT(addTerrainModel()));
        connect(a11, SIGNAL(triggered(bool)), this, SLOT(addMeshModel()));
        connect(a12, SIGNAL(triggered(bool)), this, SLOT(addSVGMeshModel()));
        connect(a13, SIGNAL(triggered(bool)), this, SLOT(addLocationModel()));
        connect(a14, SIGNAL(triggered(bool)), this, SLOT(addRoundedCubeModel()));
        connect(a15, SIGNAL(triggered(bool)), this, SLOT(addPieModel()));
        connect(a16, SIGNAL(triggered(bool)), this, SLOT(convertToMesh()));
        connect(a17, SIGNAL(triggered(bool)), this, SLOT(expodeModel()));

        addmodelsActionGroups =  new QActionGroup(this);

        addmodelsActionGroups->addAction(a1);
        addmodelsActionGroups->addAction(a2);
        addmodelsActionGroups->addAction(a3);
        addmodelsActionGroups->addAction(a4);
        addmodelsActionGroups->addAction(a15);
        addmodelsActionGroups->addAction(a5);
        addmodelsActionGroups->addAction(a6);
        addmodelsActionGroups->addAction(a7);
        addmodelsActionGroups->addAction(a8);
        addmodelsActionGroups->addAction(a9);
        addmodelsActionGroups->addAction(a14);
        addmodelsActionGroups->addAction(a0);
        addmodelsActionGroups->addAction(a10);
        addmodelsActionGroups->addAction(a11);
        addmodelsActionGroups->addAction(a12);
        addmodelsActionGroups->addAction(a13);
        addmodelsActionGroups->addAction(a16);
        addmodelsActionGroups->addAction(a17);

        addmodelsActionGroups->setExclusive(true);

        //-----------------------------------------------

        QAction * p0 = new QAction(QIcon(":/Tools Icons/icon parent.svg"),QString("Parent Models: P"),this);
        QAction * p1 = new QAction(QIcon(":/Tools Icons/icon unparent.svg"),QString("Un Parent Models: SHIFT + P"),this);
        QAction * p2 = new QAction(QIcon(":/Tools Icons/icon centerto.svg"),QString("Center To Model: SHIFT + F"),this);

        p0->setCheckable(true);p0->setShortcut(Qt::Key_P);
        p1->setCheckable(true);p1->setShortcut(Qt::SHIFT|Qt::Key_P);
        p2->setCheckable(true);p1->setShortcut(Qt::SHIFT|Qt::Key_F);

        connect(p0, SIGNAL(triggered(bool)), this, SLOT(parentModels()));
        connect(p1, SIGNAL(triggered(bool)), this, SLOT(unparentModels()));
        connect(p2, SIGNAL(triggered(bool)), this, SLOT(centerToModel()));

        parentingActions =  new QActionGroup(this);

        parentingActions->addAction(p0);
        parentingActions->addAction(p1);
        parentingActions->addAction(p2);

        parentingActions->setExclusive(true);

        modelsToolBar->addActions(addmodelsActionGroups->actions());
        modelsToolBar->addSeparator();

        modelsToolBar->addActions(parentingActions->actions());
        modelsToolBar->addSeparator();

        //modelsToolBar->addActions(psoundTools->audioActiongroups->actions());
        //modelsToolBar->addSeparator();

    }

    void createContextMenues()
    {
        modelsList.append(QString("Mesh"));
        modelsList.append(QString("Plane"));
        modelsList.append(QString("Sphere"));
        modelsList.append(QString("Quad"));
        modelsList.append(QString("Cylinder"));
        modelsList.append(QString("Cone"));
        modelsList.append(QString("Torus"));
        modelsList.append(QString("Cube"));
        //modelsList.append(QString("Ivy"));
        modelsList.append(QString("Light"));
        modelsList.append(QString("Camera"));
        modelsList.append(QString("Particles"));
        modelsList.append(QString("Terrain"));
        modelsList.append(QString("Pie"));
        modelsList.append(QString("Rounded Cube"));

        modelsList.sort();

        addModelsMenu.setTitle(QString("Add Model"));
        addModelsMenu.setIcon(icon);

        foreach(QString nodename , modelsList)
        {
            allnodes.append(nodename);
        }

        addModelsMenues();

        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           addModelsMenu.setStyleSheet(style);

           mainContextmenu.setStyleSheet(style);
        }

        //mainContextmenu.setParent(this);
        mainContextmenu.addMenu(&addModelsMenu);
        mainContextmenu.addMenu(&axesTransformer->transformsAxisMenu);
        mainContextmenu.addMenu(&axesTransformer->transformMenu);

        mainContextmenu.hide();
    }

    void createSearchCommands()
    {
        foreach(QAction * action,duplicationActions->actions())
        {
            //commands->addAction(action);

            commands->commandActions.append(action);
        }

        foreach(QAction * action,addmodelsActionGroups->actions())
        {
            //commands->addAction(action);
            commands->commandActions.append(action);
        }
        foreach(QAction * action,parentingActions->actions())
        {
            //commands->addAction(action);
            commands->commandActions.append(action);
        }
        foreach(QAction * action,axesTransformer->handlesActions->actions())
        {
            //commands->addAction(action);
            commands->commandActions.append(action);
        }

        //commands->addActions(duplicationActions->actions());
        //commands->addActions(addmodelsActionGroups->actions());
        //commands->addActions(parentingActions->actions());
        //commands->addActions(axesTransformer->handlesActions->actions());



        if(commands->commandActions.size()>=0)
        {
            QStringList commandList;

            foreach(QAction * action,commands->commandActions)
            {
                commandList.append(action->text());

                qDebug()<<action->text();
            }

            commands->nodeslists =  commandList;

            commands->setModels(commandList);
        }

        commands->hide();
    }


    QProgressBar * progressbar;

    void loadTextures()
    {
        QIcon _icon(":/Tools Icons/icon center.svg");
        QImage image = _icon.pixmap(50,50).toImage();
        image.convertToFormat(QImage::Format_ARGB32);
        image.save("D:/Metropolis/icon_image.png");


        _texture = parentWidget->bindTexture(image, GL_TEXTURE_2D);

        // _texture = parentWidget->bindTexture(QPixmap(QString(imagename), GL_TEXTURE_2D);

        textures.append(_texture);
    }



    //QLambertMaterial * defualtLambertMaterial;

    QSceneGraph(QGLWidget * widget =0,QObject *parent =0):QObject(parent)
    {
        //defualtLambertMaterial = new QLambertMaterial;
        progressbar = new QProgressBar;

        progressbar->hide();

        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        parentWidget     =  widget;

        floorParameters  = new FloorGridParameters(this);

        propertiesEditor = new QMainWindow;

        //floorParameters->getWidget()->show();

        propertiesEditor->setCentralWidget(floorParameters->getWidget());


        selectionInfo    = new QSelectionInfo;        
        axesTransformer  = new GizimoAxesTransformer(selectionInfo,parentWidget,this);

        //psoundTools      = new SoundTools(this);
        pentools         = new penTools(this);
        pselectTools     = new selectionTools(this);

        rootModel        = new QRootModel;

        rootModel->parent = 0;


        QCameraTargetModel * defaultCamera = new QCameraTargetModel;


        defaultCamera->resetCameraToHome();

        defaultCamera->setParentModel(rootModel);

        rootModel->children.append(defaultCamera);

        models.append(rootModel);
        models.append(defaultCamera);
        cameras.append(defaultCamera);




        createToolBarsAndActions();
        createContextMenues();

        //parametersToolBar->swapWidget( floorParameters->getWidget());

        //parametersToolBar->hide();

        timeline = new TimeLineWidgetEx;

        isSelectbyColor  = true;
        useDefaultLights = true;

        commands = new QSearchCommands;

        createSearchCommands();

        currentCameraIndex = 0;

        dragselection = new QMouseDragSelection;

        //loadTextures();
    }

    ~ QSceneGraph()
    {
        //delete psoundTools;
        delete pentools;
        delete pselectTools;

        delete selectionInfo;
        delete axesTransformer;
        delete modelsToolBar;
        //delete parametersToolBar;

        delete rootModel;

        qDeleteAll(models);
        //qDeleteAll(cameras);

        //qDeleteAll(groups);
    }

    void qMultMatrix(const QMatrix4x4 &mat)
    {

        if (sizeof(qreal) == sizeof(GLfloat))
            glMultMatrixf((GLfloat*)mat.constData());



    #ifndef QT_OPENGL_ES
        else if (sizeof(qreal) == sizeof(GLdouble))
            glMultMatrixd((GLdouble*)mat.constData());
    #endif

        else


        {
            GLfloat fmat[16];

            const float*r = mat.constData();

            for (int i = 0; i < 16; ++i)
            {
                fmat[i] = r[i];
            }

            glMultMatrixf(fmat);
        }


    }

    void drawGrid(QMatrix4x4 PV)
    {
        glPushMatrix();

        QMatrix4x4 PVM   = PV;

        qMultMatrix(PVM);


        float divisions = floorParameters->divisions;
        float step      = floorParameters->step;

        float scale     = divisions * step;
        float halfscale =  0.5 * scale;

        if(floorParameters->showGrid ==true)
        {
            //glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glColor4f(.3f,.3f,.3f,.2f );

            glLineWidth(2);

            float x1 =  divisions * step  * 0.5;
            float y1 =  0;
            float z1 =  0;

            float x2 =  divisions * step  * -0.5;
            float y2 =  0;
            float z2 =  0;

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            //glColor4f(1.0f,0.0f,1.0f,0.2f);

            glColor4f( 1, 0, 0,1.0f  );

            glBegin( GL_LINES );
            glVertex3f(x1, y1, z1);
            glVertex3f(x2, y2, z2);
            glEnd( );

            //QVector3D p = getWorldToScreenCoordinate(QVector3D(x1,y1,z1));

            //parentWidget->renderText(x1,y1,z1,QString("X-axis"));
            //QToolTip::showText(QPoint(p.x(),p.y()),QString("Z-axis"),parentWidget,QRect(QPoint(p.x(),p.y()),QSize(100,120)));



            x1 =  0;
            y1 =  0;
            z1 =  divisions * step  * 0.5;

            x2 =  0;
            y2 =  0;
            z2 =  divisions * step  * -0.5;


            glColor4f( 0, 0, 1 ,1.0f );
            glBegin( GL_LINES );
            glVertex3f(x1, y1, z1);
            glVertex3f(x2, y2, z2);
            glEnd( );

            //parentWidget->renderText(x1,y1,z1,QString("Z-axis"));

            glPushMatrix( );
            glTranslatef(-halfscale,0,-halfscale);
            glLineWidth(1);
            glColor4f( .1, .1, .1,.2f  );
            glBegin( GL_LINES );

            for (float i=0;i<divisions+1;i+= 1)
            {
                float x =  i * step;
                float y =  0;
                float z =  0;

                glVertex3f( x, y,  z  );

                x =  i * step;
                y =  0;
                z =  divisions * step;

                glVertex3f( x, y, z  );
            }

            for (float i=0;i<divisions+1;i+= 1)
            {
                float x =  0;
                float y =  0;
                float z =  i * step;


                glVertex3f( x, y,  z  );

                x =  divisions * step;
                y =  0;
                z =  i * step;

                glVertex3f( x, y, z  );
            }


            glEnd( );

            glDisable(GL_BLEND);

            glPopMatrix( );

            //glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);

        }

        glPopMatrix();
    }
    void drawModels(QMatrix4x4 PV)
    {
        //draw outline selected models
       if(selectionInfo->size()>0)
       {
           foreach(QBaseModel * m,selectionInfo->getSelectedModels())
           {
               m->visibilityParameters->stencilOnlyParameters();
               m->drawModel(PV);
               m->visibilityParameters->resetParameters();
           }
       }

       //draw omodels

       for(int i =0;i<models.size();i++)
       {
          models[i]->drawModel(PV);
       }
    }

    void drawAxis(QMatrix4x4 PV)
    {
        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        float x = 0,y =0;

        glDisable(GL_LIGHTING);
        glPushMatrix();
        glPushAttrib(GL_SCISSOR_BIT);
        glViewport(x, y, 100,100);
        glScissor(x, y, 100, 100);
        glEnable(GL_SCISSOR_TEST);

        glClear(GL_DEPTH_BUFFER_BIT);

        QVector3D dir = activeCamera->position - activeCamera->target;
        dir.normalize();
        QVector3D pos =  dir * 5.0f;

        QMatrix4x4 projectMat;
        projectMat.setToIdentity();
        projectMat.perspective(activeCamera->fov, 1.0f, 0.1f, 50.0f);

        QMatrix4x4 view;
        view.setToIdentity();
        view.lookAt(pos,QVector3D(0,0,0),activeCamera->up);//,QVector3D(0.0, 1.0, 0.0));

        QMatrix4x4 modelM;
        modelM.setToIdentity();
        modelM.translate(QVector3D(0,0,0));

        QMatrix4x4 scaleMat;
        scaleMat.setToIdentity();
        scaleMat.scale(2.5f,2.5f,2.5f);

        QMatrix4x4 mm = projectMat * view  * modelM *scaleMat;

        qMultMatrix(mm);

        //glColor3f(1.0f, 0.0f, 0.0f);
        //glEnable( GL_LINE_SMOOTH );
        glLineWidth( 1.5 );


        //glColor3ub(255,255,0);
        //glLineWidth(2.0f);
        const float len = 0.5f;

        QVector3D axesOrigin(0.0f,0.0f,0.0f);

        glBegin(GL_LINES);
        glColor3f(1.0f,0.0f,0.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x() + len,axesOrigin.y(),axesOrigin.z());

        glColor3f(0.0f,1.0f,0.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x(),axesOrigin.y() + len,axesOrigin.z());

        glColor3f(0.0f,0.0f,1.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z() + len);
        glEnd();

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        float offset = .05f;

        glColor3f(1.0f,0.0f,0.0f);
        parentWidget->renderText(axesOrigin.x() + len+offset,axesOrigin.y(),axesOrigin.z(),QString("X"),font);
        glColor3f(0.0f,1.0f,0.0f);
        parentWidget->renderText(axesOrigin.x(),axesOrigin.y() + len+offset,axesOrigin.z(),QString("Y"),font);
        glColor3f(0.0f,0.0f,1.0f);
        parentWidget->renderText(axesOrigin.x(),axesOrigin.y(),axesOrigin.z() + len+offset,QString("Z"),font);


        glDisable(GL_SCISSOR_TEST);
        glPopAttrib();

        glPopMatrix();

        glEnable(GL_LIGHTING);

        glViewport(0,0,activeCamera->viewRect.width(),activeCamera->viewRect.height());
    }


    void drawCompass(QMatrix4x4 PV)
    {
        glEnable(GL_DEPTH_TEST);

        glDisable(GL_LIGHTING);

        glPushMatrix();

        QMatrix4x4 PVM   = PV;

        qMultMatrix(PVM);


        //QPainterPath path;
        //path.addText(QPoint(0,0),QFont(),QString("N"));
        //QColor color = hexToRGB(svgshape.style.stroke);
        QColor scolor = QColor(Qt::darkGreen);
        //qDebug()<<"Color:"<<color;

        glColor3f( scolor.redF(), scolor.greenF(), scolor.blueF());

        glLineWidth(2);
        glBegin(GL_LINE_LOOP);

        float radius = 0.3f;

        for(int i=0;i<36;i++)
        {
            float x = radius*cos(i/36.0 * 2*PI);
            float z = radius*sin(i/36.0 * 2*PI);

            glVertex3f(x,0,z);
        }
        glEnd();


        scolor = QColor(Qt::black);


        glColor4f( scolor.redF(), scolor.greenF(), scolor.blueF(),0.4f);


        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        //glColor4f(1.0f,0.0f,1.0f,0.2f);

       // glColor4f( 1, 0, 0,1.0f  );

        glBegin(GL_POLYGON);

        radius = 0.2f;

        for(int i=0;i<36;i++)
        {
            float x = radius*cos(i/36.0 * 2*PI);
            float z = radius*sin(i/36.0 * 2*PI);

            glVertex3f(x,0,z);
        }
        glEnd();

        float offset = 0.3f;

        glBegin(GL_TRIANGLES);
        glVertex3f(-0.2,0,0.8-offset);
        glVertex3f(0,0   ,1.0-offset);
        glVertex3f(0.2,0 ,0.8-offset);
        glEnd();

        glBegin(GL_TRIANGLES);
        glVertex3f(0.8-offset,0,-0.2);
        glVertex3f(1.0-offset,0,0.0);
        glVertex3f(0.8-offset,0,0.2);
        glEnd();

         glDisable(GL_BLEND);



        glLineWidth(1);

        glBegin(GL_LINE_LOOP);
            glVertex3f(0,0,1);
            glVertex3f(0,0,-1);
        glEnd();

        glBegin(GL_LINE_LOOP);
            glVertex3f(1,0,0);
            glVertex3f(-1,0,0);
        glEnd();

        glPopMatrix();

        QFont font;
        font.setFamily("Times");
        font.setBold(true);
        font.setPointSize(15);

        QVector3D N( 0,0,1);
        QVector3D S( 0,0,-1);
        QVector3D E( 1,0,0);
        QVector3D W(-1,0,0);

        N = PV * N;
        S = PV * S;
        E = PV * E;
        W = PV * W;

        scolor = QColor(Qt::black);
        //qDebug()<<"Color:"<<color;

        glColor3f( scolor.redF(), scolor.greenF(), scolor.blueF());

        parentWidget->renderText(E.x(),E.y(),E.z(),QString("E"),font);
        parentWidget->renderText(W.x(),W.y(),W.z(),QString("W"),font);
        parentWidget->renderText(N.x(),N.y(),N.z(),QString("N"),font);
        parentWidget->renderText(S.x(),S.y(),S.z(),QString("S"),font);

        glDisable(GL_DEPTH_TEST);

        glEnable(GL_LIGHTING);
    }


    void drawToolTip(QString tipstr,QPoint p = QCursor::pos())
    {
        if(tipstr.size()==0)
        {
            tipstr = QString("<b>QToolTip</b> Example:\n"
                    "Create N points on a sphere\n "
                    "aproximately equi-distant from each other\n"
                    "Basically, N points are randomly\n "
                    "placed on the sphere and then moved\n"
                    "around until then moved around \n"
                    "until the minimal distance between the\n"
                    "closed two points is minimaised.\n");
        }

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);


        if(QRect(QPoint(0,0),activeCamera->viewRect.size().toSize()).contains(p,true))
        {
            QToolTip::showText(p,tipstr,parentWidget,QRect(p,QSize(100,120)));
        }
    }


    void drawStatics(QMatrix4x4 PV,QString statistics)
    {

        glPushMatrix();

        QMatrix4x4 PVM   = PV;

        qMultMatrix(PVM);

        QRect  r = parentWidget->rect();

        parentWidget->renderText(100,100,statistics);

        glPopMatrix();
    }

    virtual void drawStatistics(QString statistics)
    {
        float s = .60f;

        QPointF p = QPointF(-1.0 * s, -1.0*s );

        /*


        glVertex2f(-1.0 * s, -1.0*s );
        glVertex2f(1.0 * s, -1.0 *s);
        glVertex2f(1.0 * s, 1.0 *s);
        glVertex2f(-1.0 *s, 1.0 *s);
        */



        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_CULL_FACE);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);

        parentWidget->renderText(0,100,statistics);

        glPopAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }


    /*

    float getScreenFactor(QCameraModel * model)
    {
        QMatrix4x4 viewproj = model->viewProjectionMatrix;

        QVector3D c = m_pMatrix * QVector3D(0,0,0);

        QVector4D trf = c.toVector4D();

        trf = viewproj * trf ;

        float mDisplayScale  =  1.0f;

        float m_ScreenFactor = mDisplayScale * 0.15f * trf.w();

        return m_ScreenFactor;
    }
    */

    virtual void drawGLSLScene()
    {

    }

    virtual void enableDefaultLights(QMatrix4x4 PV)
    {
        if(drawMode)
            glShadeModel(GL_SMOOTH); // Enable Smooth Shading
        else
            glShadeModel(GL_FLAT);   // Enable Smooth Shading

        /*

        glClearDepth(1.0f);          // Depth Buffer Setup
        glClearStencil(0);           // Stencil Buffer Setup
        glEnable(GL_DEPTH_TEST);     // Enables Depth Testing


        float m_lightPos[4] = { -4.0f, 0.0f , -9.0f, 1.0f};// Light Position
        float m_lightAmb[4] = { 0.00f, 0.00f, 0.00f, 1.0f};// Ambient Light Values
        float m_lightDif[4] = { 0.05f, 0.05f, 0.05f, 1.0f};// Diffuse Light Values
        float m_lightSpc[4] = { 0.0f , 0.0f , 0.0f , 1.0f};// Specular Light Values

        float m_matAmb[4]   = {0.00f, 0.00f,0.00f, 1.0f};// Material - Ambient Values
        float m_matDif[4]   = {0.05f, 0.05f, 0.05f, 1.0f};// Material - Diffuse Values
        float m_matSpc[4]   = {0.0f, 0.0f, 0.0f, 1.0f};// Material - Specular Values
        float m_matShn[1]   = {0.0f};// Material - Shininess

        glLightfv(GL_LIGHT1, GL_POSITION, m_lightPos);// Set Light1 Position
        glLightfv(GL_LIGHT1, GL_AMBIENT,  m_lightAmb);// Set Light1 Ambience
        glLightfv(GL_LIGHT1, GL_DIFFUSE,  m_lightDif);// Set Light1 Diffuse
        glLightfv(GL_LIGHT1, GL_SPECULAR, m_lightSpc);// Set Light1 Specular

        glEnable(GL_LIGHT1);// Enable Light1
        glEnable(GL_LIGHTING);// Enable Lighting

        glMaterialfv(GL_FRONT, GL_AMBIENT,   m_matAmb);// Set Material Ambience
        glMaterialfv(GL_FRONT, GL_DIFFUSE,   m_matDif);// Set Material Diffuse
        glMaterialfv(GL_FRONT, GL_SPECULAR,  m_matSpc);// Set Material Specular
        glMaterialfv(GL_FRONT, GL_SHININESS, m_matShn);// Set Material Shininess

        //glCullFace(GL_BACK);// Set Culling Face To Back Face
        //glEnable(GL_CULL_FACE);// Enable Culling

        */

        glClearDepth(1.0f);          // Depth Buffer Setup
        glClearStencil(0);           // Stencil Buffer Setup


        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
        glShadeModel(GL_SMOOTH);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);

        //QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);


        //QVector3D lightPosition = activeCamera->getPosition();//  + ( activeCamera->getPosition() - activeCamera->getTarget() );

        //float lightpos[4] = {lightPosition.x(),lightPosition.y(),lightPosition.z(),1.0};

        //glLightfv( GL_LIGHT0, GL_POSITION, lightpos );




        static GLfloat lightPosition[4] = { 0.5, 5.0, 7.0, 1.0 };

        glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );


        glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 2.0);
        glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 1.0);
        glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.5);

        glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_FALSE);
        glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

        bool defaultMaterial = true;

        QColor c(Qt::gray);

        float faceColor[4];

        faceColor[0] = c.redF();
        faceColor[1] = c.greenF();
        faceColor[2] = c.blueF();
        faceColor[3] = c.alphaF();

        //faceColor[0] = 0.1;
        //faceColor[1] = 0.1;
        //faceColor[2] = 0.1;
        //faceColor[3] = 1.0;

        if(defaultMaterial)
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, faceColor);
    }

    virtual void disableDefaultLights()
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glShadeModel(GL_SMOOTH);
        glDisable(GL_LIGHTING);
        glDisable(GL_LIGHT0);

        //glDisable(GL_LIGHT1);

    }

    bool drawMode = true;


    void nextDrawMode(QKeyEvent *event)
    {
        if(event->key() == Qt::Key_D)
        {
            if(drawMode)
            {
                drawMode = false;
            }
            else
            {
                drawMode  = true;
            }
        }
    }




    virtual void drawScene()
    {
        if(floorParameters->enableMultisample ==true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glEnable(GL_MULTISAMPLE);
        }

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        glViewport (0, 0, (GLsizei) activeCamera->viewRect.width(), (GLsizei) activeCamera->viewRect.height());

        QColor m_backgroundColor = floorParameters->getColor();

        //glClearColor(m_backgroundColor.redF(),m_backgroundColor.greenF(),m_backgroundColor.blueF(),m_backgroundColor.alphaF());

        glClearColor(199.0/255.0,199.0/255.0,199.0/255.0,1.0f);

        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

        QMatrix4x4 PV = activeCamera->getProjectionViewMatrix();

        drawGrid(PV);

        drawCompass(PV);

        if(useDefaultLights)
        {
            /*
            QVector3D lightVector =  activeCamera->getPosition() - activeCamera->getTarget() ;

            QVector3D lightPosition = activeCamera->getPosition()  + lightVector;

            defualtLambertMaterial->bind();

            defualtLambertMaterial->setShaderParamters(activeCamera->getProjectionMatrix(),
                                                       activeCamera->getViewMatrix(),
                                                  activeCamera->getNormalMatrix(),
                                                       lightPosition,
                                                       //lightVector,
                                                       0.01,3);

            */

            enableDefaultLights(PV);
        }

        drawModels(PV);

        if(useDefaultLights)
        {
            //defualtLambertMaterial->release();
            disableDefaultLights();
        }

        if(selectionInfo->size()>0)
        {
            axesTransformer->setPVmatrix(PV);
            axesTransformer->drawGizmo();
        }

        if(floorParameters->showAxis == true)
        {
            drawAxis(PV);
        }

        //dragselection->drawSelectionCircle(parentWidget);

        //dragselection->drawSelectionRectangle(parentWidget);

        activeCamera->drawSafeTitleRectangle(parentWidget);

        activeCamera->drawSafeActionRectangle(parentWidget);

        //drawStatistics(activeCamera->getViewName());

        drawStatics(PV,activeCamera->getViewName());

        if(floorParameters->enableMultisample == true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glDisable(GL_MULTISAMPLE);
        }
    }

    virtual void drawFlatColorFrame()
    {
        if(floorParameters->enableMultisample ==true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glEnable(GL_MULTISAMPLE);
        }

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        //glViewport (0, 0, (GLsizei) activeCamera->viewRect.width(), (GLsizei) activeCamera->viewRect.height());

        QColor m_backgroundColor = floorParameters->getColor();

        glClearColor(m_backgroundColor.redF(),m_backgroundColor.greenF(),m_backgroundColor.blueF(),m_backgroundColor.alphaF());

        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

        //uncomment this
        //camera->orbitView();


        QMatrix4x4 PV = activeCamera->getProjectionViewMatrix();

        drawGrid(PV);

        //drawGrid();

        for(int i =0;i<models.size();i++)
        {
            if(models[i]->type()==MODEL_LOCATION)
            {
                models[i]->drawModel(PV,true);
            }
            if(models[i]->type()==MODEL_GROUP)
            {
                models[i]->drawModel(PV,true);
            }
            if(models[i]->type()==MODEL_ROOTMODEL)
            {
                models[i]->drawModel(PV,true);
            }
            else
            {
                models[i]->visibilityParameters->setSilhueottelParameters();
                models[i]->drawModel(PV,true);
                models[i]->visibilityParameters->resetParameters();
            }
        }

        if(floorParameters->showAxis ==true)
        {
            //drawAxis();
        }

        if(floorParameters->enableMultisample ==true)
        {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
            glDisable(GL_MULTISAMPLE);
        }
    }

    virtual void drawDepthPass(){}

    virtual void drawSSAO(){}


public:

    void selectByColor()
    {
        drawFlatColorFrame();

        QPoint  p = QCursor::pos();

        p = parentWidget->mapFromGlobal(QCursor::pos());

        QImage image = parentWidget->grabFrameBuffer(false);

        image.save("D:/Metropolis/frameBuffer.png");

        QRgb c = image.pixel(p.x(),p.y());

        QColor hitColor(c);

        bool foundModel= false;


        for(int i=0;i<models.size();i++)
        {
            if(models[i]->colorId.redF()   == hitColor.redF()&&
               models[i]->colorId.greenF() == hitColor.greenF()&&
               models[i]->colorId.blueF()  == hitColor.blueF()
               )
            {

                foundModel = true;

                selectionInfo->addSelectedModel(models[i]);

                //emit modelSelectionChanged();

                //break;
            }
        }

        if(!foundModel)
        {
            selectionInfo->clearSelection();            
        }
    }

    void selectByRayCasting()
    {
        bool Cselected = false;

        QPoint  p = QCursor::pos();

        p = parentWidget->mapFromGlobal(QCursor::pos());

        //QRay ray;

        //ray.rayCastScene(p.x(),p.y());

        QRay3D ray;
        ray.rayCastScene(p.x(),p.y());

        if( models.size()>0 )
        {
            for(int i =0;i<models.size();i++)
            {
                QBox3D box    =  models[i]->boundingAabbox;

                QVector3D v  =  models[i]->position;

                QVector3D r  =  models[i]->rotation;

                QMatrix4x4 mat;
                mat.setToIdentity();
                mat.translate(v);
                mat.rotate(r.x(),QVector3D(1,0,0));
                mat.rotate(r.y(),QVector3D(0,1,0));
                mat.rotate(r.z(),QVector3D(0,0,1));

                box.transform(mat);

                //QVector3D s  =  models[i]->scale;

                //box.reScale(1.0f);

                //box.translate(v);

                //box.rotate(r);

                //QRay3D nray;

                //nray.setOrigin(ray.p0);
                //nray.setDirection(ray.direction);

                //if(box.intersectRay(ray.p0,ray.direction))
                if(box.intersects(ray))
                {
                    selectionInfo->addSelectedModel(models[i]);

                    Cselected  = true;

                    //setProperties();

                    break;
                }
            }
        }

        if(!Cselected)
        {
            selectionInfo->clearSelection();
        }
        else
        {

        }

        /*
        QRay colorRay;

        qDebug()<<"QColor:"<<colorRay.getColorAtPixel(p.x(),p.y());

        QRay posRay;

        qDebug()<<"Pos:"<<posRay.get3DPositionAtPixel(p.x(),p.y());
        */

    }

    void raySelectModel()
    {
        if(parentWidget)
        {
            if(isSelectbyColor)
            {
                selectByColor();

                //setCurrentModeParameters();

                //showHideProperties();
            }
            else
            {
                selectByRayCasting();
            }
        }


    }


    virtual void processAddModelMenu(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::ShiftModifier &&  event->key()==Qt::Key_A)
        {
            qDebug()<<"Main menu";

            QPoint p = QCursor::pos();

            //p += QPoint(-50,-10);

            mainContextmenu.move(p);

            mainContextmenu.show();

            QAction *selectedAction = mainContextmenu.exec();

            if ( selectedAction != 0)
            {
               //if(_debug)
               //printf("Clicked Action:\n");
               qDebug()<<"Clicked Action:\n"<<selectedAction->text();

               //allnodes.indexOf(selectedAction->text())

               addModel(selectedAction->text());

               printf(qPrintable(selectedAction->text()));

            }
        }
    }

    virtual void deleteSelectedModel(QKeyEvent * event)
    {
        //if(event->key()== Qt::Key_Backspace)
        if(event->key()== Qt::Key_Delete)
        {
            deleteModel();
        }
    }

    virtual void duplicateSelelctedModel(QKeyEvent * event)
    {
        if(event->modifiers() & Qt::ShiftModifier &&   event->key() == Qt::Key_D)
        {
            duplicateSelectedModel();
        }
    }

    virtual void selectModel(QMouseEvent *event)
    {
        if(event->modifiers() & Qt::CTRL && event->buttons() & Qt::LeftButton  )//&& event->modifiers() & Qt::ControlModifier )
        //if(event->buttons() & Qt::LeftButton  )//&& event->modifiers() & Qt::ControlModifier )
        {
            if(!axesTransformer->handlesActions->actions()[0]->isChecked())
            {
                raySelectModel();
            }
        }
    }

    virtual void selectModel(QKeyEvent * event)
    {
        if(event->key()== Qt::Key_G)
        {
            if(!axesTransformer->handlesActions->actions()[0]->isChecked())
            {
                raySelectModel();
            }

            qDebug()<<"Grabbing";
        }
        else if(event->modifiers()&Qt::CTRL && event->key()== Qt::Key_A)
        {
            selectionInfo->addModels(models);
        }
    }

    /*

    virtual void setPerspectiveMode(QKeyEvent * event)
    {
        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        if(event->key()==Qt::Key_P)
        {
            activeCamera->cameraViewMode = QCameraTargetModel::PERSPECTIVE;

            printf("Perspective projection \n");
        }

        if(event->key()==Qt::Key_O)
        {
           activeCamera->cameraViewMode= QCameraTargetModel::ORTHO;

            printf("Ortho projection \n");
        }

    }
    */

    virtual void mouseDoubleClickEvent(QMouseEvent *event)
    {
        showHideProperties();
    }

    virtual void mousePressEvents(QMouseEvent *event)
    {
        lastPos = event->pos();

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        activeCamera->mousePressEvent(event);

        this->parentWidget->setCursor(activeCamera->cursor);




        selectModel(event);

        axesTransformer->mousePressEvent(event);
    }

    virtual void mouseMoveEvents(QMouseEvent *event)
    {
        QPoint delta = event->pos() - lastPos;

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        //qDebug()<<"Up:"<<activeCamera->up;
        //qDebug()<<"Position:"<<activeCamera->position;
        //qDebug()<<"Target:"<<activeCamera->target;




        activeCamera->mouseMoveEvent(event);
        this->parentWidget->setCursor(activeCamera->cursor);
        this->parentWidget->update();


        axesTransformer->mouseMoveEvent(event);
    }
    virtual void mouseReleaseEvents(QMouseEvent *event)
    {
        lastPos = event->pos();

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        activeCamera->mouseReleaseEvent(event);
        this->parentWidget->setCursor(activeCamera->cursor);


        axesTransformer->mouseReleaseEvent(event);
    }

    virtual void keyPressEvents(QKeyEvent *event)
    {
        showSearchCommandsWindow(event);

        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

        activeCamera->keyPressEvent(event);

        axesTransformer->keyPressEvent(event);

        //setPerspectiveMode(event);
        processAddModelMenu(event);
        selectModel(event);
        deleteSelectedModel(event);
        duplicateSelelctedModel(event);

        nextDrawMode(event);



    }

    virtual void showContextMenue()
    {
        QPoint p = QCursor::pos();

        mainContextmenu.move(p);

        mainContextmenu.show();
    }
    virtual void resizeViewPort()
    {
        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

       activeCamera->resizeViewPort(parentWidget->rect());
    }
    virtual void zoomViewPort(QWheelEvent * event)
    {
        QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

       activeCamera->zoom(event);
       this->parentWidget->setCursor(activeCamera->cursor);

    }
    virtual void showSearchCommandsWindow(QKeyEvent *event)
    {
       if(event->key()==Qt::Key_Space ||  event->key()==Qt::Key_Tab)
       {
           if(commands->isVisible())
           {
               commands->hide();
           }
           else
           {
               QPoint p =  QCursor::pos();

               commands->move(p.x(),p.y());

               commands->show();
           }
       }
    }

signals:

    void currentSelectionChange();

    void modelSelectionChanged();

    //void modelAddedtoScene();

    void modelDeletedInScene();

    void modelDuplicatesInScene();

    void modelModelReparent();

    void modelModelUnParented();

    void modelExploded();

public slots:

    void setCurrentCameraIndex(int CameraIndex = 0)
    {
        currentCameraIndex =  CameraIndex;
    }

    void showHideProperties()
    {
        if(selectionInfo->size()>0)
        {
            QBaseModel  * model =selectionInfo->getSelectedModel();

            if(model->type() == MODEL_SPHERE)
            {
                QSphereModel * m = qobject_cast<QSphereModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_MESH)
            {
                QMeshModel * m = qobject_cast<QMeshModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_QUAD)
            {
               QQuadModel * m = qobject_cast<QQuadModel *>(model);

               if(m->getWidget()->isVisible())
               {
                   m->getWidget()->hide();
               }
               else
               {
                   m->getWidget()->show();
               }

            }
            else if(model->type() == MODEL_PLANE)
            {
                 QPlaneModel * m = qobject_cast<QPlaneModel *>(model);

                 if(m->getWidget()->isVisible())
                 {
                     m->getWidget()->hide();
                 }
                 else
                 {
                     m->getWidget()->show();
                 }
            }
            else if(model->type() == MODEL_CONE)
            {
                QConeModel * m = qobject_cast<QConeModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_CYLINDER)
            {
                QCylinderModel * m = qobject_cast<QCylinderModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_DONUT)
            {
                QTorusModel * m = qobject_cast<QTorusModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_CUBE)
            {
                QCubeModel * m = qobject_cast<QCubeModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_ROUNDED_CUBE)
            {
                QRoundedCubeModel * m = qobject_cast<QRoundedCubeModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }

            else if(model->type() == MODEL_PIE)
            {
                QPieModel * m = qobject_cast<QPieModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_LIGHT)
            {
                QLightModel * m = qobject_cast<QLightModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_IVY)
            {
                //QIvyModel * m = qobject_cast<QIvyModel *>(model);
                //parametersToolBar->switchWidget(m->getWidget());
            }
            else if(model->type() == MODEL_CAMERA_FREE)
            {
                QCameraFreeModel * m = qobject_cast<QCameraFreeModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_CAMERA_TARGET)
            {
                QCameraTargetModel * m = qobject_cast<QCameraTargetModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else if(model->type() == MODEL_TERRAIN)
            {
                QTerrainModel * m = qobject_cast<QTerrainModel *>(model);

                if(m->getWidget()->isVisible())
                {
                    m->getWidget()->hide();
                }
                else
                {
                    m->getWidget()->show();
                }
            }
            else
            {
                /*

                QWidget *m =  floorParameters->getWidget();

                if(m->isVisible())
                {
                    m->hide();
                }
                else
                {
                    m->show();
                }

                propertiesEditor->setCentralWidget(m);


                */
            }
        }
    }

    void setCurrentModeParameters()
    {
        if(selectionInfo->size())
        {
            if(propertiesEditor->centralWidget())
                propertiesEditor->centralWidget()->hide();

            QBaseModel  * model = selectionInfo->getSelectedModel();

            if(model->type() == MODEL_SPHERE)
            {
                QSphereModel * m = qobject_cast<QSphereModel *>(model);

                //propertiesEditor->setLayout(m->getWidget()->layout());


                propertiesEditor->setCentralWidget(m->getWidget());

                //m->getWidget()->show();
            }
            if(model->type() == MODEL_PIE)
            {
                QPieModel * m = qobject_cast<QPieModel *>(model);

                //propertiesEditor->setLayout(m->getWidget()->layout());


                propertiesEditor->setCentralWidget(m->getWidget());

                //m->getWidget()->show();
            }
            else if(model->type() == MODEL_MESH)
            {
                QMeshModel * m = qobject_cast<QMeshModel *>(model);

                //propertiesEditor->setLayout(m->getWidget()->layout());

                propertiesEditor->setCentralWidget(m->getWidget());

                //m->getWidget()->show();
            }
            else if(model->type() == MODEL_QUAD)
            {
               QQuadModel * m = qobject_cast<QQuadModel *>(model);

               //propertiesEditor->setLayout(m->getWidget()->layout());

               propertiesEditor->setCentralWidget(m->getWidget());

               //m->getWidget()->show();

            }
            else if(model->type() == MODEL_PLANE)
            {
                 QPlaneModel * m = qobject_cast<QPlaneModel *>(model);

                 //propertiesEditor->setLayout(m->getWidget()->layout());

                 propertiesEditor->setCentralWidget(m->getWidget());

                 //m->getWidget()->show();
            }
            else if(model->type() == MODEL_CONE)
            {
                QConeModel * m = qobject_cast<QConeModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());

               // propertiesEditor->setLayout(m->getWidget()->layout());

                //m->getWidget()->show();
            }
            else if(model->type() == MODEL_CYLINDER)
            {
                QCylinderModel * m = qobject_cast<QCylinderModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());

               // propertiesEditor->setLayout(m->getWidget()->layout());

                m->getWidget()->show();
            }
            else if(model->type() == MODEL_DONUT)
            {
                QTorusModel * m = qobject_cast<QTorusModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());

                //m->getWidget()->show();
                //propertiesEditor->setLayout(m->getWidget()->layout());
            }
            else if(model->type() == MODEL_CUBE)
            {
                QCubeModel * m = qobject_cast<QCubeModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());

                //m->getWidget()->show();
                //propertiesEditor->setLayout(m->getWidget()->layout());
            }
            else if(model->type() == MODEL_ROUNDED_CUBE)
            {
                QRoundedCubeModel * m = qobject_cast<QRoundedCubeModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());


            }
            else if(model->type() == MODEL_LIGHT)
            {
                QLightModel * m = qobject_cast<QLightModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());


            }
            else if(model->type() == MODEL_IVY)
            {

                //QIvyModel * m = qobject_cast<QIvyModel *>(model);

                //propertiesEditor->setCentralWidget(m->getWidget());

            }
            else if(model->type() == MODEL_CAMERA_FREE)
            {
                QCameraFreeModel * m = qobject_cast<QCameraFreeModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());

            }
            else if(model->type() == MODEL_CAMERA_TARGET)
            {
                QCameraTargetModel * m = qobject_cast<QCameraTargetModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());


            }
            else if(model->type() == MODEL_TERRAIN)
            {
                QTerrainModel * m = qobject_cast<QTerrainModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());


            }
            else if(model->type() == MODEL_LOCATION)
            {
                QLocationModel * m = qobject_cast<QLocationModel *>(model);

                propertiesEditor->setCentralWidget(m->getWidget());


            }
            else
            {
                //propertiesEditor->setCentralWidget(floorParameters->getWidget());
                //floorParameters->getWidget()->show();


                //propertiesEditor->setLayout(floorParameters->getWidget()->layout());
            }
        }

        propertiesEditor->update();


    }

    void addModelsMenues()
    {
        foreach(QString nodename,modelsList)
        {
            if(nodename.contains("Sphere",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addSphereModel()));

            }
            else if(nodename.contains("Mesh",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addMeshModel()));

            }
            else if(nodename.contains("Quad",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addQuadModel()));

            }
            else if(nodename.contains("Plane",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addPlaneModel()));

            }
            else if(nodename.contains("Cone",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addConeModel()));

            }
            else if(nodename.contains("Cylinder",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCylinderModel()));

            }
            else if(nodename.contains("Torus",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addTorusModel()));

            }
            else if(nodename.contains("Cube",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCubeModel()));

            }
            else if(nodename.contains("Rounded Cube",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addRoundedCubeModel()));

            }
            else if(nodename.contains("Light",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addLightModel()));

            }
            else if(nodename.contains("Ivy",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addIvyModel()));

            }
            else if(nodename.contains("Camera",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCameraFreeModel()));


            }
            else if(nodename.contains("Particles",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addParticlesModel()));
            }
            else if(nodename.contains("Terrain",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addTerrainModel()));
            }
            else if(nodename.contains("Location",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addLocationModel()));
            }

            allnodes.append(nodename);
        }
    }


    QMeshModel * loadObjModel(QString filename)
    {
        QMeshModel * model = new QMeshModel;

        model->vertices.clear();
        model->normals.clear();
        model->texcoords.clear();
        model->indices.clear();
        model->edges.clear();

        QFile file(filename);

        if (file.open(QIODevice::ReadOnly))
        {
            QTextStream in(&file);

            while (!in.atEnd())
            {
                QString input = in.readLine();

                if (input.isEmpty() || input[0] == '#')
                    continue;

                QTextStream ts(&input);

                QString id;

                ts >> id;

                if (id == "v")
                {
                    QVector3D p;

                    for (int i = 0; i < 3; ++i)
                    {
                        float v;

                        ts>>v;

                        if(i ==0)
                        {
                            p.setX(v);
                        }
                        else if(i ==1)
                        {
                            p.setY(v);
                        }
                        else if(i ==2)
                        {
                            p.setZ(v);
                        }
                    }

                    model->vertices.append(p);
                }
                else if(id == "vt")
                {
                    QVector2D uv;

                    for (int i = 0; i < 2; ++i)
                    {
                        float v;

                        ts>>v;

                        if(i==0)
                            uv.setX(v);
                        if(i==1)
                            uv.setY(v);

                    }

                    model->texcoords.append( uv);

                }
                else if(id == "vn")
                {
                    QVector3D vn;

                    float x,y,z;

                    ts>>x>>y>>z;

                    vn = QVector3D(x,y,z);

                    model->normals.append(vn);
                }
                else if (id == "f" || id == "fo")
                {
                    QVarLengthArray<int, 4> p;

                    while (!ts.atEnd())
                    {
                        QString vertex;

                        ts >> vertex;

                        const int vertexIndex = vertex.split('/').value(0).toInt();

                        if (vertexIndex)
                        {
                            p.append(vertexIndex > 0 ? vertexIndex - 1 : model->vertices.size() + vertexIndex);
                        }
                    }

                    for (int i = 0; i < p.size(); ++i)
                    {
                        const int edgeA = p[i];

                        const int edgeB = p[(i + 1) % p.size()];

                        if (edgeA < edgeB)
                        {
                            model->edges.append(edgeA);

                            model->edges.append(edgeB);
                        }
                    }

                    for (int i = 0; i < 3; ++i)
                    {
                        model->indices.append(p[i]);
                    }

                    if (p.size() == 4)
                    {
                        for (int i = 0; i < 3; ++i)
                        {
                            int index = p[(i + 2) % 4];

                            model->indices.append(index);
                        }
                    }
                }
            }
        }

        return model;
    }

    void loadStlFileASCII(QMeshModel * model,QString filePath)
    {
        QFile file(filePath);

        if (!file.open(QIODevice::ReadOnly))
            return;

        QTextStream in(&file);

        QList<QVector3D> vertices;
        QList<QVector3D> points;
        QList<QVector3D> faceNormals;

        QList<int> faceIndices;        
        QList<int> pointIndices;
        QList<int> edgeIndices;

        while (!in.atEnd())
        {
            QString input = in.readLine();

            if (input.isEmpty() || input.startsWith(QString("outer")) || input.startsWith(QString("end")))
            {
                continue;
            }

            QTextStream ts(&input);

            QString id;

            ts >> id;

            if (id == "solid")
            {
                QString name;
                ts>>name;
                //qDebug()<<"Mesh object:  "<<name;
            }
            else if(id == "facet")
            {
                QVector3D vn;
                float x,y,z;
                ts>>x>>y>>z;
                vn = QVector3D(x,y,z);
                faceNormals.append(vn);
                //qDebug()<<"facet:"<<vn;
            }
            else if (id == "vertex")
            {
                QVector3D p;
                float x,y,z;
                ts>>x>>y>>z;
                p = QVector3D(x,y,z);
                points.append( p);
                //qDebug()<<"vertex:"<<p;
            }
        }

        if(model)
        {
            int numberoffaces = points.size()/3;

            int _index = 0;

            //get vertices
            foreach(QVector3D v,points)
            {
                if(vertices.contains(v) == true)
                {
                    //qDebug()<<"contains Point:"<<v;
                }
                else
                {
                    pointIndices.append(_index);

                    vertices.append(v);

                    //qDebug()<<"unique Point:"<<v;

                    _index += 1;
                }
            }

            //get face indices triangles
            for(int i=0;i<points.size();i+=1)
            {
                int index =0;

                foreach(QVector3D v,vertices)
                {
                    if(  vertices[index].x() == points[i].x()
                      && vertices[index].y() == points[i].y()
                      && vertices[index].z() == points[i].z()
                            )
                    {
                        faceIndices.append(index);
                    }

                    index += 1;
                }
            }

            //qDebug()<<"number of Faces:"<<faceIndices.size()/3<<","<<numberoffaces;

            //if(faceIndices.size()%3==0)
            {
                for(int i=0;i<faceIndices.size();i+=3)
                {
                    int index1,index2,index3;

                    index1 = faceIndices[i];
                    index2 = faceIndices[i+1];
                    index3 = faceIndices[i+2];

                    //edge 1
                    edgeIndices.append(index1);
                    edgeIndices.append(index2);

                    //edge 2
                    edgeIndices.append(index2);
                    edgeIndices.append(index3);

                    //edge 3
                    edgeIndices.append(index3);
                    edgeIndices.append(index1);
                }
            }
        }

        //qDebug()<<"STL file reading complete";

        /*
        foreach(int v,pointIndices)
        {
            model->m_pointIndices.append(v);
        }
        */

        foreach(QVector3D v,vertices)
        {
            model->vertices.append(v);
        }

        foreach(int v,edgeIndices)
        {
            model->edges.append(v);
        }

        foreach(int v,faceIndices)
        {
            model->indices.append(v);
        }

        faceIndices.clear();
        edgeIndices.clear();
        pointIndices.clear();
        vertices.clear();

        file.close();
    }

    void loadStlFileBinary(QMeshModel * model,QString filePath)
    {
        //Binary STL
        //Because ASCII STL files can become very large
        //a binary version of STL exists. A binary STL
        //file has an 80-character header
        //(which is generally ignored, but should never begin with
        //"solid" because that will lead most software to assume
        //that this is an ASCII STL file[citation needed]).
        //Following the header is a 4-byte unsigned integer
        //indicating the number of triangular facets in the file.
        //Following that is data describing each triangle in turn.
        //The file simply ends after the last triangle.

        //Each triangle is described by twelve 32-bit floating-point
        //numbers: three for the normal and then
        //         three for the X/Y/Z coordinate of each vertex � just as with the ASCII version of STL.
        //         After these follows a 2-byte ("short")
        //         unsigned integer that is the "attribute byte count" �
        //         in the standard format, this should be zero because
        //         most software does not understand anything else.



        // Load STL file
        //
        // UINT8[80] � Header
        // UINT32 � Number of triangles

        // foreach triangle
        // REAL32[3] � Normal vector
        // REAL32[3] � Vertex 1
        // REAL32[3] � Vertex 2
        // REAL32[3] � Vertex 3
        // UINT16 � Attribute byte count
        // end

        qDebug()<<"STL file reading beginning";

        std::ifstream file(filePath.toStdString().c_str(), std::ios::binary);

        char header[80];
        int nbTrianglesFile;

        file.read(header, 80); //header
        file.read((char*)&nbTrianglesFile, 4); //read number of triangles

        int nbTriangles = nbTrianglesFile;

        qDebug()<<"Number of Triangles"<<nbTriangles;

        //triangles.reserve(nbTriangles);
        //vertices.reserve(nbTriangles/2);

        QList<QVector3D> verts;
        QList<int> trianglez;

        int index1, index2, index3;

        float x, y, z;

        float nx, ny, nz;

        //Vertex v1, v2, v3;

        QVector3D v1, v2, v3;

        for (int i=0;i<nbTriangles;i++)
        {
            //file.read((char*)&x, 12); //normal

            file.read((char*)&nx, 4); //normal
            file.read((char*)&ny, 4);
            file.read((char*)&nz, 4);

            QVector3D normal(nx,ny,nz);

            qDebug()<<"Normal:"<<normal;

            file.read((char*)&x, 4); //vertex 1
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v1 = QVector3D(x,y,z);


            //index1 = detectNewVertex(v1, i, verticesSet,vertices);
            file.read((char*)&x, 4); //vertex 2
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v2 = QVector3D(x,y,z);


            //index2 = detectNewVertex(v2, i, verticesSet,vertices);
            file.read((char*)&x, 4); //vertex 3
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v3 = QVector3D(x,y,z);


            qDebug()<<v1;
            qDebug()<<v2;
            qDebug()<<v3;

            verts.append(v1);
            verts.append(v2);
            verts.append(v3);

            trianglez.append(i);

            //index3 = detectNewVertex(v3, i, verticesSet,vertices);
            file.read((char*)&x, 2); //1 byte attribute

            //QVector3D normal = QVector3D::normal(v1, v2, v3);

            //triangles.push_back(Triangle(QVector3D::normal(v1, v2, v3), index1, index2, index3, i));


            qDebug()<<"Number of Triangles"<<nbTriangles<<"N:"<<(i+1);
        }


        file.close();

        qDebug()<<"STL file reading complete";

    }



    void addMeshModel()
    {
        //QString filePath = QFileDialog::getOpenFileName(0, QString("Choose model"), QString(), QLatin1String("*.obj"));

        QString filename;
        QStringList stringlist;

        stringlist.append(QString("OBJ File (*.obj)"));

        stringlist.append(QString("STL File (*.stl)"));

        stringlist.append(QString("Metropolis File (*.metro)"));

        QFileDialog dialog;
        QDir dir;
        dir.entryList(stringlist);

        dialog.setFilter(dir.filter());
        dialog.show();

        QStringList fileNames;

        if (dialog.exec())
        {
            fileNames = dialog.selectedFiles();

            qDebug()<<fileNames;

            filename = fileNames[0];
        }

        if(filename.endsWith(".obj"))
        {
            QMeshModel *model=  new QMeshModel;

            model->clearMeshModel();


            model =  loadObjModel(filename);

            //model->centerMesh();
            //model->normals.clear();

            if(model->normals.size()==0)
            {
                model->computeNormals();


            }

            model->flipNormals();

            model->computeBounds();

            models.append(model);

            if(model)
            {
                //model->getWidget()->show();

                propertiesEditor->setCentralWidget(model->getWidget());

                //model->setParentModel(rootModel);
                //rootModel->children.append(model);
                //itemModel->setRootModel(rootModel);
            }



            ///relationships
            if(model)
            {
                //model->setParentModel(rootModel);
                //rootModel->children.append(model);
                //itemModel->setRootModel(rootModel);
            }

            //emit modelAddedtoScene();


        }
        else if(filename.endsWith(".stl"))
        {
            QMeshModel *model=  new QMeshModel;

            model->clearMeshModel();

            loadStlFileASCII(model,filename);

            model->centerMesh();
            model->normals.clear();
            model->computeNormals();
            //model->flipNormals();
            model->computeBounds();
            models.append(model);

            ///relationships
            ///
            if(model)
            {
                //model->setParentModel(rootModel);
                //rootModel->children.append(model);
                //itemModel->setRootModel(rootModel);
            }


            //emit modelAddedtoScene();

        }



       //propertiesEditor->addPanel(model->getWidget());
    }

    void addPieModel()
    {
        QPieModel * model =  new QPieModel;

        models.append(model);

        if(model)
        {
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

            //model->setParentModel(rootModel);
            //rootModel->children.append(model);
            //itemModel->setRootModel(rootModel);
        }

        //emit modelAddedtoScene();

    }

    void addQuadModel()
    {
       QQuadModel * model =  new QQuadModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addCylinderModel()
    {
       QCylinderModel *model =  new QCylinderModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addSphereModel()
    {
       QSphereModel* model =  new QSphereModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();


       //propertiesEditor->addPanel(model->getWidget());
    }

    void addCubeModel()
    {
       QCubeModel *model=  new QCubeModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addRoundedCubeModel()
    {
        QRoundedCubeModel * model = new QRoundedCubeModel;

        models.append(model);

        if(model)
        {
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

            //model->setParentModel(rootModel);
            //rootModel->children.append(model);
            //itemModel->setRootModel(rootModel);
        }

        //emit modelAddedtoScene();
        //propertiesEditor->addPanel(model->getWidget());


    }

    void addTorusModel()
    {
       QTorusModel* model =  new QTorusModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addPlaneModel()
    {
       QPlaneModel *model =  new QPlaneModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addTerrainModel()
    {
       QTerrainModel *model =  new QTerrainModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addCameraFreeModel()
    {
       QCameraFreeModel *model=  new QCameraFreeModel;

       models.append(model);

       cameras.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addCameraTargetModel()
    {
       QCameraTargetModel *model=  new QCameraTargetModel;

       models.append(model);

       cameras.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addConeModel()
    {
       QConeModel *model =  new QConeModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }


       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addLightModel()
    {
       QLightModel *model =  new QLightModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addIvyModel()
    {
       //QIvyModel *model =  new QIvyModel;

       //models.append(model);

        //model->setParentModel(rootModel);
        //rootModel->children.append(model);

        //propertiesEditor->addPanel(model->getWidget());


        //if(model)
        //{
           // model->getWidget()->show();

            //propertiesEditor->setCentralWidget(model->getWidget());

            //model->setParentModel(rootModel);
            //rootModel->children.append(model);
            //itemModel->setRootModel(rootModel);
        //}
        //emit modelAddedtoScene();
    }

    void addParticlesModel()
    {
       QParticlesModel* model =  new QParticlesModel;

       models.append(model);

       if(model)
       {
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());

           //model->setParentModel(rootModel);
           //rootModel->children.append(model);
           //itemModel->setRootModel(rootModel);
       }

       //emit modelAddedtoScene();
       //propertiesEditor->addPanel(model->getWidget());
    }

    void addSVGMeshModel()
    {
        //emit modelAddedtoScene();

    }

    void addLocationModel()
    {
        QLocationModel * model = new QLocationModel;
        models.append(model);

        if(model)
        {
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

            //model->setParentModel(rootModel);
            //rootModel->children.append(model);
            //itemModel->setRootModel(rootModel);
        }

        qDebug()<<"Added a Location";

        //emit modelAddedtoScene();

    }

    void addModel(QString modelname)
    {


        if(modelname.contains("Sphere",Qt::CaseInsensitive))
        {
            QSphereModel  * model = new QSphereModel;

            models.append(model);

            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

        }
        else if(modelname.contains("Mesh",Qt::CaseInsensitive))
        {
            QMeshModel *model = new QMeshModel;
            models.append(model);

            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

        }
        else if(modelname.contains("Quad",Qt::CaseInsensitive))
        {
           QQuadModel *model = new  QQuadModel;
           models.append(model);
           //model->getWidget()->show();

           propertiesEditor->setCentralWidget(model->getWidget());


        }
        else if(modelname.contains("Plane",Qt::CaseInsensitive))
        {
            QPlaneModel *model = new QPlaneModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }
        else if(modelname.contains("Cone",Qt::CaseInsensitive))
        {
            QConeModel *model = new QConeModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }
        else if(modelname.contains("Cylinder",Qt::CaseInsensitive))
        {
            QCylinderModel *model = new QCylinderModel;
            models.append(model);
            //model->getWidget()->show();
            propertiesEditor->setCentralWidget(model->getWidget());


        }
        else if(modelname.contains("Torus",Qt::CaseInsensitive))
        {
            QTorusModel * model = new QTorusModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }
        else if(modelname.contains("Cube",Qt::CaseInsensitive))
        {
            QCubeModel *model = new QCubeModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }

        else if(modelname.contains("Rounded Cube",Qt::CaseInsensitive))
        {
            QRoundedCubeModel *model = new QRoundedCubeModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }


        else if(modelname.contains("Pie",Qt::CaseInsensitive))
        {
            QPieModel *model = new QPieModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());


        }

        else if(modelname.contains("Light",Qt::CaseInsensitive))
        {
            QLightModel *model = new QLightModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

        }
        else if(modelname.contains("Ivy",Qt::CaseInsensitive))
        {
            //model = new QIvyModel ;
            //models.append(model);
        }
        else if(modelname.contains("Camera",Qt::CaseInsensitive))
        {
            QCameraTargetModel *model = new QCameraTargetModel;
            models.append(model);
            //model->getWidget()->show();
            propertiesEditor->setCentralWidget(model->getWidget());

        }
        else if(modelname.contains("Terrain",Qt::CaseInsensitive))
        {
            QTerrainModel *model = new QTerrainModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

        }
        else if(modelname.contains("Location",Qt::CaseInsensitive))
        {
            QLocationModel *model  = new QLocationModel;
            models.append(model);
            //model->getWidget()->show();

            propertiesEditor->setCentralWidget(model->getWidget());

        }

        //relationships

        //if(model)
        {
            //model->setParentModel(rootModel);
            //rootModel->children.append(model);
            //itemModel->setRootModel(rootModel);
        }

        //emit modelAddedtoScene();
    }


    virtual void duplicateSelectedModel()
    {
       if(models.size()>0 && selectionInfo->size()>0)
       {
           QBaseModel *selectedModel = selectionInfo->getSelectedModel();

           if(selectedModel->type()==MODEL_MESH)
           {
              QMeshModel *model=  new QMeshModel(qobject_cast<QMeshModel*>(selectedModel));

              models.append(model);
           }
           if(selectedModel->type()==MODEL_QUAD)
           {
              QQuadModel *model =  new QQuadModel;
              model->position = selectedModel->position;
              models.append(model);

           }
           else if(selectedModel->type()==MODEL_CYLINDER)
           {
              QCylinderModel *model =  new QCylinderModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_SPHERE)
           {
              QSphereModel *model =  new QSphereModel;
              model->position = selectedModel->position;
              models.append(model);

           }
           else if(selectedModel->type()==MODEL_CUBE)
           {
              QCubeModel *model=  new QCubeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_PIE)
           {
              QPieModel *model=  new QPieModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_ROUNDED_CUBE)
           {
              QRoundedCubeModel *model=  new QRoundedCubeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_DONUT)
           {
              QTorusModel *model =  new QTorusModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_PLANE)
           {
               QPlaneModel *model=  new QPlaneModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_TERRAIN)
           {
               QTerrainModel *model=  new QTerrainModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_CAMERA_FREE)
           {
               QCameraFreeModel *model =  new QCameraFreeModel;
               model->position = selectedModel->position;
               models.append(model);
               cameras.append(model);
           }
           else if(selectedModel->type()==MODEL_CAMERA_TARGET)
           {
               QCameraTargetModel *model =  new QCameraTargetModel;
               model->position = selectedModel->position;
               models.append(model);
               cameras.append(model);
           }
           else if(selectedModel->type()==MODEL_CONE)
           {
              QConeModel *model =  new QConeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_LIGHT)
           {
              QLightModel *model =  new QLightModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_IVY)
           {
              //QIvyModel *model =  new QIvyModel;
              //model->position = selectedModel->position;
              //models.append(model);
           }
           else if(selectedModel->type()==MODEL_PARTICLES)
           {
              QParticlesModel *model =  new QParticlesModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_LOCATION)
           {
              QLocationModel *model =  new QLocationModel;
              model->position = selectedModel->position;
              models.append(model);
           }

           emit modelDuplicatesInScene();


       }
    }

    virtual void duplicateSelectedModelReference()
    {
       if(models.size()>0 && selectionInfo->size()>0)
       {
           QBaseModel *selectedModel = selectionInfo->getSelectedModel();

           if(selectedModel->type()==MODEL_MESH)
           {
              QMeshModel *model=  new QMeshModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           if(selectedModel->type()==MODEL_QUAD)
           {
              QQuadModel *model =  new QQuadModel;
              model->position = selectedModel->position;
              models.append(model);

           }
           else if(selectedModel->type()==MODEL_CYLINDER)
           {
              QCylinderModel *model =  new QCylinderModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_SPHERE)
           {
              QSphereModel *model =  new QSphereModel;
              model->position = selectedModel->position;
              models.append(model);

           }
           else if(selectedModel->type()==MODEL_CUBE)
           {
              QCubeModel *model=  new QCubeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_ROUNDED_CUBE)
           {
              QRoundedCubeModel *model=  new QRoundedCubeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_PIE)
           {
              QPieModel *model=  new QPieModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_DONUT)
           {
              QTorusModel *model =  new QTorusModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_PLANE)
           {
               QPlaneModel *model=  new QPlaneModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_TERRAIN)
           {
               QTerrainModel *model=  new QTerrainModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_CAMERA_FREE)
           {
               QCameraFreeModel *model =  new QCameraFreeModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_CAMERA_TARGET)
           {
               QCameraTargetModel *model =  new QCameraTargetModel;
               model->position = selectedModel->position;
               models.append(model);
           }
           else if(selectedModel->type()==MODEL_CONE)
           {
              QConeModel *model =  new QConeModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_LIGHT)
           {
              QLightModel *model =  new QLightModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_IVY)
           {
              //QIvyModel *model =  new QIvyModel;
              //model->position = selectedModel->position;
              //models.append(model);
           }
           else if(selectedModel->type()==MODEL_PARTICLES)
           {
              QParticlesModel *model =  new QParticlesModel;
              model->position = selectedModel->position;
              models.append(model);
           }
           else if(selectedModel->type()==MODEL_LOCATION)
           {
              QLocationModel *model =  new QLocationModel;
              model->position = selectedModel->position;
              models.append(model);
           }

           emit modelDuplicatesInScene();

       }
    }

    virtual void deleteModel()
    {
       if(selectionInfo->size())
       {
           foreach(QBaseModel * m,selectionInfo->getSelectedModels())
           {
              models.removeOne(m);
           }

           selectionInfo->clearSelection();

           emit modelDeletedInScene();
       }
    }

    virtual void deleteLastModel()
    {
       if(selectionInfo->size())
       {

           QBaseModel  * model = selectionInfo->getSelectedModel();

           if(model->type() == MODEL_SPHERE)
           {
               QSphereModel * m = qobject_cast<QSphereModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);


               }
           }
           else if(model->type() == MODEL_MESH)
           {
               QMeshModel * m = qobject_cast<QMeshModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_QUAD)
           {
              QQuadModel * m = qobject_cast<QQuadModel *>(model);

              if(model->ID == m->ID)
              {
                  qDebug()<<"Contains Model:"<<model->ID;
                  selectionInfo->clearSelection();
                  models.removeOne(m);
              }
           }
           else if(model->type() == MODEL_PLANE)
           {
                QPlaneModel * m = qobject_cast<QPlaneModel *>(model);

                if(model->ID == m->ID)
                {
                    qDebug()<<"Contains Model:"<<model->ID;
                    selectionInfo->clearSelection();
                    models.removeOne(m);
                }
           }
           else if(model->type() == MODEL_CONE)
           {
               QConeModel * m = qobject_cast<QConeModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_CYLINDER)
           {
               QCylinderModel * m = qobject_cast<QCylinderModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_DONUT)
           {
               QTorusModel * m = qobject_cast<QTorusModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_CUBE)
           {
               QCubeModel * m = qobject_cast<QCubeModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_CUBE)
           {
               QRoundedCubeModel * m = qobject_cast<QRoundedCubeModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type()==MODEL_PIE)
           {
               QPieModel * m = qobject_cast<QPieModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type()==MODEL_ROUNDED_CUBE)
           {
               QRoundedCubeModel * m = qobject_cast<QRoundedCubeModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_LIGHT)
           {
               QLightModel * m = qobject_cast<QLightModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_IVY)
           {
               //QIvyModel * m = qobject_cast<QIvyModel *>(model);
               //parametersToolBar->switchWidget(m->getWidget());

               //propertiesEditor->clear();
               //propertiesEditor->addPanel(m->getWidget());

           }
           else if(model->type() == MODEL_CAMERA_FREE)
           {
               QCameraFreeModel * m = qobject_cast<QCameraFreeModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_CAMERA_TARGET)
           {
               QCameraTargetModel * m = qobject_cast<QCameraTargetModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type() == MODEL_TERRAIN)
           {
               QTerrainModel * m = qobject_cast<QTerrainModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }
           }
           else if(model->type()==MODEL_LOCATION)
           {
               QLocationModel * m = qobject_cast<QLocationModel *>(model);

               if(model->ID == m->ID)
               {
                   qDebug()<<"Contains Model:"<<model->ID;
                   selectionInfo->clearSelection();
                   models.removeOne(m);
               }

           }


            emit modelDeletedInScene();

       }
    }

    virtual void parentModels()
    {
        if(selectionInfo->size()>1)
        {
            QVector<QBaseModel *> selectionSet = selectionInfo->getSelectedModels();

            if(selectionInfo->size()==2)
            {
                selectionSet.first()->setParentModel(selectionSet.last());

                selectionSet.first()->setHasParent(true);

            }
            else if(selectionInfo->size()>2)
            {
                foreach(QBaseModel *model,selectionSet)
                {
                    if(selectionSet.last()->ID!= model->ID)
                    {
                        model->setParentModel(selectionSet.last());

                        model->setHasParent(true);
                    }
                }
            }

            foreach(QBaseModel *model,selectionSet)
            {
                if(model->getHasParent())
                {
                   qDebug()<<"Model ID"<<model->ID;
                   qDebug()<<"ParentID"<<model->getParentModel()->ID;
                }
            }

            emit modelModelReparent();
        }
    }

    virtual void unparentModels()
    {
        if(selectionInfo->size()>1)
        {
            QVector<QBaseModel *> selectionSet = selectionInfo->getSelectedModels();

             foreach(QBaseModel *model,selectionSet)
             {
                 model->setParentModel(0);
                 model->setHasParent(false);
             }

             foreach(QBaseModel *model,selectionSet)
             {
                 if(model->getHasParent())
                 {
                    qDebug()<<"Model ID"<<model->ID;
                    qDebug()<<"ParentID"<<model->getParentModel()->ID;
                 }
             }

             emit modelModelUnParented();
        }
    }

    virtual void lookAtSelectedModel()
    {

    }

    virtual void centerToModel()
    {
        if(selectionInfo->size()>0)
        {
            QBaseModel * model =  selectionInfo->getSelectedModel();

            QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

            activeCamera->lookAt(model->position);

            /*
            QBaseModel * model =  selectionInfo->getSelectedModel();

            QCameraTargetModel * activeCamera =  qobject_cast<QCameraTargetModel *>(cameras[currentCameraIndex]);

            QVector3D dir =  activeCamera->position - activeCamera->target;

            dir.normalize();

            activeCamera->forward = dir;

            QVector3D center = model->position;

            center /= model->vertices.size();

            float length  =  dir.length();

            if(model->boundingAabbox.radius<length)
            {

            }
            else if(model->boundingAabbox.radius>length)
            {

            }

            activeCamera->position = dir * model->boundingAabbox.radius;

            activeCamera->target  = center;

            */
        }
    }

    virtual void expodeModel()
    {
        if(selectionInfo->size())
        {
            QBaseModel  * model = selectionInfo->getSelectedModel();

            if(model->type() == MODEL_LIGHT||
               model->type() == MODEL_CAMERA_FREE||
               model->type() == MODEL_CAMERA_TARGET||
               model->type() == MODEL_LOCATION||
               model->type() == MODEL_PARTICLES)
            {
                return;
            }
            else
            {
                if(model->vertices.size()>0 && model->indices.size()>0)
                {

                    progressbar->show();

                    QVector<QVector3D> vertices = model->vertices;

                    QVector<QVector3D> normals  = model->normals;

                    QVector<QVector2D> texcoords = model->texcoords;

                    QVector<int> indices =  model->indices;

                    QVector<int> edges   =  model->edges;


                    QVector3D position = model->position;
                    QVector3D scale    = model->scale;
                    QVector3D rotation = model->rotation;

                    QString name = model->name;


                    deleteModel();

                    int size = indices.size();

                    if(size%4 ==0)
                    {
                        for(int i =0;i<indices.size();i+=4)
                        {
                            int index0 = indices[i];
                            int index1 = indices[i+1];
                            int index2 = indices[i+2];
                            int index3 = indices[i+3];

                            QMeshModel * mesh =  new QMeshModel;

                            mesh->indices.append(index0);
                            mesh->indices.append(index1);
                            mesh->indices.append(index2);
                            mesh->indices.append(index3);


                           if(model->texcoords.size()>0)
                           {
                                mesh->texcoords.append(texcoords[index0]);
                                mesh->texcoords.append(texcoords[index1]);
                                mesh->texcoords.append(texcoords[index2]);
                                mesh->texcoords.append(texcoords[index3]);
                           }

                           if(model->normals.size()>0)
                           {
                                mesh->normals.append(normals[index0]);
                                mesh->normals.append(normals[index1]);
                                mesh->normals.append(normals[index2]);
                                mesh->normals.append(normals[index3]);

                           }

                           if( model->vertices.size()>0 )
                           {
                                mesh->vertices.append(vertices[index0]);
                                mesh->vertices.append(vertices[index1]);
                                mesh->vertices.append(vertices[index2]);
                                mesh->vertices.append(vertices[index3]);

                                QVector3D p = vertices[index0] +vertices[index1]+vertices[index2]+vertices[index3];

                                p/=4;

                                mesh->position =  position;
                                mesh->rotation =  rotation;
                                mesh->scale    =  scale;
                                mesh->name     =  QString("Mesh Polygon ")+ QString::number(i);

                                models.append(mesh);

                                //emit modelAddedtoScene();
                           }

                           int percentage =  i/model->indices.size() * 100;

                           progressbar->setValue(percentage);
                           progressbar->update();

                        }

                        progressbar->hide();

                        emit modelExploded();


                    }
                }
            }
        }
    }

    virtual void convertToMesh()
    {
        if(selectionInfo->size())
        {
            QBaseModel  * model = selectionInfo->getSelectedModel();

            if(model->type() == MODEL_LIGHT||
               model->type() == MODEL_CAMERA_FREE||
               model->type() == MODEL_CAMERA_TARGET||
               model->type() == MODEL_LOCATION||
               model->type() == MODEL_PARTICLES)
            {
                return;
            }
            else
            {
                QMeshModel * mesh =  new QMeshModel;

                mesh->position =  model->position;
                mesh->rotation =  model->rotation;
                mesh->scale    =  model->scale;
                mesh->name     =  model->name;

                if(model->vertices.size()>0)
                {
                    mesh->vertices =  model->vertices;
                }

                if(model->normals.size()>0)
                {
                    mesh->normals =  model->normals;
                }

                if(model->texcoords.size()>0)
                {
                    mesh->texcoords =  model->texcoords;
                }

                if(model->indices.size()>0)
                {
                    mesh->indices =  model->indices;
                }

                if(model->edges.size()>0)
                {
                    mesh->edges =  model->edges;
                }

                if(model->hasParent)
                {
                    mesh->setParentModel(model->parent);
                }

                models.append(mesh);

                //emit modelAddedtoScene();

                deleteModel();
            }
        }

    }


};

class QOutlinerWidget : public QTreeWidget
{
     Q_OBJECT

     QSceneGraph * scene;

public:

    QToolBar *toolbar;    
    QMenu *contextmenu;
    QTreeWidgetItem * rootitem;

    int frames;
    bool doduplicate;


    QOutlinerWidget(QSceneGraph * pscene=0,QWidget * parent =0):QTreeWidget(parent)
    {
        scene =  pscene;
        //frames =  1500;
        setDragEnabled(true);
        setAcceptDrops(true);
        setDropIndicatorShown(true);
        setFocusPolicy(Qt::ClickFocus);
        setDefaultDropAction(Qt::MoveAction);
        setDragDropMode(QAbstractItemView::DragDrop);

        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

        //header()->setVisible(0);
        //setHeaderLabel("Models");
        QStringList str;

        str.append(QString("Models"));
        str.append(QString("Visibility"));
        str.append(QString("Selectable"));
        str.append(QString("Renderable"));

        setHeaderLabels(str);

        //setSelectionMode(QAbstractItemView::MultiSelection);

        setAlternatingRowColors(true);

        //setSelectionMode(QAbstractItemView::ExtendedSelection);

        //setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed);

        //setExpandsOnDoubleClick(0);
        //setSortingEnabled(0);

        //verticalScrollBar()->setSingleStep(1);


        //setColumnCount(frames+1);

        //setColumnWidth(0,150);

        setColumnCount(4);

        setColumnWidth(0,200);
        setColumnWidth(1,60);
        setColumnWidth(2,60);
        setColumnWidth(3,60);


        for(int i=1;i<frames+1;i++)
        {
            //setColumnWidth(i,40);
        }



        createContextMenues();

        setTheme();

        //connect(this, SIGNAL(itemChanged()), this, SLOT(freezeSelection()));
        //connect(this, SIGNAL(itemSelectionChanged()), this,  SLOT(copySelection()));
        //connect(this, SIGNAL(itemExpanded()), this,  SLOT(pasteSelection()));
        //connect(this, SIGNAL(itemCollapsed()), this,  SLOT(duplicateSelection()));
        //connect(this, SIGNAL(activated()), this,  SLOT(deleteSelection()));
        //connect(this, SIGNAL(itemDoubleClicked()), this,  SLOT(hideSelection()));

        doduplicate = true;

        //traverseTree(rootitem);

        //connect(this,SIGNAL(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)),this,SLOT(pitemchange()));

        setMouseTracking(false);

        //connect(scene,SIGNAL(modelAddedtoScene()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelDeletedInScene()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelDuplicatesInScene()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelModelReparent()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelModelUnParented()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelExploded()),this, SLOT(populateTree()));

        //connect(scene,SIGNAL(modelSelectionChanged()),this, SLOT(changeTreeItemSelection()));


        //connect(this,SIGNAL(itemSelectionChanged()), this, SLOT(changeSceneModelSelection()));

        //connect(this,SIGNAL(entered(QModelIndex)),this,SLOT(changeSceneModelName()));


        populateTree();

    }

    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file("../resource/glowBlue.stylesheet");

        // QString s ="darkorange.stylesheet"

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  array =  file.readAll();

            setStyleSheet(array);

            contextmenu->setStyleSheet(array);

            file.close();
        }

        qDebug()<<"Styles Loaded";
    }

    void createContextMenues()
    {
        contextmenu = new QMenu;

        QStringList list;

        list.append(QString("Copy"));
        list.append(QString("Paste"));
        list.append(QString("Duplicate"));
        list.append(QString("Rename"));
        list.append(QString("Delete"));
        list.append(QString("Hide"));
        list.append(QString("Freeze"));
        list.append(QString("Expand Tree"));

        list.sort();

        contextmenu->setTitle(QString("Ouliner Context Menu"));

        /*
        contextmenu.addAction(QIcon("../Tools Icons/copy.svg"),QString("Copy"),this,SLOT(copySelection()));
        contextmenu.addAction(QIcon("../Tools Icons/paste.svg"),QString("Paste"),this,SLOT(pasteSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/duplicate.svg"),QString("Duplicate"),this,SLOT(duplicateSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/rename.svg"),QString("Rename"),this,SLOT(renameSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/delete.svg"),QString("Delete"),this,SLOT(deleteSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/hide.svg"),QString("Hide"),this,SLOT(hideSelection()));
        contextmenu.addAction(QIcon("../Tools Icons/freeze.svg"),QString("Freeze"),this,SLOT(freezeSelection()));
        */

        QAction * d0 = new QAction(QIcon("../Tools Icons/copy.svg"),QString("Copy: CTRL+C"),this);
        QAction * d1 = new QAction(QIcon("../Tools Icons/paste.svg"),QString("Paste: CTRL+V"),this);
        QAction * d2 = new QAction(QIcon("../Tools Icons/duplicate.svg"),QString("Duplicate: CTRL+D"),this);
        QAction * d3 = new QAction(QIcon("../Tools Icons/rename.svg"),QString("Rename: CTRL+R"),this);
        QAction * d4 = new QAction(QIcon("../Tools Icons/delete.svg"),QString("Delete: Delete"),this);
        QAction * d5 = new QAction(QIcon("../Tools Icons/hide.svg"),QString("Hide: CTRL+H"),this);
        QAction * d6 = new QAction(QIcon("../Tools Icons/freeze.svg"),QString("Freeze: CTRL+F"),this);
        QAction * d7 = new QAction(QIcon("../Tools Icons/freeze.svg"),QString("Expand Tree: CTRL+E"),this);

        d0->setCheckable(true);d0->setShortcut(Qt::CTRL|Qt::Key_C);
        d1->setCheckable(true);d1->setShortcut(Qt::CTRL|Qt::Key_V);
        d2->setCheckable(true);d2->setShortcut(Qt::CTRL|Qt::Key_D);
        d3->setCheckable(true);d3->setShortcut(Qt::CTRL|Qt::Key_R);
        d4->setCheckable(true);d4->setShortcut(Qt::Key_Delete);
        d5->setCheckable(true);d5->setShortcut(Qt::Key_H);
        d6->setCheckable(true);d6->setShortcut(Qt::CTRL|Qt::Key_F);
        d7->setCheckable(true);d6->setShortcut(Qt::CTRL|Qt::Key_E);

        connect(d0, SIGNAL(triggered(bool)), this, SLOT(copySelection()));
        connect(d1, SIGNAL(triggered(bool)), this, SLOT(pasteSelection()));
        connect(d2, SIGNAL(triggered(bool)), this, SLOT(duplicateSelection()));
        connect(d3, SIGNAL(triggered(bool)), this, SLOT(renameSelection()));
        connect(d4, SIGNAL(triggered(bool)), this, SLOT(deleteSelection()));
        connect(d5, SIGNAL(triggered(bool)), this, SLOT(hideSelection()));
        connect(d6, SIGNAL(triggered(bool)), this, SLOT(freezeSelection()));
        connect(d7, SIGNAL(triggered(bool)), this, SLOT(collapseExpandTree()));

        QActionGroup *duplicationActions =  new QActionGroup(this);

        duplicationActions->addAction(d0);
        duplicationActions->addAction(d1);
        duplicationActions->addAction(d2);
        duplicationActions->addAction(d3);
        duplicationActions->addAction(d4);
        duplicationActions->addAction(d5);
        duplicationActions->addAction(d6);
        duplicationActions->addAction(d7);


        toolbar = new QToolBar(QString("Outliner toolbar"));

        toolbar->addActions(duplicationActions->actions());

        contextmenu->addActions(duplicationActions->actions());
    }

    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        //const QModelIndex index = selectionModel()->currentIndex();

        //QString selectedText = index.data(Qt::DisplayRole).toString();

        //qDebug()<<"Selection Change:"<<index;
        //qDebug()<<"Selection Text:"<<selectedText;
        //qDebug()<<"Selection Text:"<<selectedItems()[0]->text(0);

        qDebug()<<"Selection Changed"<<selectedItems()[0]->text(0);

        updateProperties();

        QTreeWidget::selectionChanged(selected,deselected);
    }

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if (event->keyboardModifiers() == Qt::CTRL)
        {
            duplicateAndReparentItem(event->pos());
        }
        else
        {
            reparentItem(event->pos());
        }

        return QTreeWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {
        contextmenu->exec(event->globalPos());
        //contextmenu->popup(event->globalPos());
    }

    void keyPressEvent(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::CTRL && event->key()==Qt::Key_G)
        {
            createGroupItem();
        }
    }

signals:

    void valueChanged();

public slots:


    void populateTree()
    {
        this->clear();

        qDebug()<<"QTree Widget: model added";

        rootitem = new QTreeWidgetItem;

        rootitem->setText(0,QString("Root"));
        //rootitem->setText(1,QString("Visibility"));

        rootitem->setIcon(0,QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

        //rootitem->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);

        for(int i=0;i<scene->models.size();i++)
        {
            QBaseModel * model = scene->models[i];

            QTreeWidgetItem * item = new QTreeWidgetItem;

            item->setText(0,model->getName()+QString::number(model->ID));


            if( scene->models.size()>0)
            {
                /*
                QAction * a0 = new QAction(QIcon(":/Tools Icons/mesh cylinder.svg"),QString("Add Cylinder: SHIFT + 0"),this);
                QAction * a1 = new QAction(QIcon(":/Tools Icons/mesh camera.svg"),QString("Add Camera: SHIFT + 1"),this);
                QAction * a2 = new QAction(QIcon(":/Tools Icons/mesh particles.svg"),QString("Add Particles: SHIFT + 2"),this);
                QAction * a3 = new QAction(QIcon(":/Tools Icons/mesh light.svg"),QString("Add Light: SHIFT + 3"),this);
                QAction * a4 = new QAction(QIcon(":/Tools Icons/mesh cone.svg"),QString("Add Cone: SHIFT + 4"),this);
                QAction * a5 = new QAction(QIcon(":/Tools Icons/mesh grid.svg"),QString("Add Grid: SHIFT + 5"),this);
                QAction * a6 = new QAction(QIcon(":/Tools Icons/mesh plane.svg"),QString("Add Plane: SHIFT + 6"),this);
                QAction * a7 = new QAction(QIcon(":/Tools Icons/mesh sphere.svg"),QString("Add Sphere: SHIFT + 7"),this);
                QAction * a8 = new QAction(QIcon(":/Tools Icons/mesh torus.svg"),QString("Add Torus: SHIFT + 8"),this);
                QAction * a9 = new QAction(QIcon(":/Tools Icons/mesh box.svg"),QString("Add Box: SHIFT + 9"),this);
                QAction * a10 = new QAction(QIcon(":/Tools Icons/mesh terrain.svg"),QString("Add Terrain: CTRL + T"),this);
                QAction * a11 = new QAction(QIcon(":/Tools Icons/mesh import.svg"),QString("Import Mesh: SHIFT + I"),this);
                QAction * a12 = new QAction(QIcon(":/Tools Icons/mesh svg.svg"),QString("Import SVG: SHIFT + W"),this);
                QAction * a13 = new QAction(QIcon(":/Tools Icons/mesh location.svg"),QString("Add Location: SHIFT + L"),this);

                */

                if(model->type()==MODEL_MESH)
                {
                   //QMeshModel *model=  new QMeshModel(qobject_cast<QMeshModel*>(model));

                    item->setIcon(0,QIcon(":/Tools Icons/mesh import.svg"));


                }
                if(model->type()==MODEL_QUAD)
                {
                   //QQuadModel *model =  new QQuadModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh plane.svg"));



                }
                else if(model->type()==MODEL_CYLINDER)
                {
                   //QCylinderModel *model =  new QCylinderModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh cylinder.svg"));

                }
                else if(model->type()==MODEL_SPHERE)
                {
                   //QSphereModel *model =  new QSphereModel;
                     item->setIcon(0,QIcon(":/Tools Icons/mesh sphere.svg"));

                }
                else if(model->type()==MODEL_CUBE)
                {
                   //QCubeModel *model=  new QCubeModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh box.svg"));


                }
                else if(model->type()==MODEL_PIE)
                {
                   //QCubeModel *model=  new QCubeModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh pie.svg"));


                }
                else if(model->type()==MODEL_ROUNDED_CUBE)
                {
                   //QCubeModel *model=  new QCubeModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh box rounded.svg"));


                }
                else if(model->type()==MODEL_DONUT)
                {
                   //QTorusModel *model =  new QTorusModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh torus.svg"));

                }
                else if(model->type()==MODEL_PLANE)
                {
                    //QPlaneModel *model=  new QPlaneModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh plane.svg"));


                }
                else if(model->type()==MODEL_TERRAIN)
                {
                    //QTerrainModel *model=  new QTerrainModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh terrain.svg"));

                }
                else if(model->type()==MODEL_CAMERA_FREE)
                {
                    //QCameraFreeModel *model =  new QCameraFreeModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh camera.svg"));

                }
                else if(model->type()==MODEL_CAMERA_TARGET)
                {
                    //QCameraTargetModel *model =  new QCameraTargetModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh camera.svg"));

                }
                else if(model->type()==MODEL_CONE)
                {
                   //QConeModel *model =  new QConeModel;

                    item->setIcon(0,QIcon(":/Tools Icons/mesh cone.svg"));

                }
                else if(model->type()==MODEL_LIGHT)
                {
                   //QLightModel *model =  new QLightModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh light.svg"));

                }
                else if(model->type()==MODEL_IVY)
                {
                   //QIvyModel *model =  new QIvyModel;

                }
                else if(model->type()==MODEL_PARTICLES)
                {
                   //QParticlesModel *model =  new QParticlesModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh particles.svg"));

                }
                else if(model->type()==MODEL_LOCATION)
                {
                   //QLocationlModel *model =  new QLocationlModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh location.svg"));

                }

                else if(model->type()==MODEL_SVG)
                {
                   //QLocationlModel *model =  new QLocationlModel;
                    item->setIcon(0,QIcon(":/Tools Icons/mesh svg.svg"));

                }
            }

            item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);


            /*
            QTreeWidgetItem * child = new QTreeWidgetItem;

            child->setText(0,QString("child")+QString::number(i));

            child->setIcon(0,QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

            child->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);


            item->addChild(child);

            */

            rootitem->addChild(item);

        }



        addTopLevelItem(rootitem);

        rootitem->setExpanded(true);
    }

    void addModelItem(QBaseModel * model)
    {

    }

    void collapseExpandTree()
    {
        expandAll();
    }

    void pitemchange()
    {
        qDebug()<<"Current Item:"<<currentItem()->text(0);

    }


    bool itemInTree(QTreeWidgetItem *root,QString name)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                //qDebug()<<"Item name:"<<item->text(0);

                if(name.startsWith(item->text(0)))
                {
                    return true;
                }

                itemInTree(item,name);
            }
        }

        return false;
    }

    void fullyCollapse(QTreeWidgetItem *item)
    {
        for (int i = 0; i < item->childCount(); ++i)
        {
           item->child(i)->setExpanded(0);
        }
    }

    void fullyExpand(QTreeWidgetItem *item)
    {
        for (int i = 0; i < item->childCount(); ++i)
        {
            item->child(i)->setExpanded(1);
        }
    }

    void rename(QTreeWidgetItem *item, int col)
    {
        item->text(col).toStdString();
    }


    void traverseTree(QTreeWidgetItem *root)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                qDebug()<<"Item name:"<<item->text(0);

                //QRadioButton *r = new QRadioButton();
                //r->setIcon(QIcon(QString("D:/Metropolis/testXML/icon center.svg")));

                //setItemWidget(item,1,new QRadioButton());
                //setItemWidget(item,2,new QRadioButton());
                //setItemWidget(item,3,new QRadioButton());

                traverseTree(item);
            }
        }
    }

    void recursiveHideItems(QTreeWidgetItem * root,bool hide = false)
    {
        if(root)
        {
            for(int i =0;i<root->childCount();i++)
            {
                QTreeWidgetItem *item = root->child(i);

                item->setSelected(hide);

                //recursiveHideItems(item,hide);
            }
        }
    }


    void createGroupItem()
    {
        if(selectedItems()[0]->parent())
        {
            selectedItems()[0]->parent()->removeChild(selectedItems()[0]);
        }

        removeItemWidget(selectedItems()[0],0);

        QTreeWidgetItem * cloneItem = selectedItems()[0]->clone();

        QTreeWidgetItem * group     = new QTreeWidgetItem;

        group->setIcon(0,QIcon(QString("../Tools Icons/mesh location.svg")));
        group->setText(0,QString("group"));
        group->addChild(cloneItem);
        group->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);

        rootitem->addChild(group);

        group->setSelected(true);
    }


    void duplicateAndReparentItem(QPoint pos)
    {
        //duplicate:
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(item && selectItems.size()>0 )
        {
            if(selectItems[0]->parent())
            {
                QTreeWidgetItem * duplicate =  selectItems[0]->clone();

                if(!duplicate->isExpanded())
                    duplicate->setExpanded(true);

                item->addChild(duplicate);
            }

           // qDebug()<<"drop:"<<myItem->text(0);
        }
        else
        {
            if(selectItems.size()>0 && selectItems[0]->parent())
            {
                QTreeWidgetItem *parent = selectItems[0]->parent();

                QTreeWidgetItem * duplicate =  selectItems[0]->clone();

                if(!duplicate->isExpanded())
                    duplicate->setExpanded(true);

                parent->addChild(duplicate);
            }
        }
    }


    void reparentItem(QPoint pos)
    {
        QList<QTreeWidgetItem*> pselectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(pselectItems.size()>0 )
        {
            if(item)
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                item->addChild(clone);
            }
            else
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                rootitem->addChild(clone);
            }
        }



        /*

        QList<QTreeWidgetItem*> pselectItems = selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(pselectItems.size()>0 )
        {
            if(item)
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();



                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                item->addChild(clone);
            }
            else
            {
                QTreeWidgetItem * clone =  pselectItems[0]->clone();

                clone->setExpanded(true);

                removeItemWidget(pselectItems[0],0);

                if(pselectItems[0]->parent())
                {
                    pselectItems[0]->parent()->removeChild(clone);
                }

                rootitem->addChild(clone);
            }
        }

    */

    }

    void reorderItem(QPoint pos)
    {
        QList<QTreeWidgetItem*> selectItems = this->selectedItems();

        QTreeWidgetItem *item = itemAt(pos);

        if(item && selectItems.size()>0 )
        {
            if(item->parent())
            {
                int index = item->parent()->indexOfChild(item);

                item->parent()->insertChild(index,selectItems[0]);
            }



            /*
            if(selectItems[0]->parent())
            {
                QTreeWidgetItem *parent = selectItems[0]->parent();

                parent->removeChild(selectItems[0]);

                item->addChild(selectItems[0]);
            }

           // qDebug()<<"drop:"<<myItem->text(0);

           */
        }

    }


    void copySelection()
    {
        qDebug()<<"copy Selection";
    }

    void pasteSelection()
    {
        qDebug()<<"paste Selection";
    }

    void deleteSelection()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && !selectItems[0]->text(0).startsWith("Root") )
        {
            removeItemWidget(selectItems[0],0);

            delete selectItems[0];
        }

        qDebug()<<"delete Selection";
    }

    void duplicateSelection()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && selectItems[0]->parent())
        {
            QTreeWidgetItem *parent = selectItems[0]->parent();

            //QTreeWidgetItem duplicate = QTreeWidgetItem(*selectItems[0]);


            //QTreeWidgetItem * duplicate = new QTreeWidgetItem;
            //duplicate->setText(0,selectItems[0]->text(0));
            //duplicate->setIcon(0,selectItems[0]->icon(0));
            //duplicate->addChildren(selectItems[0]->);

            QTreeWidgetItem * duplicate =  selectItems[0]->clone();

            if(!duplicate->isExpanded())
                duplicate->setExpanded(true);

            parent->addChild(duplicate);
        }

        qDebug()<<"duplicate Selection";
    }

    void duplicateTree()
    {
        QList<QTreeWidgetItem*> selectItems = selectedItems();

        if(selectItems.size()>0 && selectItems[0]->parent())
        {
            QTreeWidgetItem *parent = selectItems[0]->parent();

            QTreeWidgetItem * duplicate =  selectItems[0]->clone();

            parent->addChild(duplicate);
        }

        qDebug()<<"duplicate Selection";
    }



    void renameSelection()
    {
        qDebug()<<"rename Selection";
    }

    void freezeSelection()
    {
         qDebug()<<"freeze Selection";
    }

    void hideSelection()
    {
         qDebug()<<"hide Selection";
    }

    void updateProperties()
    {

    }


    void changeSceneModelSelection()
    {
        scene->selectionInfo->clearSelection();

        foreach(QBaseModel * model, scene->models)
        {
            foreach(QTreeWidgetItem *singleItem , selectedItems())
            {
                if (singleItem->text(0).startsWith(model->name) == true)
                {
                    scene->selectionInfo->addSelectedModel(model);

                    break;
                }
            }
        }
    }

    void changeSceneModelName()
    {
        QBaseModel * model = scene->selectionInfo->getSelectedModel();

        if(model)
        {
            model->name = selectedItems()[0]->text(0);
        }
    }


    void changeTreeItemSelection()
    {
        QBaseModel * model = scene->selectionInfo->getSelectedModel();

        selectedItems()[0]->setSelected(false);

        QList<QTreeWidgetItem *> sitems = this->findItems(model->name,Qt::MatchStartsWith,0);

        sitems[0]->setSelected(true);
    }
};




/*
class QOutlinerWidget : public QTreeWidget
{
    Q_OBJECT

    QList<QTreeWidgetItem*> itemList;
    QList<QTreeWidgetItem*> allLabels;

public:

    QStringList objs;

    QOutlinerWidget(bool test = false,QWidget * parent = 0): QTreeWidget(parent)
    {
        QFile file(":/icons/glowBlue.stylesheet");

        //QFile file(":/icons/styleMain.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }

        setColumnCount(1);

        setHeaderLabel("Properties Editor");

        verticalScrollBar()->setSingleStep(1);

        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

        //setAlternatingRowColors(true);

        if(test)
        {
            for(int i = 0;i<3;i++)
            {
                QColorEditorWidget * cs  = new QColorEditorWidget;
                cs->setWindowTitle("Color Widget");
                addPanel(cs);

                QGradientRampWidget *ge = new QGradientRampWidget;
                ge->setWindowTitle("Gradient Ramp");
                addPanel(ge);

                QVector3DWidget *k =  new QVector3DWidget;
                k->setWindowTitle("Vector 3D");
                addPanel(k);

                QVector2DWidget *m =  new QVector2DWidget;
                m->setWindowTitle("Vector 2D");
                addPanel(m);

                QRampCurveWidget *curv =  new QRampCurveWidget;
                curv->setWindowTitle("QRamp Curve Widget");
                addPanel(curv);
            }
        }
    }

    QOutlinerWidget(QWidget *parent) : QTreeWidget(parent)
    {
        setColumnCount(1);
        header()->setVisible(0);
        //setFrameShadow(QFrame::Raised);
        //setItemDelegate(myWin.myFocus);
        setAlternatingRowColors(1);

        setSelectionMode(QAbstractItemView::ExtendedSelection);
        setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed);
        setExpandsOnDoubleClick(0);
        setSortingEnabled(0);
        setDefaultDropAction(Qt::MoveAction);
        setProperty("isOutliner", 1);

        connect(this, SIGNAL(itemChanged()), this, SLOT(changeName()));
        connect(this, SIGNAL(itemSelectionChanged()), this, SLOT(changeSel()));
        connect(this, SIGNAL(itemExpanded()), this, SLOT(fullyExpand()));
        connect(this, SIGNAL(itemCollapsed()), this, SLOT(fullyCollapse()));
        connect(this, SIGNAL(activated()), this, SLOT(disableCuts()));
        connect(this, SIGNAL(itemDoubleClicked()), this, SLOT(disableCuts()));

        //keepSel = lmbTgl = rmbTgl = mmbTgl = ctrlTgl = shiftTgl = false;
        refreshOutliner(1);

        installEventFilter(this);

        QString str = QString("class stores a pointer to a\
        dynamically allocated object deletes \
         upon destruction Managing heap allocated objects\
        manually is hard and error prone with common\
        result that code leaks memory and is hard to maintain.\
        QScopedPointer is a small utility class that heavily\
        simplifies this by assigning stack-based memory ownership\
        to heap allocations, more generally called resource\
        acquisition is initialization(RAII).");


        objs = str.split(" ");
    }


    ~QOutlinerWidget()
    {
        qDeleteAll(itemList);
        qDeleteAll(allLabels);
    }

    void addPanel(QWidget * panel)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem(this);

        item->setText(0, panel->windowTitle());

        QTreeWidgetItem * childItem = new QTreeWidgetItem(item);

        setItemWidget(childItem, 0, panel);

        itemList.append(item);
    }

    void removePanel(QWidget * panel)
    {
        for(int i=0;i<itemList.size();i++)
        {
            QString itemName =  itemList[i]->text(0);

            if(itemName.startsWith(panel->windowTitle()))
            {
                removeItemWidget(itemList[i],0);

                itemList.removeAt(i);

                break;
            }
        }
    }

protected:

    void prepItems(QTreeWidgetItem *item, QString type)
    {
        item->setFont(0, QFont("DejaVu Sans Mono", 10, 75));
        item->setTextAlignment(0, Qt::AlignLeft | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);

        if (!item->data(0, 35).toBool())
        {
            item->setForeground(0, QBrush(Qt::black));
        }

        QPixmap *myPixmap;

        if (type.startsWith("EMPTY") || type.startsWith("FBO") || type.startsWith("TXT"))
        {
            myPixmap = new QPixmap(60, 60);
            myPixmap->fill(Qt::white);
        }

        else if (type.startsWith("CAM"))
        {
            myPixmap = new QPixmap("icons/camIcon.png");
        }

        else if (type.startsWith("LIGHT"))
        {
            myPixmap = new QPixmap("icons/lightIcon.png");
        }

        else if (type.startsWith("GRID" )|| type.startsWith("OBJ"))
        {
            myPixmap = new QPixmap("icons/meshIcon.png");
        }

        QIcon myIcon(*myPixmap);

        item->setIcon(0, myIcon);
    }


    void enterEvent(QEvent *)
    {
        setFocus();
    }

    void leaveEvent(QEvent *)
    {
        //myWin.cutTable->multiCutTgl(1);
    }

    bool eventFilter(QObject *obj, QEvent *e)
    {
        if (e->type() == QEvent::KeyPress)
        {
            QKeyEvent *ke = static_cast<QKeyEvent*>(e);

            if (ke->key() == Qt::Key_Tab)
            {
                QModelIndex currIdx = currentIndex();
                QModelIndex nextIdx;

                if ((unsigned int)currIdx.row() + 1 == outLinerItemCt)
                {
                    nextIdx = model()->index(0, 0);
                }
                else
                {
                    nextIdx = model()->index(currIdx.row() + 1, 0);

                }

                selectionModel()->select(nextIdx, QItemSelectionModel::Select);
                setCurrentIndex(nextIdx);
                setFocus();
                edit(nextIdx);
            }
        }

        return QWidget::eventFilter(obj, e);
    }

    void keyPressEvent(QKeyEvent *e)
    {
        if (e->isAutoRepeat())
            return;



        return QTreeWidget::keyPressEvent(e);
    }

    void keyReleaseEvent(QKeyEvent *e)
    {
        if (e->isAutoRepeat())
            return;


        else if (e->key() == Qt::Key_F)
        {
            //if (altTgl && !ctrlTgl) // alt+F
            {
                QTreeWidgetItem *myItem = selectedItems()[0];

                if (myItem) //if item selected
                    scrollToItem(myItem);
            }
        }

        else if (e->key() == Qt::Key_I)
        {
            //if (myWin.myPaintWin->stackedMain->currentIndex() == 0)
            //    myWin.PaintWinTgl(0, 999);
        }

        else if (e->key() == Qt::Key_K)
        {
            //if (myWin.myPaintWin->stackedMain->currentIndex() == 1)
             //   myWin.PaintWinTgl(0, 999);
        }

        return QTreeWidget::keyReleaseEvent(e);
    }

    void mousePressEvent(QMouseEvent *e)
    {
        if (mmbTgl)
            setDragDropMode(QAbstractItemView::InternalMove);

        else
            setDragDropMode(QAbstractItemView::NoDragDrop);

        return QTreeWidget::mousePressEvent(e);
    }

    void dropEvent(QDropEvent *e) // parentTo (drop) / unparent
    {
        QTreeWidgetItem *myItem = itemAt(e->pos());

        if (myItem)
        {
            QString dragParentTo = myItem->text(0);

            foreach(QString i , objs)
            {
                if (i->selected)
                    i->parentObj(dragParentTo);
            }
        }
        else
        {
            for (auto &i : myWin.allObj)
            {
                if (i->selected)
                    i->parentTo = 0;
            }
        }

        return QTreeWidget::dropEvent(e);
    }

public slots:
    void changeName(QTreeWidgetItem *item, int col)
    {
        if (!ignoreChangeName)
        {
            for (auto &i : myWin.allObj)
            {
                if (i->selected)
                {
                    i->rename(item->text(col).toStdString());

                    if (i->type == "CAMLI")
                    {
                        for (auto &j : myWin.allCamCombo)
                            j->refresh();
                    }
                }
            }

            refreshOutliner(1);
            myWin.attrTable->refreshTable();
        }
    }

    void changeSel()
    {
        if (!keepSel)
        {
            myWin.clearSel();

            for (auto &i : myWin.allObj)
            {
                for (QTreeWidgetItem *singleItem : selectedItems())
                {
                    if (singleItem->text(0).toStdString() == i->name->val_s)
                    {
                        i->selected = true;
                        myWin.selB = i;

                        break;
                    }
                }
            }

            myWin.gizPivAutoShow(); //
            myWin.attrTable->refreshTable();
        }

        myWin.cutTable->multiCutTgl(1);
    }

    void disableCuts()
    {
        myWin.cutTable->multiCutTgl(0);
    }

    void refreshOutliner(bool keep)
    {
        if (keep)
            keepSel = true;

        clear();

        outLinerItemCt = 0;

        for (auto &i : myWin.allObj)
        {
            if (!i->ignoreOutliner)
            {
                auto *outlinerLabel = new QTreeWidgetItem();

                outlinerLabel->setData(0, 32, QString::fromStdString(i->name->val_s));

                if (i->parentTo == 0) outlinerLabel->setData(0, 33, 0);
                else outlinerLabel->setData(0, 33, QString::fromStdString(i->parentTo->name->val_s)); //parentTo

                outlinerLabel->setData(0, 34, i->expand);
                outlinerLabel->setData(0, 35, i->v->val_b);
                outlinerLabel->setData(0, 36, QString::fromStdString(i->type));

                outlinerLabel->setText(0, QString::fromStdString(i->name->val_s));

                auto myType = i->type;

                if (myType == "CAMLI")
                {
                    if (i->camLiTypeGet("cam"))
                        myType = "CAM";

                    else
                        myType = "LIGHT";
                }

                prepItems(outlinerLabel, myType);
                allLabels.push_back(outlinerLabel);
            }
        }

        outLinerItemCt = (unsigned int)allLabels.size();

        for (auto &i : allLabels)
        {
            if (i->data(0, 33) == 0)
                addTopLevelItem(i); //

            else
            {
                for (auto &j : allLabels)
                {
                    if (j->text(0) == i->data(0, 33).toString())
                        j->addChild(i); //
                }
            }

            if (i->data(0, 34) == 1)
                i->setExpanded(1);

            for (auto &j : myWin.allObj) // WRONG RESULTING COLOR .... GIVES SAME COL FOR HIDDEN / VIZ OBJECTS
            {
                if (j->selected && i->data(0, 32).toString().toStdString() == j->name->val_s)
                    i->setSelected(1);
            }


        }

        allLabels.clear();
        keepSel = false;
    }

    void fullyCollapse(QTreeWidgetItem *item)
    {
        if (shiftTgl)
        {
            for (int i = 0; i < item->childCount(); ++i)
            {
                item->child(i)->setExpanded(0);

                for (auto &j : myWin.allObj)
                {
                    if (item->data(0, 32).toString().toStdString() == j->name->val_s)
                        j->expand = false;

                    if (item->child(i)->data(0, 32).toString().toStdString() == j->name->val_s)
                        j->expand = false;
                }
            }
        }

        else
        {
            for (auto &i : myWin.allObj)
            {
                if (item->data(0, 32).toString().toStdString() == i->name->val_s)
                    i->expand = false;
            }
        }
    }

    void fullyExpand(QTreeWidgetItem *item)
    {
        if (shiftTgl)
        {
            for (int i = 0; i < item->childCount(); ++i)
            {
                item->child(i)->setExpanded(1);

                for (auto &j : myWin.allObj)
                {
                    if (item->data(0, 32).toString().toStdString() == j->name->val_s)
                        j->expand = true;

                    else if (item->child(i)->data(0, 32).toString().toStdString() == j->name->val_s)
                        j->expand = true;
                }
            }
        }

        else
        {
            for (auto &j : myWin.allObj)
            {
                if (item->data(0, 32).toString().toStdString() == j->name->val_s)
                    j->expand = true;
            }
        }
    }
};

*/





#endif // SCENE_HPP

